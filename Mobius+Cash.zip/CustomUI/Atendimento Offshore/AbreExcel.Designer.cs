﻿namespace Mobios
{
    partial class AbreExcel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Abre_Excel = new System.Windows.Forms.Button();
            this.dataGridView_Excel = new System.Windows.Forms.DataGridView();
            this.comboBox_planilhas = new System.Windows.Forms.ComboBox();
            this.textBox_caminhoExcel = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox_range = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Excel)).BeginInit();
            this.SuspendLayout();
            // 
            // Abre_Excel
            // 
            this.Abre_Excel.Location = new System.Drawing.Point(12, 6);
            this.Abre_Excel.Name = "Abre_Excel";
            this.Abre_Excel.Size = new System.Drawing.Size(127, 23);
            this.Abre_Excel.TabIndex = 0;
            this.Abre_Excel.Text = "Selecionar Excel";
            this.Abre_Excel.UseVisualStyleBackColor = true;
            this.Abre_Excel.Click += new System.EventHandler(this.Abre_Excel_Click);
            // 
            // dataGridView_Excel
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_Excel.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_Excel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_Excel.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_Excel.Location = new System.Drawing.Point(12, 88);
            this.dataGridView_Excel.Name = "dataGridView_Excel";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_Excel.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView_Excel.Size = new System.Drawing.Size(754, 346);
            this.dataGridView_Excel.TabIndex = 1;
            // 
            // comboBox_planilhas
            // 
            this.comboBox_planilhas.FormattingEnabled = true;
            this.comboBox_planilhas.Location = new System.Drawing.Point(114, 59);
            this.comboBox_planilhas.Name = "comboBox_planilhas";
            this.comboBox_planilhas.Size = new System.Drawing.Size(142, 21);
            this.comboBox_planilhas.TabIndex = 2;
            this.comboBox_planilhas.SelectedIndexChanged += new System.EventHandler(this.comboBox_planilhas_SelectedIndexChanged);
            // 
            // textBox_caminhoExcel
            // 
            this.textBox_caminhoExcel.Enabled = false;
            this.textBox_caminhoExcel.Location = new System.Drawing.Point(114, 35);
            this.textBox_caminhoExcel.Name = "textBox_caminhoExcel";
            this.textBox_caminhoExcel.Size = new System.Drawing.Size(652, 20);
            this.textBox_caminhoExcel.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Arquivo Excolhido";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Escolha a Planilha";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(305, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox_range
            // 
            this.textBox_range.Location = new System.Drawing.Point(366, 61);
            this.textBox_range.Name = "textBox_range";
            this.textBox_range.Size = new System.Drawing.Size(100, 20);
            this.textBox_range.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(266, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Escolha a Planilha";
            // 
            // AbreExcel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(778, 446);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox_range);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_caminhoExcel);
            this.Controls.Add(this.comboBox_planilhas);
            this.Controls.Add(this.dataGridView_Excel);
            this.Controls.Add(this.Abre_Excel);
            this.Name = "AbreExcel";
            this.Text = "AbreExcel";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Excel)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Abre_Excel;
        private System.Windows.Forms.DataGridView dataGridView_Excel;
        private System.Windows.Forms.ComboBox comboBox_planilhas;
        private System.Windows.Forms.TextBox textBox_caminhoExcel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox_range;
        private System.Windows.Forms.Label label3;
    }
}