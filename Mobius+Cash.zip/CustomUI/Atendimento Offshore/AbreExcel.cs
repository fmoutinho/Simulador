﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;





namespace Mobios
{
    public partial class AbreExcel : Form
    {

        string caminhoExcel = "";
        string planilha = "";
        bool BuscaPlanilha = false;


        public AbreExcel()
        {
            InitializeComponent();
        }

       
        private void Abre_Excel_Click(object sender, EventArgs e)
        {
            OpenFileDialog vAbreArq = new OpenFileDialog();
            vAbreArq.Filter = "Microsoft Excel (*.xlsx)|*.xlsx|Microsoft Excel (*.xls) (*.xls)|*.xls";
            vAbreArq.Title = "Selecione o Arquivo Excel";
            
            if (vAbreArq.ShowDialog() == DialogResult.OK)
            {
                caminhoExcel = vAbreArq.FileName;
                string strConexao = string.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"", caminhoExcel);
                OleDbConnection conn = new OleDbConnection(strConexao);
                conn.Open();

                DataTable dt = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

                DataSet output = new DataSet();
                foreach (DataRow row in dt.Rows)
                {
                    // obtem o noma da planilha corrente
                    //string sheet = row["TABLE_NAME"].ToString();
                    // obtem todos as linhas da planilha corrente
                    //OleDbCommand cmd = new OleDbCommand("SELECT * FROM [" + sheet + "]", conn);
                    //cmd.CommandType = CommandType.Text;
                    // copia os dados da planilha para o datatable
                    //DataTable outputTable = new DataTable(sheet);
                    //output.Tables.Add(outputTable);
                    //new OleDbDataAdapter(cmd).Fill(outputTable);
                }
                
                if (dt!=null) {
                    BuscaPlanilha = false;
                    comboBox_planilhas.DataSource = dt;
                    comboBox_planilhas.DisplayMember = "TABLE_NAME";
                    comboBox_planilhas.ValueMember = "TABLE_NAME";
                    BuscaPlanilha = true;
                }
                else
                {
                    comboBox_planilhas.Items.Clear();
                }


                textBox_caminhoExcel.Text = caminhoExcel;
                conn.Close();


                /*DataSet ds = new DataSet();
                OleDbConnection conexao = new OleDbConnection("Microsoft.ACE.OLEDB.12.0;" +
                "Data Source=" + vAbreArq.FileName + ";" +
                "Extended Properties=Excel 12.0;");
                OleDbDataAdapter da = new OleDbDataAdapter("Select * From [Plan1$]", conexao);
                da.Fill(ds);
                dataGridView_Excel.DataSource = ds.Tables[0];
                dataGridView_Excel.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCellsExceptHeader;
                conexao.Close();*/
            }



        }

        private void comboBox_planilhas_SelectedIndexChanged(object sender, EventArgs e)
        {
           

            if (BuscaPlanilha) {
                
                string sheet = comboBox_planilhas.SelectedValue.ToString();

                //string sheet = "[NOME_PLANILHA]$"// ( Colocar sempre o $ depois )
               // string caminhoExcel = "[CAMINHO EXCEL]"
                string strConexao = string.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"", caminhoExcel);
                OleDbConnection conn = new OleDbConnection(strConexao);
                conn.Open();
                
                DataSet ds = new DataSet();
                //sheet = sheet.Substring(0, sheet.Length- 1);
                OleDbDataAdapter da = new OleDbDataAdapter("Select * From [" + sheet + "]", conn);
                da.Fill(ds);
                //dataGridView_Excel.DataSource = ds.Tables[0];
                SharedData.BulkExportToAccess(ds.Tables[0], "D:\\Users\\gtcampos\\Desktop\\BaseColeta.accdb", "temp");
                //SharedData.BulkExportToAccess(ds.Tables[0], "\\\\bbaprod3\\Projetos e Processos\\Inteligencia Operacional\\3.Coordenação - GCA\\1.Automação de Processos\\8.Projetos\\0604. Coff (Reorg) - Workflow de Contratação Cambio e off shore\\9. Fonte\\___SistemaMobios\\BD2\\BaseColeta\\BaseColeta.accdb", "temp");
            
                conn.Close();        
            }

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sheet = comboBox_planilhas.SelectedValue.ToString();
            sheet = sheet.Substring(0, sheet.Length- 1);
            DataTable dt = new DataTable();
            string myrange = textBox_range.Text;
            dt = SharedData.ReadTableFromExcelRange(caminhoExcel, sheet, myrange);
            dataGridView_Excel.DataSource = null;
            dataGridView_Excel.DataSource = dt;

            //SharedData.BulkExportToAccess(dt, "\\\\bbaprod3\\Projetos e Processos\\Inteligencia Operacional\\3.Coordenação - GCA\\1.Automação de Processos\\8.Projetos\0604. Coff (Reorg) - Workflow de Contratação Cambio e off shore\\9. Fonte\\___SistemaMobios\\BD2\\BaseColeta\\BaseColeta.accdb", "Coleta_ListaEndereco");
            
            SharedData.BulkExportToAccess(dt, "D:\\Users\\gtcampos\\Desktop\\BaseColeta.accdb", "temp");
        }
    }
}
