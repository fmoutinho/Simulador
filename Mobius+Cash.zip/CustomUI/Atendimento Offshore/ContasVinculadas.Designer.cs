﻿namespace Mobios
{
    partial class ContasVinculadas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dgvContVinc = new System.Windows.Forms.DataGridView();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.txtNomeCliente = new System.Windows.Forms.TextBox();
            this.txtCNPJ = new System.Windows.Forms.MaskedTextBox();
            this.lblCNPJ = new System.Windows.Forms.Label();
            this.lblNomeCliente = new System.Windows.Forms.Label();
            this.btnPesquisar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SharePoint = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.IdConta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Agencia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Conta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AgVinc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContaVinc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NomeGarantidor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CNPJ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Valor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Porcentagem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tipo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Bem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Natureza = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Data_Emissao = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContVinc)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.dgvContVinc);
            this.groupBox2.Location = new System.Drawing.Point(40, 81);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1210, 232);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Contas Vinculadas";
            // 
            // dgvContVinc
            // 
            this.dgvContVinc.AllowUserToAddRows = false;
            this.dgvContVinc.AllowUserToDeleteRows = false;
            this.dgvContVinc.BackgroundColor = System.Drawing.Color.White;
            this.dgvContVinc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContVinc.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SharePoint,
            this.IdConta,
            this.Agencia,
            this.Conta,
            this.AgVinc,
            this.ContaVinc,
            this.NomeGarantidor,
            this.CNPJ,
            this.Valor,
            this.Porcentagem,
            this.Tipo,
            this.Bem,
            this.Natureza,
            this.Data_Emissao});
            this.dgvContVinc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvContVinc.EnableHeadersVisualStyles = false;
            this.dgvContVinc.Location = new System.Drawing.Point(3, 16);
            this.dgvContVinc.Name = "dgvContVinc";
            this.dgvContVinc.RowHeadersVisible = false;
            this.dgvContVinc.Size = new System.Drawing.Size(1204, 213);
            this.dgvContVinc.TabIndex = 0;
            this.dgvContVinc.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvContVinc_CellContentClick);
            // 
            // btnSalvar
            // 
            this.btnSalvar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSalvar.BackColor = System.Drawing.Color.White;
            this.btnSalvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvar.Location = new System.Drawing.Point(1120, 338);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(95, 23);
            this.btnSalvar.TabIndex = 6;
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.UseVisualStyleBackColor = false;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // txtNomeCliente
            // 
            this.txtNomeCliente.BackColor = System.Drawing.SystemColors.Menu;
            this.txtNomeCliente.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNomeCliente.Enabled = false;
            this.txtNomeCliente.Location = new System.Drawing.Point(131, 12);
            this.txtNomeCliente.Name = "txtNomeCliente";
            this.txtNomeCliente.Size = new System.Drawing.Size(178, 13);
            this.txtNomeCliente.TabIndex = 28;
            // 
            // txtCNPJ
            // 
            this.txtCNPJ.BackColor = System.Drawing.SystemColors.Menu;
            this.txtCNPJ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCNPJ.Enabled = false;
            this.txtCNPJ.Location = new System.Drawing.Point(131, 41);
            this.txtCNPJ.Mask = "00.000.000/0000-00";
            this.txtCNPJ.Name = "txtCNPJ";
            this.txtCNPJ.Size = new System.Drawing.Size(109, 13);
            this.txtCNPJ.TabIndex = 29;
            // 
            // lblCNPJ
            // 
            this.lblCNPJ.AutoSize = true;
            this.lblCNPJ.Location = new System.Drawing.Point(91, 41);
            this.lblCNPJ.Name = "lblCNPJ";
            this.lblCNPJ.Size = new System.Drawing.Size(34, 13);
            this.lblCNPJ.TabIndex = 30;
            this.lblCNPJ.Text = "CNPJ";
            // 
            // lblNomeCliente
            // 
            this.lblNomeCliente.AutoSize = true;
            this.lblNomeCliente.Location = new System.Drawing.Point(55, 12);
            this.lblNomeCliente.Name = "lblNomeCliente";
            this.lblNomeCliente.Size = new System.Drawing.Size(70, 13);
            this.lblNomeCliente.TabIndex = 31;
            this.lblNomeCliente.Text = "Nome Cliente";
            // 
            // btnPesquisar
            // 
            this.btnPesquisar.BackColor = System.Drawing.Color.White;
            this.btnPesquisar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPesquisar.Location = new System.Drawing.Point(851, 338);
            this.btnPesquisar.Name = "btnPesquisar";
            this.btnPesquisar.Size = new System.Drawing.Size(92, 23);
            this.btnPesquisar.TabIndex = 5;
            this.btnPesquisar.Text = "Pesquisar";
            this.btnPesquisar.UseVisualStyleBackColor = false;
            this.btnPesquisar.Visible = false;
            this.btnPesquisar.Click += new System.EventHandler(this.btnPesquisar_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(1008, 338);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 23);
            this.button1.TabIndex = 32;
            this.button1.Text = "Adicionar Registro";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // SharePoint
            // 
            this.SharePoint.DataPropertyName = "SharePoint";
            this.SharePoint.HeaderText = "SharePoint";
            this.SharePoint.Items.AddRange(new object[] {
            "",
            "Garantias",
            "Contratos Internacionais",
            "Hipoteca",
            "N/A"});
            this.SharePoint.Name = "SharePoint";
            this.SharePoint.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.SharePoint.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // IdConta
            // 
            this.IdConta.DataPropertyName = "IdContaVinculada";
            this.IdConta.HeaderText = "IdConta";
            this.IdConta.Name = "IdConta";
            this.IdConta.ReadOnly = true;
            this.IdConta.Visible = false;
            // 
            // Agencia
            // 
            this.Agencia.DataPropertyName = "Agencia";
            this.Agencia.HeaderText = "Agencia";
            this.Agencia.MaxInputLength = 4;
            this.Agencia.Name = "Agencia";
            this.Agencia.Width = 50;
            // 
            // Conta
            // 
            this.Conta.DataPropertyName = "Conta";
            dataGridViewCellStyle1.Format = "00000-0";
            dataGridViewCellStyle1.NullValue = null;
            this.Conta.DefaultCellStyle = dataGridViewCellStyle1;
            this.Conta.HeaderText = "Conta";
            this.Conta.MaxInputLength = 6;
            this.Conta.Name = "Conta";
            // 
            // AgVinc
            // 
            this.AgVinc.DataPropertyName = "AgVinc";
            this.AgVinc.HeaderText = "Ag Vinc";
            this.AgVinc.MaxInputLength = 4;
            this.AgVinc.Name = "AgVinc";
            // 
            // ContaVinc
            // 
            this.ContaVinc.DataPropertyName = "ContaVinc";
            this.ContaVinc.HeaderText = "Conta Vinc";
            this.ContaVinc.MaxInputLength = 6;
            this.ContaVinc.Name = "ContaVinc";
            // 
            // NomeGarantidor
            // 
            this.NomeGarantidor.DataPropertyName = "NomeGarantidor";
            this.NomeGarantidor.HeaderText = "Garantidor/Avalista";
            this.NomeGarantidor.Name = "NomeGarantidor";
            // 
            // CNPJ
            // 
            this.CNPJ.DataPropertyName = "CNPJ";
            this.CNPJ.HeaderText = "CNPJ";
            this.CNPJ.Name = "CNPJ";
            // 
            // Valor
            // 
            this.Valor.DataPropertyName = "Valor";
            this.Valor.HeaderText = "Valor";
            this.Valor.Name = "Valor";
            this.Valor.ReadOnly = true;
            // 
            // Porcentagem
            // 
            this.Porcentagem.DataPropertyName = "Porcentagem";
            this.Porcentagem.HeaderText = "%";
            this.Porcentagem.Name = "Porcentagem";
            this.Porcentagem.ReadOnly = true;
            // 
            // Tipo
            // 
            this.Tipo.DataPropertyName = "Tipo";
            this.Tipo.HeaderText = "Tipo";
            this.Tipo.Name = "Tipo";
            this.Tipo.ReadOnly = true;
            this.Tipo.Width = 150;
            // 
            // Bem
            // 
            this.Bem.DataPropertyName = "Bem";
            this.Bem.HeaderText = "Bem";
            this.Bem.Name = "Bem";
            this.Bem.ReadOnly = true;
            this.Bem.Width = 150;
            // 
            // Natureza
            // 
            this.Natureza.DataPropertyName = "Natureza";
            this.Natureza.HeaderText = "Natureza";
            this.Natureza.Name = "Natureza";
            this.Natureza.ReadOnly = true;
            this.Natureza.Width = 150;
            // 
            // Data_Emissao
            // 
            this.Data_Emissao.DataPropertyName = "Data_Emissao";
            this.Data_Emissao.HeaderText = "Data Emitido";
            this.Data_Emissao.Name = "Data_Emissao";
            // 
            // ContasVinculadas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1293, 373);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblNomeCliente);
            this.Controls.Add(this.lblCNPJ);
            this.Controls.Add(this.txtCNPJ);
            this.Controls.Add(this.txtNomeCliente);
            this.Controls.Add(this.btnSalvar);
            this.Controls.Add(this.btnPesquisar);
            this.Controls.Add(this.groupBox2);
            this.Name = "ContasVinculadas";
            this.Text = "MOBIOS| Contas Vinculadas";
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvContVinc)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dgvContVinc;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.TextBox txtNomeCliente;
        private System.Windows.Forms.MaskedTextBox txtCNPJ;
        private System.Windows.Forms.Label lblCNPJ;
        private System.Windows.Forms.Label lblNomeCliente;
        private System.Windows.Forms.Button btnPesquisar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridViewComboBoxColumn SharePoint;
        private System.Windows.Forms.DataGridViewTextBoxColumn IdConta;
        private System.Windows.Forms.DataGridViewTextBoxColumn Agencia;
        private System.Windows.Forms.DataGridViewTextBoxColumn Conta;
        private System.Windows.Forms.DataGridViewTextBoxColumn AgVinc;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContaVinc;
        private System.Windows.Forms.DataGridViewTextBoxColumn NomeGarantidor;
        private System.Windows.Forms.DataGridViewTextBoxColumn CNPJ;
        private System.Windows.Forms.DataGridViewTextBoxColumn Valor;
        private System.Windows.Forms.DataGridViewTextBoxColumn Porcentagem;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tipo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Bem;
        private System.Windows.Forms.DataGridViewTextBoxColumn Natureza;
        private System.Windows.Forms.DataGridViewTextBoxColumn Data_Emissao;
    }
}