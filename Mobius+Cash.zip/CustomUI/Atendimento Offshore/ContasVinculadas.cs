﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mobios
{
    public partial class ContasVinculadas : Form
    {

        int _Servico;

        public ContasVinculadas(int ID_Servico, string CNPJ, string NomeCliente)
        {
            _Servico = ID_Servico;
            InitializeComponent();
            this.dgvContVinc.AutoGenerateColumns = false;
            this.txtCNPJ.Text = CNPJ;
            this.txtNomeCliente.Text = NomeCliente;
            BindContasVinculadas(_Servico);
        }

        private void BindContasVinculadas(int ID_Servico)
        {
            //int ID_Responsavel = Convert.ToInt32(this.cboAnalista.SelectedValue.ToString());
            this.dgvContVinc.DataSource = DataAccess.BuscarContasVinculadas(ID_Servico);
            Application.DoEvents();
            this.btnPesquisar_Click(null, null);

        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in this.dgvContVinc.Rows)
            {
                string sharepoint = "";
                if (row.Cells["SharePoint"].Value != null)
                    sharepoint = row.Cells["SharePoint"].Value.ToString();
                DataAccess.UpdateContasVinculadas(_Servico, row.Cells["Tipo"].Value.ToString(), row.Cells["Bem"].Value.ToString(), row.Cells["Natureza"].Value.ToString(), row.Cells["Agencia"].Value.ToString(), row.Cells["Conta"].Value.ToString(), row.Cells["AgVinc"].Value.ToString(), row.Cells["ContaVinc"].Value.ToString(), row.Cells["CNPJ"].Value.ToString(), sharepoint, row.Cells["IdConta"].Value.ToString());
            }
            this.dgvContVinc.DataSource = DataAccess.BuscarContasVinculadas(_Servico);
            
            DataAccess.DeleteContasVinculadas(_Servico);
            this.dgvContVinc.DataSource = DataAccess.BuscarContasVinculadas(_Servico);

            Application.DoEvents();
            MessageBox.Show("Contas salvas com sucesso.");
            this.Close();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            List<ContasVinculadasGarantias> ContasLocalizadas = new List<ContasVinculadasGarantias>();
            ContasLocalizadas = DataAccess.PesquisarContasVinculadas();

            if (ContasLocalizadas.Count() > 0)
            {
                foreach (DataGridViewRow row in this.dgvContVinc.Rows)
                {
                    List<ContasVinculadasGarantias> GarantiasLocalizadas = ContasLocalizadas.Where(n => n.Bem == row.Cells["Bem"].Value.ToString() && n.Tipo == row.Cells["Tipo"].Value.ToString() && n.Natureza == row.Cells["Natureza"].Value.ToString() && n.CNPJ == row.Cells["CNPJ"].Value.ToString()).ToList();
                    if (GarantiasLocalizadas.Count() > 0)
                    {
                        foreach (ContasVinculadasGarantias Garantia in GarantiasLocalizadas)
                        {
                            if ((row.Cells["Agencia"].Value == null | row.Cells["Agencia"].Value.ToString() == "") && (row.Cells["Conta"].Value == null | row.Cells["Conta"].Value.ToString() == "") && (row.Cells["AgVinc"].Value == null | row.Cells["AgVinc"].Value.ToString() == "") && (row.Cells["ContaVinc"].Value == null | row.Cells["ContaVinc"].Value.ToString() == ""))
                            {
                                row.Cells["Agencia"].Value = Garantia.Agencia;
                                row.Cells["Conta"].Value = Garantia.Conta;
                                row.Cells["AgVinc"].Value = Garantia.AgVinc;
                                row.Cells["ContaVinc"].Value = Garantia.ContaVinc;
                            }
                        }
                    }
                }
            }

            DataAccess.DeleteContasVinculadas(_Servico);
            this.dgvContVinc.DataSource = DataAccess.BuscarContasVinculadas(_Servico);

            foreach (DataGridViewRow row in this.dgvContVinc.Rows)
            {
                string sharepoint = "";
                if (row.Cells["SharePoint"].Value != null)
                    sharepoint = row.Cells["SharePoint"].Value.ToString();

                Application.DoEvents();
                DataAccess.UpdateContasVinculadas(_Servico, row.Cells["Tipo"].Value.ToString(), row.Cells["Bem"].Value.ToString(), row.Cells["Natureza"].Value.ToString(), row.Cells["Agencia"].Value.ToString(), row.Cells["Conta"].Value.ToString(), row.Cells["AgVinc"].Value.ToString(), row.Cells["ContaVinc"].Value.ToString(), row.Cells["CNPJ"].Value.ToString(), sharepoint, row.Cells["IdConta"].Value.ToString());
            }
        }

        private void dgvContVinc_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnPesquisar_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in this.dgvContVinc.Rows)
            {
                string sharepoint = "";
                if (row.Cells["SharePoint"].Value != null)
                    sharepoint = row.Cells["SharePoint"].Value.ToString();
                Application.DoEvents();
                DataAccess.UpdateContasVinculadas(_Servico, row.Cells["Tipo"].Value.ToString(), row.Cells["Bem"].Value.ToString(), row.Cells["Natureza"].Value.ToString(), row.Cells["Agencia"].Value.ToString(), row.Cells["Conta"].Value.ToString(), row.Cells["AgVinc"].Value.ToString(), row.Cells["ContaVinc"].Value.ToString(), row.Cells["CNPJ"].Value.ToString(), sharepoint, row.Cells["IdConta"].Value.ToString());
            }

            DataAccess.UpdateContasVinculadas(_Servico, "---", "---", "---", "", "", "", "", "---", "", "", true);
            this.dgvContVinc.DataSource = DataAccess.BuscarContasVinculadas(_Servico);
            Application.DoEvents();
        }
    }
}
