﻿namespace Mobios
{
    partial class IntegracaoExcel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(IntegracaoExcel));
            this.lblPlanilha = new System.Windows.Forms.Label();
            this.txtPath = new System.Windows.Forms.TextBox();
            this.btnSelecionar = new System.Windows.Forms.Button();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.lblNumBoletoCompra = new System.Windows.Forms.Label();
            this.txtNumBoletoCompra = new System.Windows.Forms.TextBox();
            this.btnSalvarIntExcel = new System.Windows.Forms.Button();
            this.txtNumBoletoVenda = new System.Windows.Forms.TextBox();
            this.lblNumBoletoVenda = new System.Windows.Forms.Label();
            this.txtNumBoleto = new System.Windows.Forms.TextBox();
            this.lblNumBoleto = new System.Windows.Forms.Label();
            this.txtNumWAO = new System.Windows.Forms.TextBox();
            this.lblNumWAO = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblPlanilha
            // 
            this.lblPlanilha.AutoSize = true;
            this.lblPlanilha.Location = new System.Drawing.Point(8, 24);
            this.lblPlanilha.Name = "lblPlanilha";
            this.lblPlanilha.Size = new System.Drawing.Size(50, 13);
            this.lblPlanilha.TabIndex = 0;
            this.lblPlanilha.Text = "Planilha: ";
            // 
            // txtPath
            // 
            this.txtPath.Location = new System.Drawing.Point(55, 21);
            this.txtPath.Name = "txtPath";
            this.txtPath.Size = new System.Drawing.Size(385, 20);
            this.txtPath.TabIndex = 1;
            // 
            // btnSelecionar
            // 
            this.btnSelecionar.AutoSize = true;
            this.btnSelecionar.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnSelecionar.BackColor = System.Drawing.SystemColors.Window;
            this.btnSelecionar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelecionar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnSelecionar.Image = ((System.Drawing.Image)(resources.GetObject("btnSelecionar.Image")));
            this.btnSelecionar.Location = new System.Drawing.Point(449, 15);
            this.btnSelecionar.Name = "btnSelecionar";
            this.btnSelecionar.Size = new System.Drawing.Size(31, 31);
            this.btnSelecionar.TabIndex = 2;
            this.btnSelecionar.UseVisualStyleBackColor = false;
            this.btnSelecionar.Click += new System.EventHandler(this.btnSelecionar_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog";
            // 
            // lblNumBoletoCompra
            // 
            this.lblNumBoletoCompra.AutoSize = true;
            this.lblNumBoletoCompra.Location = new System.Drawing.Point(9, 50);
            this.lblNumBoletoCompra.Name = "lblNumBoletoCompra";
            this.lblNumBoletoCompra.Size = new System.Drawing.Size(70, 13);
            this.lblNumBoletoCompra.TabIndex = 3;
            this.lblNumBoletoCompra.Text = "Bol. Compra: ";
            this.lblNumBoletoCompra.Visible = false;
            // 
            // txtNumBoletoCompra
            // 
            this.txtNumBoletoCompra.Location = new System.Drawing.Point(74, 47);
            this.txtNumBoletoCompra.Name = "txtNumBoletoCompra";
            this.txtNumBoletoCompra.Size = new System.Drawing.Size(119, 20);
            this.txtNumBoletoCompra.TabIndex = 4;
            this.txtNumBoletoCompra.Visible = false;
            // 
            // btnSalvarIntExcel
            // 
            this.btnSalvarIntExcel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnSalvarIntExcel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvarIntExcel.Location = new System.Drawing.Point(405, 66);
            this.btnSalvarIntExcel.Name = "btnSalvarIntExcel";
            this.btnSalvarIntExcel.Size = new System.Drawing.Size(75, 23);
            this.btnSalvarIntExcel.TabIndex = 8;
            this.btnSalvarIntExcel.Text = "Salvar";
            this.btnSalvarIntExcel.UseVisualStyleBackColor = false;
            this.btnSalvarIntExcel.Click += new System.EventHandler(this.btnSalvarIntExcel_Click);
            // 
            // txtNumBoletoVenda
            // 
            this.txtNumBoletoVenda.Location = new System.Drawing.Point(270, 47);
            this.txtNumBoletoVenda.Name = "txtNumBoletoVenda";
            this.txtNumBoletoVenda.Size = new System.Drawing.Size(119, 20);
            this.txtNumBoletoVenda.TabIndex = 10;
            this.txtNumBoletoVenda.Visible = false;
            // 
            // lblNumBoletoVenda
            // 
            this.lblNumBoletoVenda.AutoSize = true;
            this.lblNumBoletoVenda.Location = new System.Drawing.Point(205, 50);
            this.lblNumBoletoVenda.Name = "lblNumBoletoVenda";
            this.lblNumBoletoVenda.Size = new System.Drawing.Size(65, 13);
            this.lblNumBoletoVenda.TabIndex = 9;
            this.lblNumBoletoVenda.Text = "Bol. Venda: ";
            this.lblNumBoletoVenda.Visible = false;
            // 
            // txtNumBoleto
            // 
            this.txtNumBoleto.Location = new System.Drawing.Point(64, 73);
            this.txtNumBoleto.Name = "txtNumBoleto";
            this.txtNumBoleto.Size = new System.Drawing.Size(119, 20);
            this.txtNumBoleto.TabIndex = 12;
            this.txtNumBoleto.Visible = false;
            // 
            // lblNumBoleto
            // 
            this.lblNumBoleto.AutoSize = true;
            this.lblNumBoleto.Location = new System.Drawing.Point(9, 76);
            this.lblNumBoleto.Name = "lblNumBoleto";
            this.lblNumBoleto.Size = new System.Drawing.Size(60, 13);
            this.lblNumBoleto.TabIndex = 11;
            this.lblNumBoleto.Text = "Nr. Boleto: ";
            this.lblNumBoleto.Visible = false;
            // 
            // txtNumWAO
            // 
            this.txtNumWAO.Location = new System.Drawing.Point(244, 73);
            this.txtNumWAO.Name = "txtNumWAO";
            this.txtNumWAO.Size = new System.Drawing.Size(119, 20);
            this.txtNumWAO.TabIndex = 14;
            this.txtNumWAO.Visible = false;
            // 
            // lblNumWAO
            // 
            this.lblNumWAO.AutoSize = true;
            this.lblNumWAO.Location = new System.Drawing.Point(197, 76);
            this.lblNumWAO.Name = "lblNumWAO";
            this.lblNumWAO.Size = new System.Drawing.Size(53, 13);
            this.lblNumWAO.TabIndex = 13;
            this.lblNumWAO.Text = "Nr WAO: ";
            this.lblNumWAO.Visible = false;
            // 
            // IntegracaoExcel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(492, 106);
            this.Controls.Add(this.txtNumWAO);
            this.Controls.Add(this.lblNumWAO);
            this.Controls.Add(this.txtNumBoleto);
            this.Controls.Add(this.lblNumBoleto);
            this.Controls.Add(this.txtNumBoletoVenda);
            this.Controls.Add(this.lblNumBoletoVenda);
            this.Controls.Add(this.btnSalvarIntExcel);
            this.Controls.Add(this.txtNumBoletoCompra);
            this.Controls.Add(this.lblNumBoletoCompra);
            this.Controls.Add(this.btnSelecionar);
            this.Controls.Add(this.txtPath);
            this.Controls.Add(this.lblPlanilha);
            this.Name = "IntegracaoExcel";
            this.Text = "MOBIOS| Integração via Excel";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPlanilha;
        private System.Windows.Forms.TextBox txtPath;
        private System.Windows.Forms.Button btnSelecionar;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.Label lblNumBoletoCompra;
        private System.Windows.Forms.TextBox txtNumBoletoCompra;
        private System.Windows.Forms.Button btnSalvarIntExcel;
        private System.Windows.Forms.TextBox txtNumBoletoVenda;
        private System.Windows.Forms.Label lblNumBoletoVenda;
        private System.Windows.Forms.TextBox txtNumBoleto;
        private System.Windows.Forms.Label lblNumBoleto;
        private System.Windows.Forms.TextBox txtNumWAO;
        private System.Windows.Forms.Label lblNumWAO;
    }
}