﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Configuration;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace Mobios
{
    public partial class IntegracaoExcel : Form
    {
        //Declara variaveis à serem utilizadas no Objeto Excel
        Excel.Application xlApp = null;
        Excel.Workbook xlWorkBook = null;
        Excel.Worksheet xlWorkSheet = null;
        Excel.Worksheet xlWorkSheetList = null;
        int? idServico;
        int? idEtapa;
        string ExcelFileName;
        //Variavel para armazenar qual importação que está sendo feita
        string nomeImport;
        //Variavel que direciona o nome da planilha escrita no App.config
        string nomePlan;
        //Variavel para definir qual coluna que está o número do boleto a ser pesquisado
        string columnSearch;
        string[] colunasRetorno;
        string[] retorno;
        string[] nomecampos;
        string[] idcampos;

        List<CamposInfo> listaCampo = new List<CamposInfo>();

        public IntegracaoExcel(int tipoImportacao)
        {
            InitializeComponent();
            txtPath.Enabled = false;
            //idServico = id_Servico;
            //idEtapa = id_Etapa;

            switch (tipoImportacao)
            {
                case 1:
                    {
                        this.Text = "MOBIOS| Integração via Excel - Importação I8.";
                        //Variaveis com a configuração do App.Config
                        nomePlan = "NomePlanilhaI8";
                        columnSearch = "ColunaPlanilhaI8";
                        nomeImport = "I8";
                        //FormatarTela(nomeImport);
                        break;
                    }
                case 2:
                    {
                        this.Text = "MOBIOS| Integração via Excel - Importação WAO.";
                        //Variaveis com a configuração do App.Config
                        nomePlan = "NomePlanilhaWAO";
                        columnSearch = "ColunaPlanilhaWAO";
                        nomeImport = "WAO";
                        //FormatarTela(nomeImport);
                        break;
                    }
                case 3:
                    {
                        this.Text = "MOBIOS| Integração via Excel - Importação SAD.";
                        //Variaveis com a configuração do App.Config
                        nomePlan = "NomePlanilhaSAD";
                        columnSearch = "ColunaPlanilhaSAD";
                        nomeImport = "SAD";
                        //FormatarTela(nomeImport);
                        break;
                    }
                default: { this.Text = "MOBIOS| Integração via Excel - Tipo não definido."; break; }

            }


        }

        private void FormatarTela(string nomeImportacao)
        {
            string msgLog = "Formatando formulário de importação.";
            Log.GravaLog(msgLog);
            switch (nomeImportacao)
            {
                case "I8":
                    {
                        lblNumBoletoCompra.Visible = true;
                        lblNumBoletoVenda.Visible = true;
                        txtNumBoletoCompra.Visible = true;
                        txtNumBoletoVenda.Visible = true;
                        lblNumBoletoCompra.Top = 57;
                        lblNumBoletoCompra.Left = 7;
                        txtNumBoletoCompra.Top = lblNumBoletoCompra.Top - 3;
                        txtNumBoletoCompra.Left = lblNumBoletoCompra.Left + lblNumBoletoCompra.Width + 1;
                        lblNumBoletoVenda.Top = lblNumBoletoCompra.Top;
                        lblNumBoletoVenda.Left = txtNumBoletoCompra.Left + txtNumBoletoCompra.Width + 5;
                        txtNumBoletoVenda.Top = lblNumBoletoVenda.Top - 3;
                        txtNumBoletoVenda.Left = lblNumBoletoVenda.Left + lblNumBoletoVenda.Width + 1;
                        break;
                    }
                case "WAO":
                    {
                        lblNumWAO.Visible = true;
                        txtNumWAO.Visible = true;
                        lblNumWAO.Top = 57;
                        lblNumWAO.Left = 7;
                        txtNumWAO.Top = lblNumBoleto.Top - 3;
                        txtNumWAO.Left = lblNumBoleto.Left + lblNumBoleto.Width + 1;
                        break;
                    }
                case "SAD":
                    {
                        lblNumBoleto.Visible = true;
                        txtNumBoleto.Visible = true;
                        lblNumBoleto.Top = 57;
                        lblNumBoleto.Left = 7;
                        txtNumBoleto.Top = lblNumBoleto.Top - 3;
                        txtNumBoleto.Left = lblNumBoleto.Left + lblNumBoleto.Width + 1;
                        break;
                    }
            }
        }

        private void btnSelecionar_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            //define as propriedades do controle           
            this.openFileDialog.Multiselect = false;
            this.openFileDialog.Title = "Selecionar planilha";
            openFileDialog.InitialDirectory = "\\\\bbaprod3\\bo\\Cambio\\Processamento de Cambio\\Comum\\Indicadores e Controles\\___SistemaMobios\\PlanilhasIntegração"; // pathPlaniha; 
            //
            //filtra para exibir somente arquivos de imagens
            //ofd1.Filter = "Images (*.xls;*.xlsx)|*.xls;*.xlsx|" + "All files (*.*)|*.*";
            openFileDialog.Filter = "Planilha (*.xls;*.xlsx)|*.xls;*.xlsx";
            openFileDialog.CheckFileExists = true;
            openFileDialog.CheckPathExists = true;
            openFileDialog.FilterIndex = 2;
            openFileDialog.RestoreDirectory = true;
            openFileDialog.ReadOnlyChecked = true;
            openFileDialog.ShowReadOnly = false;
            openFileDialog.FileName = "";

            DialogResult dr = this.openFileDialog.ShowDialog();

            if (dr == System.Windows.Forms.DialogResult.OK)
            {
                // Le os arquivos selecionados 
                foreach (String arquivo in openFileDialog.FileNames)
                {
                    //MessageBox.Show(arquivo.Substring(arquivo.LastIndexOf('\\') + 1));
                    txtPath.Text += arquivo;
                    ExcelFileName = openFileDialog.SafeFileName;
                }
            }

            Cursor.Current = Cursors.Default;

            txtNumBoletoCompra.Enabled = true;
        }

        private void btnSalvarIntExcel_Click(object sender, EventArgs e)
        {
                //Declara variavel do tipo Range para retornar o boleto procurado.
                Excel.Range currentFind = null;
                Excel.Range currentFindV = null;
                
                //ABRIR EXCEL E RETORNAR NUMERO
                String FullPath = txtPath.Text;
                xlApp = new Excel.Application();
                //Valida se o arquivo está fechado para evitar erros.
                //if (IsOpened(ExcelFileName))
                //{
                //    MessageBox.Show("O Arquivo " + ExcelFileName + " está aberto. Por favor, feche-o.");
                //}
                //else
                //{
                string msgLog = "Abrindo Excel para buscar número do WAO.";
                Log.GravaLog(msgLog);
                //Abre o WorkBook para buscar o Número do Boleto e retornar a data da boletagem.
                xlWorkBook = xlApp.Workbooks.Open(FullPath, Type.Missing, true);
                    //currentFind = xlWorkSheet.UsedRange.Columns[ConfigurationManager.AppSettings[columnSearch], Type.Missing].Find(txtNumBoletoCompra.Text, Type.Missing, Excel.XlFindLookIn.xlValues, Excel.XlLookAt.xlWhole, Excel.XlSearchOrder.xlByRows, Excel.XlSearchDirection.xlNext, true);
                    switch (nomeImport)
                    {
                        case "I8":
                            {
                                

                                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(ConfigurationManager.AppSettings[nomePlan]);
                                int j = 0;
                                currentFind = xlWorkSheet.UsedRange.Columns[ConfigurationManager.AppSettings[columnSearch], Type.Missing].Find(txtNumBoletoCompra.Text, Type.Missing, Excel.XlFindLookIn.xlValues, Excel.XlLookAt.xlWhole, Excel.XlSearchOrder.xlByRows, Excel.XlSearchDirection.xlNext, true);
                                currentFindV = xlWorkSheet.UsedRange.Columns[ConfigurationManager.AppSettings[columnSearch], Type.Missing].Find(txtNumBoletoVenda.Text, Type.Missing, Excel.XlFindLookIn.xlValues, Excel.XlLookAt.xlWhole, Excel.XlSearchOrder.xlByRows, Excel.XlSearchDirection.xlNext, true);
                                if (currentFind == null)
                                {
                                    MessageBox.Show("Não existe o número do boleto " + txtNumBoletoCompra.Text + " na planilha ou o número do boleto está incorreto!");
                                }
                                else if (currentFindV == null)
                                {
                                    MessageBox.Show("Não existe o número do boleto " + txtNumBoletoVenda.Text + " na planilha ou o número do boleto está incorreto!");
                                }
                                else
                                {
                                    idcampos = new string[Convert.ToInt32(ConfigurationManager.AppSettings["QuantidadeRetornosI8"])];
                                    nomecampos = new string[Convert.ToInt32(ConfigurationManager.AppSettings["QuantidadeRetornosI8"])];
                                    retorno = new string[Convert.ToInt32(ConfigurationManager.AppSettings["QuantidadeRetornosI8"])];
                                    colunasRetorno = ConfigurationManager.AppSettings["ColunasRetornosI8"].Split(';');
                                    for (int i = 0; i < Convert.ToInt32(ConfigurationManager.AppSettings["QuantidadeRetornosI8"]) / 2; i++)
                                    {
                                        string[] campo = ConfigurationManager.AppSettings["CampoI8Compra" + i].Split(';');
                                        idcampos[i] = campo[0].ToString();
                                        nomecampos[i] = campo[1].ToString();
                                        retorno[i] = xlWorkSheet.Range[colunasRetorno[i] + currentFind.Row.ToString()].Value.ToString();
                                        j++;
                                    }
                                    for (int i = 0; i < Convert.ToInt32(ConfigurationManager.AppSettings["QuantidadeRetornosI8"]) / 2; i++)
                                    {
                                        string[] campo = ConfigurationManager.AppSettings["CampoI8Venda" + i].Split(';');
                                        idcampos[j] = campo[0].ToString();
                                        nomecampos[j] = campo[1].ToString();
                                        retorno[j] = xlWorkSheet.Range[colunasRetorno[i] + currentFindV.Row.ToString()].Value.ToString();
                                        j++;
                                    }
                                }

                                break;
                            }
                        case "WAO":
                            {
                                msgLog = "Buscando WAOs na base";
                                Log.GravaLog(msgLog);
                                List<DadosCamposServico> listDC = new List<DadosCamposServico>();
                                listDC = DataAccess.buscarNumsWAO();
                                //Lista de Numeros de WAO encontrados no Access
                                if (listDC.Count > 0)
                                {
                                    for (int iPlan = 1; iPlan < 3; iPlan++)
                                    {
                                        xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(iPlan);

                                        //Para cada WAO irá retornar procurar registros na planilha do EXCEL
                                        foreach (DadosCamposServico dcs in listDC)
                                        {
                                            List<Excel.Range> findList = new List<Excel.Range>();
                                            currentFind = xlWorkSheet.UsedRange.Columns[ConfigurationManager.AppSettings[columnSearch], Type.Missing].Find(dcs.ValorCampo, Type.Missing, Excel.XlFindLookIn.xlValues, Excel.XlLookAt.xlWhole, Excel.XlSearchOrder.xlByRows, Excel.XlSearchDirection.xlNext, true);
                                            if (currentFind == null)
                                            {
                                                continue;
                                            }
                                            do
                                            {
                                                findList.Add(currentFind);
                                                currentFind = xlWorkSheet.UsedRange.Columns[ConfigurationManager.AppSettings[columnSearch], Type.Missing].FindNext(currentFind);
                                            } while (findList[0].Row != currentFind.Row);
                                            //Com a lista de registros encontrados preenchida será feita o insert na tabela tb_0126_DadosServico
                                            if (findList.Count > 0)
                                            {
                                                idcampos = new string[Convert.ToInt32(ConfigurationManager.AppSettings["QuantidadeRetornosWAO"])];
                                                nomecampos = new string[Convert.ToInt32(ConfigurationManager.AppSettings["QuantidadeRetornosWAO"])];
                                                retorno = new string[findList.Count];
                                                for (int i = 0; i < Convert.ToInt32(ConfigurationManager.AppSettings["QuantidadeRetornosWAO"]); i++)
                                                {
                                                    string[] campo = ConfigurationManager.AppSettings["CampoWAO" + i].Split(';');
                                                    idcampos[i] = campo[0].ToString();
                                                    nomecampos[i] = campo[1].ToString();
                                                }
                                                for (int i = 0; i < findList.Count; i++)
                                                {
                                                    try
                                                    {
                                                        retorno[i] = xlWorkSheet.Range[ConfigurationManager.AppSettings["ColunaTarefa"].ToString() + findList[i].Row.ToString()].Value.ToString() + ";" + xlWorkSheet.Range[ConfigurationManager.AppSettings["ColunaRetorno"].ToString() + findList[i].Row.ToString()].Value.ToString();
                                                    }
                                                    catch
                                                    {
                                                        continue;

                                                    }

                                                }
                                                //Para cada retorno encontrado será feito a comparação da Tarefa com o Nome do Campo para ser adicionado corretamente na Tabela.
                                                foreach (string ret in retorno)
                                                {
                                                    if (ret == null)
                                                    {
                                                        continue;
                                                    }
                                                    else
                                                    {
                                                        string[] campoRetorno = ret.Split(';');
                                                        for (int i = 0; i < nomecampos.Length; i++)
                                                        {
                                                            if (campoRetorno[0].ToUpper() == nomecampos[i].ToUpper())
                                                            {
                                                                DataAccess.InserirDadoFluxo(Convert.ToInt32(dcs.ID_Servico), Convert.ToInt32(dcs.ID_Fluxo), Convert.ToInt32(idcampos[i]), nomecampos[i].ToString(), campoRetorno[1].ToString());
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                MessageBox.Show("Não foi encontrado nenhum registro na planilha.");
                                            }
                                        }
                                    }

                                    MessageBox.Show("Impotação feita com sucesso!");
                                    msgLog = "Importação WAO feita com sucesso.";
                                    Log.GravaLog(msgLog);
                                }
                                else
                                {
                                    MessageBox.Show("Não há nenhum WAO para ser pesquisado.");
                                }
                                
                                break;
                            }
                        case "SAD":
                            {
                                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(ConfigurationManager.AppSettings[nomePlan]);
                                currentFind = xlWorkSheet.UsedRange.Columns[ConfigurationManager.AppSettings[columnSearch], Type.Missing].Find(txtNumBoleto.Text, Type.Missing, Excel.XlFindLookIn.xlValues, Excel.XlLookAt.xlWhole, Excel.XlSearchOrder.xlByRows, Excel.XlSearchDirection.xlNext, true);
                                if (currentFind == null)
                                {
                                    MessageBox.Show("Não existe o número do boleto " + txtNumBoletoCompra.Text + " na planilha ou o número do boleto está incorreto!");
                                }
                                else
                                {
                                    idcampos = new string[Convert.ToInt32(ConfigurationManager.AppSettings["QuantidadeRetornosSAD"])];
                                    nomecampos = new string[Convert.ToInt32(ConfigurationManager.AppSettings["QuantidadeRetornosSAD"])];
                                    retorno = new string[Convert.ToInt32(ConfigurationManager.AppSettings["QuantidadeRetornosSAD"])];
                                    colunasRetorno = ConfigurationManager.AppSettings["ColunasRetornosSAD"].Split(';');
                                    for (int i = 0; i < Convert.ToInt32(ConfigurationManager.AppSettings["QuantidadeRetornosSAD"]); i++)
                                    {
                                        string[] campo = ConfigurationManager.AppSettings["CampoSAD" + i].Split(';');
                                        idcampos[i] = campo[0].ToString();
                                        nomecampos[i] = campo[1].ToString();
                                        retorno[i] = xlWorkSheet.Range[colunasRetorno[i] + currentFind.Row.ToString()].Value;
                                    }
                                }
                                break;
                            }
                        default:
                            {
                                break;
                            }
                    }
                    xlWorkBook.Close();
                //}

            //PARTE DO ADRIANO PARA GRAVAR INDICADOR USEI COMO BASE PARA MONTAR O FOR ACIMA.
            //List<CamposInfo> listaCampo = DataAccess.BuscarInfoCampo(idCampo.ToString());
            //if (listaCampo[0].CampoIndicador == true)
            //{
            //    TratarEventos.GravaLinhaEvento(Convert.ToInt32(idServico), listaCampo[0].CampoIndicador.ToString(), listaCampo[0].CampoRegraCalculo, listaCampo[0].CampoItemIndicador, txtDtHrBoletagem.Text, Environment.UserName.ToUpper(), listaCampo[0].CampoEvento, "Importação I8");
            //};
        }

        public static bool IsOpened(string wbook)
        {
            bool isOpened = true;
            Excel.Application exApp;
            exApp = (Excel.Application)System.Runtime.InteropServices.Marshal.GetActiveObject("Excel.Application");
            try
            {
                exApp.Workbooks.get_Item(wbook);
            }
            catch (Exception)
            {
                isOpened = false;
            }
            return isOpened;
        }

        private void txtDtHrBoletagem_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
