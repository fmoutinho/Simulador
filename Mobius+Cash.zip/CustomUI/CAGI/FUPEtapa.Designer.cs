﻿namespace Mobios
{
    partial class FUPEtapa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtbFollowUp = new System.Windows.Forms.RichTextBox();
            this.btnSalvarFollow = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnEncerrarFollow = new System.Windows.Forms.Button();
            this.txtFUPPendencia = new System.Windows.Forms.TextBox();
            this.lblFUPPendencia = new System.Windows.Forms.Label();
            this.lblFUPResponsavel = new System.Windows.Forms.Label();
            this.txtFUPResponsavel = new System.Windows.Forms.TextBox();
            this.lblFUPEmail = new System.Windows.Forms.Label();
            this.txtFUPEmail = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDtCriacao = new System.Windows.Forms.TextBox();
            this.txtDtAtualizacao = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // rtbFollowUp
            // 
            this.rtbFollowUp.Location = new System.Drawing.Point(12, 106);
            this.rtbFollowUp.Name = "rtbFollowUp";
            this.rtbFollowUp.Size = new System.Drawing.Size(364, 130);
            this.rtbFollowUp.TabIndex = 0;
            this.rtbFollowUp.Text = "";
            // 
            // btnSalvarFollow
            // 
            this.btnSalvarFollow.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnSalvarFollow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvarFollow.Location = new System.Drawing.Point(12, 247);
            this.btnSalvarFollow.Name = "btnSalvarFollow";
            this.btnSalvarFollow.Size = new System.Drawing.Size(75, 23);
            this.btnSalvarFollow.TabIndex = 17;
            this.btnSalvarFollow.Text = "Salvar";
            this.btnSalvarFollow.UseVisualStyleBackColor = true;
            this.btnSalvarFollow.Click += new System.EventHandler(this.btnSalvarFollow_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "Descrição:";
            // 
            // btnEncerrarFollow
            // 
            this.btnEncerrarFollow.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnEncerrarFollow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEncerrarFollow.Location = new System.Drawing.Point(93, 247);
            this.btnEncerrarFollow.Name = "btnEncerrarFollow";
            this.btnEncerrarFollow.Size = new System.Drawing.Size(75, 23);
            this.btnEncerrarFollow.TabIndex = 19;
            this.btnEncerrarFollow.Text = "Encerrar";
            this.btnEncerrarFollow.UseVisualStyleBackColor = true;
            this.btnEncerrarFollow.Click += new System.EventHandler(this.btnEncerrarFollow_Click);
            // 
            // txtFUPPendencia
            // 
            this.txtFUPPendencia.Location = new System.Drawing.Point(76, 6);
            this.txtFUPPendencia.Name = "txtFUPPendencia";
            this.txtFUPPendencia.Size = new System.Drawing.Size(300, 20);
            this.txtFUPPendencia.TabIndex = 20;
            // 
            // lblFUPPendencia
            // 
            this.lblFUPPendencia.AutoSize = true;
            this.lblFUPPendencia.Location = new System.Drawing.Point(11, 9);
            this.lblFUPPendencia.Name = "lblFUPPendencia";
            this.lblFUPPendencia.Size = new System.Drawing.Size(61, 13);
            this.lblFUPPendencia.TabIndex = 21;
            this.lblFUPPendencia.Text = "Pendência:";
            // 
            // lblFUPResponsavel
            // 
            this.lblFUPResponsavel.AutoSize = true;
            this.lblFUPResponsavel.Location = new System.Drawing.Point(0, 35);
            this.lblFUPResponsavel.Name = "lblFUPResponsavel";
            this.lblFUPResponsavel.Size = new System.Drawing.Size(72, 13);
            this.lblFUPResponsavel.TabIndex = 23;
            this.lblFUPResponsavel.Text = "Responsável:";
            // 
            // txtFUPResponsavel
            // 
            this.txtFUPResponsavel.Location = new System.Drawing.Point(76, 32);
            this.txtFUPResponsavel.Name = "txtFUPResponsavel";
            this.txtFUPResponsavel.Size = new System.Drawing.Size(300, 20);
            this.txtFUPResponsavel.TabIndex = 22;
            // 
            // lblFUPEmail
            // 
            this.lblFUPEmail.AutoSize = true;
            this.lblFUPEmail.Location = new System.Drawing.Point(34, 61);
            this.lblFUPEmail.Name = "lblFUPEmail";
            this.lblFUPEmail.Size = new System.Drawing.Size(38, 13);
            this.lblFUPEmail.TabIndex = 24;
            this.lblFUPEmail.Text = "E-mail:";
            // 
            // txtFUPEmail
            // 
            this.txtFUPEmail.Location = new System.Drawing.Point(76, 58);
            this.txtFUPEmail.Name = "txtFUPEmail";
            this.txtFUPEmail.Size = new System.Drawing.Size(300, 20);
            this.txtFUPEmail.TabIndex = 25;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(234, 244);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 26;
            this.label2.Text = "Data Criação:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(183, 262);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 13);
            this.label3.TabIndex = 27;
            this.label3.Text = "Data Última Atualização:";
            // 
            // txtDtCriacao
            // 
            this.txtDtCriacao.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDtCriacao.Enabled = false;
            this.txtDtCriacao.Location = new System.Drawing.Point(304, 244);
            this.txtDtCriacao.Name = "txtDtCriacao";
            this.txtDtCriacao.Size = new System.Drawing.Size(72, 13);
            this.txtDtCriacao.TabIndex = 28;
            this.txtDtCriacao.Text = "##/##/####";
            // 
            // txtDtAtualizacao
            // 
            this.txtDtAtualizacao.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDtAtualizacao.Enabled = false;
            this.txtDtAtualizacao.Location = new System.Drawing.Point(304, 263);
            this.txtDtAtualizacao.Name = "txtDtAtualizacao";
            this.txtDtAtualizacao.Size = new System.Drawing.Size(72, 13);
            this.txtDtAtualizacao.TabIndex = 29;
            this.txtDtAtualizacao.Text = "##/##/####";
            // 
            // FUPEtapa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(388, 282);
            this.Controls.Add(this.txtDtAtualizacao);
            this.Controls.Add(this.txtDtCriacao);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtFUPEmail);
            this.Controls.Add(this.lblFUPEmail);
            this.Controls.Add(this.lblFUPResponsavel);
            this.Controls.Add(this.txtFUPResponsavel);
            this.Controls.Add(this.lblFUPPendencia);
            this.Controls.Add(this.txtFUPPendencia);
            this.Controls.Add(this.btnEncerrarFollow);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSalvarFollow);
            this.Controls.Add(this.rtbFollowUp);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FUPEtapa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Follow Up";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FUPEtapa_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtbFollowUp;
        private System.Windows.Forms.Button btnSalvarFollow;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnEncerrarFollow;
        private System.Windows.Forms.TextBox txtFUPPendencia;
        private System.Windows.Forms.Label lblFUPPendencia;
        private System.Windows.Forms.Label lblFUPResponsavel;
        private System.Windows.Forms.TextBox txtFUPResponsavel;
        private System.Windows.Forms.Label lblFUPEmail;
        private System.Windows.Forms.TextBox txtFUPEmail;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDtCriacao;
        private System.Windows.Forms.TextBox txtDtAtualizacao;
    }
}