﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mobios
{
    public partial class FUPEtapa : Form
    {
        FollowUp _Follow;
        bool fechaFormFollowUpEtapa = false;

        public FUPEtapa(FollowUp fw)
        {
            InitializeComponent();

            if (fw.ID_Follow != 0)
            {
                _Follow = DataAccess.RecuperaFollowUpEtapaServicoByID(fw.ID_Follow);
            }
            else
            {
                _Follow = fw;
            }
            
            if (_Follow != null)
            {
                rtbFollowUp.Text = _Follow.FollowUpEtapa;
                txtFUPPendencia.Text = _Follow.Pendencia;
                txtFUPResponsavel.Text = _Follow.Responsavel;
                txtFUPEmail.Text = _Follow.EmailResponsavel;
                txtDtCriacao.Text = _Follow.DataCriacao.ToString("dd/MM/yyyy");
                txtDtAtualizacao.Text = _Follow.DataAlteracao.ToString("dd/MM/yyyy");
            }
            else
            {
                _Follow = new FollowUp();
                _Follow.ID_Servico = fw.ID_Servico;
                _Follow.ID_Fluxo = fw.ID_Fluxo;
                rtbFollowUp.Text = fw.FollowUpEtapa;
            }

            if (_Follow.ID_Follow == 0)
            {
                this.btnEncerrarFollow.Visible = false;
            }

        }

        private void btnSalvarFollow_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtFUPPendencia.Text != "" && txtFUPResponsavel.Text != "" && txtFUPEmail.Text != "" && rtbFollowUp.Text != "")
                {
                    _Follow.FollowUpEtapa = rtbFollowUp.Text;
                    _Follow.Pendencia = txtFUPPendencia.Text;
                    _Follow.Responsavel = txtFUPResponsavel.Text;
                    _Follow.EmailResponsavel = txtFUPEmail.Text;
                    if (_Follow.ID_Follow != 0)
                    {
                        DataAccess.RegistrarFollowUpEtapaServico(_Follow, true, false);
                        MessageBox.Show("Acompanhamento atualizado com sucesso.");
                    }
                    else
                    {
                        //PEGA OS CAMPOS DO SERVIÇO PARA COLOCAR NO E-MAIL
                        List<Campos> listaCamposServico = DataAccess.buscarCamposDinamicosConjunto(_Follow.ID_Servico);
                        string parmBody = "<span style='font-size:12.0pt; color:#003399'>Prezados,</span><br><br><span style='font-size:12.0pt; color:#003399'>Foi gerado a pendência abaixo.<br><br>" + _Follow.FollowUpEtapa + "<br><br>Peço total atenção.<br><br>Abaixo segue os dados da garantia:</span><br><br>";

                        parmBody += "<table border=0 cellspacing=0 cellpadding=2 width=450><tr><td colspan=2 width=450><font color=#003399><b>Dados da Garantia</b></font></td></tr>";
                        foreach (Campos valorCampo in listaCamposServico)
                        {
                            switch (valorCampo.CampoTipo.ToUpper())
                            {
                                case "CHECKBOX":
                                    if (valorCampo.ValorCampo.ToUpper() == "TRUE")
                                    {
                                        parmBody += "<tr bgcolor=#fffff ><td align=right valign=middle width=250>&nbsp;</td><td td align=left valign=middle width=200>" + valorCampo.CampoLabel + "</td></tr>";
                                    };
                                    break;
                                case "LABEL":
                                    parmBody += "<tr bgcolor=#fffff ><td colspan=2 align=middle valign=middle width=450><b>" + valorCampo.CampoNome + "</b></td></tr>";
                                    break;
                                default:
                                    if (valorCampo.ValorCampo != "" && valorCampo.ValorCampo != null)
                                    {
                                        parmBody += "<tr bgcolor=#fffff ><td align=right valign=middle width=250>" + valorCampo.CampoLabel + ":</td><td td align=left valign=middle width=200>" + valorCampo.ValorCampo + "</td></tr>";
                                    }
                                    break;
                            }
                        }
                        parmBody += "</table><br>";
                        string subject = "[CAGI - FUP] PENDÊNCIA: " + _Follow.Pendencia;
                        SharedData.CreateMailItem(subject, _Follow.EmailResponsavel, parmBody, "", false, "");
                        DataAccess.RegistrarFollowUpEtapaServico(_Follow, false, false);
                        MessageBox.Show("Acompanhamento inserido com sucesso.");
                    }
                    this.Close();
                    fechaFormFollowUpEtapa = true;
                }
                else
                {
                    MessageBox.Show("TODOS os campos devem estar preenchidos.");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao inserir acompanhamento. Erro: " + ex.Message);
            }

        }

        private void btnEncerrarFollow_Click(object sender, EventArgs e)
        {
            try
            {
                _Follow.FollowUpEtapa = rtbFollowUp.Text;
                _Follow.Pendencia = txtFUPPendencia.Text;
                _Follow.Responsavel = txtFUPResponsavel.Text;
                if (_Follow.ID_Follow != 0)
                {
                    DataAccess.RegistrarFollowUpEtapaServico(_Follow, true, true);
                    MessageBox.Show("Acompanhamento encerrado.");
                    this.Close();
                    fechaFormFollowUpEtapa = true;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao encerrar acompanhamento. Erro: " + ex.Message);
            }

        }

        private void FUPEtapa_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (fechaFormFollowUpEtapa)
            {
                if (SharedData.isOpenForm(typeof(FollowUpEtapa), false, false))
                {
                    try
                    {
                        ((FollowUpEtapa)Application.OpenForms["FollowUpEtapa"]).Close();
                    }
                    catch { }
                }
            }
        }
    }
}
