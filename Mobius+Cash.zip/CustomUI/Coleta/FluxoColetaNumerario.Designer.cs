﻿namespace Mobios
{
    partial class FluxoColetaNumerario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FluxoColetaNumerario));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label_spread2 = new System.Windows.Forms.Label();
            this.label_spread1 = new System.Windows.Forms.Label();
            this.button_exportar_calculo_para_cliente = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridView_escolhas = new System.Windows.Forms.DataGridView();
            this.dataGridView_Valores_Calculados = new System.Windows.Forms.DataGridView();
            this.dataGridView_custos_numerario = new System.Windows.Forms.DataGridView();
            this.button_exportar_planilha_contrato = new System.Windows.Forms.Button();
            this.button_gerar_tabela_calculada = new System.Windows.Forms.Button();
            this.button_exporta_planilha_TV = new System.Windows.Forms.Button();
            this.button_importar_escolhas_cliente = new System.Windows.Forms.Button();
            this.button_importar_custos_numerario = new System.Windows.Forms.Button();
            this.button_Importa_Enderecos = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView_enderecos = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_escolhas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Valores_Calculados)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_custos_numerario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_enderecos)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(808, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(96, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label_spread2);
            this.groupBox2.Controls.Add(this.label_spread1);
            this.groupBox2.Controls.Add(this.button_exportar_calculo_para_cliente);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.dataGridView_escolhas);
            this.groupBox2.Controls.Add(this.dataGridView_Valores_Calculados);
            this.groupBox2.Controls.Add(this.dataGridView_custos_numerario);
            this.groupBox2.Controls.Add(this.button_exportar_planilha_contrato);
            this.groupBox2.Controls.Add(this.button_gerar_tabela_calculada);
            this.groupBox2.Controls.Add(this.button_exporta_planilha_TV);
            this.groupBox2.Controls.Add(this.button_importar_escolhas_cliente);
            this.groupBox2.Controls.Add(this.button_importar_custos_numerario);
            this.groupBox2.Controls.Add(this.button_Importa_Enderecos);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.dataGridView_enderecos);
            this.groupBox2.Location = new System.Drawing.Point(12, 42);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(892, 509);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Endereços para Cotação";
            // 
            // label_spread2
            // 
            this.label_spread2.AutoSize = true;
            this.label_spread2.Location = new System.Drawing.Point(325, 455);
            this.label_spread2.Name = "label_spread2";
            this.label_spread2.Size = new System.Drawing.Size(102, 13);
            this.label_spread2.TabIndex = 16;
            this.label_spread2.Text = "Spread não definido";
            // 
            // label_spread1
            // 
            this.label_spread1.AutoSize = true;
            this.label_spread1.Location = new System.Drawing.Point(325, 326);
            this.label_spread1.Name = "label_spread1";
            this.label_spread1.Size = new System.Drawing.Size(102, 13);
            this.label_spread1.TabIndex = 4;
            this.label_spread1.Text = "Spread não definido";
            // 
            // button_exportar_calculo_para_cliente
            // 
            this.button_exportar_calculo_para_cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_exportar_calculo_para_cliente.Location = new System.Drawing.Point(746, 282);
            this.button_exportar_calculo_para_cliente.Name = "button_exportar_calculo_para_cliente";
            this.button_exportar_calculo_para_cliente.Size = new System.Drawing.Size(142, 20);
            this.button_exportar_calculo_para_cliente.TabIndex = 15;
            this.button_exportar_calculo_para_cliente.Text = "Exportar Cálculo para Cliente";
            this.button_exportar_calculo_para_cliente.UseVisualStyleBackColor = true;
            this.button_exportar_calculo_para_cliente.Click += new System.EventHandler(this.button_exportar_calculo_para_cliente_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 393);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(222, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Tabela com os custos escolhidos pelo Cliente";
            // 
            // dataGridView_escolhas
            // 
            this.dataGridView_escolhas.AllowUserToAddRows = false;
            this.dataGridView_escolhas.AllowUserToDeleteRows = false;
            this.dataGridView_escolhas.AllowUserToOrderColumns = true;
            this.dataGridView_escolhas.AllowUserToResizeRows = false;
            dataGridViewCellStyle33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_escolhas.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle33;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle34.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle34.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_escolhas.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle34;
            this.dataGridView_escolhas.ColumnHeadersHeight = 18;
            this.dataGridView_escolhas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle35.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle35.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle35.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle35.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle35.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle35.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_escolhas.DefaultCellStyle = dataGridViewCellStyle35;
            this.dataGridView_escolhas.Location = new System.Drawing.Point(25, 408);
            this.dataGridView_escolhas.Name = "dataGridView_escolhas";
            this.dataGridView_escolhas.ReadOnly = true;
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle36.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle36.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle36.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle36.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle36.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle36.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_escolhas.RowHeadersDefaultCellStyle = dataGridViewCellStyle36;
            this.dataGridView_escolhas.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridView_escolhas.RowTemplate.Height = 15;
            this.dataGridView_escolhas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_escolhas.Size = new System.Drawing.Size(715, 96);
            this.dataGridView_escolhas.TabIndex = 13;
            // 
            // dataGridView_Valores_Calculados
            // 
            this.dataGridView_Valores_Calculados.AllowUserToAddRows = false;
            this.dataGridView_Valores_Calculados.AllowUserToDeleteRows = false;
            this.dataGridView_Valores_Calculados.AllowUserToOrderColumns = true;
            this.dataGridView_Valores_Calculados.AllowUserToResizeRows = false;
            dataGridViewCellStyle37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_Valores_Calculados.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle37;
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle38.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle38.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle38.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle38.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle38.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle38.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_Valores_Calculados.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle38;
            this.dataGridView_Valores_Calculados.ColumnHeadersHeight = 18;
            this.dataGridView_Valores_Calculados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle39.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle39.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle39.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle39.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle39.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle39.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_Valores_Calculados.DefaultCellStyle = dataGridViewCellStyle39;
            this.dataGridView_Valores_Calculados.Location = new System.Drawing.Point(25, 282);
            this.dataGridView_Valores_Calculados.Name = "dataGridView_Valores_Calculados";
            this.dataGridView_Valores_Calculados.ReadOnly = true;
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle40.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle40.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle40.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle40.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle40.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_Valores_Calculados.RowHeadersDefaultCellStyle = dataGridViewCellStyle40;
            this.dataGridView_Valores_Calculados.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridView_Valores_Calculados.RowTemplate.Height = 15;
            this.dataGridView_Valores_Calculados.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_Valores_Calculados.Size = new System.Drawing.Size(715, 96);
            this.dataGridView_Valores_Calculados.TabIndex = 12;
            // 
            // dataGridView_custos_numerario
            // 
            this.dataGridView_custos_numerario.AllowUserToAddRows = false;
            this.dataGridView_custos_numerario.AllowUserToDeleteRows = false;
            this.dataGridView_custos_numerario.AllowUserToOrderColumns = true;
            this.dataGridView_custos_numerario.AllowUserToResizeRows = false;
            dataGridViewCellStyle41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_custos_numerario.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle41;
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle42.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle42.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle42.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle42.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle42.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_custos_numerario.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle42;
            this.dataGridView_custos_numerario.ColumnHeadersHeight = 18;
            this.dataGridView_custos_numerario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle43.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle43.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle43.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle43.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle43.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle43.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_custos_numerario.DefaultCellStyle = dataGridViewCellStyle43;
            this.dataGridView_custos_numerario.Location = new System.Drawing.Point(25, 166);
            this.dataGridView_custos_numerario.Name = "dataGridView_custos_numerario";
            this.dataGridView_custos_numerario.ReadOnly = true;
            dataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle44.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle44.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle44.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle44.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle44.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle44.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_custos_numerario.RowHeadersDefaultCellStyle = dataGridViewCellStyle44;
            this.dataGridView_custos_numerario.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridView_custos_numerario.RowTemplate.Height = 15;
            this.dataGridView_custos_numerario.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_custos_numerario.Size = new System.Drawing.Size(715, 96);
            this.dataGridView_custos_numerario.TabIndex = 11;
            // 
            // button_exportar_planilha_contrato
            // 
            this.button_exportar_planilha_contrato.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_exportar_planilha_contrato.Location = new System.Drawing.Point(746, 434);
            this.button_exportar_planilha_contrato.Name = "button_exportar_planilha_contrato";
            this.button_exportar_planilha_contrato.Size = new System.Drawing.Size(142, 20);
            this.button_exportar_planilha_contrato.TabIndex = 10;
            this.button_exportar_planilha_contrato.Text = "Exportar Planilha Contrato";
            this.button_exportar_planilha_contrato.UseVisualStyleBackColor = true;
            this.button_exportar_planilha_contrato.Click += new System.EventHandler(this.button_exportar_planilha_contrato_Click);
            // 
            // button_gerar_tabela_calculada
            // 
            this.button_gerar_tabela_calculada.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_gerar_tabela_calculada.Location = new System.Drawing.Point(746, 192);
            this.button_gerar_tabela_calculada.Name = "button_gerar_tabela_calculada";
            this.button_gerar_tabela_calculada.Size = new System.Drawing.Size(142, 20);
            this.button_gerar_tabela_calculada.TabIndex = 9;
            this.button_gerar_tabela_calculada.Text = "Gerar Planilha Calculada";
            this.button_gerar_tabela_calculada.UseVisualStyleBackColor = true;
            this.button_gerar_tabela_calculada.Click += new System.EventHandler(this.button_gerar_tabela_calculada_Click);
            // 
            // button_exporta_planilha_TV
            // 
            this.button_exporta_planilha_TV.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_exporta_planilha_TV.Location = new System.Drawing.Point(746, 70);
            this.button_exporta_planilha_TV.Name = "button_exporta_planilha_TV";
            this.button_exporta_planilha_TV.Size = new System.Drawing.Size(142, 20);
            this.button_exporta_planilha_TV.TabIndex = 8;
            this.button_exporta_planilha_TV.Text = "Exportar Planilha TV";
            this.button_exporta_planilha_TV.UseVisualStyleBackColor = true;
            this.button_exporta_planilha_TV.Click += new System.EventHandler(this.button_exporta_planilha_TV_Click);
            // 
            // button_importar_escolhas_cliente
            // 
            this.button_importar_escolhas_cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_importar_escolhas_cliente.Location = new System.Drawing.Point(746, 408);
            this.button_importar_escolhas_cliente.Name = "button_importar_escolhas_cliente";
            this.button_importar_escolhas_cliente.Size = new System.Drawing.Size(142, 20);
            this.button_importar_escolhas_cliente.TabIndex = 7;
            this.button_importar_escolhas_cliente.Text = "Importar Escolhas Cliente";
            this.button_importar_escolhas_cliente.UseVisualStyleBackColor = true;
            this.button_importar_escolhas_cliente.Click += new System.EventHandler(this.button_importar_escolhas_cliente_Click);
            // 
            // button_importar_custos_numerario
            // 
            this.button_importar_custos_numerario.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_importar_custos_numerario.Location = new System.Drawing.Point(746, 166);
            this.button_importar_custos_numerario.Name = "button_importar_custos_numerario";
            this.button_importar_custos_numerario.Size = new System.Drawing.Size(142, 20);
            this.button_importar_custos_numerario.TabIndex = 6;
            this.button_importar_custos_numerario.Text = "Importar Custos";
            this.button_importar_custos_numerario.UseVisualStyleBackColor = true;
            this.button_importar_custos_numerario.Click += new System.EventHandler(this.button_importar_custos_numerario_Click);
            // 
            // button_Importa_Enderecos
            // 
            this.button_Importa_Enderecos.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Importa_Enderecos.Location = new System.Drawing.Point(746, 44);
            this.button_Importa_Enderecos.Name = "button_Importa_Enderecos";
            this.button_Importa_Enderecos.Size = new System.Drawing.Size(142, 20);
            this.button_Importa_Enderecos.TabIndex = 4;
            this.button_Importa_Enderecos.Text = "Importar Endereços";
            this.button_Importa_Enderecos.UseVisualStyleBackColor = true;
            this.button_Importa_Enderecos.Click += new System.EventHandler(this.button_Importa_Enderecos_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 266);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(169, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Tabela com os valores Calculados";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 150);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(162, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Tabela com os custos Numerário";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(144, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Tabela Endereços do Cliente";
            // 
            // dataGridView_enderecos
            // 
            this.dataGridView_enderecos.AllowUserToAddRows = false;
            this.dataGridView_enderecos.AllowUserToDeleteRows = false;
            this.dataGridView_enderecos.AllowUserToOrderColumns = true;
            this.dataGridView_enderecos.AllowUserToResizeRows = false;
            dataGridViewCellStyle45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_enderecos.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle45;
            dataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle46.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle46.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle46.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle46.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle46.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle46.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_enderecos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle46;
            this.dataGridView_enderecos.ColumnHeadersHeight = 18;
            this.dataGridView_enderecos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle47.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle47.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle47.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle47.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle47.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle47.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_enderecos.DefaultCellStyle = dataGridViewCellStyle47;
            this.dataGridView_enderecos.Location = new System.Drawing.Point(25, 44);
            this.dataGridView_enderecos.Name = "dataGridView_enderecos";
            this.dataGridView_enderecos.ReadOnly = true;
            dataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle48.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle48.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle48.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle48.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle48.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle48.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_enderecos.RowHeadersDefaultCellStyle = dataGridViewCellStyle48;
            this.dataGridView_enderecos.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridView_enderecos.RowTemplate.Height = 15;
            this.dataGridView_enderecos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_enderecos.Size = new System.Drawing.Size(715, 96);
            this.dataGridView_enderecos.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(219, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Fluxo Coleta - Etapa ID: - Número do Serviço";
            // 
            // progressBar
            // 
            this.progressBar.ForeColor = System.Drawing.SystemColors.Desktop;
            this.progressBar.Location = new System.Drawing.Point(37, 557);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(715, 23);
            this.progressBar.TabIndex = 4;
            // 
            // FluxoColetaNumerario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(929, 589);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox2);
            this.Name = "FluxoColetaNumerario";
            this.Text = "FluxoColetaNumerario";
            this.Load += new System.EventHandler(this.FluxoColetaNumerario_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_escolhas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Valores_Calculados)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_custos_numerario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_enderecos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_Importa_Enderecos;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView_enderecos;
        private System.Windows.Forms.Button button_importar_escolhas_cliente;
        private System.Windows.Forms.Button button_importar_custos_numerario;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button_exportar_planilha_contrato;
        private System.Windows.Forms.Button button_gerar_tabela_calculada;
        private System.Windows.Forms.Button button_exporta_planilha_TV;
        private System.Windows.Forms.DataGridView dataGridView_custos_numerario;
        private System.Windows.Forms.Button button_exportar_calculo_para_cliente;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dataGridView_escolhas;
        private System.Windows.Forms.DataGridView dataGridView_Valores_Calculados;
        private System.Windows.Forms.Label label_spread2;
        private System.Windows.Forms.Label label_spread1;
        private System.Windows.Forms.ProgressBar progressBar;
    }
}