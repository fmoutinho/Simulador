﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Reflection;
using System.Data.OleDb;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.Configuration;

namespace Mobios
{
    
    public partial class FluxoColetaNumerario : Form
    {
        string msgLog;
        int _ID_Servico = SharedData.Etapa.ID_Servico;
        string _StrRacf = SharedData.User.LoginResponsavel;
        string _NomeTBL = CustomMethod.GetParametroFromColeta("TABELA_ENDERECOS");
        string _NomeTBLCustosNumerario = CustomMethod.GetParametroFromColeta("TABELA_CUSTOS_NUMERARIO");
        
        
        public static List<ResponsavelServico> BuscarPipeline(string coluna, int Id)
        {
            //string sqlCommand = String.Format(@"SELECT * FROM vw_PipeLineResponsavel WHERE LOGIN = '{0}' AND STATUS = 'Em Análise'", Id_Responsavel);
            string sqlCommand = String.Format(@"SELECT * FROM vw_PipeLineResponsavel WHERE " + coluna + "= {0} And Concluido = {1} ORDER BY Prioridade", Id, "false");

            List<ResponsavelServico> list = new List<ResponsavelServico>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new ResponsavelServico(row));

            return list;
        }
        public FluxoColetaNumerario()
        {
            InitializeComponent();
            int x = SharedData.Etapa.ID_Etapa;
            int y = SharedData.Etapa.ID_Servico;

            //msgLog = "Formulário FluxoColetaNumerario Aberto. Servico: " + sv.ID_Objeto + " / " + sv.ID_Servico + " / " + sv.ID_Responsavel + ".";
            //Log.GravaLog(ConfigurationManager.AppSettings["CaminhoLOG"].ToString(), msgLog, "Mobios");
            //_Responsavel = sv;
    //            this.label1.Text = "Detalhe:[Servico: " + _Etapa.ID_Servico + " - " + _Responsavel.NomeObjeto + " - Identificação: " + _Responsavel.ServicoName + "]" + " Etapa - " + _Etapa.ID_Etapa + " (" + _Etapa.NomeEtapa + ")";
        }

        private void AtualizarDataGridEnderecos()
        {
            DataTable dt = new DataTable();
            string SQL="";
            SQL = "select * from " + _NomeTBL + " where ID_Servico=" + _ID_Servico + " AND Ativo=1 order by ID";
            dt = CustomMethod.ReturnDTFromBaseColeta(SQL);
            dataGridView_enderecos.DataSource = dt;
            dataGridView_enderecos.AutoResizeColumns();
            
        }
        private void AtualizarDataGridCustos()
        {
            DataTable dt = new DataTable();
            string SQL = "";
            SQL = "select * from " + _NomeTBLCustosNumerario + " where ID_Servico=" + _ID_Servico + " AND Ativo=1 order by ID_Endereco, ID";
            dt = CustomMethod.ReturnDTFromBaseColeta(SQL);
            
            dataGridView_custos_numerario.DataSource = dt;
            //dataGridView_custos_numerario.Columns[9].DefaultCellStyle.Format = "0\\%";
            //dataGridView_custos_numerario.Columns[10].DefaultCellStyle.Format = "0\\%";
            //dataGridView_custos_numerario.Columns[11].DefaultCellStyle.Format = "0\\%";
            //dataGridView_custos_numerario.Columns[12].DefaultCellStyle.Format = "0\\%";
            //dataGridView_custos_numerario.Columns[13].DefaultCellStyle.Format = "0\\%";
            //dataGridView_custos_numerario.Columns["Ad Valorem"].DefaultCellStyle.Format = "P";
            dataGridView_custos_numerario.AutoResizeColumns();
            //dataGridView_custos_numerario.Refresh();
            

        }
        private void AtualizarDataGridCustosEscolhas()
        {
            DataTable dt = new DataTable();
            string SQL = "";
            SQL = "select * from " + _NomeTBLCustosNumerario + " where ID_Servico=" + _ID_Servico + " AND Ativo=1 And Escolha=1 order by ID_Endereco, ID";
            dt = CustomMethod.ReturnDTFromBaseColeta(SQL);
            
            dataGridView_escolhas.DataSource = dt;
            //dataGridView_custos_numerario.Columns[9].DefaultCellStyle.Format = "0\\%";
            //dataGridView_custos_numerario.Columns[10].DefaultCellStyle.Format = "0\\%";
            //dataGridView_custos_numerario.Columns[11].DefaultCellStyle.Format = "0\\%";
            //dataGridView_custos_numerario.Columns[12].DefaultCellStyle.Format = "0\\%";
            //dataGridView_custos_numerario.Columns[13].DefaultCellStyle.Format = "0\\%";
            //dataGridView_custos_numerario.Columns["Ad Valorem"].DefaultCellStyle.Format = "P";
            dataGridView_escolhas.AutoResizeColumns();
            //dataGridView_custos_numerario.Refresh();
            

        }

        

        private void FluxoColetaNumerario_Load(object sender, EventArgs e)
        {
            AtualizarDataGridEnderecos();
            AtualizarDataGridCustos();
            atualizar_calculo();
            //AtualizarDataGridCustosEscolhas();
                            
        }

        private void button_Importa_Enderecos_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            OpenFileDialog vAbreArq = new OpenFileDialog();
            vAbreArq.Filter = "Microsoft Excel (*.xlsx)|*.xlsx|Microsoft Excel (*.xls) (*.xls)|*.xls";
            vAbreArq.Title = "Selecione o Arquivo Excel";

            if (vAbreArq.ShowDialog() == DialogResult.OK)
            {
                if (dataGridView_enderecos.Rows.Count > 0)
                {
                    if (MessageBox.Show("Atenção: Esta ação irá limpar todos os endereços já importados anteriormente. Deseja continuar?", "Mobios", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2) == DialogResult.No)
                    {
                        return;
                    }
                    else
                    {
                        string SQL = "update " + _NomeTBL + " set Ativo=0 where ID_Servico=" + _ID_Servico + "";
                        CustomMethod.SetDataOnBaseColeta(SQL);
                        msgLog = "Endereços do serviço "+ _ID_Servico + " foram excluídos ( Ativo=0)";
                        Log.GravaLog(msgLog);

                    }


                }
                
                //Abre Conexão com arquivo excel
                string caminhoExcel = vAbreArq.FileName;
                
                /******************************************************************************************
                string strConexao = string.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"", caminhoExcel);
                OleDbConnection conn = new OleDbConnection(strConexao);
                conn.Open();
                *******************************************************************************************/
                
                //Define o nome da Sheet para pesquisar
                //string sheet = "Sheet1$";

                //Define o DataTable
                



                //[Opção 1] - Usar quando a planilha tem a primeira linha como cabeçalho
                //Coloca resultado da planilha dentro do DataSet, usando conexão aberta
                /************************************************************************************ 
                DataSet ds = new DataSet();
                OleDbDataAdapter da = new OleDbDataAdapter("Select * From [" + sheet + "]", conn);
                da.Fill(ds);
                dt=ds.Tables[0];
                *************************************************************************************/

                //[Opção 2] - usar quando o cabeçalhos estiver fora da primeira linha
                //Pega um range da planilha e coloca dentro do DataTable
                string myrange = CustomMethod.GetParametroFromColeta("SHEET_EXCEL_ENDERECO_RANGE");
                string sheet = CustomMethod.GetParametroFromColeta("SHEET_EXCEL_ENDERECO_NOME");
                desabilitar_botoes();
                dt = SharedData.ReadTableFromExcelRange(caminhoExcel, sheet, myrange,progressBar);
                habilitar_botoes();
                if (dt == null)
                {
                    msgLog = "Leitura do arquivo excel não foi realizada ( datatable vazio )\n";
                    msgLog += "Caminho Excel = " +caminhoExcel+ "\n";
                    msgLog += "SHEET_EXCEL_ENDERECO_RANGE= " +myrange+ "\n";
                    msgLog += "SHEET_EXCEL_ENDERECO_RANGE= " +sheet+ "\n";
                    Log.GravaLog(msgLog);
                    return;
                }
                //
                // Limpar linhas vazias
                bool DeleteRow = true;
                for (int i = dt.Rows.Count-1; i >= 0; i--)
                {
                    DeleteRow = true;
                    //verificando se todas as colunas são null
                    for (int j = 0; j < dt.Columns.Count-1; j++)
                    {
                        if (dt.Rows[i][j] != null && dt.Rows[i][j].ToString()!="")
                        {
                            DeleteRow=false;
                        }
                    }
                    //Deletando linha se null
                    if (DeleteRow)
                    {
                        dt.Rows[i].Delete();
                    }
                }
               
                //Inserindo nova Coluna com o número do serviço
                // Observação: Existem mais duas colunas com auto preenchimento na tabela [Coluna Ativo=1, Coluna Data=Now()]
                System.Data.DataColumn newColumn = new System.Data.DataColumn("ID_Servico", typeof(System.Int32));
                newColumn.DefaultValue = _ID_Servico;
                dt.Columns.Add(newColumn);

                System.Data.DataColumn newColumn2 = new System.Data.DataColumn("RespImpotacao", typeof(System.String));
                newColumn2.DefaultValue = _StrRacf;
                dt.Columns.Add(newColumn2);
                
                //Copia o resultado para a tabela Access
                string PathDB = CustomMethod.ReturnPathBaseColeta("BDconsulta");
                SharedData.BulkExportToAccess(dt, PathDB, _NomeTBL);

                AtualizarDataGridEnderecos();
                msgLog = "Importação realizada com sucesso\n";
                msgLog += "PathDB = " +PathDB+ "\n";
                msgLog += "NomeTBL = " +_NomeTBL+ "\n";
                msgLog += "Caminho Excel = " +caminhoExcel+ "\n";
                msgLog += "SHEET_EXCEL_ENDERECO_RANGE= " +myrange+ "\n";
                msgLog += "SHEET_EXCEL_ENDERECO_RANGE= " +sheet+ "\n";
                Log.GravaLog(msgLog);
                MessageBox.Show("Importação da planilha do cliente finalizada com sucesso");
            }

        }

        private void button_exporta_planilha_TV_Click(object sender, EventArgs e)
        {
            string pathPadrao = CustomMethod.GetParametroFromColeta("PADRAO_TV_PATH");
            string Sheet = CustomMethod.GetParametroFromColeta("PADRAO_TV_SHEET_NOME");
            string Range = CustomMethod.GetParametroFromColeta("PADRAO_TV_SHEET_RANGE");
            string SQL = CustomMethod.GetParametroFromColeta("PADRAO_TV_QUERY");
            string NomeSaida = CustomMethod.GetParametroFromColeta("PADRAO_TV_NOME_SAIDA");

            SQL = SQL.Replace("[ID_SERVICO]", _ID_Servico.ToString());
            
            DataTable dt = new DataTable();
            dt = CustomMethod.ReturnDTFromBaseColeta(SQL);

            // Consulta para recuperar dados para imprimir na tabela excel
            string result = "";
            // string result = SharedData.WriteTable_TranspValores(pathPadraoTV, Sheet, Range, dt);
            try
            {
                desabilitar_botoes();
                result = SharedData.WriteTable_Excel(pathPadrao, Sheet, Range, dt, NomeSaida, progressBar);
                habilitar_botoes();
            }
            catch (Exception)
            {
                habilitar_botoes();
                throw;
                //return "";
            }
            
            MessageBox.Show("Exportação realizada com sucesso da planilha do cliente finalizada com sucesso\n Verifique o caminho:" + result + "");
        }
        private void desabilitar_botoes()
        {
            button_Importa_Enderecos.Enabled = false;
            button_exporta_planilha_TV.Enabled = false;
            button_importar_custos_numerario.Enabled = false;
            button_gerar_tabela_calculada.Enabled = false;
            button_exportar_calculo_para_cliente.Enabled = false;
            button_importar_escolhas_cliente.Enabled = false;
            button_exportar_planilha_contrato.Enabled = false;

        }
        private void limpar_progressBar()
        {
            progressBar.Value = 0;
        }

        private void habilitar_botoes()
        {
            button_Importa_Enderecos.Enabled = true;
            button_exporta_planilha_TV.Enabled = true;
            button_importar_custos_numerario.Enabled = true;
            button_gerar_tabela_calculada.Enabled = true;
            button_exportar_calculo_para_cliente.Enabled = true;
            button_importar_escolhas_cliente.Enabled = true;
            button_exportar_planilha_contrato.Enabled = true;
            limpar_progressBar();

        }
        private void button_importar_custos_numerario_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            DataTable dtTeste = new DataTable();
            DataTable dtAccess = new DataTable();
            

            OpenFileDialog vAbreArq = new OpenFileDialog();
            vAbreArq.Filter = "Microsoft Excel (*.xlsx)|*.xlsx|Microsoft Excel (*.xls) (*.xls)|*.xls";
            vAbreArq.Title = "Selecione o Arquivo Excel";

            if (vAbreArq.ShowDialog() == DialogResult.OK)
            {

                string SQL = "";
                string caminhoExcel = vAbreArq.FileName;
                             
                //Pega os parametros necessários
                string myrange = CustomMethod.GetParametroFromColeta("SHEET_EXCEL_CUSTO_NUMERARIO_RANGE");
                string sheet = CustomMethod.GetParametroFromColeta("SHEET_EXCEL_CUSTO_NUMERARIO_NOME");
                
                desabilitar_botoes();
                dt = SharedData.ReadTableFromExcelRange(caminhoExcel, sheet, myrange, progressBar);
                habilitar_botoes();
                if (dt == null)
                {
                    msgLog = "Data table Vazio na importação dos custos Numerário: Pode ser um erro ou pode ser arquivo em branco\n";
                    msgLog += "SHEET_EXCEL_CUSTO_NUMERARIO_RANGE = " + myrange + " \n";
                    msgLog += "SHEET_EXCEL_CUSTO_NUMERARIO_NOME = " + sheet + " \n";
                    Log.GravaLog(msgLog);
                   
                    return;
                }
                SQL = "select top1 * from " + _NomeTBLCustosNumerario + "";
                //dtAccess = SharedData.ReturnDTFromBaseColeta(SQL);

                string caminhoDB = CustomMethod.ReturnPathBaseColeta("BDconsulta");
                string strConexao = string.Format(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Persist Security Info=False", caminhoDB);
                
                OleDbConnection mdbConnection = new OleDbConnection(strConexao);
                mdbConnection.Open();
                OleDbCommand mdbCommand = new OleDbCommand("SELECT * FROM "+ _NomeTBLCustosNumerario + "", mdbConnection);
                OleDbDataReader myReader = mdbCommand.ExecuteReader(CommandBehavior.KeyInfo);
                DataTable schemaTable = myReader.GetSchemaTable();
                List<String> columnNameList = new List<string>();
                foreach (DataRow myField in schemaTable.Rows)
                {
                    foreach (DataColumn myProperty in schemaTable.Columns)
                    {
                        if (myProperty.ColumnName == "ColumnName") columnNameList.Add(myField[myProperty].ToString());
                    }

                }

                
                
                //retirando as colunas sobressalentes da tabela dt ( Excel importado )
                bool alreadyExist = false;
                List<String> columnNameExcelList = new List<string>();
                foreach (DataColumn dc in dt.Columns)
                {
                    columnNameExcelList.Add(dc.ColumnName.ToString());
                }


                foreach (string item in columnNameExcelList)
                {
                    alreadyExist = columnNameList.Contains(item.ToString());
                    if (!alreadyExist)
                    {
                        dt.Columns.Remove(item.ToString());
                    }

                }


                // Limpar linhas vazias
                bool DeleteRow = true;
                for (int i = dt.Rows.Count - 1; i >= 0; i--)
                {
                    DeleteRow = true;
                    //verificando se todas as colunas são null
                    for (int j = 0; j < dt.Columns.Count - 1; j++)
                    {
                        if (dt.Rows[i][j] != null && dt.Rows[i][j].ToString() != "")
                        {
                            DeleteRow = false;
                        }
                    }
                    //Deletando linha se null
                    if (DeleteRow)
                    {
                        dt.Rows[i].Delete();
                    }
                }

                System.Data.DataColumn newColumn2 = new System.Data.DataColumn("RespImpotacao", typeof(System.String));
                newColumn2.DefaultValue = _StrRacf;
                dt.Columns.Add(newColumn2);

                int ID_servico_planilha = Convert.ToInt32(dt.Rows[0][0].ToString());
                if (ID_servico_planilha != _ID_Servico)
                {
                    MessageBox.Show("Serviço da Planilha diverge do Serviço aberto");
                    return;
                }
                //Copia o resultado para a tabela Access
                string PathDB = CustomMethod.ReturnPathBaseColeta("BDconsulta");
                string nome_cabecalho_transportadora = CustomMethod.GetParametroFromColeta("PADRAO_TV_SHEET_CABECALHO_TRANSPORTADORA");
                string nome="";
                string importados = "";
                DataView DV = new DataView(dt);
                foreach (DataRow row in DV.ToTable(true, nome_cabecalho_transportadora).Rows)
                {
                    nome = row[0].ToString();
                    SQL = "SELECT * FROM " + _NomeTBLCustosNumerario + " where Ativo=1 and ID_Servico=" + _ID_Servico + " and TRANSPORTADORA='" + nome + "'";
                    dtTeste = CustomMethod.ReturnDTFromBaseColeta(SQL);
                    if (dtTeste != null && dtTeste.Rows.Count > 0)
                    {
                        if (MessageBox.Show("A transportadora " + nome + " já foi importada. Deseja continuar? \n\n Atenção: Os dados existentes serão cancelados.", "Mobios", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                        {
                            SQL = "update " + _NomeTBLCustosNumerario + " Set Ativo=0 where ID_Servico=" + _ID_Servico + " and TRANSPORTADORA='" + nome + "'";
                            importados += nome + "; ";
                            msgLog = "Os custos custos para a Transportadora " + nome + " foram limpados ( Ativo=0)";
                            msgLog += "ID_Servico = " + _ID_Servico + " \n";
                            Log.GravaLog(msgLog);
                   
                        }
                        else
                        {
                            return;
                        }

                    }
                    else
                    {
                        importados += nome + "; ";
                    }

                }
                

                SharedData.BulkExportToAccess(dt, PathDB, _NomeTBLCustosNumerario);

                AtualizarDataGridCustos();
                msgLog = "Planilha com a(s) transportadora(s) " + importados + " importada com sucesso.";
                msgLog += "ID_Servico = " + _ID_Servico + " \n";
                Log.GravaLog(msgLog);

                MessageBox.Show("Planilha com a(s) transportadora(s) " + importados + " importada com sucesso.");
            }

        }

        private void button_gerar_tabela_calculada_Click(object sender, EventArgs e)
        {
                atualizar_calculo(true);
        }

        private string return_query_com_valores(string SQL)
        {
            //pegar os valores dos campos para multiplicar
            //tabela: tb_0126_DadosServico
            //paramentros: ID_servico,ID_Fluxo e ID_Campo
            int ID_Etapa = SharedData.Etapa.ID_Etapa;
            int ID_Servico = SharedData.Etapa.ID_Servico;
            string ID_CampoTransporte = CustomMethod.GetParametroFromColeta("ID_CAMPO_SPREAD_TRANSPORTE");
            string ID_CampoProcessamento = CustomMethod.GetParametroFromColeta("ID_CAMPO_SPREAD_PROCESSAMENTO");
            string ID_EtapaFluxo = CustomMethod.GetParametroFromColeta("ID_ETAPAFLUXO");
            string ID_TarifaBancoBrasil = CustomMethod.GetParametroFromColeta("ID_CAMPO_TARIFA_BANCO_BRASIL");

            List<DadosCampos> listaDadosCamposEtapas = new List<DadosCampos>();
            listaDadosCamposEtapas = DataAccess.BuscarDadosCamposEtapas(Convert.ToInt32(ID_EtapaFluxo), ID_Servico);

            //List<DadosCampos> listaDadosCampos = new List<DadosCampos>();
            //listaDadosCampos = DataAccess.BuscarDadosCampos(ID_Servico);


            //SQL = SharedData.GetParametroFromColeta("QUERY_CALCULO_SPREAD");
            bool CheckTransporte = false;
            bool CheckProcessamento = false;
            foreach (DadosCampos c in listaDadosCamposEtapas)
            {
                if (c.Id_Campo == Convert.ToInt32(ID_CampoTransporte))
                {
                    double valor_spread_transporte = 0;
                    valor_spread_transporte = Convert.ToDouble(c.ValorCampo);
                    valor_spread_transporte = 1 + valor_spread_transporte / 100;
                    SQL = SQL.Replace("[SPREAD_TRANSPORTE]", valor_spread_transporte.ToString().Replace(",", "."));
                    CheckTransporte = true;
                }
                if (c.Id_Campo == Convert.ToInt32(ID_CampoProcessamento))
                {
                    double valor_spread_processamento = 0;
                    valor_spread_processamento = Convert.ToDouble(c.ValorCampo);
                    valor_spread_processamento = 1 + valor_spread_processamento / 100;
                    SQL = SQL.Replace("[SPREAD_PROCESSAMENTO]", valor_spread_processamento.ToString().Replace(",", "."));
                    CheckProcessamento = true;
                }
                if (c.Id_Campo == Convert.ToInt32(ID_TarifaBancoBrasil))
                {
                    double valor_tarifa_BB = 0;
                    valor_tarifa_BB = Convert.ToDouble(c.ValorCampo);
                    //valor_tarifa_BB = valor_tarifa_BB;
                    SQL = SQL.Replace("[TAR_BANCO_BRASIL]", valor_tarifa_BB.ToString().Replace(",", ".")+"%");
                    CheckProcessamento = true;
                }
            }

            SQL = SQL.Replace("[ID_SERVICO]", ID_Servico.ToString());

            if (CheckProcessamento && CheckTransporte)
            {
                return SQL;
            }
            else
            {
                return "";
            }



        }

        
        private void atualizar_calculo(bool MessageShow=false)
        {
            
            /*SELECT 
            Coleta_Custos_Numerario.ID
            , Coleta_Custos_Numerario.ID_Servico
            , Coleta_Custos_Numerario.ID_Endereco
            , Coleta_Custos_Numerario.TRANSPORTADORA
            , Coleta_Custos_Numerario.FILIAL
            , Coleta_Custos_Numerario.Rotineiro * [SPREAD_TRANSPORTE] as [RotineiroSpread]
            , Coleta_Custos_Numerario.Eventual * [SPREAD_TRANSPORTE] as [EventualSpread]
            , Coleta_Custos_Numerario.Especial * [SPREAD_TRANSPORTE] as [EspecialSpread]
            , Coleta_Custos_Numerario.[Ad Valorem]
            , Coleta_Custos_Numerario.[Preparação Numerário] * [SPREAD_PROCESSAMENTO] as [PreparaçãoNumerárioSpread]
            , Coleta_Custos_Numerario.[Preparação Moeda] * [SPREAD_PROCESSAMENTO] as  [PreparaçãoMoedaSpread]
            , Coleta_Custos_Numerario.[Custódia Cédulas]
            , Coleta_Custos_Numerario.[Custódia Moedas]
            , Coleta_Custos_Numerario.[Minuto Excedente] * [SPREAD_TRANSPORTE] as [MinutoExcedenteSpread]
            , Coleta_Custos_Numerario.[Malote Plástico] * [SPREAD_PROCESSAMENTO] as [MalotePlásticoSpread]
            , Coleta_Custos_Numerario.ICMS
            , Coleta_Custos_Numerario.Observação
            FROM Coleta_Custos_Numerario
            where  ID_servico = [ID_SERVICO] AND ATIVO=1 order by ID_Endereco
            */
            string SQL = return_query_com_valores(CustomMethod.GetParametroFromColeta("QUERY_CALCULO_SPREAD"));

            if (SQL!="")
            {
                DataTable dt = new DataTable();
                dt = CustomMethod.ReturnDTFromBaseColeta(SQL);
                //SQL = "update " + _NomeTBLCustosNumerarioCalculado + " set Ativo=0 where ID_Servico=" + _ID_Servico + "";
                //SharedData.SetDataOnBaseColeta(SQL);
                //string PathDB = SharedData.ReturtPathBaseColeta();
                //SharedData.BulkExportToAccess(dt, PathDB, _NomeTBLCustosNumerarioCalculado);
                dataGridView_Valores_Calculados.DataSource = dt;
                dataGridView_Valores_Calculados.AutoResizeColumns();

                if (dt != null && dt.Rows.Count > 0)
                {
                    DataView DV = new DataView(dt);
                    DV.RowFilter = "Escolha = 1";
                    dataGridView_escolhas.DataSource = DV.ToTable();
                    dataGridView_escolhas.AutoResizeColumns();
                    label_spread2.Visible = false;
                    label_spread1.Visible = false;
                }
                
            }
            else
            {
                //MessageBox.Show("Os campos de Spread ainda não foram preenchidos no WorkFlow.", "Mobios", MessageBoxButtons.OK, MessageBoxIcon.Information);
                label_spread2.Visible = true;
                label_spread1.Visible = true;
                if (MessageShow)
                {
                    MessageBox.Show("Spread não definido no fluxo");
                }

            }

          
        }
        private void exportar(bool escolha = false)
        {
            string pathPadrao = CustomMethod.GetParametroFromColeta("PADRAO_ESCOLHA_CLIENTE_PATH");
            string Sheet = CustomMethod.GetParametroFromColeta("PADRAO_ESCOLHA_CLIENTE_SHEET_NOME");
            string Range = CustomMethod.GetParametroFromColeta("PADRAO_ESCOLHA_CLIENTE_SHEET_RANGE");
            string NomeSaida ="";
            string SQL = "";
            if (!escolha)
            {
                SQL = return_query_com_valores(CustomMethod.GetParametroFromColeta("PADRAO_ESCOLHA_CLIENTE_QUERY"));
                NomeSaida = CustomMethod.GetParametroFromColeta("PADRAO_ESCOLHA_CLIENTE_NOME_SAIDA");
            }

            else
            {
                SQL = return_query_com_valores(CustomMethod.GetParametroFromColeta("PADRAO_ESCOLHA_CLIENTE_QUERY_ESCOLHA"));
                NomeSaida = CustomMethod.GetParametroFromColeta("PADRAO_ESCOLHA_CLIENTE_ESCOLHAS_NOME_SAIDA");
            }



            
            if (SQL == "")
            {
                atualizar_calculo(true);
                return;
            }

            DataTable dt = new DataTable();
            dt = CustomMethod.ReturnDTFromBaseColeta(SQL);
            // Consulta para recuperar dados para imprimir na tabela excel

            
            try
            {
                desabilitar_botoes();
                string result = SharedData.WriteTable_Excel(pathPadrao, Sheet, Range, dt, NomeSaida, progressBar);
                habilitar_botoes();
                MessageBox.Show("Exportação realizada com sucesso da planilha do cliente finalizada com sucesso\n Verifique o caminho:" + result + "");
        
            }
            catch (Exception)
            {
                habilitar_botoes();
                throw;
                //return;
            }

           
        }
        private void button_exportar_calculo_para_cliente_Click(object sender, EventArgs e)
        {
            exportar();
        }

        private void button_importar_escolhas_cliente_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            DataTable dtAccess = new DataTable();


            OpenFileDialog vAbreArq = new OpenFileDialog();
            vAbreArq.Filter = "Microsoft Excel (*.xlsx)|*.xlsx|Microsoft Excel (*.xls) (*.xls)|*.xls";
            vAbreArq.Title = "Selecione o Arquivo Excel";

            if (vAbreArq.ShowDialog() == DialogResult.OK)
            {

                string SQL = "";
                if (dataGridView_escolhas.Rows.Count > 0)
                {
                    if (MessageBox.Show("Atenção: Esta ação irá limpar todos os custos de numerário já escolhidos anteriormente. Deseja continuar?", "Mobios", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2) == DialogResult.No)
                    {
                        return;
                    }
                    else
                    {
                        SQL = "update " + _NomeTBLCustosNumerario + " set Escolha=0 where ID_Servico=" + _ID_Servico + "";
                        CustomMethod.SetDataOnBaseColeta(SQL);
                    }


                }

                //Abre Conexão com arquivo excel
                string caminhoExcel = vAbreArq.FileName;
                string myrange = CustomMethod.GetParametroFromColeta("PADRAO_ESCOLHA_CLIENTE_SHEET_RANGE_IMPORTACAO");
                string sheet = CustomMethod.GetParametroFromColeta("PADRAO_ESCOLHA_CLIENTE_SHEET_NOME");
                
                desabilitar_botoes();
                dt = SharedData.ReadTableFromExcelRange(caminhoExcel, sheet, myrange, progressBar);
                habilitar_botoes();
                if (dt == null)
                {
                    msgLog = "Importação de arquivo não realizada. Possível erro em alguns dos paramentros\n";
                    msgLog += "Arquivo Escolhido = " + caminhoExcel + "\n";
                    msgLog += "PADRAO_ESCOLHA_CLIENTE_SHEET_RANGE_IMPORTACAO = " + myrange + "\n";
                    msgLog += "PADRAO_ESCOLHA_CLIENTE_SHEET_NOME = " + sheet + "\n";
                    Log.GravaLog(msgLog);
                    return;
                }
                
                // Limpar linhas vazias
                bool DeleteRow = true;
                for (int i = dt.Rows.Count - 1; i >= 0; i--)
                {
                    DeleteRow = true;
                    //verificando se todas as colunas são null
                    for (int j = 0; j < dt.Columns.Count - 1; j++)
                    {
                        if (dt.Rows[i][j] != null && dt.Rows[i][j].ToString() != "")
                        {
                            DeleteRow = false;
                        }
                    }
                    //Deletando linha se null
                    if (DeleteRow)
                    {
                        dt.Rows[i].Delete();
                    }
                }
                string cabecalho_ID = CustomMethod.GetParametroFromColeta("PADRAO_ESCOLHA_CLIENTE_SHEET_CABECALHO_ID_IMPORTACAO");
                string cabecalho_Escolha = CustomMethod.GetParametroFromColeta("PADRAO_ESCOLHA_CLIENTE_SHEET_CABECALHO_ESCOLHA_IMPORTACAO");
                int ID_endereco=0;
                string Escolha = "";
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ID_endereco = Convert.ToInt32(dt.Rows[i][cabecalho_ID].ToString());
                    Escolha = dt.Rows[i][cabecalho_Escolha].ToString();
                    if (Escolha != null && Escolha != "")
                    {
                        SQL = "update " + _NomeTBLCustosNumerario + " set Escolha=1 where ID=" + ID_endereco + " and Ativo=1 ";
                        CustomMethod.SetDataOnBaseColeta(SQL);
                    }

                }

                SQL = CustomMethod.GetParametroFromColeta("QUERY_VERIFICAR_ESCOLHA_DUPLA");
                SQL = SQL.Replace("[ID_SERVICO]", _ID_Servico.ToString());
                dt = CustomMethod.ReturnDTFromBaseColeta(SQL);
                if (dt.Rows.Count>0)
                {
                    SQL = "update " + _NomeTBLCustosNumerario + " set Escolha=0 where ID_Servico=" + _ID_Servico + "";
                    CustomMethod.SetDataOnBaseColeta(SQL);
                    MessageBox.Show("Escolhas duplas, importação cancelada");
                    msgLog += "Existia Escolhas duplas, importação cancelada";
                    Log.GravaLog(msgLog);
                }
                else
                {
                    atualizar_calculo();
                    MessageBox.Show("Importação da planilha do cliente finalizada com sucesso");
                }


                
                
                //Inserindo nova Coluna com o número do serviço
                // Observação: Existem mais duas colunas com auto preenchimento na tabela [Coluna Ativo=1, Coluna Data=Now()]
                //System.Data.DataColumn newColumn = new System.Data.DataColumn("ID_Servico", typeof(System.Int32));
                //newColumn.DefaultValue = _ID_Servico;
                //dt.Columns.Add(newColumn);

                //System.Data.DataColumn newColumn2 = new System.Data.DataColumn("RespImpotacao", typeof(System.String));
                //newColumn2.DefaultValue = _StrRacf;
                //dt.Columns.Add(newColumn2);

                //Copia o resultado para a tabela Access
                //string PathDB = SharedData.ReturtPathBaseColeta();
                //SharedData.BulkExportToAccess(dt, PathDB, _NomeTBLCustosNumerario);

                //AtualizarDataGridCustos();
                
                
            }

        }

        private void button_exportar_planilha_contrato_Click(object sender, EventArgs e)
        {

            //List<DadosCampos> listaDadosCamposEtapas = new List<DadosCampos>();
            //listaDadosCamposEtapas = DataAccess.BuscarDadosCamposEtapas(Convert.ToInt32(ID_EtapaFluxo), _ID_Servico);
            //Pegando o segmento do Serviço para definir qual arquivo abrir
            int MeuIDServico = _ID_Servico;
            string segmento="";
            string ExcelFilePath="";
            string SheetNameEnderecos = "";
            string SheetNameInicio = "";
            string NOME_Arquivo = "";
            ProgressBar PB = this.progressBar;

            //Fazendo a validação de quantidade máxima de registros da query principal ( Valores escolhidos )
            string SQL = return_query_com_valores(CustomMethod.GetParametroFromColeta("EXPORTA_CONTRATO_QUERY_ENDERECO"));
            if (SQL == "")
            {
                atualizar_calculo(true);
                return;
            }
            DataTable Enderecos = new DataTable();
            Enderecos = CustomMethod.ReturnDTFromBaseColeta(SQL);

            bool PreencherPlanilhaContrato = true;
            int qtdemax = Convert.ToInt32(CustomMethod.GetParametroFromColeta("EXPORTA_CONTRATO_QTDE_MAX_LINHAS"));
            if (Enderecos != null && Enderecos.Rows.Count > qtdemax)
            {
                //exportando os endereços
                PreencherPlanilhaContrato = false;
                exportar(true);
                MessageBox.Show("Atenção, foi exportado planilha para anexar ao contrato, pois existem muitos endereços");
                return;
            }
            if (Enderecos.Rows.Count < qtdemax)
            {
                qtdemax = Enderecos.Rows.Count;
            }



            //pegando dados do Segmento do Serviço
            string sqlCommand = String.Format(@"SELECT * FROM vw_servico_segmento WHERE ID_Servico= {0}", _ID_Servico, "false");
            DataTable DTServicoSegmento = DataConnector.ExecuteDataTable(sqlCommand,"BDconsulta");
            if (DTServicoSegmento.Rows.Count > 0)
            {
                segmento = DTServicoSegmento.Rows[0]["COD_SEGMENTO"].ToString();
            }
            else
            {
                MessageBox.Show("Servico não encontrado");
                return;
            }
            if (segmento.ToUpper().Trim() == "CIB")
            {
                ExcelFilePath = CustomMethod.GetParametroFromColeta("PADRAO_PLANILHACONTRATO_CIB_PATH");
                SheetNameEnderecos = CustomMethod.GetParametroFromColeta("PADRAO_PLANILHACONTRATO_CIB_SHEET_NAME_ENDERECOS");
                SheetNameInicio = CustomMethod.GetParametroFromColeta("PADRAO_PLANILHACONTRATO_CIB_SHEET_NAME_INICIO");
                NOME_Arquivo = "CIB";
            }
            else
            {
                ExcelFilePath = CustomMethod.GetParametroFromColeta("PADRAO_PLANILHACONTRATO_UPPER_PATH");
                SheetNameEnderecos = CustomMethod.GetParametroFromColeta("PADRAO_PLANILHACONTRATO_UPPER_SHEET_NAME_ENDERECOS");
                SheetNameInicio = CustomMethod.GetParametroFromColeta("PADRAO_PLANILHACONTRATO_UPPER_SHEET_NAME_INICIO");
                NOME_Arquivo = "UPPER";
            }




            //Mostrando ProgressBar
            PB.Maximum = 3;
            PB.Minimum = 0;
            PB.Value = 1;
            Application.DoEvents();


            //Abrindo arquivo
            PB.Value = 1;
            object misValue = System.Reflection.Missing.Value;
            var xlApp = new Excel.Application();
            bool IfReadOnly = false;
            //Excel.Worksheet xlWorkSheet = null;
            Excel.Workbook xlWorkBook = null;
            try
            {
                // open workbook
                xlWorkBook = xlApp.Workbooks.Open(ExcelFilePath, 0, IfReadOnly, 5, "", "", true,
                        Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "\t", true, false, 0, true, 1, 0);

                // check if sheet exists
                bool SheetExists = false;

                foreach (Excel.Worksheet sheet in xlWorkBook.Sheets)
                {
                    if (sheet.Name.Equals(SheetNameEnderecos))
                    {
                        SheetExists = true;
                        break;
                    }
                   
                }
                foreach (Excel.Worksheet sheet in xlWorkBook.Sheets)
                {
                    if (sheet.Name.Equals(SheetNameInicio))
                    {
                        SheetExists = true;
                        break;
                    }

                }

                if (!SheetExists)
                {
                    MessageBox.Show("ReadTableFromExcelRange: Sheet is not found in excel file!");
                    throw new Exception("ReadTableFromExcelRange: Sheet is not found in excel file!");
                }

                // get worksheet
                //xlWorkSheet = (Excel.Worksheet)xlWorkBook.Sheets.get_Item(SheetNameInicio);
                
                sqlCommand = String.Format(@"SELECT * FROM tb_0126_DadosServico WHERE ID_Servico= {0}", MeuIDServico, "false");
                DataTable DTServico = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

                DataTable ParamentrosMobiosToExcel = new DataTable();
                ParamentrosMobiosToExcel = CustomMethod.ReturnDTFromBaseColeta("select * from MOBIOS_TO_EXCEL_PARAMETRO where Ativo=1");
                int index = -1;
                DataRow[] rowsOfservico;

                // Parametros de exportação
                PB.Value = 2;
                foreach (DataRow row in ParamentrosMobiosToExcel.Rows)
                {
                    rowsOfservico = DTServico.Select("Id_Campo =" + row["Origem_IdCampoMobios"].ToString() + "");
                    if (rowsOfservico.Count() > 0)
                    {
                        index = DTServico.Rows.IndexOf(rowsOfservico[0]);
                        xlWorkBook.Sheets[row["Destino_PlanilhaExcel"].ToString()].Range[row["Destino_RangeExcel"].ToString()].Value2 = DTServico.Rows[index]["ValorCampo"].ToString();
                    }
                     
                }
                if (PreencherPlanilhaContrato)
                {


                    string floatNumerario = "";
                    string floatCheque = "";
                    string floatExcecao = "";
                    string agcc_credito = "";
                    string agcc_tarifa = "";
                    string agcc_entrega = "";
                    string agcc_diferenca = "";

                    string[] arrCampos = new string[] { "2000", "2001", "2009", "2011", "2012", "2013", "2014", "2015", "2016", "2017" };
                    for (int i = 0; i < arrCampos.Count(); i++)
                    {
                        rowsOfservico = DTServico.Select("Id_Campo =" + arrCampos[i].ToString() + "");
                        if (rowsOfservico.Count() > 0)
                        {
                            index = DTServico.Rows.IndexOf(rowsOfservico[0]);
                            switch (arrCampos[i].ToString())
                            {
                                case "2000":
                                    agcc_credito += DTServico.Rows[index]["ValorCampo"].ToString();
                                    break;
                                case "2001":
                                    agcc_credito += "/" + DTServico.Rows[index]["ValorCampo"].ToString();
                                    break;
                                case "2009":
                                    agcc_credito += "-" + DTServico.Rows[index]["ValorCampo"].ToString();
                                    break;
                                case "2011":
                                    agcc_entrega += "" + DTServico.Rows[index]["ValorCampo"].ToString();
                                    break;
                                case "2012":
                                    agcc_entrega += "/" + DTServico.Rows[index]["ValorCampo"].ToString();
                                    break;
                                case "2013":
                                    agcc_tarifa += "" + DTServico.Rows[index]["ValorCampo"].ToString();
                                    break;
                                case "2014":
                                    agcc_tarifa += "/" + DTServico.Rows[index]["ValorCampo"].ToString();
                                    break;
                                case "2015":
                                    agcc_diferenca += "" + DTServico.Rows[index]["ValorCampo"].ToString();
                                    break;
                                case "2016":
                                    agcc_diferenca += "/" + DTServico.Rows[index]["ValorCampo"].ToString();
                                    break;
                                case "2017":
                                    {
                                        floatNumerario += DTServico.Rows[index]["ValorCampo"].ToString();
                                        floatCheque += DTServico.Rows[index]["ValorCampo"].ToString();
                                        floatExcecao += DTServico.Rows[index]["ValorCampo"].ToString();
                                        break;
                                    }

                            }
                        }


                    }
                    string[] arr1 = new string[] { "B", "D", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P" };

                    //DataTable endereço está no início do processo
                    System.Data.DataColumn newColumn1 = new System.Data.DataColumn("FloatNumerario", typeof(System.String));
                    newColumn1.DefaultValue = floatNumerario;
                    Enderecos.Columns.Add(newColumn1);

                    System.Data.DataColumn newColumn2 = new System.Data.DataColumn("FloatCheque", typeof(System.String));
                    newColumn2.DefaultValue = floatCheque;
                    Enderecos.Columns.Add(newColumn2);

                    System.Data.DataColumn newColumn3 = new System.Data.DataColumn("FloatExcecao", typeof(System.String));
                    newColumn3.DefaultValue = floatExcecao;
                    Enderecos.Columns.Add(newColumn3);

                    System.Data.DataColumn newColumn4 = new System.Data.DataColumn("AGCCCredito", typeof(System.String));
                    newColumn4.DefaultValue = agcc_credito;
                    Enderecos.Columns.Add(newColumn4);

                    System.Data.DataColumn newColumn5 = new System.Data.DataColumn("AGCCTarifa", typeof(System.String));
                    newColumn5.DefaultValue = agcc_tarifa;
                    Enderecos.Columns.Add(newColumn5);

                    System.Data.DataColumn newColumn6 = new System.Data.DataColumn("AGCCEntrega", typeof(System.String));
                    newColumn6.DefaultValue = agcc_entrega;
                    Enderecos.Columns.Add(newColumn6);

                    System.Data.DataColumn newColumn7 = new System.Data.DataColumn("AGCCDiferenca", typeof(System.String));
                    newColumn7.DefaultValue = agcc_diferenca;
                    Enderecos.Columns.Add(newColumn7);

                    PB.Maximum = qtdemax;
                    if (PreencherPlanilhaContrato)
                    {
                        for (int i = 0; i < qtdemax; i++)
                        {
                            if (PB != null) PB.Value = i;
                            Application.DoEvents();
                            for (int j = 0; j < Enderecos.Columns.Count; j++)
                            {
                                Application.DoEvents();
                                xlWorkBook.Sheets["Coleta"].Range[arr1[j].ToString() + (i + 9).ToString()] = Enderecos.Rows[i][j].ToString();
                            }
                        }
                    }

                    


                    string[] arr2 = new string[] { "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P" };
                    SQL = return_query_com_valores(CustomMethod.GetParametroFromColeta("EXPORTA_CONTRATO_QUERY_VALORES"));
                    DataTable Valores = new DataTable();
                    Valores = CustomMethod.ReturnDTFromBaseColeta(SQL);

                    PB.Maximum = qtdemax;
                    for (int i = 0; i < qtdemax; i++)
                    {
                        if (PB != null) PB.Value = i;
                        Application.DoEvents();
                        for (int j = 0; j < Valores.Columns.Count; j++)
                        {
                            Application.DoEvents();
                            xlWorkBook.Sheets["Coleta"].Range[arr2[j].ToString() + (i + 26).ToString()] = Valores.Rows[i][j].ToString();
                        }
                    }


                    /*       
                     * // Query para parte de valores ( está nos parametros )     
                     SELECT 
                     Coleta_Enderecos.Cliente
                     , Coleta_Enderecos.Endereço
                     , Coleta_Enderecos.Cidade
                     , Coleta_Enderecos.UF
                     , Coleta_Enderecos.[Dia da frequência 1] & ';' & Coleta_Enderecos.[Dia da frequência 2]& ';' & Coleta_Enderecos.[Dia da frequência 3]& ';' & Coleta_Enderecos.[Dia da frequência 4]& ';' & Coleta_Enderecos.[Dia da frequência 5]& ';' & Coleta_Enderecos.[Dia da frequência 6]& ';' & Coleta_Enderecos.[Dia da frequência 7] as [Frequência]
                     , Coleta_Enderecos.[Hora Inicial Semanal] & ' às ' & Coleta_Enderecos.[Hora Final Semanal] as [Horario]
                     FROM Coleta_Enderecos INNER JOIN Coleta_Custos_Numerario ON Coleta_Enderecos.ID = Coleta_Custos_Numerario.ID_Endereco
                     WHERE 
                     Coleta_Custos_Numerario.[ID_servico]=[ID_SERVICO] 
                     AND Coleta_Custos_Numerario.[ATIVO]=1 
                     AND Coleta_Enderecos.Ativo=1 
                     AND Coleta_Custos_Numerario.Escolha=1 
                     ORDER BY 
                     Coleta_Custos_Numerario.ID_Endereco 
                     ,Coleta_Custos_Numerario.TRANSPORTADORA

                
                    // Query para parte de valores ( está nos parametros )               
                     SELECT 
                     , Coleta_Custos_Numerario.Rotineiro * [SPREAD_TRANSPORTE] as [Rotineiro]
                     , Coleta_Custos_Numerario.Eventual * [SPREAD_TRANSPORTE] as [Eventual]
                     , Coleta_Custos_Numerario.Especial * [SPREAD_TRANSPORTE] as [Especial]
                     , Coleta_Custos_Numerario.[Minuto Excedente] * [SPREAD_TRANSPORTE] as [Minuto Excedente]
                     , Coleta_Custos_Numerario.[Ad Valorem]
                     , Coleta_Custos_Numerario.[Preparação Moeda] * [SPREAD_PROCESSAMENTO] as  [Preparação Moeda]
                     , Coleta_Custos_Numerario.[Preparação Numerário] * [SPREAD_PROCESSAMENTO] as [Preparação Numerário]
                     , Coleta_Custos_Numerario.[Custódia Moedas]
                     , Coleta_Custos_Numerario.[Custódia Cédulas]
                     , '' as [AberturaSangria]
                     , '[TAR_BANCO_BRASIL]' as [DepositoNoCustodiante]
                     , '' as [PreparacaoKitTroco]
                     , '' as [Envelopamento]
                     , '' as [EntregaDeTroco]
                     FROM Coleta_Enderecos INNER JOIN Coleta_Custos_Numerario ON Coleta_Enderecos.ID = Coleta_Custos_Numerario.ID_Endereco
                     WHERE 
                     Coleta_Custos_Numerario.[ID_servico]=[ID_SERVICO] 
                     AND Coleta_Custos_Numerario.[ATIVO]=1 
                     AND Coleta_Enderecos.Ativo=1 
                     AND Coleta_Custos_Numerario.Escolha=1 
                     ORDER BY 
                     Coleta_Custos_Numerario.ID_Endereco 
                     ,Coleta_Custos_Numerario.TRANSPORTADORA

                                     */
                }

                string path_Arquivo = CustomMethod.GetParametroFromColeta("PATH_ARQUIVOS");
                string Pasta = "Demanda_" + _ID_Servico;
                path_Arquivo = TratamentoCampo.AdicionaBarraPath(path_Arquivo);
                path_Arquivo += Pasta;
                if (!Directory.Exists(path_Arquivo))
                {
                    Directory.CreateDirectory(path_Arquivo);
                }

                string timeStamp = DateTime.Now.ToString("s");
                timeStamp = timeStamp.Replace(":", "");
                timeStamp = timeStamp.Replace("T", "_");
                
                string NomeExcel = "Servico_" + _ID_Servico + "_" + NOME_Arquivo + "_" + timeStamp + ".xlsb";
                path_Arquivo += @"\" + NomeExcel;
                xlApp.DisplayAlerts = false;
                xlWorkBook.SaveAs(path_Arquivo, Excel.XlFileFormat.xlExcel12, misValue, misValue, misValue, misValue,
                        Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                xlWorkBook.Close();
                msgLog = "Excel gerado com suscesso\nCaminho: " + path_Arquivo;
                Log.GravaLog(msgLog);
                   
                MessageBox.Show("Excel gerado com suscesso\nCaminho: " + path_Arquivo);
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("ReadTableFromExcelRange: " + ex.Message);
                //throw new Exception("ReadTableFromExcelRange: " + ex.Message);
            }
            finally
            {
                try
                {

                    //System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkSheet);
                    if (xlWorkBook != null)
                    {
                        Marshal.FinalReleaseComObject(xlWorkBook);
                    }
                    if (xlApp != null)
                    {
                        xlApp.Quit();
                        Marshal.FinalReleaseComObject(xlApp);
                    }
                    msgLog = "Arquivo Fechado";
                    Log.GravaLog(msgLog);
                    GC.Collect();
                    GC.WaitForPendingFinalizers(); 

                }
                catch (Exception ex)
                {
                    MessageBox.Show("ReadTableFromExcelRange: " + ex.Message);
                }

            }
            

        }

      


      

        
        

     }
}

