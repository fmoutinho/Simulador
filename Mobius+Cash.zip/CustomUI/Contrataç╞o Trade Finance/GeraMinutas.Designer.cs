﻿namespace Mobios
{
    partial class GeraMinutas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GeraMinutas));
            this.bgwMinutas = new System.ComponentModel.BackgroundWorker();
            this.label1 = new System.Windows.Forms.Label();
            this.btnGerarMin = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.cboDoc = new System.Windows.Forms.ComboBox();
            this.cboMinuta = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // bgwMinutas
            // 
            this.bgwMinutas.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bgwMinutas_DoWork);
            this.bgwMinutas.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bgwMinutas_RunWorkerCompleted);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(527, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 20);
            this.label1.TabIndex = 47;
            this.label1.Text = "Formato:";
            // 
            // btnGerarMin
            // 
            this.btnGerarMin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnGerarMin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnGerarMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnGerarMin.Image = ((System.Drawing.Image)(resources.GetObject("btnGerarMin.Image")));
            this.btnGerarMin.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGerarMin.Location = new System.Drawing.Point(705, 31);
            this.btnGerarMin.Name = "btnGerarMin";
            this.btnGerarMin.Size = new System.Drawing.Size(127, 25);
            this.btnGerarMin.TabIndex = 43;
            this.btnGerarMin.Text = "Gerar Minuta";
            this.btnGerarMin.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGerarMin.UseVisualStyleBackColor = false;
            this.btnGerarMin.Click += new System.EventHandler(this.btnGerarMin_Click);
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Yellow;
            this.label4.Location = new System.Drawing.Point(6, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 20);
            this.label4.TabIndex = 44;
            this.label4.Text = "Minutas:";
            // 
            // cboDoc
            // 
            this.cboDoc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cboDoc.DisplayMember = "nomeDOC";
            this.cboDoc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDoc.FormattingEnabled = true;
            this.cboDoc.Location = new System.Drawing.Point(603, 31);
            this.cboDoc.Name = "cboDoc";
            this.cboDoc.Size = new System.Drawing.Size(74, 21);
            this.cboDoc.TabIndex = 46;
            this.cboDoc.ValueMember = "idDOC";
            this.cboDoc.SelectedIndexChanged += new System.EventHandler(this.cboDoc_SelectedIndexChanged);
            // 
            // cboMinuta
            // 
            this.cboMinuta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cboMinuta.DisplayMember = "NomeMinuta";
            this.cboMinuta.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMinuta.FormattingEnabled = true;
            this.cboMinuta.Location = new System.Drawing.Point(85, 31);
            this.cboMinuta.Name = "cboMinuta";
            this.cboMinuta.Size = new System.Drawing.Size(426, 21);
            this.cboMinuta.TabIndex = 45;
            this.cboMinuta.ValueMember = "IdMinuta";
            this.cboMinuta.SelectedIndexChanged += new System.EventHandler(this.cboMinuta_SelectedIndexChanged);
            // 
            // GeraMinutas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Desktop;
            this.ClientSize = new System.Drawing.Size(872, 79);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnGerarMin);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cboMinuta);
            this.Controls.Add(this.cboDoc);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "GeraMinutas";
            this.Text = "Geração de Minutas";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker bgwMinutas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnGerarMin;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cboDoc;
        private System.Windows.Forms.ComboBox cboMinuta;
    }
}