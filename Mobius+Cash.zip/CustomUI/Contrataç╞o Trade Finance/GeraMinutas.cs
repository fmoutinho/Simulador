﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Mobios
{
    public partial class GeraMinutas : Form
    {
        #region [ Objetos ]
        public ResponsavelServico _Responsavel;
        public List<Campos> _listaCamposServico = new List<Campos>();                  // Contem os campos para preenchimento da tela - Dados Servicos;
        List<Minuta> MinutasOperacao = new List<Minuta>();
        int _Minuta;
        int _TipoArquivo;
        string _QRdados;
        #endregion

        public GeraMinutas(ResponsavelServico sv, List<Campos> listaCamposServico)
        {
            #region [ Atualiza Variáveis ]
            InitializeComponent();
            _Responsavel = sv;
            _listaCamposServico = listaCamposServico;
            #endregion

            #region [ Minutas ]
            MinutasOperacao = DataAccess.buscarMinutas(sv.ID_Objeto, sv.Segmento, listaCamposServico);
            this.cboMinuta.DataSource = MinutasOperacao;
            this.cboDoc.DataSource = DataAccess.buscarMinutasDoc();
            this.btnGerarMin.Enabled = false;
            #endregion
        }

        private void btnGerarMin_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(cboMinuta.SelectedValue) != 0 && Convert.ToInt32(cboDoc.SelectedValue) != 0)
            {
                _Minuta = Convert.ToInt32(cboMinuta.SelectedValue);
                _TipoArquivo = Convert.ToInt32(cboDoc.SelectedValue);
                _QRdados = MinutasOperacao.Find(n => n.IdMinuta == _Minuta).QRdados.ToString();

                Form frmLoading = new Loading();
                frmLoading.Show();

                btnGerarMin.Enabled = false;
                Application.DoEvents();

                bgwMinutas.RunWorkerAsync();

                while(btnGerarMin.Enabled == false)
                {
                    Application.DoEvents();
                }

                try
                {
                    frmLoading.Close();
                }
                catch { }          
            }
            else
            {
                MessageBox.Show("Escolha uma minuta e um modelo de documento.");
            }
        }

        private void cboDoc_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(cboMinuta.SelectedValue) != 0 && Convert.ToInt32(cboDoc.SelectedValue) != 0)
            {
                this.btnGerarMin.Enabled = true;
            }
            else
            {
                this.btnGerarMin.Enabled = false;
            }
        }

        private void cboMinuta_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(cboMinuta.SelectedValue) != 0 && Convert.ToInt32(cboDoc.SelectedValue) != 0)
            {
                this.btnGerarMin.Enabled = true;
            }
            else
            {
                this.btnGerarMin.Enabled = false;
            }
        }

        private void bgwMinutas_DoWork(object sender, DoWorkEventArgs e)
        {
            
            try
            {
                Loading.EnableStaticTextBox("Processando...");
                
                ProcessaMinutas.ListaMinutas(_Responsavel, _listaCamposServico, _Minuta, _TipoArquivo, _QRdados);
            }
            catch (Exception err)
            {
                Loading.StaticFormVisible(false);
                MessageBox.Show(err.Message);
            }
        }

        private void bgwMinutas_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            Loading.StaticFormVisible(false);
            btnGerarMin.Enabled = true;
        }

    }
}
