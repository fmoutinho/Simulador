﻿namespace Mobios
{
    partial class Minutas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Minutas));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnPlayMethod = new System.Windows.Forms.Button();
            this.txtSegmento = new System.Windows.Forms.TextBox();
            this.lblSegmento = new System.Windows.Forms.Label();
            this.chkPrioridade = new System.Windows.Forms.CheckBox();
            this.label_ListMethod = new System.Windows.Forms.Label();
            this.cbAtualizar = new System.Windows.Forms.CheckBox();
            this.cmb_ListMethod = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbBoletador = new System.Windows.Forms.ComboBox();
            this.btnImportarBoleto = new System.Windows.Forms.Button();
            this.txtIdentificacao = new System.Windows.Forms.TextBox();
            this.lbNomeServico = new System.Windows.Forms.Label();
            this.btnResumo = new System.Windows.Forms.Button();
            this.btnSalvarServico = new System.Windows.Forms.Button();
            this.tabControlServico = new System.Windows.Forms.TabControl();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.btnConcluirServico = new System.Windows.Forms.Button();
            this.btnCancelarServico = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.btnPlayMethod);
            this.groupBox1.Controls.Add(this.txtSegmento);
            this.groupBox1.Controls.Add(this.lblSegmento);
            this.groupBox1.Controls.Add(this.chkPrioridade);
            this.groupBox1.Controls.Add(this.label_ListMethod);
            this.groupBox1.Controls.Add(this.cbAtualizar);
            this.groupBox1.Controls.Add(this.cmb_ListMethod);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.cbBoletador);
            this.groupBox1.Controls.Add(this.btnImportarBoleto);
            this.groupBox1.Controls.Add(this.txtIdentificacao);
            this.groupBox1.Controls.Add(this.lbNomeServico);
            this.groupBox1.Controls.Add(this.btnResumo);
            this.groupBox1.Controls.Add(this.btnSalvarServico);
            this.groupBox1.Controls.Add(this.tabControlServico);
            this.groupBox1.Location = new System.Drawing.Point(12, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1198, 619);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Informações";
            // 
            // btnPlayMethod
            // 
            this.btnPlayMethod.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnPlayMethod.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnPlayMethod.Image = ((System.Drawing.Image)(resources.GetObject("btnPlayMethod.Image")));
            this.btnPlayMethod.Location = new System.Drawing.Point(409, 585);
            this.btnPlayMethod.Name = "btnPlayMethod";
            this.btnPlayMethod.Size = new System.Drawing.Size(29, 23);
            this.btnPlayMethod.TabIndex = 58;
            this.btnPlayMethod.UseVisualStyleBackColor = false;
            this.btnPlayMethod.Visible = false;
            this.btnPlayMethod.Click += new System.EventHandler(this.btnPlayMethod_Click);
            // 
            // txtSegmento
            // 
            this.txtSegmento.Enabled = false;
            this.txtSegmento.Location = new System.Drawing.Point(410, 19);
            this.txtSegmento.Name = "txtSegmento";
            this.txtSegmento.Size = new System.Drawing.Size(141, 20);
            this.txtSegmento.TabIndex = 57;
            // 
            // lblSegmento
            // 
            this.lblSegmento.AutoSize = true;
            this.lblSegmento.Location = new System.Drawing.Point(352, 23);
            this.lblSegmento.Name = "lblSegmento";
            this.lblSegmento.Size = new System.Drawing.Size(58, 13);
            this.lblSegmento.TabIndex = 56;
            this.lblSegmento.Text = "Segmento:";
            // 
            // chkPrioridade
            // 
            this.chkPrioridade.AutoSize = true;
            this.chkPrioridade.Enabled = false;
            this.chkPrioridade.Location = new System.Drawing.Point(272, 22);
            this.chkPrioridade.Name = "chkPrioridade";
            this.chkPrioridade.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.chkPrioridade.Size = new System.Drawing.Size(73, 17);
            this.chkPrioridade.TabIndex = 55;
            this.chkPrioridade.Text = "Prioridade";
            this.chkPrioridade.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkPrioridade.UseVisualStyleBackColor = true;
            // 
            // label_ListMethod
            // 
            this.label_ListMethod.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label_ListMethod.AutoSize = true;
            this.label_ListMethod.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ListMethod.Location = new System.Drawing.Point(20, 589);
            this.label_ListMethod.Name = "label_ListMethod";
            this.label_ListMethod.Size = new System.Drawing.Size(59, 13);
            this.label_ListMethod.TabIndex = 44;
            this.label_ListMethod.Text = "Métodos:";
            this.label_ListMethod.Visible = false;
            // 
            // cbAtualizar
            // 
            this.cbAtualizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cbAtualizar.AutoSize = true;
            this.cbAtualizar.Location = new System.Drawing.Point(869, 587);
            this.cbAtualizar.Name = "cbAtualizar";
            this.cbAtualizar.Size = new System.Drawing.Size(66, 17);
            this.cbAtualizar.TabIndex = 17;
            this.cbAtualizar.Text = "Atualizar";
            this.cbAtualizar.UseVisualStyleBackColor = true;
            this.cbAtualizar.CheckedChanged += new System.EventHandler(this.cbAtualizar_CheckedChanged);
            // 
            // cmb_ListMethod
            // 
            this.cmb_ListMethod.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmb_ListMethod.DisplayMember = "MethodDescricao";
            this.cmb_ListMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_ListMethod.FormattingEnabled = true;
            this.cmb_ListMethod.Location = new System.Drawing.Point(84, 586);
            this.cmb_ListMethod.Name = "cmb_ListMethod";
            this.cmb_ListMethod.Size = new System.Drawing.Size(319, 21);
            this.cmb_ListMethod.TabIndex = 43;
            this.cmb_ListMethod.ValueMember = "MethodName";
            this.cmb_ListMethod.Visible = false;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(891, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 38;
            this.label3.Text = "Importar:";
            this.label3.Visible = false;
            // 
            // cbBoletador
            // 
            this.cbBoletador.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cbBoletador.DisplayMember = "NomeBoletador";
            this.cbBoletador.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBoletador.FormattingEnabled = true;
            this.cbBoletador.Location = new System.Drawing.Point(954, 18);
            this.cbBoletador.Name = "cbBoletador";
            this.cbBoletador.Size = new System.Drawing.Size(99, 21);
            this.cbBoletador.TabIndex = 37;
            this.cbBoletador.ValueMember = "IdBoletador";
            this.cbBoletador.Visible = false;
            // 
            // btnImportarBoleto
            // 
            this.btnImportarBoleto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnImportarBoleto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImportarBoleto.Location = new System.Drawing.Point(1059, 17);
            this.btnImportarBoleto.Name = "btnImportarBoleto";
            this.btnImportarBoleto.Size = new System.Drawing.Size(122, 23);
            this.btnImportarBoleto.TabIndex = 27;
            this.btnImportarBoleto.Text = "Capturar";
            this.btnImportarBoleto.UseVisualStyleBackColor = true;
            this.btnImportarBoleto.Visible = false;
            this.btnImportarBoleto.Click += new System.EventHandler(this.btnImportarBoleto_Click);
            // 
            // txtIdentificacao
            // 
            this.txtIdentificacao.Enabled = false;
            this.txtIdentificacao.Location = new System.Drawing.Point(85, 19);
            this.txtIdentificacao.Name = "txtIdentificacao";
            this.txtIdentificacao.Size = new System.Drawing.Size(177, 20);
            this.txtIdentificacao.TabIndex = 24;
            // 
            // lbNomeServico
            // 
            this.lbNomeServico.AutoSize = true;
            this.lbNomeServico.Location = new System.Drawing.Point(4, 23);
            this.lbNomeServico.Name = "lbNomeServico";
            this.lbNomeServico.Size = new System.Drawing.Size(75, 13);
            this.lbNomeServico.TabIndex = 23;
            this.lbNomeServico.Text = "*Identificação:";
            // 
            // btnResumo
            // 
            this.btnResumo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnResumo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnResumo.Image = ((System.Drawing.Image)(resources.GetObject("btnResumo.Image")));
            this.btnResumo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnResumo.Location = new System.Drawing.Point(1068, 584);
            this.btnResumo.Name = "btnResumo";
            this.btnResumo.Size = new System.Drawing.Size(111, 23);
            this.btnResumo.TabIndex = 19;
            this.btnResumo.Text = "Resumo";
            this.btnResumo.UseVisualStyleBackColor = true;
            this.btnResumo.Click += new System.EventHandler(this.btnResumo_Click);
            // 
            // btnSalvarServico
            // 
            this.btnSalvarServico.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSalvarServico.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvarServico.Image = ((System.Drawing.Image)(resources.GetObject("btnSalvarServico.Image")));
            this.btnSalvarServico.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalvarServico.Location = new System.Drawing.Point(947, 584);
            this.btnSalvarServico.Name = "btnSalvarServico";
            this.btnSalvarServico.Size = new System.Drawing.Size(115, 23);
            this.btnSalvarServico.TabIndex = 16;
            this.btnSalvarServico.Text = "Salvar";
            this.btnSalvarServico.UseVisualStyleBackColor = true;
            this.btnSalvarServico.Click += new System.EventHandler(this.btnSalvarServico_Click);
            // 
            // tabControlServico
            // 
            this.tabControlServico.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControlServico.Location = new System.Drawing.Point(6, 55);
            this.tabControlServico.Name = "tabControlServico";
            this.tabControlServico.SelectedIndex = 0;
            this.tabControlServico.Size = new System.Drawing.Size(1175, 520);
            this.tabControlServico.TabIndex = 7;
            // 
            // btnExcluir
            // 
            this.btnExcluir.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExcluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcluir.Location = new System.Drawing.Point(855, 636);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(92, 23);
            this.btnExcluir.TabIndex = 20;
            this.btnExcluir.Text = "Excluir serviço";
            this.btnExcluir.UseVisualStyleBackColor = true;
            this.btnExcluir.Visible = false;
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // btnConcluirServico
            // 
            this.btnConcluirServico.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnConcluirServico.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConcluirServico.Image = ((System.Drawing.Image)(resources.GetObject("btnConcluirServico.Image")));
            this.btnConcluirServico.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnConcluirServico.Location = new System.Drawing.Point(1080, 636);
            this.btnConcluirServico.Name = "btnConcluirServico";
            this.btnConcluirServico.Size = new System.Drawing.Size(111, 23);
            this.btnConcluirServico.TabIndex = 41;
            this.btnConcluirServico.Text = "Concluir serviço";
            this.btnConcluirServico.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnConcluirServico.UseVisualStyleBackColor = true;
            this.btnConcluirServico.Click += new System.EventHandler(this.btnConcluirServico_Click);
            // 
            // btnCancelarServico
            // 
            this.btnCancelarServico.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancelarServico.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelarServico.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelarServico.Image")));
            this.btnCancelarServico.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelarServico.Location = new System.Drawing.Point(959, 636);
            this.btnCancelarServico.Name = "btnCancelarServico";
            this.btnCancelarServico.Size = new System.Drawing.Size(115, 23);
            this.btnCancelarServico.TabIndex = 31;
            this.btnCancelarServico.Text = "Cancelar Serviço";
            this.btnCancelarServico.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelarServico.UseVisualStyleBackColor = true;
            this.btnCancelarServico.Click += new System.EventHandler(this.btnCancelarServico_Click);
            // 
            // Minutas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1223, 667);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnConcluirServico);
            this.Controls.Add(this.btnCancelarServico);
            this.Controls.Add(this.btnExcluir);
            this.Name = "Minutas";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Informações Consolidadas";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Minutas_FormClosed);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TabControl tabControlServico;
        private System.Windows.Forms.Button btnSalvarServico;
        private System.Windows.Forms.CheckBox cbAtualizar;
        private System.Windows.Forms.Button btnResumo;
        private System.Windows.Forms.Button btnExcluir;
        private System.Windows.Forms.TextBox txtIdentificacao;
        private System.Windows.Forms.Label lbNomeServico;
        private System.Windows.Forms.Button btnImportarBoleto;
        private System.Windows.Forms.Button btnCancelarServico;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbBoletador;
        private System.Windows.Forms.Button btnConcluirServico;
        private System.Windows.Forms.Label label_ListMethod;
        private System.Windows.Forms.ComboBox cmb_ListMethod;
        private System.Windows.Forms.TextBox txtSegmento;
        private System.Windows.Forms.Label lblSegmento;
        private System.Windows.Forms.CheckBox chkPrioridade;
        private System.Windows.Forms.Button btnPlayMethod;
    }
}