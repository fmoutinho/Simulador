﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Reflection;
using System.Configuration;

namespace Mobios
{
    public partial class Minutas : Form
    {
        #region [ Objetos ]
        string msgLog;
        public ResponsavelServico _Responsavel;

        public List<Campos> _listaCamposServico = new List<Campos>();                  // Contem os campos para preenchimento da tela - Dados Servicos;
        List<CamposTabela> _camposTabela = new List<CamposTabela>();
        List<Boletador> _listaBoletador = new List<Boletador>();
        public ClassListMethod _MyMethod = new ClassListMethod();
        public List<ClassListMethod> _Metodos = new List<ClassListMethod>();
        public int _IdMetodoCampos;
        public int _IdEtapa;
        bool SalvandoServiço;
        #endregion

        public Minutas(ResponsavelServico sv, bool AtualizarCampos = false, int IdMetodo = 0, string nomeMetodo = "", int IdEtapa = 0)
        {
            _Responsavel = sv;
            _IdMetodoCampos = IdMetodo;
            _IdEtapa = IdEtapa;
            InitializeComponent();

            msgLog = "Formulário de " + nomeMetodo + "aberto. Servico: " + sv.ID_Objeto + " / " + sv.ID_Servico + " / " + sv.ID_Responsavel + ".";
            Log.GravaLog(msgLog);

            txtIdentificacao.Text = _Responsavel.ServicoName;
            chkPrioridade.Checked = _Responsavel.Prioridade;
            txtSegmento.Text = _Responsavel.Segmento;
            groupBox1.Text = "Informações " + nomeMetodo + ": [Servico: " + _Responsavel.ID_Servico + " - " + _Responsavel.NomeObjeto + " - Identificação: " + _Responsavel.ServicoName + "]";

            #region [ Boletador ]
            bool exibeBoletador = SharedData.gBoletadorTela.Contains("MINUTAS=TRUE");

            if (exibeBoletador)
            {
                _listaBoletador = DataAccess.buscarBoletador();
                this.cbBoletador.DataSource = _listaBoletador;

                if (_listaBoletador.Count > 0)
                {
                    //this.cbBoletador.DataSource = _listaBoletador;
                    this.label3.Visible = true;
                    this.cbBoletador.Visible = true;
                    this.btnImportarBoleto.Visible = true;
                }
            }
            #endregion

            #region [ Botões Gestor ]
            string ParametroForm = SharedData.gFormOperação;

            if (ParametroForm == "MINUTAS")
            {
                btnConcluirServico.Visible = true;
                btnCancelarServico.Visible = true;
                if (SharedData.User.FLG_Gestor)
                {
                    btnExcluir.Visible = true;
                }
                else
                {
                    btnExcluir.Visible = false;
                }
            }
            else
            {
                btnConcluirServico.Visible = false;
                btnCancelarServico.Visible = false;
                btnExcluir.Visible = false;
            }
            #endregion

            #region [ Campos Objeto ]
            if (SharedData.gFormOperação == "MINUTAS")
            {
                if (SharedData.gCamposObjeto != null && SharedData.gCamposObjeto.Count > 0)
                {
                    List<Campos> temp = SharedData.gCamposObjeto.Where(n => n.ID_Objeto == _Responsavel.ID_Objeto).ToList();
                    if (temp != null && temp.Count > 0)
                    {
                        foreach (Campos c in temp)
                        {
                            c.ID_Servico = _Responsavel.ID_Servico;
                            _listaCamposServico.Add(new Campos(c));
                        }
                    }
                }
            }

            if (_listaCamposServico == null || _listaCamposServico.Count == 0)
            {
                _listaCamposServico = DataAccess.buscarCamposDinamicosConjunto(_Responsavel.ID_Servico, _IdMetodoCampos);
            }
            else
            {
                _listaCamposServico = TelaDinamica.RecuperarServico(_listaCamposServico, _Responsavel.ID_Servico);
            }
            #endregion

            #region [ Campos Tabela ]
            if ((_listaCamposServico != null) && (_listaCamposServico.Exists(n => n.CampoTipo.ToUpper() == "TABELA" || n.CampoTipo.ToUpper() == "TABELAGERAL")))
            {
                if (SharedData.gCamposTabela != null && SharedData.gCamposTabela.Count > 0)
                {
                    foreach (CamposTabela c in SharedData.gCamposTabela)
                    {
                        c.IdServico = _Responsavel.ID_Servico;
                        _camposTabela.Add(new CamposTabela(c));
                    }
                }

                if (_camposTabela == null || _camposTabela.Count == 0)
                {
                    if (_listaCamposServico.Exists(n => n.CampoTipo.ToUpper() == "TABELAGERAL"))
                    {
                        _camposTabela = DataAccess.BuscarCamposTabela(_Responsavel.ID_Servico, true);
                    }
                    else
                    {
                        _camposTabela = DataAccess.BuscarCamposTabela(_Responsavel.ID_Servico, false);
                    }
                }
                else
                {
                    if (_listaCamposServico.Exists(n => n.CampoTipo.ToUpper() == "TABELAGERAL"))
                    {
                        _camposTabela = TelaDinamica.RecuperarServico(_camposTabela, _Responsavel.ID_Servico, true);
                    }
                    else
                    {
                        _camposTabela = TelaDinamica.RecuperarServico(_camposTabela, _Responsavel.ID_Servico, false);
                    }
                }
            }
            #endregion

            #region [ Carrega Métodos ]
            if (SharedData.gMetodos != null && SharedData.gMetodos.Count > 0)
            {
                List<ClassListMethod> temp = SharedData.gMetodos.Where(n => n.ID_Method == 0 || (n.ID_Objeto == _Responsavel.ID_Objeto && n.MethodForm.ToUpper() == "MINUTA" && n.IdMethodForm == IdMetodo)).ToList();
                if (temp != null && temp.Count > 0)
                {
                    foreach (ClassListMethod c in temp)
                    {
                        _Metodos.Add(new ClassListMethod(c));
                    }
                }
            }

            if (_Metodos == null || _Metodos.Count == 0)
            {
                _Metodos = DataAccess.GetListMethodMinuta(sv.ID_Objeto, IdMetodo);
            }

            List<ClassListMethod> metodosMinuta = _Metodos;
            List<ClassListMethod> l = metodosMinuta.Where(n => n.CriterioCampo != "").ToList();
            if (l.Count > 0)
            {
                DataTable Resp = TratamentoCampo.ConvertObjectToDataTable(_Responsavel);
                List<ClassListMethod> removerMetodo = new List<ClassListMethod>();
                foreach (ClassListMethod m in l)
                {
                    string[] criterios = m.CriterioCampo.Split(';');
                    string[] valores = m.CriterioValor.Split(';');
                    for (int i = 0; i < criterios.Count(); i++)
                    {
                        int IdCampo = 0;
                        if (criterios[i].StartsWith("[") && criterios[i].EndsWith("]"))
                        {
                            criterios[i] = Resp.Rows[0][criterios[i].Substring(1, criterios[i].Length - 2)].ToString();
                            if (criterios[i].ToUpper() != valores[i].ToUpper())
                            {
                                removerMetodo.Add(m);
                                break;
                            }
                        }
                        else if (int.TryParse(criterios[i], out IdCampo))
                        {
                            if (!_listaCamposServico.Exists(n => n.ID_Campo == IdCampo && n.ValorCampo.ToUpper() == valores[i].ToUpper()))
                            {
                                removerMetodo.Add(m);
                                break;
                            }
                        }
                    }
                }

                if (removerMetodo.Count > 0)
                {
                    foreach (ClassListMethod m in removerMetodo)
                        metodosMinuta.Remove(m);
                }
            }

            cmb_ListMethod.DataSource = metodosMinuta;
            cmb_ListMethod.Visible = (cmb_ListMethod.Items.Count > 1);      // sempre é adicionado o campo vazio, por isso >1
            label_ListMethod.Visible = (cmb_ListMethod.Items.Count > 1);
            btnPlayMethod.Visible = (cmb_ListMethod.Items.Count > 1);
            if (cmb_ListMethod.Visible)
                cmb_ListMethod.SelectedValue = 0;
            #endregion

            SalvandoServiço = false;
            if (cbAtualizar.Checked != AtualizarCampos)
            {
                cbAtualizar.Checked = AtualizarCampos;
            }
            else
            {
                MontarCamposServiço(cbAtualizar.Checked, _listaCamposServico);
            }
            if (cbAtualizar.Checked)
            {
                cbAtualizar.Visible = false;
            }
        }

        private void MontarCamposServiço(bool camposAtivos = false, List<Campos> c = null)
        {
            //tabControlServico.TabPages.Clear();
            if (c == null || c.Count == 0)
            {
                _listaCamposServico = TelaDinamica.RecuperarServico(_listaCamposServico, _Responsavel.ID_Servico);
                c = new List<Campos>();
                c = _listaCamposServico;

                if (_listaCamposServico.Exists(n => n.CampoTipo.ToUpper() == "TABELAGERAL" || n.CampoTipo.ToUpper() == "TABELA"))
                {
                    if (_listaCamposServico.Exists(n => n.CampoTipo.ToUpper() == "TABELAGERAL"))
                    {
                        _camposTabela = TelaDinamica.RecuperarServico(_camposTabela, _Responsavel.ID_Servico, true);
                    }
                    else
                    {
                        _camposTabela = TelaDinamica.RecuperarServico(_camposTabela, _Responsavel.ID_Servico, false);
                    }
                }

            }
            TelaDinamica.MontarFormulario(c, this, tabControlServico, camposAtivos, _camposTabela,  519, 1175);
        }

        private void btnSalvarServico_Click(object sender, EventArgs e)
        {
            btnSalvarServico.Enabled = false;
            this.btnConcluirServico.Enabled = false;
            this.Cursor = Cursors.WaitCursor;

            try
            {
                msgLog = "Salvando dados do servico: Objeto " + _Responsavel.ID_Objeto + " / Serviço " + _Responsavel.ID_Servico + ".";
                Log.GravaLog(msgLog);

                var tupla = TelaDinamica.ValidarCamposObrigatorios(_listaCamposServico, tabControlServico, false, _camposTabela);
                var tupla2 = TelaDinamica.ValidarTIPOSCampos(_listaCamposServico, tabControlServico, _camposTabela);
                if (tupla.Item1 && tupla2.Item1)
                {
                    DataAccess.AtualizarDadosCamposGenerico(_listaCamposServico, tabControlServico, _Responsavel.ID_Servico, "", _camposTabela);
                    MessageBox.Show("Registro salvo com sucesso!");
                    SalvandoServiço = true;
                    this.cbAtualizar.Checked = false;
                }
                else
                {
                    if (tupla.Item1 == false)
                    {
                        MessageBox.Show(tupla.Item2);
                    }
                    else if (tupla2.Item1 == false)
                    {
                        MessageBox.Show(tupla2.Item2);
                    }
                    btnSalvarServico.Enabled = true;
                }

                #region [ Atualiza Métodos ]
                List<ClassListMethod> metodosMinuta = _Metodos;
                List<ClassListMethod> l = metodosMinuta.Where(n => n.CriterioCampo != "").ToList();
                if (l.Count > 0)
                {
                    DataTable Resp = TratamentoCampo.ConvertObjectToDataTable(_Responsavel);
                    List<ClassListMethod> removerMetodo = new List<ClassListMethod>();
                    foreach (ClassListMethod m in l)
                    {
                        string[] criterios = m.CriterioCampo.Split(';');
                        string[] valores = m.CriterioValor.Split(';');
                        for (int i = 0; i < criterios.Count(); i++)
                        {
                            int IdCampo = 0;
                            if (criterios[i].StartsWith("[") && criterios[i].EndsWith("]"))
                            {
                                criterios[i] = Resp.Rows[0][criterios[i].Substring(1, criterios[i].Length - 2)].ToString();
                                if (criterios[i].ToUpper() != valores[i].ToUpper())
                                {
                                    removerMetodo.Add(m);
                                    break;
                                }
                            }
                            else if (int.TryParse(criterios[i], out IdCampo))
                            {
                                if (!_listaCamposServico.Exists(n => n.ID_Campo == IdCampo && n.ValorCampo.ToUpper() == valores[i].ToUpper()))
                                {
                                    removerMetodo.Add(m);
                                    break;
                                }
                            }
                        }
                    }

                    if (removerMetodo.Count > 0)
                    {
                        foreach (ClassListMethod m in removerMetodo)
                            metodosMinuta.Remove(m);
                    }
                }

                cmb_ListMethod.DataSource = metodosMinuta;
                cmb_ListMethod.Visible = (cmb_ListMethod.Items.Count > 1);      // sempre é adicionado o campo vazio, por isso >1
                label_ListMethod.Visible = (cmb_ListMethod.Items.Count > 1);
                btnPlayMethod.Visible = (cmb_ListMethod.Items.Count > 1);
                #endregion

                cbAtualizar.Visible = true;
            }
            catch (Exception exp)
            {
                MessageBox.Show("Erro ao salvar registro. Erro: " + exp.Message);
            }
            this.btnConcluirServico.Enabled = true;
            this.Cursor = Cursors.Default;

        }

        private void cbAtualizar_CheckedChanged(object sender, EventArgs e)
        {
            btnSalvarServico.Enabled = cbAtualizar.Checked;

            if (!SalvandoServiço)
            {
                MontarCamposServiço(cbAtualizar.Checked, _listaCamposServico);
            }
            else
            {
                SalvandoServiço = false;
                MontarCamposServiço(cbAtualizar.Checked);
            }
        }

        private void btnConcluirServico_Click(object sender, EventArgs e)
        {
            msgLog = "Concluindo Serviço. Servico: Objeto " + _Responsavel.ID_Objeto + " / Serviço " + _Responsavel.ID_Servico + ".";
            Log.GravaLog(msgLog);

            if (MessageBox.Show("Confirma conclusão do serviço?", "Contratos", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                DataAccess.ConcluirServico(_Responsavel.ID_Servico);
                MessageBox.Show("Serviço concluído com sucesso.", "Mobios", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cbAtualizar.Checked = false;
                cbAtualizar.Visible = false;
                this.Close();
            }
            else
            {
                MessageBox.Show("Serviço concluído com sucesso.", "Mobios", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void btnResumo_Click(object sender, EventArgs e)
        {
            Form frm = new Resumo(_Responsavel);
            frm.MdiParent = this.MdiParent;
            frm.WindowState = FormWindowState.Normal;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Left = 0;
            frm.Top = 0;
            frm.Show();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("ATENÇÃO: Confirma exclusão do serviço?", "Mobios", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                try
                {
                    DataAccess.ExcluirServico(_Responsavel.ID_Servico);  
                    this.Close();
                    MessageBox.Show("Serviço excluído com sucesso!");
                }
                catch (Exception exp)
                {
                    MessageBox.Show("Erro ao tentar deletar registro. Erro: " + exp.Message);
                }
            }
        }

        private void btnCancelarServico_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Confirma cancelamento do serviço?", "Mobios", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                DataAccess.CancelarServico(_Responsavel.ID_Servico);
                MessageBox.Show("Serviço cancelado.");
                cbAtualizar.Checked = false;
                cbAtualizar.Visible = false;
                this.Close();
            }
        }

        private void btnImportarBoleto_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(cbBoletador.SelectedValue) != 0)
            {
                try
                {
                    Boletador bol = (Boletador)(cbBoletador.SelectedItem);
                    if (bol.NomeMetodo != "")
                    {
                        CustomMethod.ChamarMetodo(bol.NomeMetodo, CustomMethod.MethodForm.Minutas);
                    }
                    //tabControlServico.TabPages.Clear();
                    _listaCamposServico = DataAccess.buscarCamposDinamicosConjunto(_Responsavel.ID_Servico, _IdMetodoCampos);      // Preenche a tela com campos do serviço;
                    TelaDinamica.MontarFormulario(_listaCamposServico, this, tabControlServico, false, _camposTabela, 519, 1175);
                }
                catch (Exception Excep)
                {
                    msgLog = "Erro ao chamar serviço de importação.\n\nErro: " + Excep.Message;
                    Log.GravaLog(msgLog);
                    MessageBox.Show(msgLog);
                }
            }
            else
            {
                MessageBox.Show("Escolha a forma de importação.", "Mobios", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        #region [ Retorno ao Pipeline ]
        private void Minutas_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (SharedData.isOpenForm(typeof(Pipeline), false, false))
            {
                ((Pipeline)Application.OpenForms["Pipeline"]).Bind();
            }
        }
        #endregion
       
        private void btnPlayMethod_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbAtualizar.Checked == false)
                {
                    if (cmb_ListMethod.SelectedValue.ToString() != "")
                    {
                        if (MessageBox.Show("Executar " + cmb_ListMethod.Text.ToString() + "?", "Método", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            _MyMethod = new ClassListMethod();
                            _MyMethod = (Mobios.ClassListMethod)(cmb_ListMethod.SelectedItem);

                            string _MethodName = cmb_ListMethod.SelectedValue.ToString();

                            CustomMethod.ChamarMetodo(_MethodName, CustomMethod.MethodForm.Minutas);

                            #region [ Follow-Up ]
                            if (_MyMethod.MethodFUP == true && _IdEtapa != 0)
                            {
                                FollowUp FollowUpMetodo = new FollowUp();
                                FollowUpMetodo.ID_Servico = _Responsavel.ID_Servico;
                                FollowUpMetodo.ID_Fluxo = _IdEtapa;
                                FollowUpMetodo.FollowUpEtapa = _MyMethod.MethodDescricao;
                                DataAccess.RegistrarFollowUpEtapaServico(FollowUpMetodo, false);
                            }
                            #endregion

                            //tabControlServico.TabPages.Clear();
                            _listaCamposServico = DataAccess.buscarCamposDinamicosConjunto(_Responsavel.ID_Servico, _IdMetodoCampos);      // Preenche a tela com campos do serviço;
                            TelaDinamica.MontarFormulario(_listaCamposServico, this, tabControlServico, false, _camposTabela, 519, 1175);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Salve os campos primeiro.", "Método", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "Métodos", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

