﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mobios
{
    public partial class Ptax : Form
    {
        int _ID_CAMPO = 0;
        ResponsavelServico _sv = null;
        public Ptax(ResponsavelServico sv = null, int ID_CAMPO = 0)
        {
            InitializeComponent();
            _ID_CAMPO = ID_CAMPO;
            this.dateTimePicker1.Value = DateTime.Now;
            monta_ptax(TratamentoSQL.ReturnDataCurtaSQL(DateTime.Now));
            _sv = sv;
            if (sv != null)
            {
                this.button_salvar_ptax_operacao.Text = "Salvar Ptax na operação ID: " + sv.ID_Servico.ToString() + " | " + sv.ServicoName.ToString();
                this.button_salvar_ptax_operacao.Visible = true;
            }
            else
            {
                this.button_salvar_ptax_operacao.Visible = false;
            }
        }
        private void monta_ptax(string Data)
        {
            Panel me = this.panel1;
            foreach (Control item in me.Controls.OfType<Control>())
            {
                if (item.Name == "Ptax")
                    panel1.Controls.Remove(item);
            }

            DataGridView tbl = new DataGridView();
            tbl = ProcessaPtax.Ptax(136, "Ptax", 1, 1, 1, 400, 400, true, true, "[Data=#" + Data.ToString() + "#]DATA;MOEDA;PTAX");
            me.Controls.Add(tbl);
            tbl.Dock = DockStyle.Fill;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {

            #region [ TabelaGeral ]
            Panel me = this.panel1;

            DataGridView valueDataGrid = new DataGridView();
            valueDataGrid = (DataGridView)me.Controls["Ptax"];

            DateTime MinhaData = new DateTime();
            MinhaData = this.dateTimePicker1.Value;

            string sqlDT = "";
            int linha = DataAccess.BuscarTabelaMaiorLinha(136); //Pegando linha máxima

            //Pega as linhas que devem ser substituidas, filtro por data.
            DataTable Dt_LinhasPtax_a_Excluir = new DataTable();
            Dt_LinhasPtax_a_Excluir = DataAccess.BuscarLinhasPtaxByData(136, MinhaData.ToShortDateString());

            //Deletando linhas
            if (Dt_LinhasPtax_a_Excluir.Rows.Count > 0)
            {
                for (int i = 0; i < Dt_LinhasPtax_a_Excluir.Rows.Count; i++)
                {
                    string sqlDelete = string.Format("delete from tb_0134_DadosTabela where Linha='{0}'", Dt_LinhasPtax_a_Excluir.Rows[i]["Linha"].ToString());
                    DataConnector.ExecuteDataTable(sqlDelete, "BDconsulta");
                }
            }


            //Gravando Novas linhas que estão no DataGridView

            List<CamposTabela> camposTabela = DataAccess.BuscarCamposTabela();

            foreach (DataGridViewRow linhaDT in valueDataGrid.Rows)
            {
                foreach (DataGridViewColumn colunaDT in valueDataGrid.Columns)
                {
                    if (colunaDT.Name != "Linha" && valueDataGrid[colunaDT.Index, linhaDT.Index].Value != null && valueDataGrid[colunaDT.Index, linhaDT.Index].Value.ToString() != "")
                    {
                        string Dominio = "";
                        string vlrCampo = "";
                        List<CamposTabela> camposTbl = camposTabela.Where(n => n.ID_Campo == 136 && n.CampoNome == colunaDT.Name).ToList();

                        if (camposTbl.Count() > 0)
                        {
                            Dominio = camposTbl[0].CampoDominio;
                            vlrCampo = TelaDinamica.FormatarValorCampo(Dominio, valueDataGrid[colunaDT.Index, linhaDT.Index].Value.ToString());
                        }
                        else
                        {
                            vlrCampo = valueDataGrid[colunaDT.Index, linhaDT.Index].Value.ToString();
                        }
                        sqlDT = string.Format("Insert Into tb_0134_DadosTabela (IdCampo, NomeTabela, Linha, NomeCampo, ValorCampo) Values ({0},'{1}','{2}','{3}','{4}')", 136, "Ptax", linha.ToString(), colunaDT.Name, vlrCampo);
                        DataConnector.ExecuteDataTable(sqlDT, "BDconsulta");
                    }
                }
                linha++;
            }

            #endregion
            monta_ptax(TratamentoSQL.ReturnDataCurtaSQL(dateTimePicker1.Value));
            MessageBox.Show("Ptax salvo", "Salvo", MessageBoxButtons.OK);

        }

        private void button_salvar_ptax_operacao_Click(object sender, EventArgs e)
        {
            #region [ Tabela ]
            var response = MessageBox.Show("Atenção!!!\n\nEsta ação substituirá os dados Ptax já gravados para a operação ID: " + _sv.ID_Servico.ToString() + " | " + _sv.ServicoName, "Apagar", MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (response == DialogResult.OK)
            {
                DataAccess.DeletarTodasLinhasDadosTabelaByServico("tb_0134_DadosTabela", "BDconsulta", _ID_CAMPO, _sv.ID_Servico);

                Panel me = this.panel1;
                DataGridView valueDataGrid = new DataGridView();
                valueDataGrid = (DataGridView)me.Controls["Ptax"];

                string sqlDT = "";
                int linha = DataAccess.BuscarTabelaMaiorLinha(_ID_CAMPO, _sv.ID_Servico);
                foreach (DataGridViewRow linhaDT in valueDataGrid.Rows)
                {
                    foreach (DataGridViewColumn colunaDT in valueDataGrid.Columns)
                    {
                        if (colunaDT.Name != "Linha" && valueDataGrid[colunaDT.Index, linhaDT.Index].Value != null && valueDataGrid[colunaDT.Index, linhaDT.Index].Value.ToString() != "")
                        {
                            sqlDT = string.Format("Insert Into tb_0134_DadosTabela (IdServico, IdCampo, NomeTabela, Linha, NomeCampo, ValorCampo) Values ({0},{1},'{2}','{3}','{4}','{5}')", _sv.ID_Servico, _ID_CAMPO, "PtaxOperacao", linha.ToString(), colunaDT.Name, valueDataGrid[colunaDT.Index, linhaDT.Index].Value.ToString());
                            DataConnector.ExecuteDataTable(sqlDT, "BDconsulta");
                        }
                    }
                    linha++;
                }

            #endregion

                MessageBox.Show("Ptax salvo na operação ID: " + _sv.ID_Servico + " | " + _sv.ServicoName, "Salvo", MessageBoxButtons.OK,MessageBoxIcon.Information);
                this.Close();
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            monta_ptax(TratamentoSQL.ReturnDataCurtaSQL(dateTimePicker1.Value));
        }
    }
}
