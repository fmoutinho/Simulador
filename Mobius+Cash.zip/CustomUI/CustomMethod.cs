﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.InfoPath;
using System.Configuration;
using System.Reflection;
using System.Data;
using System.Xml;
using System.ComponentModel;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;

namespace Mobios
{
    public class CustomMethod
    {
        public static MethodForm _CallerForm;

        public enum MethodForm
        {
            Main = 0,
            Detalhe = 1,
            Minutas = 2,
            RegistrarOperacao = 3,
            MainBackGround = 4,
            FollowUp = 5,
            Pipeline = 6
        }

        public static void ChamarMetodo(string NomeMetodo, MethodForm CallerForm, object[] CustomParameters = null) //object obj, string NomeMetodo
        {
            _CallerForm = CallerForm;

            Type t = typeof(CustomMethod);
            MethodInfo mMethod = t.GetMethod(NomeMetodo);
            ParameterInfo[] parameters = mMethod.GetParameters();
            int size = parameters.Length;
            object[] parametersArray = new object[size];

            if (CustomParameters != null)
            {
                parametersArray = CustomParameters;
            }

            if (mMethod != null)
            {
                if (mMethod.IsStatic)
                {
                    mMethod.Invoke(null, parameters.Length == 0 ? null : parametersArray);
                }
                else
                {
                    MessageBox.Show(string.Format("Método [{0}] configurado precisa ser estático", NomeMetodo));
                }
            }
            else
            {
                MessageBox.Show(string.Format("Método [{0}] não existe.\nFavor configurar corretamente a tabela de métodos [tb_0400_Method].\nObservação: O Nome do método é Case Sensitive.", NomeMetodo), "Configuração", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
        }

        public static void Upload()
        {
            int IdServico = 0;
            string Diretorio = "";

            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                        IdServico = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel.ID_Servico;
                        Diretorio = ((Detalhe)Application.OpenForms["Detalhe"])._MyMethod.MethodParametro;
                    }
                    break;
            }

            if (SharedData.gHomologação)
            {
                Diretorio = SharedData.BDPath + "Documentos\\";
            }
            else
            {
                Diretorio = TratamentoCampo.AdicionaBarraPath(Diretorio);
            }

            string diretorio = Diretorio + IdServico;
            if (!File.Exists(diretorio))
            {
                Log.CriaDiretorioRede(diretorio);
            }
            System.Diagnostics.Process.Start(diretorio);
        }

        public static void MoveFolder()
        {
            int IdServico = 0;
            string[] Diretorio = new string[1];

            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                        IdServico = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel.ID_Servico;
                        Diretorio = ((Detalhe)Application.OpenForms["Detalhe"])._MyMethod.MethodParametro.Split(';');
                    }
                    break;
            }

            if (SharedData.gHomologação)
            {
                Diretorio[0] = SharedData.BDPath + "Documentos\\";
                Diretorio[1] = SharedData.BDPath + "Processados\\";
            }
            else
            {
                Diretorio[0] = TratamentoCampo.AdicionaBarraPath(Diretorio[0]);
                Diretorio[1] = TratamentoCampo.AdicionaBarraPath(Diretorio[1]);
            }
            Log.CriaDiretorioRede(Diretorio[1]);

            string diretorioOrigem = Diretorio[0] + IdServico;
            string diretorioDestino = Diretorio[1] + IdServico;

            try
            {
                if (Directory.Exists(diretorioOrigem))
                {
                    Log.MoveDiretorio(diretorioOrigem, diretorioDestino);
                    System.Diagnostics.Process.Start(diretorioDestino);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Houve um erro ao transferir a pasta de documentos.\n\nConsulte a pasta de número " + IdServico + " no diretório: " + diretorioOrigem + "\n\n" + "Mensagem de Erro: " + e.Message);
                if (Directory.Exists(diretorioOrigem))
                {
                    System.Diagnostics.Process.Start(diretorioOrigem);
                }
            }
        }

        public static void AtualizaStatusSharepoint()
        {
            try
            {
                #region [ Busca parametros do método ]
                ClassListMethod Metodo = new ClassListMethod();
                ResponsavelServico ResponsavelServico = new ResponsavelServico();
                List<Campos> CamposServico = new List<Campos>();
                List<Campos> CamposEtapa = new List<Campos>();

                switch (_CallerForm)
                {
                    case MethodForm.Minutas:
                        if (SharedData.isOpenForm(typeof(Minutas), false))
                        {
                            Metodo = ((Minutas)Application.OpenForms["Minutas"])._MyMethod;
                            ResponsavelServico = ((Minutas)Application.OpenForms["Minutas"])._Responsavel;
                            CamposServico = ((Minutas)Application.OpenForms["Minutas"])._listaCamposServico;
                        }
                        break;
                    case MethodForm.Main:
                        if (SharedData.isOpenForm(typeof(MainForm), false))
                        {
                        }
                        break;
                    case MethodForm.Detalhe:
                        if (SharedData.isOpenForm(typeof(Detalhe), false))
                        {
                            Metodo = ((Detalhe)Application.OpenForms["Detalhe"])._MyMethod;
                            ResponsavelServico = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel;
                            CamposServico = ((Detalhe)Application.OpenForms["Detalhe"])._listaCamposServico;
                            CamposEtapa = ((Detalhe)Application.OpenForms["Detalhe"])._listaCamposEtapas;
                        }
                        break;
                }

                CamposServico.AddRange(CamposEtapa);
                #endregion

                DataTable Resp = TratamentoCampo.ConvertObjectToDataTable(ResponsavelServico);
                string[] CamposCriterio = Metodo.SharePointCriterio.Split(';');
                string[] ValoresCriterio = Metodo.MobiosCriterio.Split(';');
                string[] TipoCriterio = Metodo.TipoCriterio.Split(';');
                string[] CamposRetornar = { "ID" };

                #region [ Busca Valores Critérios ]
                int IdCampo = 0;
                for (int i = 0; i < ValoresCriterio.Count(); i++)
                {
                    if (ValoresCriterio[i].StartsWith("'") && ValoresCriterio[i].EndsWith("'"))
                    {
                        ValoresCriterio[i] = ValoresCriterio[i].Replace("'", "");
                    }
                    else if (ValoresCriterio[i].StartsWith("[") && ValoresCriterio[i].EndsWith("]"))
                    {
                        ValoresCriterio[i] = Resp.Rows[0][ValoresCriterio[i].Substring(1, ValoresCriterio[i].Length - 2)].ToString();
                    }
                    else if (int.TryParse(ValoresCriterio[i], out IdCampo))
                    {
                        Campos c = CamposServico.Find(n => n.ID_Campo == IdCampo);

                        if (c != null)
                        {
                            ValoresCriterio[i] = c.ValorCampo;
                        }
                    }
                }
                #endregion

                if (CamposCriterio.Count() == ValoresCriterio.Count() && CamposCriterio.Count() == TipoCriterio.Count())
                {
                    XmlNode RetornoSP = SharePoint.GetListItem(Metodo.SharepointTabelaGUID, Metodo.SharepointSite, CamposCriterio, ValoresCriterio, TipoCriterio, CamposRetornar);

                    #region [ Retorna ID SharePoint ]
                    int IdSP = 0;
                    foreach (System.Xml.XmlNode listItem in RetornoSP)
                    {
                        if (listItem.Name == "rs:data")
                        {

                            for (int f = 0; f < listItem.ChildNodes.Count; f++)
                            {
                                if (listItem.ChildNodes[f].Name == "z:row")
                                {
                                    IdSP = Convert.ToInt32(listItem.ChildNodes[f].Attributes["ows_ID"].Value);
                                }
                            }
                        }
                    }
                    #endregion

                    if (IdSP != 0)
                    {
                        bool atualizaValor = true;
                        if (SharedData.gHomologação)
                        {
                            if (MessageBox.Show("Atualizar o status no SharePoint?\n\nProssiga apenas se for um registro de teste.", "Atualiza Status SharePoint", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
                            {
                                atualizaValor = false;
                            }
                        }

                        if (atualizaValor)
                        {

                            if (Metodo.SharepointCampos != "")
                                Metodo.SharepointCampos += ";";
                            if (Metodo.MobiosCampos != "")
                                Metodo.MobiosCampos += ";";

                            Metodo.SharepointCampos += "ID";
                            Metodo.MobiosCampos += "'" + IdSP + "'";

                            string[] CampoAtualizarSPArray = Metodo.SharepointCampos.Split(';');
                            string[] ValorAtualizarSPArray = Metodo.MobiosCampos.Split(';');

                            #region [ Busca Valores Critérios ]
                            IdCampo = 0;
                            for (int i = 0; i < ValorAtualizarSPArray.Count(); i++)
                            {
                                if (ValorAtualizarSPArray[i].StartsWith("'") && ValorAtualizarSPArray[i].EndsWith("'"))
                                {
                                    ValorAtualizarSPArray[i] = ValorAtualizarSPArray[i].Replace("'", "");
                                }
                                else if (ValorAtualizarSPArray[i].StartsWith("[") && ValorAtualizarSPArray[i].EndsWith("]"))
                                {
                                    ValorAtualizarSPArray[i] = Resp.Rows[0][ValorAtualizarSPArray[i]].ToString();
                                }
                                else if (int.TryParse(ValorAtualizarSPArray[i], out IdCampo))
                                {
                                    Campos c = CamposServico.Find(n => n.ID_Campo == IdCampo);

                                    if (c != null)
                                    {
                                        ValorAtualizarSPArray[i] = c.ValorCampo;
                                    }
                                }
                            }
                            #endregion

                            if (CampoAtualizarSPArray.Count() == ValorAtualizarSPArray.Count())
                            {
                                SharePoint.GravarRegistro(Metodo.SharepointSite, Metodo.SharepointTabelaGUID, CampoAtualizarSPArray, ValorAtualizarSPArray, "UPDATE");
                            }
                        }
                    }
                }
                else
                {
                    throw new Exception("A quantidade de critérios (Campo | Valor | Tipo) está inconsistente para se realizar a integração com sharepoint");
                }
            }
            catch (Exception errSP)
            {
                Log.GravaLog("Erro: " + errSP.Message);
                MessageBox.Show("Ocorreu uma falha ao tentar integrar com os SharePoints.\n\nVerifique se o status foi alterado no SharePoint correspondente.\n\nErro: " + errSP.Message);
            }
        }

        public static void AbreFormEmail()
        {
            List<ClassListEmail> parmsEmailsFound = null;
            string parmBody = null;
            string IdServico = null;
            string IdEtapa = null;
            string IdCampo = null;
            string chaveTimeStamp = null;
            string NomeObjeto = null;
            string identificacao = null;

            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                        chaveTimeStamp = DateTime.Now.ToString("yyyyMMddHHmmssffff");
                        parmsEmailsFound = DataAccess.RetornaParametrosFormEmail(((Detalhe)Application.OpenForms["Detalhe"])._MyMethod.MethodParametro);
                        IdServico = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel.ID_Servico.ToString();
                        IdEtapa = ((Detalhe)Application.OpenForms["Detalhe"])._Etapa.ID_Etapa.ToString();
                        NomeObjeto = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel.NomeObjeto;
                        identificacao = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel.ServicoName;


                        #region [ Parametros ]
                        parmBody = "<table border=0 cellspacing=0 cellpadding=2 width=450><tr><td colspan=2 width=450><font color=#003399><b>" + parmsEmailsFound[0].emailBodyHeaderInfoOp + "</b></font></td></tr>";

                        // Dados da operação
                        if (((Detalhe)Application.OpenForms["Detalhe"])._MyMethod.MethodCamposServicoBody.ToString() != "")
                        {
                            string[] camposServicos = ((Detalhe)Application.OpenForms["Detalhe"])._MyMethod.MethodCamposServicoBody.Split(';');
                            for (int i = 0; i < camposServicos.Count(); i++)
                            {
                                List<Campos> valorCampo = ((Detalhe)Application.OpenForms["Detalhe"])._listaCamposServico.FindAll(element => element.ID_Campo == Convert.ToInt32(camposServicos[i]));
                                if (valorCampo.Count > 0)
                                {
                                    switch (valorCampo[0].CampoTipo.ToUpper())
                                    {
                                        case "CHECKBOX":
                                            if (valorCampo[0].ValorCampo == "True")
                                            {
                                                parmBody += "<tr bgcolor=#fffff ><td align=right valign=middle width=250>&nbsp;</td><td td align=left valign=middle width=200>" + valorCampo[0].CampoLabel + "</td></tr>";
                                            };
                                            break;
                                        case "LABEL":
                                            parmBody += "<tr bgcolor=#fffff ><td colspan=2 align=middle valign=middle width=450><b>" + valorCampo[0].CampoNome + "</b></td></tr>";
                                            break;
                                        default:
                                            if (valorCampo[0].ValorCampo != "" && valorCampo[0].ValorCampo != null)
                                            {
                                                parmBody += "<tr bgcolor=#fffff ><td align=right valign=middle width=250>" + valorCampo[0].CampoLabel + ":</td><td td align=left valign=middle width=200>" + valorCampo[0].ValorCampo + "</td></tr>";
                                            }
                                            break;
                                    }
                                }

                            }
                            parmBody += "</table><br>";
                        }
                        // Dados da etapa da operação
                        if (((Detalhe)Application.OpenForms["Detalhe"])._MyMethod.MethodCamposEtapasBody.ToString() != "")
                        {
                            parmBody += "<table border=0 cellspacing=0 cellpadding=2 width=450><tr><td colspan=2 width=450><font color=#003399><b>" + parmsEmailsFound[0].emailBodyHeaderInfoEtapa + "</b></font></td></tr>";
                            string[] camposEtapas = ((Detalhe)Application.OpenForms["Detalhe"])._MyMethod.MethodCamposEtapasBody.Split(';');
                            for (int i = 0; i < camposEtapas.Count(); i++)
                            {
                                List<Campos> valorCampoEtapa = ((Detalhe)Application.OpenForms["Detalhe"])._listaCamposEtapas.FindAll(element => element.ID_Campo == Convert.ToInt32(camposEtapas[i]));
                                if (valorCampoEtapa.Count > 0)
                                {
                                    switch (valorCampoEtapa[0].CampoTipo.ToUpper())
                                    {
                                        case "CHECKBOX":
                                            if (valorCampoEtapa[0].ValorCampo == "True")
                                            {
                                                parmBody += "<tr bgcolor=#fffff ><td align=right valign=middle width=250>&nbsp;</td><td td align=left valign=middle width=200>" + valorCampoEtapa[0].CampoLabel + "</td></tr>";
                                            };
                                            break;
                                        case "LABEL":
                                            parmBody += "<tr bgcolor=#fffff ><td align=right valign=middle width=250>&nbsp;</td><td td align=left valign=middle width=200>" + valorCampoEtapa[0].CampoLabel + "</td></tr>";
                                            break;
                                        default:
                                            if (valorCampoEtapa[0].ValorCampo != "" && valorCampoEtapa[0].ValorCampo != null)
                                            {
                                                parmBody += "<tr bgcolor=#fffff ><td align=right valign=middle width=250>" + valorCampoEtapa[0].CampoLabel + ":</td><td td align=left valign=middle width=200>" + valorCampoEtapa[0].ValorCampo + "</td></tr>"; ;
                                            }
                                            break;
                                    }
                                }
                            }
                            parmBody += "</table><br>";
                        }

                        // Espaço para resposta:
                        if (((Detalhe)Application.OpenForms["Detalhe"])._MyMethod.MethodPergunta.ToString() != "")
                        {
                            parmBody += "<table border=0 cellspacing=1 cellpadding=2 width=450><tr><td colspan=2 width=350><font color=#FF8C00><b>" + parmsEmailsFound[0].emailBodyHeaderResposta + "</b></font></td></tr>";
                            parmBody += "<tr bgcolor=#fffff ><td align=right valign=middle width=250><font color=#FF8C00 size=4><b>" + ((Detalhe)Application.OpenForms["Detalhe"])._MyMethod.MethodPergunta.ToString() + ":</b></font></td><td td align=left valign=middle width=200><font color=#FF8C00 size=4><b>{#" + "&nbsp;" + "#}</b></font></td></tr>";
                            parmBody += "</table><br>";
                        }
                        #endregion

                    }
                    break;
            }




            //1. Busca as configurações de acordo com método e parâmetro;
            string emailBodyScrit = "";
            //2. Formata a mensagem (valores default)       
            string emailSubject = "MOBIOS+ | Operação";                  // Precisa conter padrão para identificação de alertas!!!
            string emailAccount = "";
            string emailBodyHTML = "";
            string emailRodape = "";
            string emailPathAttach = "";
            string emailChaveTimeStamp = "";
            if (chaveTimeStamp == null) { emailChaveTimeStamp = "-" + DateTime.Now.ToString("yyyyMMddHHmmssffff"); } else { emailChaveTimeStamp = "-" + chaveTimeStamp; };

            // Busca informações personalizadas
            //List<ClassListEmail> parmsEmailsFound = DataAccess.RetornaParametrosFormEmail(parmEmail);
            if (parmsEmailsFound != null)
            {
                // Personalizado
                emailBodyScrit = "<html ><style><!--";
                emailBodyScrit += "body {font-family:Calibri;panose-1:2 15 5 2 2 2 4 3 2 4;font-size: 11pt;}";
                emailBodyScrit += "p.MsoNormal, li.MsoNormal, div.MsoNormal	{margin:0cm;	margin-bottom:.0001pt;	font-size:11.0pt;	font-family:'Calibri','sans-serif';	mso-fareast-language:EN-US;}";
                emailBodyScrit += "a:link, span.MsoHyperlink {mso-style-priority:99; color:blue; text-decoration:underline;}";
                emailBodyScrit += "table {font-family:Calibri;panose-1:2 15 5 2 2 2 4 3 2 4;font-size: 11pt;}";
                emailBodyScrit += "--></style><body>";

                emailSubject = parmsEmailsFound[0].emailSubject + " - " + NomeObjeto + " - " + identificacao + " " + "[#" + IdServico + "-" + IdEtapa + "-" + IdCampo + emailChaveTimeStamp + Properties.Settings.Default.EmailAssinatura.Trim();
                emailAccount = parmsEmailsFound[0].emailAccount;

                if (parmsEmailsFound[0].emailSharepointLink != null)
                { emailRodape = parmsEmailsFound[0].emailSharepointLink + "<br>" + parmsEmailsFound[0].emailBodyHTMLFooter; }
                else { parmsEmailsFound[0].emailBodyHTMLFooter = parmsEmailsFound[0].emailBodyHTMLFooter; }

                // Monta Corpo
                emailBodyHTML = emailBodyScrit + @"<img src='\\BBAPROD3\bo\Cambio\processamento de cambio\Comum\Indicadores e Controles\___SistemaMobios\Email\ItauLogo.jpg'><span style='font-size:14pt; color:#000080'><b>Middle Office Offshore</b></span><br><br>" + parmsEmailsFound[0].emailBodyHTMLHeader + emailBodyHTML;
                emailBodyHTML += "<br><br>" + parmsEmailsFound[0].emailBodyHTMLBody + "<br><br>" + parmBody + "<br>" + emailRodape + "<body></html>";
                emailPathAttach = "";
            }
            else
            {
                emailBodyHTML = "Parâmetros para criação do e-mail não especificados.";
            }

            // Chama mensagem de e-mail
            try
            {
                SharedData.CreateMailItem(emailSubject, emailAccount, emailBodyHTML, emailPathAttach, true);
            }
            catch (Exception exEmail)
            {
                MessageBox.Show("Erro ao abrir mensagem de e-mail. Erro: " + exEmail + ".");
            }

        }

        public static void AbreFormMinuta(ResponsavelServico sv = null)
        {
            int IdMetodo = 0;
            string nomeMetodo = "";
            int IdEtapa = 0;
            bool edit = true;

            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                        sv = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel;
                        IdMetodo = ((Detalhe)Application.OpenForms["Detalhe"])._MyMethod.IdMethodForm;
                        bool teste;
                        Boolean.TryParse(((Detalhe)Application.OpenForms["Detalhe"])._MyMethod.MethodParametro, out edit);
                        nomeMetodo = ((Detalhe)Application.OpenForms["Detalhe"])._MyMethod.MethodDescricao;
                        IdEtapa = ((Detalhe)Application.OpenForms["Detalhe"])._Etapa.ID_Etapa;
                    }
                    break;
            }



            if (!SharedData.isOpenForm(typeof(Minutas), true))
            {
                using (Minutas frm = new Minutas(sv, edit, IdMetodo, nomeMetodo, IdEtapa))
                {
                    frm.Left = 0;
                    frm.Top = 0;
                    frm.ShowDialog();
                }
            }
        }

        #region [ importações ]
        public static void AbreFormImportarPDF()
        {
            ResponsavelServico sv = null;
            bool CamposMinutas = false;
            int IdMetodoCampos = 0;

            #region [ referencias ]
            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                        sv = ((Minutas)Application.OpenForms["Minutas"])._Responsavel;
                        CamposMinutas = true;
                        IdMetodoCampos = ((Minutas)Application.OpenForms["Minutas"])._IdMetodoCampos;
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                        sv = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel;
                    }
                    break;
                case MethodForm.RegistrarOperacao:
                    if (SharedData.isOpenForm(typeof(RegistrarOperacao), false))
                    {
                        sv = ((RegistrarOperacao)Application.OpenForms["RegistrarOperacao"])._Responsavel;
                    }
                    break;
            }
            #endregion

            if (!SharedData.isOpenForm(typeof(ImportaArquivos), true))
            {
                using (ImportaArquivos frm = new ImportaArquivos(sv, "PDF", CamposMinutas, IdMetodoCampos))
                {
                    frm.Focus();
                    frm.ShowDialog();
                }
            }
        }
        public static void AbreFormImportarExcel()
        {
            ResponsavelServico sv = null;
            bool CamposMinutas = false;
            int IdMetodoCampos = 0;

            #region [ referencias ]
            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                        sv = ((Minutas)Application.OpenForms["Minutas"])._Responsavel;
                        CamposMinutas = true;
                        IdMetodoCampos = ((Minutas)Application.OpenForms["Minutas"])._IdMetodoCampos;
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                        sv = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel;
                    }
                    break;
                case MethodForm.RegistrarOperacao:
                    if (SharedData.isOpenForm(typeof(RegistrarOperacao), false))
                    {
                        sv = ((RegistrarOperacao)Application.OpenForms["RegistrarOperacao"])._Responsavel;
                    }
                    break;
            }
            #endregion

            if (!SharedData.isOpenForm(typeof(ImportaArquivos), true))
            {
                using (ImportaArquivos frm = new ImportaArquivos(sv, "Excel", CamposMinutas, IdMetodoCampos))
                {
                    frm.Focus();
                    frm.ShowDialog();
                }
            }
        }
        public static void AbreFormImportarBaseExcel()
        {
            ResponsavelServico sv = null;

            #region [ referencias ]
            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                        sv = ((Minutas)Application.OpenForms["Minutas"])._Responsavel;
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                        sv = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel;
                    }
                    break;
                case MethodForm.RegistrarOperacao:
                    if (SharedData.isOpenForm(typeof(RegistrarOperacao), false))
                    {
                        sv = ((RegistrarOperacao)Application.OpenForms["RegistrarOperacao"])._Responsavel;
                    }
                    break;
            }
            #endregion

            if (!SharedData.isOpenForm(typeof(ImportaArquivos), true))
            {
                using (ImportaArquivos frm = new ImportaArquivos(sv, "Base Excel"))
                {
                    frm.Focus();
                    frm.ShowDialog();
                }
            }
        }
        public static void AbreFormImportarBoletoOQ()
        {
            ResponsavelServico sv = null;
            bool CamposMinutas = false;
            int IdMetodoCampos = 0;

            #region [ referencias ]
            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                        sv = ((Minutas)Application.OpenForms["Minutas"])._Responsavel;
                        CamposMinutas = true;
                        IdMetodoCampos = ((Minutas)Application.OpenForms["Minutas"])._IdMetodoCampos;
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                        sv = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel;
                    }
                    break;
                case MethodForm.RegistrarOperacao:
                    if (SharedData.isOpenForm(typeof(RegistrarOperacao), false))
                    {
                        sv = ((RegistrarOperacao)Application.OpenForms["RegistrarOperacao"])._Responsavel;
                    }
                    break;
            }
            #endregion

            if (!SharedData.isOpenForm(typeof(ImportaBoletoOQ), true))
            {
                using (ImportaBoletoOQ frm = new ImportaBoletoOQ(sv, CamposMinutas, IdMetodoCampos))
                {
                    frm.Focus();
                    frm.ShowDialog();
                }
            }
        }
        public static void AbreFormImportarPN()
        {
            ResponsavelServico sv = null;
            bool CamposMinutas = false;
            int IdMetodoCampos = 0;

            #region [ referencias ]
            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                        sv = ((Minutas)Application.OpenForms["Minutas"])._Responsavel;
                        CamposMinutas = true;
                        IdMetodoCampos = ((Minutas)Application.OpenForms["Minutas"])._IdMetodoCampos;
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                        sv = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel;
                    }
                    break;
                case MethodForm.RegistrarOperacao:
                    if (SharedData.isOpenForm(typeof(RegistrarOperacao), false))
                    {
                        sv = ((RegistrarOperacao)Application.OpenForms["RegistrarOperacao"])._Responsavel;
                    }
                    break;
            }
            #endregion

            if (!SharedData.isOpenForm(typeof(ImportaPN), true))
            {
                using (ImportaPN frm = new ImportaPN(sv, CamposMinutas, IdMetodoCampos))
                {
                    frm.Focus();
                    frm.ShowDialog();
                }
            }
        }
        public static void AbreFormImportarBEN()
        {
            ResponsavelServico sv = null;
            bool CamposMinutas = false;
            int IdMetodoCampos = 0;

            #region [ referencias ]
            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                        sv = ((Minutas)Application.OpenForms["Minutas"])._Responsavel;
                        CamposMinutas = true;
                        IdMetodoCampos = ((Minutas)Application.OpenForms["Minutas"])._IdMetodoCampos;
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                        sv = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel;
                    }
                    break;
                case MethodForm.RegistrarOperacao:
                    if (SharedData.isOpenForm(typeof(RegistrarOperacao), false))
                    {
                        sv = ((RegistrarOperacao)Application.OpenForms["RegistrarOperacao"])._Responsavel;
                    }
                    break;
            }
            #endregion

            if (!SharedData.isOpenForm(typeof(ImportaBEN), true))
            {
                using (ImportaBEN frm = new ImportaBEN(sv, CamposMinutas, IdMetodoCampos))
                {
                    frm.Focus();
                    frm.ShowDialog();
                }
            }
        }
        public static void IntegrarWeb(string user = "", string password = "")
        {
            string Metodo = "";
            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                        Metodo = ((Minutas)Application.OpenForms["Minutas"])._MyMethod.MethodParametro;
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                    }
                    break;
            }

            string[] MetodoSplit = Metodo.Split(';');
            Metodo = MetodoSplit[0];

            if (Metodo != "")
            {
                WebCustom webCustom = new WebCustom(Metodo, _CallerForm, user, password, false);
            }
        }
        #endregion

        #region [ Mobios Coleta ]
        public static void AbreFormColeta()
        {
            using (Form frm = new FluxoColetaNumerario())
            {
                //frm.MdiParent = this;
                frm.WindowState = FormWindowState.Normal;
                frm.Left = 0;
                frm.Top = 0;
                frm.ShowDialog();
            }
        }

        public static string ReturnPathBaseColeta(string DB)
        {
            string connectionString = string.Empty;

            if (SharedData.gHomologação)
            {
                DB = DB + "Homologacao";
            }
            connectionString = string.Format(SharedData.BDPath + ConfigurationManager.ConnectionStrings[DB].ConnectionString);

            return connectionString;
        }
        public static String GetParametroFromColeta(String PAR_NOME)
        {
            DataTable dt = new DataTable();
            string SQL = "";
            SQL = "select PAR_DESCRICAO from COLETA_PARAMETRO where PAR_NOME='" + PAR_NOME + "'";
            dt = ReturnDTFromBaseColeta(SQL);
            string retorno = "";
            if (dt != null && dt.Rows.Count > 0)
            {
                retorno = dt.Rows[0]["PAR_DESCRICAO"].ToString();
            }
            return retorno;
        }
        public static DataTable ReturnDTFromBaseColeta(string SQL)
        {
            string caminhoDB = ReturnPathBaseColeta("BDconsulta");
            DataTable dt = new DataTable();
            try
            {
                Gibinho.Data _Data = new Gibinho.Data(caminhoDB, true);
                dt = _Data.ObterTabela(SQL);
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Function ReturnDT - Erro de acesso a base de dados\n" + ex.Message);
                return null;
            }


        }
        public static bool SetDataOnBaseColeta(string SQL)
        {
            string caminhoDB = ReturnPathBaseColeta("BDconsulta");

            try
            {
                Gibinho.Data _Data = new Gibinho.Data(caminhoDB, true);
                _Data.ExecutarAcao(SQL);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Function ReturnDT - Erro de acesso a base de dados\n" + ex.Message);
                return false;
            }


        }
        #endregion

        #region [ Mobios Contratação Trade Finance ]
        public static void AbreFormGeraMinutas()
        {
            ResponsavelServico sv = new ResponsavelServico();
            List<Campos> Campos = new List<Campos>();
            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                        sv = ((Minutas)Application.OpenForms["Minutas"])._Responsavel;
                        Campos = ((Minutas)Application.OpenForms["Minutas"])._listaCamposServico;
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                    }
                    break;
            }



            if (!SharedData.isOpenForm(typeof(GeraMinutas), true))
            {
                using (GeraMinutas frm = new GeraMinutas(sv, Campos))
                {
                    frm.Left = 0;
                    frm.Top = 0;
                    frm.ShowDialog();
                }
            }
        }

        public static void AbreFormPtax()
        {
            ResponsavelServico sv = null;
            int IDCAMPO_PTAXOPERACAO = 0;

            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                        sv = ((Minutas)Application.OpenForms["Minutas"])._Responsavel;
                        IDCAMPO_PTAXOPERACAO = ((Minutas)Application.OpenForms["Minutas"])._MyMethod.MethodCampoID; //Id do campo de tabela Ptax das demandas
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                        sv = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel;
                        IDCAMPO_PTAXOPERACAO = ((Detalhe)Application.OpenForms["Detalhe"])._MyMethod.MethodCampoID; //Id do campo de tabela Ptax das demandas
                    }
                    break;
            }


            if (!SharedData.isOpenForm(typeof(Ptax), true))
            {

                if (sv != null)
                {
                    using (Ptax frm = new Ptax(sv, IDCAMPO_PTAXOPERACAO))
                    {
                        frm.Left = 0;
                        frm.Top = 0;
                        frm.ShowDialog();
                    }
                }
                else
                {
                    using (Ptax frm = new Ptax())
                    {
                        frm.Left = 0;
                        frm.Top = 0;
                        frm.ShowDialog();
                    }
                }
            }
        }
        #endregion

        #region [ Mobios Moeda Estrangeira - Offshore]
        public static void IntegraSharePointContratos()
        {
            List<Campos> DadosOperacao = null;
            List<Campos> DadosEtapa = null;
            ResponsavelServico Responsavel = null;


            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                        Responsavel = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel;
                        DadosOperacao = ((Detalhe)Application.OpenForms["Detalhe"])._listaCamposServico;
                        DadosEtapa = ((Detalhe)Application.OpenForms["Detalhe"])._listaCamposEtapas;
                    }
                    break;
            }

            List<Campos> DadosTodasEtapas = new List<Campos>();
            DadosTodasEtapas = DataAccess.buscarCamposEtapaConjunto(Responsavel.ID_Servico);  // tornar mais rapido
            IntegraSharePointInfoPath(DadosOperacao, DadosEtapa, Responsavel, "Contratos Internacionais", DadosTodasEtapas);
            System.Diagnostics.Process.Start(DataAccess.BuscaURLsharepoint("Contratos Internacionais", Responsavel.ServicoName));
        }

        public static void IntegraSharePointGarantias()
        {
            List<Campos> DadosOperacao = null;
            List<Campos> DadosEtapa = null;
            ResponsavelServico Responsavel = null;

            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                        Responsavel = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel;
                        DadosOperacao = ((Detalhe)Application.OpenForms["Detalhe"])._listaCamposServico;
                        DadosEtapa = ((Detalhe)Application.OpenForms["Detalhe"])._listaCamposEtapas;
                    }
                    break;
            }



            List<Campos> DadosTodasEtapas = new List<Campos>();
            DadosTodasEtapas = DataAccess.buscarCamposEtapaConjunto(Responsavel.ID_Servico);  // tornar mais rapido
            IntegraSharePointInfoPath(DadosOperacao, DadosEtapa, Responsavel, "Garantias", DadosTodasEtapas);
            System.Diagnostics.Process.Start(DataAccess.BuscaURLsharepoint("Garantias", Responsavel.ServicoName));
        }

        public static void IntegraSharePointInfoPath(List<Campos> DadosOperacao, List<Campos> DadosEtapa, ResponsavelServico Responsavel, string NomeSharePoint, List<Campos> DadosTodasEtapas)
        {
            string msgLog = "Salvando no Sharepoint. Servico: " + Responsavel.ID_Objeto + " / " + Responsavel.ID_Servico + " / " + Responsavel.ID_Responsavel + ". No Sharepoint " + NomeSharePoint;
            Log.GravaLog(msgLog);
            List<IntegrarGarantiasSP> listaIntegrarGarantias = new List<IntegrarGarantiasSP>();
            listaIntegrarGarantias = DataAccess.buscarDadosGarantias(Responsavel.ID_Servico, NomeSharePoint);

            List<GarantiasValorSP> ValorSP = new List<GarantiasValorSP>();
            ValorSP = DataAccess.buscarValoresGarantiasSP(Responsavel.ID_Objeto, NomeSharePoint);

            List<TiposGarantias> listaTiposGarantias = new List<TiposGarantias>();
            listaTiposGarantias = DataAccess.buscarTiposGarantias(Responsavel.ID_Servico, NomeSharePoint);

            string UltimoCampoProcessado = "";
            int i = 1;
            try
            {
                foreach (TiposGarantias TipoGarantia in listaTiposGarantias)
                {
                    //string myId = null;
                    string xmlDetalhe = string.Empty;
                    string fileName = TipoGarantia.Template;
                    string destPath = TipoGarantia.Destino;
                    var srDetalhe = new StreamReader(fileName);
                    xmlDetalhe = srDetalhe.ReadToEnd();

                    List<IntegrarGarantiasSP> DadosIntegrarTipo = listaIntegrarGarantias.FindAll(element => element.TipoGarantia == TipoGarantia.Tipo && element.BemGarantia == TipoGarantia.Bem && element.NaturezaGarantia == TipoGarantia.Natureza);
                    foreach (IntegrarGarantiasSP Dados in DadosIntegrarTipo)
                    {
                        if (Dados.CampoLista || Dados.NomeCampoSP != UltimoCampoProcessado)
                        {
                            if (Dados.TipoCampoSP != null && Dados.TipoCampoSP != "")
                            {
                                switch (Dados.TipoCampoSP.ToString())
                                {
                                    case "Servico":
                                        switch (Dados.ID_Campo.ToString())
                                        {
                                            case "ServicoName":
                                                Dados.ValorCampo = Responsavel.ServicoName.ToString();
                                                break;
                                            case "NomeObjeto":
                                                Dados.ValorCampo = Responsavel.NomeObjeto.ToString();
                                                break;
                                        }
                                        break;
                                    case "Garantia":
                                        switch (Dados.ID_Campo.ToString())
                                        {
                                            case "Tipo":
                                                Dados.ValorCampo = Dados.TipoGarantia.ToString();
                                                break;
                                            case "Bem":
                                                Dados.ValorCampo = Dados.BemGarantia.ToString();
                                                break;
                                            case "Natureza":
                                                Dados.ValorCampo = Dados.NaturezaGarantia.ToString();
                                                break;
                                            case "Valor":

                                                if (Dados.TipoDados == "NUMERO")
                                                {
                                                    Dados.ValorCampo = Convert.ToDecimal(Dados.ValorGarantia).ToString(Dados.FormatoCampo);
                                                }
                                                else if (Dados.TipoDados == "DATA")
                                                {
                                                    Dados.ValorCampo = Convert.ToDateTime(Dados.ValorGarantia).ToString(Dados.FormatoCampo);
                                                }
                                                else
                                                {
                                                    Dados.ValorCampo = Dados.ValorGarantia.ToString();
                                                }
                                                break;
                                        }
                                        break;
                                    case "Trinca":
                                        switch (Dados.ID_Campo.ToString())
                                        {
                                            case "Produto":
                                                Dados.ValorCampo = Dados.Produto.ToString();
                                                break;
                                            case "Modalidade":
                                                Dados.ValorCampo = Dados.Modalidade.ToString();
                                                break;
                                            case "Evento":
                                                Dados.ValorCampo = Dados.Evento.ToString();
                                                break;
                                        }
                                        break;
                                    case "DadosServico":
                                        if (DadosOperacao.Exists(element => element.ID_Campo == Convert.ToInt32(Dados.ID_Campo)))
                                        {
                                            if (Dados.TipoDados == "NUMERO")
                                            {
                                                if (DadosOperacao.Find(element => element.ID_Campo == Convert.ToInt32(Dados.ID_Campo)).ValorCampo != "" && DadosOperacao.Find(element => element.ID_Campo == Convert.ToInt32(Dados.ID_Campo)).ValorCampo != null)
                                                {
                                                    Dados.ValorCampo = Convert.ToDecimal(DadosOperacao.Find(element => element.ID_Campo == Convert.ToInt32(Dados.ID_Campo)).ValorCampo).ToString(Dados.FormatoCampo);
                                                }
                                            }
                                            else if (Dados.TipoDados == "DATA")
                                            {
                                                if (DadosOperacao.Find(element => element.ID_Campo == Convert.ToInt32(Dados.ID_Campo)).ValorCampo != "" && DadosOperacao.Find(element => element.ID_Campo == Convert.ToInt32(Dados.ID_Campo)).ValorCampo != null)
                                                {
                                                    Dados.ValorCampo = Convert.ToDateTime(DadosOperacao.Find(element => element.ID_Campo == Convert.ToInt32(Dados.ID_Campo)).ValorCampo).ToString(Dados.FormatoCampo);
                                                }
                                            }
                                            else
                                            {
                                                Dados.ValorCampo = DadosOperacao.Find(element => element.ID_Campo == Convert.ToInt32(Dados.ID_Campo)).ValorCampo.ToString();
                                            }
                                        }
                                        break;
                                    case "DadosFluxo":
                                        string[] ID_Campo_Array = Dados.ID_Campo.Split(';');
                                        if (ID_Campo_Array.Count() > 1)
                                        {
                                            string Valor = "";
                                            foreach (string Campo in ID_Campo_Array)
                                            {
                                                if (DadosTodasEtapas.Exists(element => element.ID_Campo == Convert.ToInt32(Campo)))
                                                    //Valor = Valor + "<div xmlns=\"http://www.w3.org/1999/xhtml\">" + DadosTodasEtapas.Find(element => element.ID_Campo == Convert.ToInt32(Campo)).CampoLabel.ToString() + ": " + DadosTodasEtapas.Find(element => element.ID_Campo == Convert.ToInt32(Campo)).ValorCampo.ToString() + "</div>";
                                                    Valor = Valor + DadosTodasEtapas.Find(element => element.ID_Campo == Convert.ToInt32(Campo)).CampoLabel.ToString() + ": " + DadosTodasEtapas.Find(element => element.ID_Campo == Convert.ToInt32(Campo)).ValorCampo.ToString() + Environment.NewLine;
                                            }
                                            Dados.ValorCampo = Valor;
                                        }
                                        else
                                        {
                                            if (DadosEtapa.Exists(element => element.ID_Campo == Convert.ToInt32(Dados.ID_Campo)))
                                            {
                                                if (Dados.TipoDados == "NUMERO")
                                                {
                                                    if (DadosEtapa.Find(element => element.ID_Campo == Convert.ToInt32(Dados.ID_Campo)).ValorCampo != "" && DadosEtapa.Find(element => element.ID_Campo == Convert.ToInt32(Dados.ID_Campo)).ValorCampo != null)
                                                    {
                                                        Dados.ValorCampo = Convert.ToDecimal(DadosEtapa.Find(element => element.ID_Campo == Convert.ToInt32(Dados.ID_Campo)).ValorCampo).ToString(Dados.FormatoCampo);
                                                    }
                                                }
                                                else if (Dados.TipoDados == "DATA")
                                                {
                                                    if (DadosEtapa.Find(element => element.ID_Campo == Convert.ToInt32(Dados.ID_Campo)).ValorCampo != "" && DadosEtapa.Find(element => element.ID_Campo == Convert.ToInt32(Dados.ID_Campo)).ValorCampo != null)
                                                    {
                                                        Dados.ValorCampo = Convert.ToDateTime(DadosEtapa.Find(element => element.ID_Campo == Convert.ToInt32(Dados.ID_Campo)).ValorCampo).ToString(Dados.FormatoCampo);
                                                    }
                                                }
                                                else
                                                {
                                                    Dados.ValorCampo = DadosEtapa.Find(element => element.ID_Campo == Convert.ToInt32(Dados.ID_Campo)).ValorCampo.ToString();
                                                }
                                            }
                                        }
                                        break;
                                    case "Usuario":
                                        Dados.ValorCampo = DataAccess.BuscaNomeUsuario(Environment.UserName.ToUpper());
                                        break;
                                    case "DataHora":
                                        Dados.ValorCampo = DateTime.Now.ToString(Dados.FormatoCampo);
                                        break;
                                    case "Fixo":
                                        Dados.ValorCampo = Dados.ID_Campo.ToString();
                                        break;
                                }

                                string ValorValido = "";

                                if (ValorSP.Exists(element => element.Objeto == Dados.ID_Objeto && element.ValorMobios == Dados.ValorCampo && element.Campo == Dados.NomeCampoSP))
                                {
                                    ValorValido = ValorSP.Find(element => element.ValorMobios == Dados.ValorCampo && element.Campo == Dados.NomeCampoSP).ValorSP.ToString();
                                    Dados.ValorCampo = ValorValido;
                                }

                                if (Dados.ValorPadraoSP != null && Dados.ValorPadraoSP != "" && (Dados.ValorCampo == null || Dados.ValorCampo == ""))
                                {
                                    Dados.ValorCampo = Dados.ValorPadraoSP;
                                }

                                if (Dados.ValorCampo.Contains("<") || Dados.ValorCampo.Contains(">"))
                                {
                                    Dados.ValorCampo = Dados.ValorCampo.Replace("<", string.Empty).Replace(">", string.Empty);
                                }

                                if (Dados.ValorCampo != null && Dados.ValorCampo != "")
                                {
                                    string ValorTag = "";
                                    if (Dados.ValorPadraoSP != "" && Dados.ValorPadraoSP != null)
                                    {
                                        ValorTag = Dados.ValorPadraoSP;
                                    }

                                    string Tag = Dados.NomeCampoSP.ToString().Replace("#@#", ValorTag);
                                    string ValorInserir = Dados.NomeCampoSP.ToString().Replace("#@#", Dados.ValorCampo);

                                    if (Dados.CampoLista)
                                    {
                                        Tag.Replace("###", "");
                                        ValorInserir.Replace("###", i.ToString());

                                        int PosicaoTag = Dados.NomeCampoSP.ToString().IndexOf("#@#");
                                        string LocalizarTag = Dados.NomeCampoSP.ToString().Substring(PosicaoTag + 3, Dados.NomeCampoSP.ToString().Length - PosicaoTag - 3).Replace("###", i.ToString());

                                        if (xmlDetalhe.IndexOf(LocalizarTag) == -1)
                                        {
                                            Tag = LocalizarTag + Tag;
                                            ValorInserir = LocalizarTag + ValorInserir;
                                        }

                                        i = i + 1;
                                    }
                                    xmlDetalhe = xmlDetalhe.Replace(Tag, ValorInserir);
                                }

                                //xmlDetalhe = xmlDetalhe.Replace("<my:contrato></my:contrato>", "<my:contrato>1234567890</my:contrato>");
                                //xmlDetalhe = xmlDetalhe.Replace("<my:boleto></my:boleto>","<my:boleto>" + boleto + "</my:boleto>");
                            }
                        }

                        UltimoCampoProcessado = Dados.NomeCampoSP;

                    }
                    int posicaoInicial = xmlDetalhe.IndexOf(@"<my:ID_>") + 8;
                    int posicaoFinal = xmlDetalhe.IndexOf(@"</my:ID_>");
                    string xmlData = xmlDetalhe.Substring(posicaoInicial, posicaoFinal - posicaoInicial).ToString().Replace(":", "_");
                    var swResult = new StreamWriter(destPath + "//" + Responsavel.ServicoName + " ID_" + xmlData + ".xml");
                    swResult.Write(xmlDetalhe);

                    swResult.Flush();

                    i = 1;
                }
                MessageBox.Show("Integração concluída com sucesso.");
            }
            catch (Exception exp)
            {
                msgLog = "Erro ao integrar dados no SharePoint " + NomeSharePoint + " " + exp.Message + " " + exp.StackTrace;
                Log.GravaLog(msgLog);
                MessageBox.Show("Erro ao integrar com Sharepoint. Erro: " + exp.Message);
            }
        }

        public static void AbreFormIntegracaoExcelSAD()
        {
            int id_Servico = 0;
            int id_Etapa = 0;

            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                        id_Servico = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel.ID_Servico;
                        id_Etapa = ((Detalhe)Application.OpenForms["Detalhe"])._Etapa.ID_Etapa;
                    }
                    break;
            }




            using (Form frm = new IntegracaoExcel(3))
            {
                //frm.MdiParent = this;
                frm.WindowState = FormWindowState.Normal;
                frm.Left = 0;
                frm.Top = 0;
                frm.ShowDialog();
            }
        }

        public static void AbreFormContaVinculada()
        {
            int ID_Servico = 0;
            string CNPJ = "";
            string NomeCliente = "";

            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                        ID_Servico = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel.ID_Servico;

                        string MobiosCampos = ((Detalhe)Application.OpenForms["Detalhe"])._MyMethod.MobiosCampos.ToString();

                        if (MobiosCampos != "")
                        {
                            string[] camposContVinc = MobiosCampos.Split(';');

                            List<Campos> CamposServico = ((Detalhe)Application.OpenForms["Detalhe"])._listaCamposServico;
                            string[] parametersArray = new string[camposContVinc.Count()];

                            for (int i = 0; i < camposContVinc.Count(); i++)
                            {
                                List<Campos> ValorCamposContVinc = CamposServico.FindAll(element => element.ID_Campo == Convert.ToInt32(camposContVinc[i]));
                                if (ValorCamposContVinc.Count > 0)
                                {
                                    parametersArray[i + 1] = ValorCamposContVinc[0].ValorCampo;
                                }
                            }
                            CNPJ = parametersArray[0];
                            NomeCliente = parametersArray[1];
                        }
                    }
                    break;
            }




            using (Form frm = new ContasVinculadas(ID_Servico, CNPJ, NomeCliente))
            {
                //frm.MdiParent = this;
                frm.WindowState = FormWindowState.Normal;
                frm.Left = 0;
                frm.Top = 0;
                frm.ShowDialog();
            }
        }

        public static void AbreFormIntegracaoExcelI8()
        {
            int id_Servico = 0;
            int id_Etapa = 0;

            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                        id_Servico = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel.ID_Servico;
                        id_Etapa = ((Detalhe)Application.OpenForms["Detalhe"])._Etapa.ID_Etapa;
                    }
                    break;
            }



            using (Form frm = new IntegracaoExcel(1))
            {
                //frm.MdiParent = this;
                frm.WindowState = FormWindowState.Normal;
                frm.Left = 0;
                frm.Top = 0;
                frm.ShowDialog();
            }
        }

        public static void AbreFormIntegracaoExcelWAO()
        {
            int id_Servico = 0;
            int id_Etapa = 0;

            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                        id_Servico = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel.ID_Servico;
                        id_Etapa = ((Detalhe)Application.OpenForms["Detalhe"])._Etapa.ID_Etapa;
                    }
                    break;
            }

            using (Form frm = new IntegracaoExcel(2))
            {
                //frm.MdiParent = this;
                frm.WindowState = FormWindowState.Normal;
                frm.Left = 0;
                frm.Top = 0;
                frm.ShowDialog();
            }
        }
        #endregion

        #region [Mobios+Cash]

        public static void MobiosCashOpenSAD()
        {
            int IdServico = 0;
            string Diretorio = "";

            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                        IdServico = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel.ID_Servico;
                        Diretorio = ((Detalhe)Application.OpenForms["Detalhe"])._MyMethod.MethodParametro;
                    }
                    break;
            }
            string sql = "select NomeCampo,ValorCampo from tb_0126_DadosServico where Id_Campo in (55,17) and ID_Servico=" + IdServico + "";
            DataTable dt = DataConnector.ExecuteDataTable(sql, "BDdados");
            string idSAD = "";
            string Link = "";
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        if (dt.Rows[i]["NomeCampo"].ToString() == "SAD Vinculada")
                        {
                            idSAD = dt.Rows[i]["ValorCampo"].ToString();
                        }
                        if (dt.Rows[i]["NomeCampo"].ToString() == "LinkSAD")
                        {
                            Link = dt.Rows[i]["ValorCampo"].ToString();
                            Link = Link.Substring(Link.IndexOf("=") + 1, Link.IndexOf(">") - Link.IndexOf("=") - 1);
                        }
                    }
                    if (idSAD != "")
                        System.Diagnostics.Process.Start(Link);
                    else
                        MessageBox.Show("Não existe SAD no campos SAD Vinculada.", "SAD Vinculada", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }

            }

        }
        public static void MobiosCashOpenSharePoint()
        {
            int IdServico = 0;
            string Diretorio = "";

            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                        IdServico = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel.ID_Servico;
                        Diretorio = ((Detalhe)Application.OpenForms["Detalhe"])._MyMethod.MethodParametro;
                    }
                    break;
            }
            string sql = "select NomeCampo,ValorCampo from tb_0126_DadosServico where Id_Campo in (54,1) and ID_Servico=" + IdServico + "";
            DataTable dt = DataConnector.ExecuteDataTable(sql, "BDdados");
            string idSharePoint = "";
            string Link = "";
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        if (dt.Rows[i]["NomeCampo"].ToString() == "ID Origem")
                        {
                            idSharePoint = dt.Rows[i]["ValorCampo"].ToString();
                        }
                        if (dt.Rows[i]["NomeCampo"].ToString() == "LinkSharePoint")
                        {
                            Link = dt.Rows[i]["ValorCampo"].ToString();
                            Link = Link.Substring(Link.IndexOf("=") + 1, Link.IndexOf(">") - Link.IndexOf("=") - 1);
                        }
                    }

                    Log.GravaLog("Abrindo Link: " + Link);
                    System.Diagnostics.Process.Start(Link);
                }

            }


        }
        public static void ImportarSharePointCASH(bool MostraMsg = true)
        {

            using (MensagemConfirmacao msg = new MensagemConfirmacao("Este processo pode demorar alguns minutos\nDeseja continuar com a importação dos dados?"))
            {
                if (msg.ShowDialog() == DialogResult.Yes)
                {
                    //continua
                }
                else
                {
                    return;
                }

            }

            ClassListMethod _MyMethodLocal = null;

            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                        _MyMethodLocal = ((MainForm)Application.OpenForms["MainForm"])._MyMethod;
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                        //IdServico = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel.ID_Servico;
                        //Diretorio = ((Detalhe)Application.OpenForms["Detalhe"])._MyMethod.MethodParametro;
                    }
                    break;
            }

            if (_MyMethodLocal != null)
            {
                if (!bool.TryParse(_MyMethodLocal.MethodParametro, out MostraMsg))
                {
                    MostraMsg = true;
                }
            }

            DateTime Ini = new DateTime();
            DateTime Fim = new DateTime();
            DateTime IniGeral = new DateTime();
            DateTime FimGeral = new DateTime();
            TimeSpan intervalo = new TimeSpan();
            string IntervaloOut = "";
            IniGeral = DateTime.Now;
            string id_origem_teste = DataAccess.GetParametro("id_origem_teste");

            Form frmLoading = new Loading();
            frmLoading.Show();

            try
            {

                //Log.GravaArqAguardar();

                Loading.StaticFormVisible(true);
                Loading.EnableStaticTextBox("Buscando informações no SharePoint...");

                StringBuilder sb_etapas = new StringBuilder();
                sb_etapas.AppendLine("Etapas que existem no cockpit - Objetivo é analisar se alguma etapa não está na função GetEtapaID");

                #region [ Leitura SharePoint Mocash ]
                //Buscando dados no SharePoint por serviço
                Ini = DateTime.Now;
                DataTable dt = new DataTable("OPERACOES");
                string URL_MOCASH = @"http://mocash/servcash";
                string listname = "{FAD5051C-E243-4A49-9933-B93F2CAA7E21}";//Operacoes 
                string CalmQuery = "";
                dt = SharePoint.GetListItemService(listname, URL_MOCASH, null, CalmQuery);

                // Coluna 'Analista (login_x002' deve ser alterado para 'LoginResponsavel' para realizar Join
                dt.Columns["Analista_x0020__x0028_login_x002"].ColumnName = "LoginResponsavel";
                dt.Columns["ID_x0020_Origem"].ColumnName = "ID Origem";

                System.Data.DataColumn newColumnDt = new System.Data.DataColumn("IDOrigemAuxDt", typeof(System.String));
                dt.Columns.Add(newColumnDt);

                //Colocando login em maiusculo
                for (int ii = 0; ii < dt.Rows.Count; ii++)
                {
                    //verificando se tem que parar no ID_teste
                    if (id_origem_teste.ToUpper().IndexOf(dt.Rows[ii]["ID Origem"].ToString().ToUpper()) >= 0)
                    {
                        Console.WriteLine("Para no Id Origem: " + dt.Rows[ii]["ID Origem"].ToString());
                    }
                    dt.Rows[ii]["LoginResponsavel"] = dt.Rows[ii]["LoginResponsavel"].ToString().ToUpper();
                    dt.Rows[ii]["IDOrigemAuxDt"] = dt.Rows[ii]["ID Origem"].ToString().ToUpper();
                }
                Fim = DateTime.Now;
                intervalo = Fim - Ini;
                IntervaloOut = "Leitura do SharePoint | Tempo (hh:mm:ss) : " + intervalo.ToString(@"hh\:mm\:ss");
                Log.GravaLog(IntervaloOut, "_MobiosImportaSharePoint_");
                #endregion


                #region [ InformaçõesMobios ]
                Ini = DateTime.Now;
                DataTable dt_IDs_ja_importados = DataConnector.ExecuteDataTable("SELECT ValorCampo as [ID Origem],ValorCampo as [IDOrigemAux],ID_Servico FROM tb_0126_DadosServico Where Id_Campo = 1", "BDdados");

                DataTable dt_IDs_to_conclude = DataConnector.ExecuteDataTable("SELECT * from vw_ids_to_conclude", "BDdados");

                Loading.EnableStaticTextBox("Buscando informações no Mobios...");

                DataTable Responsaveis = DataConnector.ExecuteDataTable("SELECT LoginResponsavel,ID_Responsavel FROM tb_0100_Responsavel", "BDdados");
                //Colocando login em maiusculo
                for (int ii = 0; ii < Responsaveis.Rows.Count; ii++)
                {
                    Responsaveis.Rows[ii]["LoginResponsavel"] = Responsaveis.Rows[ii]["LoginResponsavel"].ToString().ToUpper();
                }
                string query_id_objeto = "SELECT tb_0100_Responsavel.ID_Responsavel, tb_0010_EtapasObjetos.ID_Objeto " +
                                        " FROM (tb_0100_Responsavel INNER JOIN tb_0116_ResponsavelCelula ON tb_0100_Responsavel.ID_Responsavel = tb_0116_ResponsavelCelula.ID_Responsavel) INNER JOIN tb_0010_EtapasObjetos ON tb_0116_ResponsavelCelula.ID_Celula = tb_0010_EtapasObjetos.CelulaResponsavel " +
                                        " GROUP BY tb_0100_Responsavel.ID_Responsavel, tb_0010_EtapasObjetos.ID_Objeto ";

                DataTable Dt_ID_Objeto = DataConnector.ExecuteDataTable(query_id_objeto, "BDdados");


                DataTable JoinedTable00 = TratamentoCampo.JoinTwoDataTablesOnOneColumn(dt, dt_IDs_ja_importados, "ID Origem", TratamentoCampo.JoinType.Left);

                //Tabela com os IDs dos usuários responsáveis e também com os IDs de origem e também com IDs de Serviço
                DataTable JoinedTable01 = TratamentoCampo.JoinTwoDataTablesOnOneColumn(JoinedTable00, Responsaveis, "LoginResponsavel", TratamentoCampo.JoinType.Left);

                DataTable JoinedTable = TratamentoCampo.JoinTwoDataTablesOnOneColumn(JoinedTable01, Dt_ID_Objeto, "ID_Responsavel", TratamentoCampo.JoinType.Left);



                DataTable JoinedTable2 = JoinedTable.Clone();
                JoinedTable2.Columns["ID Origem"].DataType = Type.GetType("System.Int32");

                foreach (DataRow dr in JoinedTable.Rows)
                {
                    JoinedTable2.ImportRow(dr);
                }
                JoinedTable2.AcceptChanges();
                DataView dv = JoinedTable2.DefaultView;
                dv.Sort = "[ID Origem] ASC";
                JoinedTable2 = dv.ToTable();

                //Pegando dados para concluir o Serviço
                DataTable JoinedTableToConclude = TratamentoCampo.JoinTwoDataTablesOnOneColumn(dt_IDs_to_conclude, dt, "ID Origem", TratamentoCampo.JoinType.Left);

                DataTable dt_IDs_Campos = DataConnector.ExecuteDataTable("SELECT NomeCampoSP,ValorCampoMobios from tb_0406_ServicosSharePointValores where SharePoint='MobiosCash' and Ativo=true", "BDdados");


                string expressionConclude = "[IDOrigemAuxDt] = '' OR [IDOrigemAuxDt] is null";
                var filteredDtRows = JoinedTableToConclude.Select(expressionConclude);
                var filteredDataTable_Conclude = new DataTable();
                if (filteredDtRows.Length != 0)
                {
                    filteredDataTable_Conclude = filteredDtRows.CopyToDataTable();
                }


                //Tabela de novos registros
                string expression = "[IDOrigemAux] = '' OR [IDOrigemAux] is null";

                var filteredDataRows = JoinedTable.Select(expression);

                var filteredDataTable_NOVOS = new DataTable();
                if (filteredDataRows.Length != 0)
                {
                    filteredDataTable_NOVOS = filteredDataRows.CopyToDataTable();
                }

                //Tabela de registros para atualizar
                expression = "[IDOrigemAux] is not null";

                var filteredDataRows2 = JoinedTable.Select(expression);

                var filteredDataTable_UPDATE = new DataTable();
                if (filteredDataRows2.Length != 0)
                {
                    filteredDataTable_UPDATE = filteredDataRows2.CopyToDataTable();
                }
                Fim = DateTime.Now;
                intervalo = Fim - Ini;
                IntervaloOut = "Leitura de dados do Mobios, Join Entre tabelas e Filtros de Novos e Update | Tempo (hh:mm:ss) : " + intervalo.ToString(@"hh\:mm\:ss");
                Log.GravaLog(IntervaloOut, "_MobiosImportaSharePoint_");
                #endregion


                #region [ DefineVariaveis e Tabelas ]
                //Strings de logs - usados para aquelas IDs que não posuem responsável dentro do SharePoint.
                StringBuilder sb = new StringBuilder();
                StringBuilder sb2 = new StringBuilder();
                StringBuilder sb3 = new StringBuilder();

                int i_total = filteredDataTable_NOVOS.Rows.Count + filteredDataTable_UPDATE.Rows.Count;
                int i = 1;
                int aux = 0;
                int aux2 = 0;
                int aux3 = 0;

                //Preparando DataTable para Insert
                DataTable dt_to_bulk = new DataTable();
                System.Data.DataColumn newColumn = new System.Data.DataColumn("ID_SERVICO", typeof(System.Int32));
                dt_to_bulk.Columns.Add(newColumn);
                System.Data.DataColumn newColumn2 = new System.Data.DataColumn("ID_CAMPO", typeof(System.Int32));
                dt_to_bulk.Columns.Add(newColumn2);
                System.Data.DataColumn newColumn3 = new System.Data.DataColumn("NomeCampo", typeof(System.String));
                dt_to_bulk.Columns.Add(newColumn3);
                System.Data.DataColumn newColumn4 = new System.Data.DataColumn("ValorCampo", typeof(System.String));
                dt_to_bulk.Columns.Add(newColumn4);
                System.Data.DataColumn newColumn5 = new System.Data.DataColumn("Data Criacao", typeof(System.DateTime));
                dt_to_bulk.Columns.Add(newColumn5);
                System.Data.DataColumn newColumn6 = new System.Data.DataColumn("Data Atualizacao", typeof(System.DateTime));
                dt_to_bulk.Columns.Add(newColumn6);

                //Preparando DataTable para Update
                DataTable dt_to_bulk_update = new DataTable();
                System.Data.DataColumn newColumnUpdate1 = new System.Data.DataColumn("ValorCampo", typeof(System.String));
                dt_to_bulk_update.Columns.Add(newColumnUpdate1);
                System.Data.DataColumn newColumnUpdate2 = new System.Data.DataColumn("Data Atualizacao", typeof(System.DateTime));
                dt_to_bulk_update.Columns.Add(newColumnUpdate2);
                System.Data.DataColumn newColumnUpdate3 = new System.Data.DataColumn("ID_SERVICO", typeof(System.Int32));
                dt_to_bulk_update.Columns.Add(newColumnUpdate3);
                System.Data.DataColumn newColumnUpdate4 = new System.Data.DataColumn("ID_CAMPO", typeof(System.Int32));
                dt_to_bulk_update.Columns.Add(newColumnUpdate4);
                #endregion

                #region  [ Novos Serviços ]
                Ini = DateTime.Now;
                string InserMsg = "";
                foreach (DataRow row in filteredDataTable_NOVOS.Rows)
                {

                    //verificando se tem que parar no ID_teste

                    if (id_origem_teste.ToUpper().IndexOf(row["ID Origem"].ToString().ToUpper()) >= 0)
                    {
                        Console.WriteLine("Para no Id Origem: " + row["ID Origem"].ToString());
                    }
                    bool resp_generico_msg = false;
                    bool objeto_generico_msg = false;
                    InserMsg = i.ToString().PadLeft(4, '0') + "/" + filteredDataTable_NOVOS.Rows.Count.ToString().PadLeft(4, '0');
                    var porcentagem = ((double)i / filteredDataTable_NOVOS.Rows.Count) * 100;
                    Loading.EnableStaticTextBox("Novos..." + i.ToString().PadLeft(4, '0') + "/" + filteredDataTable_NOVOS.Rows.Count.ToString().PadLeft(4, '0') + "(" + string.Format("{0:0,0}", porcentagem) + " %)"); // saída = 43.239,11 + "%");

                    i = i + 1;
                    //var porcentagem = ((double)i / i_total) * 100;
                    //Loading.EnableStaticTextBox("Tratando dados..." + string.Format("{0:0,0}", porcentagem) + " %"); // saída = 43.239,11 + "%");

                    Int32 idResp = 0; ; // apenas para teste . Verificar o que fazer quando não tiver responsável e tiver que incluir na base.
                    if (!Int32.TryParse(row["ID_Responsavel"].ToString(), out idResp))
                    {
                        idResp = 219; //Genérico
                        resp_generico_msg = true;
                    }
                    if (idResp == 0)
                    {
                        resp_generico_msg = true;
                        idResp = 219; //Genérico
                    }

                    if (idResp > 0)
                    {
                        Int32 IDobjeto = 0;

                        if (!Int32.TryParse(row["ID_Objeto"].ToString(), out IDobjeto))
                        {
                            objeto_generico_msg = true;
                            IDobjeto = 4;
                        }

                        if (IDobjeto == 0)
                        {
                            objeto_generico_msg = true;
                            IDobjeto = 4; //Atribuido objeto Genérico
                        }
                        InserMsg += " | ID Origem: " + row["ID Origem"].ToString().PadLeft(12, '0');
                        int IdServico = DataAccess.SalvarServico(1, IDobjeto, row["ID Origem"].ToString(), false, DateTime.Now);

                        if (IdServico != 0)
                        {
                            InserMsg += " | Insert Serviço Número: " + IdServico.ToString().PadLeft(10, '0');
                            EtapasObjeto Etp = new EtapasObjeto();
                            Etp.ID_Servico = IdServico;
                            Etp.StatusInicial = 1;
                            Etp.ID_Status = 2;
                            Etp.ID_Etapa = GetEtapaId(row["Etapa"].ToString());
                            if (sb_etapas.ToString().IndexOf(row["Etapa"].ToString()) < 0 && Etp.ID_Etapa == 0)
                            {
                                sb_etapas.AppendLine("Etapa não localizada na função GetEtapaId:" + (row["Etapa"].ToString()) == "" ? "VAZIO" : row["Etapa"].ToString());
                                InserMsg += " | Etapa não localizada na função GetEtapaId:" + (row["Etapa"].ToString()) == "" ? "VAZIO" : row["Etapa"].ToString();
                            }
                            //DataAccess.RegistrarFluxoServico(Convert.ToInt16(row["ID_Responsavel"]), Etp);
                            TelaDinamica.CriarEtapaFluxo(IdServico, 1, idResp);
                            InserMsg += " | Criadas Etapas";
                            DataAccess.AtualizaStatusEtapa(IdServico, false, 1, Etp.ID_Etapa);
                            //DataAccess.GravarIndicadorStatus(IdServico, Etp.ID_Etapa, Etp.ID_Status);

                            InserMsg += " | Atualizado Status Etapas";
                            //Dados para inclusão na tabela tb_0126_DadosServico
                            if (filteredDataTable_NOVOS.Columns.Contains("ID Origem")) if (row["ID Origem"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 1, "ID Origem", row["ID Origem"].ToString(), DateTime.Now, DateTime.Now);
                            if (filteredDataTable_NOVOS.Columns.Contains("Fonte")) if (row["Fonte"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 2, "Fonte Origem", row["Fonte"].ToString(), DateTime.Now, DateTime.Now);
                            if (filteredDataTable_NOVOS.Columns.Contains("Produto")) if (row["Produto"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 3, "Produto", row["Produto"].ToString(), DateTime.Now, DateTime.Now);
                            if (filteredDataTable_NOVOS.Columns.Contains("Grupo")) if (row["Grupo"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 4, "Grupo Econômico", row["Grupo"].ToString(), DateTime.Now, DateTime.Now);
                            if (filteredDataTable_NOVOS.Columns.Contains("Empresa")) if (row["Empresa"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 5, "Empresa", row["Empresa"].ToString(), DateTime.Now, DateTime.Now);
                            if (filteredDataTable_NOVOS.Columns.Contains("CNPJ")) if (row["CNPJ"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 6, "CNPJ", row["CNPJ"].ToString(), DateTime.Now, DateTime.Now);
                            if (filteredDataTable_NOVOS.Columns.Contains("AG_x002f_CC")) if (row["AG_x002f_CC"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 7, "Agência/Conta", row["AG_x002f_CC"].ToString(), DateTime.Now, DateTime.Now);
                            if (filteredDataTable_NOVOS.Columns.Contains("Segmento")) if (row["Segmento"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 8, "Segmento", row["Segmento"].ToString(), DateTime.Now, DateTime.Now);
                            if (filteredDataTable_NOVOS.Columns.Contains("Officer")) if (row["Officer"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 9, "Officer Cash", row["Officer"].ToString(), DateTime.Now, DateTime.Now);
                            if (filteredDataTable_NOVOS.Columns.Contains("Etapa")) if (row["Etapa"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 10, "Etapa Interna", row["Etapa"].ToString(), DateTime.Now, DateTime.Now);

                            string SLAVencidoBolean = "false";
                            if (filteredDataTable_NOVOS.Columns.Contains("SLA_x0020_Vencido_x0020__x0028_E"))
                            {
                                if (row["SLA_x0020_Vencido_x0020__x0028_E"].ToString() == "1")
                                    SLAVencidoBolean = "true";
                                else
                                    SLAVencidoBolean = "false";
                            }
                            if (filteredDataTable_NOVOS.Columns.Contains("SLA_x0020_Vencido_x0020__x0028_E")) if (row["SLA_x0020_Vencido_x0020__x0028_E"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 11, "SLA Etapa", SLAVencidoBolean, DateTime.Now, DateTime.Now);
                            if (filteredDataTable_NOVOS.Columns.Contains("LoginResponsavel")) if (row["LoginResponsavel"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 12, "Responsável", row["LoginResponsavel"].ToString(), DateTime.Now, DateTime.Now);//verificar essa linha
                            if (filteredDataTable_NOVOS.Columns.Contains("Data_x0020_de_x0020_Emiss_x00e3_")) if (row["Data_x0020_de_x0020_Emiss_x00e3_"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 13, "Data de Emissão", row["Data_x0020_de_x0020_Emiss_x00e3_"].ToString(), DateTime.Now, DateTime.Now);
                            if (filteredDataTable_NOVOS.Columns.Contains("Data_x0020_de_x0020_recep_x00e7_")) if (row["Data_x0020_de_x0020_recep_x00e7_"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 14, "Data da Recepção", row["Data_x0020_de_x0020_recep_x00e7_"].ToString(), DateTime.Now, DateTime.Now);
                            if (filteredDataTable_NOVOS.Columns.Contains("Data_x0020_de_x0020_Cadastro")) if (row["Data_x0020_de_x0020_Cadastro"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 15, "Data de Cadastro", row["Data_x0020_de_x0020_Cadastro"].ToString(), DateTime.Now, DateTime.Now);
                            if (filteredDataTable_NOVOS.Columns.Contains("Aging_x0020_da_x0020_etapa")) if (row["Aging_x0020_da_x0020_etapa"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 16, "Aging", row["Aging_x0020_da_x0020_etapa"].ToString().Replace(".", ","), DateTime.Now, DateTime.Now);
                            if (filteredDataTable_NOVOS.Columns.Contains("SAD_x0020_vinculada")) if (row["SAD_x0020_vinculada"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 17, "SAD Vinculada", row["SAD_x0020_vinculada"].ToString(), DateTime.Now, DateTime.Now);
                            if (filteredDataTable_NOVOS.Columns.Contains("CPE_x0020__x002d__x0020_Data_x00")) if (row["CPE_x0020__x002d__x0020_Data_x00"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 18, "Data Vencimento CPE", row["CPE_x0020__x002d__x0020_Data_x00"].ToString(), DateTime.Now, DateTime.Now);
                            if (filteredDataTable_NOVOS.Columns.Contains("Observa_x00e7__x00e3_o")) if (row["Observa_x00e7__x00e3_o"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 52, "Obs CAD", row["Observa_x00e7__x00e3_o"].ToString(), DateTime.Now, DateTime.Now);
                            if (filteredDataTable_NOVOS.Columns.Contains("_x00da_ltima_x0020_etapa")) if (row["_x00da_ltima_x0020_etapa"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 53, "Última Etapa", row["_x00da_ltima_x0020_etapa"].ToString(), DateTime.Now, DateTime.Now);
                            if (filteredDataTable_NOVOS.Columns.Contains("Link")) if (row["Link"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 54, "LinkSharePoint", row["Link"].ToString(), DateTime.Now, DateTime.Now);
                            if (filteredDataTable_NOVOS.Columns.Contains("Link_x0020_SAD")) if (row["Link_x0020_SAD"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 55, "LinkSAD", row["Link_x0020_SAD"].ToString(), DateTime.Now, DateTime.Now);
                            if (filteredDataTable_NOVOS.Columns.Contains("Contrato")) if (row["Contrato"].ToString() != "") dt_to_bulk.Rows.Add(IdServico, 56, "Contrato", row["Contrato"].ToString(), DateTime.Now, DateTime.Now);


                            //Insert novos dados na tbl 0126
                            try
                            {
                                DataConnector.BulkExportToAccess(dt_to_bulk, SharedData.ReturnPathBase("BDdados"), "tb_0126_DadosServico");
                                dt_to_bulk.Clear();
                                InserMsg += " | Dados Inseridos";
                                if (resp_generico_msg)
                                    InserMsg += " | Atribuido usuário Genérico pois cockpit NÃO possui responsável";
                                if (objeto_generico_msg)
                                    InserMsg += " | Atribuido Objeto Genérico";
                                Log.GravaLog(InserMsg, "_MobiosImportaSharePoint_");
                            }
                            catch (Exception ex)
                            {
                                InserMsg += " | Erro na Inserção dos dados: " + ex.Message;
                                dt_to_bulk.Clear();
                            }


                        }
                        else
                        {
                            int IdServico2 = DataAccess.BuscarIDServico(row["ID Origem"].ToString());
                            if (IdServico2 != 0)
                            {
                                DataAccess.ExcluirServico(IdServico2);
                            }
                        }
                    }
                    else
                    {
                        aux += 1;
                        if (sb.Length > 0)
                        {

                            string codigo = row["ID Origem"].ToString();
                            codigo = codigo.PadLeft(12, '0');
                            sb.Append(codigo + " ; ");
                            int resto = (aux % 10);
                            if (resto == 0)
                                sb.AppendLine();

                        }
                        else
                        {
                            sb.AppendLine("IDs abaixo não foram abertos no Mobios, pois estão sem responsável definido no SharePoint.");
                            sb.AppendLine();
                            string codigo = row["ID Origem"].ToString();
                            codigo = codigo.PadLeft(12, '0');
                            sb.Append(codigo + " ; ");

                        }
                    }
                }


                Fim = DateTime.Now;
                intervalo = Fim - Ini;
                IntervaloOut = "Criação de " + (filteredDataTable_NOVOS.Rows.Count - aux).ToString() + " Novos Serviços | Tempo (hh:mm:ss) : " + intervalo.ToString(@"hh\:mm\:ss") + " | Qtde de Serviços avaliados: " + filteredDataTable_NOVOS.Rows.Count.ToString() + " | Qtde de Serviços sem Responsável: " + aux.ToString();
                Log.GravaLog(IntervaloOut, "_MobiosImportaSharePoint_");
                // ATUALIZAR
                #endregion

                #region [ Atualização de Serviços ]
                Ini = DateTime.Now;
                string UpdateMsg = "";
                string auxMsgUserGenerico = "";


                Ini = DateTime.Now;
                List<Campos> ListCamposTotal = DataAccess.buscarCamposDinamicosConjunto("vw_MontarFormularioDados");
                Fim = DateTime.Now;
                intervalo = Fim - Ini;
                IntervaloOut = "ListCamposTotal | Tempo (hh:mm:ss) : " + intervalo.ToString(@"hh\:mm\:ss");
                Log.GravaLog(IntervaloOut, "_MobiosImportaSharePoint_");

                Ini = DateTime.Now;
                List<FluxoServico> ListFluxosTotal = DataAccess.BuscarFluxoServico();
                Fim = DateTime.Now;
                intervalo = Fim - Ini;
                IntervaloOut = "ListFluxosTotal | Tempo (hh:mm:ss) : " + intervalo.ToString(@"hh\:mm\:ss");
                Log.GravaLog(IntervaloOut, "_MobiosImportaSharePoint_");

                Ini = DateTime.Now;
                List<ResponsavelServico> ListServicosTotal = DataAccess.BuscarTodosServicos();
                Fim = DateTime.Now;
                intervalo = Fim - Ini;
                IntervaloOut = "ListServicosTotal | Tempo (hh:mm:ss) : " + intervalo.ToString(@"hh\:mm\:ss") + " | Qtde de ServicosTotal" + ListServicosTotal.Count;
                Log.GravaLog(IntervaloOut, "_MobiosImportaSharePoint_");




                i = 0;
                foreach (DataRow r in filteredDataTable_UPDATE.Rows)
                {
                    //verificando se tem que parar no ID_teste
                    if (id_origem_teste.ToUpper().IndexOf(r["ID Origem"].ToString().ToUpper()) >= 0)
                    {
                        Console.WriteLine("Para no Id Origem: " + r["ID Origem"].ToString());
                    }
                    auxMsgUserGenerico = "";
                    UpdateMsg = i.ToString().PadLeft(4, '0') + "/" + filteredDataTable_UPDATE.Rows.Count.ToString().PadLeft(4, '0');

                    //var porcentagem = ((double)i / i_total) * 100;
                    var porcentagem = ((double)i / filteredDataTable_UPDATE.Rows.Count) * 100;
                    Loading.EnableStaticTextBox("Update..." + i.ToString().PadLeft(4, '0') + "/" + filteredDataTable_UPDATE.Rows.Count.ToString().PadLeft(4, '0') + "(" + string.Format("{0:0,0}", porcentagem) + " %)"); // saída = 43.239,11 + "%");


                    i = i + 1;



                    UpdateMsg += " | Update IDOrigem:" + r["ID Origem"].ToString().PadLeft(12, '0');

                    Int32 IDobjeto = 0;

                    if (!Int32.TryParse(r["ID_Objeto"].ToString(), out IDobjeto))
                    {
                        IDobjeto = 4;
                    }

                    UpdateMsg += " | IDobjeto:" + IDobjeto.ToString().PadLeft(2, '0');

                    //DataTable dt_id_servico = DataConnector.ExecuteDataTable20102013("select ID_Servico from tb_0126_DadosServico where 
                    int idServico = Convert.ToInt32(r["ID_Servico"]);

                    UpdateMsg += " | idServico:" + idServico.ToString().PadLeft(10, '0');

                    EtapasObjeto Etp = new EtapasObjeto();
                    Etp = new EtapasObjeto();
                    Etp.ID_Servico = idServico;
                    Etp.StatusInicial = 1;
                    Etp.ID_Status = 2;
                    Etp.ID_Etapa = GetEtapaId(r["Etapa"].ToString());
                    string etapaaux_to_log = r["Etapa"].ToString();
                    UpdateMsg += " | Etapa:" + r["Etapa"].ToString().PadLeft(30, ' ');


                    if (sb_etapas.ToString().IndexOf(r["Etapa"].ToString()) < 0 && Etp.ID_Etapa == 0)
                    {
                        sb_etapas.AppendLine("Etapa não localizada na função GetEtapaId:" + (r["Etapa"].ToString()) == "" ? "VAZIO" : r["Etapa"].ToString());
                        UpdateMsg += " | Etapa Não Localizada dentro do Mobios :" + (r["Etapa"].ToString()) == "" ? "VAZIO" : r["Etapa"].ToString();
                    }
                    Int32 idResp = 219; // Generico
                    Int32.TryParse(r["ID_Responsavel"].ToString(), out idResp);



                    if (idResp == 0)
                    {
                        auxMsgUserGenerico += " | idResp:" + idResp.ToString().PadLeft(3, '0') + " | Atribuído Genérico pois NÃO consta responsável no Cockpit";
                        idResp = 219;
                    }
                    else
                    {
                        UpdateMsg += " | idResp:" + idResp.ToString().PadLeft(3, '0');
                    }



                    if (idResp > 0 && Etp.ID_Etapa != 0)
                    {


                        ResponsavelServico ObjetoExiste = ListServicosTotal.Find(n => n.ID_Servico == idServico);

                        if (ObjetoExiste != null && ObjetoExiste.ID_Objeto != IDobjeto)
                        {
                            DataAccess.AtualizaIdObjetoServico(idServico, IDobjeto);
                        }
                        if (ObjetoExiste != null && ObjetoExiste.Concluido == true)
                        {
                            DataAccess.DesConcluirServico(idServico, "_MobiosImportaSharePoint_");
                        }

                        FluxoServico FluxoExiste = ListFluxosTotal.Find(n => n.ID_Servico == idServico && n.ID_Fluxo == Etp.ID_Etapa);
                        if (FluxoExiste != null)
                        {
                            if (FluxoExiste.ID_Status != Etp.ID_Status || FluxoExiste.IdResponsavel != idResp)
                            {
                                List<FluxoServico> FluxosStatusAlterados = new List<FluxoServico>();

                                //Se status mudou, gravará indicador
                                if (FluxoExiste.ID_Status != Etp.ID_Status)
                                {
                                    FluxoServico FluxoStatusAlterado = new FluxoServico();
                                    FluxoStatusAlterado.ID_Fluxo = Etp.ID_Etapa;
                                    FluxoStatusAlterado.ID_Status = Etp.ID_Status;
                                    FluxoStatusAlterado.StatusFecha = false;
                                    FluxosStatusAlterados.Add(FluxoStatusAlterado);
                                }
                                //Pega todos os status das outras etapas para concluir.
                                List<FluxoServico> FluxoExisteLista = new List<FluxoServico>();
                                FluxoExisteLista = ListFluxosTotal.FindAll(n => n.ID_Servico == idServico && n.ID_Fluxo != Etp.ID_Etapa && n.ID_Status != 0 && n.ID_Status != 5);
                                for (int ii = 0; ii < FluxoExisteLista.Count; ii++)
                                {
                                    FluxoExisteLista[ii].ID_Status = 5;
                                    FluxoExisteLista[ii].StatusFecha = true;
                                }
                                FluxosStatusAlterados.AddRange(FluxoExisteLista);


                                //DataAccess.GravarIndicadorStatusLote(idServico, FluxosStatusAlterados); 11/05/2017 - Incluído dentro do AtualizaStatusEtapaLote
                                DataAccess.AtualizaStatusEtapaLote(idServico, FluxosStatusAlterados);
                                DataAccess.AtualizaEtapa(idServico, false, Etp.ID_Status, Etp.ID_Etapa, idResp); //Somente para atualizar o responsável


                                //Log.GravaLog("IdServico: " + IDServico + " | ID Origem: " + filteredDataTable_Conclude.Rows[iii]["ID Origem"].ToString(), "_MobiosImportaSharePoint_");
                                //DataAccess.AtualizaDemaisEtapas(idServico, 5, Etp.ID_Etapa);//Atualiza demais etapas para Status=5; Concluído
                            }
                        }
                        else
                        {
                            DataAccess.RegistrarFluxoServico(idResp, Etp);
                            //if (Etp.ID_Status != 0)
                            //{
                                //grava indicador do status
                                //DataAccess.GravarIndicadorStatus(idServico, Etp.ID_Etapa, Etp.ID_Status, DateTime.Now);
                            //}
                        }



                        UpdateMsg += " | Atualizado Etapas";
                    }
                    else
                    {
                        if (idResp == 0)
                        {
                            UpdateMsg += " | IdResp Vazio";

                            aux2 += 1;
                            if (sb2.Length > 0)
                            {

                                string codigo = r["ID Origem"].ToString();
                                codigo = codigo.PadLeft(12, '0');
                                sb2.Append(codigo + " ; ");
                                int resto = (aux2 % 10);
                                if (resto == 0)
                                    sb2.AppendLine();
                            }
                            else
                            {
                                sb2.AppendLine();
                                sb2.Append("IDs abaixo estavam no mobios e por algum motivo ficaram sem responsável.");
                                sb2.AppendLine();
                                string codigo = r["ID Origem"].ToString();
                                codigo = codigo.PadLeft(12, '0');
                                sb2.Append(codigo + " ; ");

                            }
                        }
                        if (Etp.ID_Etapa == 0)
                        {
                            UpdateMsg += " | ID_Etapa Vazio";
                            aux3 += 1;
                            if (sb3.Length > 0)
                            {
                                string codigo = r["ID Origem"].ToString();
                                codigo = "ID Origem: '" + codigo.PadLeft(12, '0');
                                codigo += "' | Etapa: '";
                                codigo += etapaaux_to_log == "" ? "[VAZIO]" : etapaaux_to_log + "'";
                                sb3.AppendLine(codigo);
                                //int resto = (aux3 % 10);
                                //if (resto == 0)
                                //    sb3.AppendLine();
                            }
                            else
                            {
                                sb3.AppendLine("IDs abaixo estão em uma etapa que não está cadastrada no Mobios. Observação: O cadastro depende de alteração no código");
                                string codigo = r["ID Origem"].ToString();
                                if (etapaaux_to_log == null) etapaaux_to_log = "";
                                codigo = "ID Origem: '" + codigo.PadLeft(12, '0');
                                codigo += "' | Etapa: '";
                                codigo += etapaaux_to_log == "" ? "[VAZIO]" : etapaaux_to_log + "'";
                                sb3.AppendLine(codigo);
                            }
                        }
                    }

                    //List<Campos> ListCampos = DataAccess.buscarCamposDinamicosConjunto(idServico, "vw_MontarFormularioDados");
                    List<Campos> ListCampos = ListCamposTotal.FindAll(n => n.ID_Servico == idServico);

                    for (int c = 0; c < dt_IDs_Campos.Rows.Count; c++)
                    {
                        Campos MeuCampo = ListCampos.Find(n => n.ID_Campo == Convert.ToInt32(dt_IDs_Campos.Rows[c]["ValorCampoMobios"]));
                        if (MeuCampo != null)
                        {

                            if (filteredDataTable_UPDATE.Columns.Contains(dt_IDs_Campos.Rows[c]["NomeCampoSP"].ToString()))
                            {
                                MeuCampo.ValorCampo = r[dt_IDs_Campos.Rows[c]["NomeCampoSP"].ToString()].ToString();

                                if (MeuCampo.CampoTipo.ToUpper() == "CHECKBOX")
                                {
                                    if (MeuCampo.ValorCampo == "1") MeuCampo.ValorCampo = "true";
                                    if (MeuCampo.ValorCampo == "0") MeuCampo.ValorCampo = "false";
                                    if (MeuCampo.ValorCampo == "") MeuCampo.ValorCampo = "false";
                                }
                            }
                        }
                    }

                    try
                    {
                        DataAccess.AtualizarDadosCamposGenerico(ListCampos, idServico);

                        UpdateMsg += " | Atualizado Dados";

                        UpdateMsg += auxMsgUserGenerico;

                        Log.GravaLog(UpdateMsg, "_MobiosImportaSharePoint_");

                    }
                    catch (Exception ex)
                    {
                        StringBuilder sberro = new StringBuilder();
                        UpdateMsg += auxMsgUserGenerico + " | NÃO ATUALIZADO | Erro: " + SharedData.FormatarErro(sberro, ex);

                        Log.GravaLog(UpdateMsg, "_MobiosImportaSharePoint_");
                    }

                }
                Fim = DateTime.Now;
                intervalo = Fim - Ini;
                IntervaloOut = "Atualização de " + (filteredDataTable_UPDATE.Rows.Count - aux2).ToString() + " Serviços | Tempo (hh:mm:ss) : " + intervalo.ToString(@"hh\:mm\:ss") + " | Qtde de Serviços avaliados: " + filteredDataTable_UPDATE.Rows.Count.ToString() + " | Qtde de Serviços sem Responsável: " + aux2.ToString();
                Log.GravaLog(IntervaloOut, "_MobiosImportaSharePoint_");
                #endregion

                string msgaux = "";
                if (sb.Length > 0 || sb2.Length > 0 || sb3.Length > 0)
                {
                    if (sb.Length > 0)
                        Log.GravaLog(sb.ToString(), "_MobiosImportaSharePoint_");

                    if (sb2.Length > 0)
                        Log.GravaLog(sb2.ToString(), "_MobiosImportaSharePoint_");

                    if (sb3.Length > 0)
                        Log.GravaLog(sb3.ToString(), "_MobiosImportaSharePoint_");

                    msgaux = "\n\nAtenção!!\n\nExistem IDs Origem que não foram transferidos para o Mobius, pois estão sem responsável definido no SharePoint.\n\nVisualize o log para ver detalhes.";

                }

                Log.GravaLog(sb_etapas.ToString(), "_MobiosImportaSharePoint_");


                #region [Concluir Demandas]
                Ini = DateTime.Now;
                Loading.EnableStaticTextBox("Concluindo demandas... Isto pode demorar alguns minutos.");

                Log.GravaLog("Concluindo demandas...", "_MobiosImportaSharePoint_");
                if (filteredDataTable_Conclude.Rows.Count > 0)
                {


                    for (int iii = 0; iii < filteredDataTable_Conclude.Rows.Count; iii++)
                    {

                        //verificando se tem que parar no ID_teste
                        if (id_origem_teste.ToUpper().IndexOf(filteredDataTable_Conclude.Rows[iii]["ID Origem"].ToString().ToUpper()) >= 0)
                        {
                            Console.WriteLine("Para no Id Origem: " + filteredDataTable_Conclude.Rows[iii]["ID Origem"].ToString());
                        }

                        Loading.EnableStaticTextBox("Concluindo demandas..." + iii + "/" + filteredDataTable_Conclude.Rows.Count);
                        Int32 IDServico = 0;
                        if (Int32.TryParse(filteredDataTable_Conclude.Rows[iii]["ID_Servico"].ToString(), out IDServico))
                        {
                            DataAccess.ConcluirServico(IDServico);
                            Log.GravaLog("IdServico: " + IDServico + " | ID Origem: " + filteredDataTable_Conclude.Rows[iii]["ID Origem"].ToString(), "_MobiosImportaSharePoint_");
                        }
                    }

                }
                Fim = DateTime.Now;
                intervalo = Fim - Ini;
                IntervaloOut = "Conclusão de demandas | Tempo (hh:mm:ss) : " + intervalo.ToString(@"hh\:mm\:ss") + "| Qtde de demandas concluídas: " + filteredDataTable_Conclude.Rows.Count.ToString();
                Log.GravaLog(IntervaloOut, "_MobiosImportaSharePoint_");
                #endregion

                frmLoading.Close();

                Fim = DateTime.Now;
                intervalo = Fim - IniGeral;
                IntervaloOut = "Processo de importação do SharePoint terminado | Tempo (hh:mm:ss) : " + intervalo.ToString(@"hh\:mm\:ss");
                Log.GravaLog(IntervaloOut, "_MobiosImportaSharePoint_");

                if (MostraMsg)
                    MessageBox.Show("Importação concluida." + msgaux + "\n\nTempo Gasto: " + intervalo.ToString(@"hh\:mm\:ss"), "Importação", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception err)
            {
                frmLoading.Close();
                Log.GravaLog("ERRO: " + err.Message, "_MobiosImportaSharePoint_");
                throw;
            }


        }
        public static int GetEtapaId(string name)
        {

            switch (name)
            {
                case "Emissão": return 1;
                case "Aguardando Contrato (Cliente)": return 2;
                case "Abono": return 3;
                case "Cadastramento": return 4;
                case "Implantação Técnica": return 5;
                case "Aguardando Docto do Cliente": return 6;
                case "Serviços Cash": return 7;
                case "Recepção": return 8;
                default:
                    return 0;
            }
        }

        public static void AbreFormMobiosCash_AjusteGrupos()
        {
            using (Form frm = new MobiosCash_AjustedeGrupos())
            {
                //frm.MdiParent = this;
                frm.WindowState = FormWindowState.Normal;
                frm.Left = 0;
                frm.Top = 0;
                frm.ShowDialog();
            }
        }
        #endregion

        #region [ Ruptura ]
        public static void TranscreverPortalFYAbertura(WebBrowser wb)
        {
            Loading l = null;
            try
            {
                l = new Loading();
                #region [ Parametros ]
                List<Campos> campos = new List<Campos>();
                ResponsavelServico r = new ResponsavelServico();
                DataTable dadosServico = new DataTable();
                int IdMetodo = 0;

                string url = "";
                switch (_CallerForm)
                {
                    case MethodForm.Minutas:
                        if (SharedData.isOpenForm(typeof(Minutas), false, false))
                        {
                            IdMetodo = ((Minutas)Application.OpenForms["Minutas"])._MyMethod.ID_Method;
                            url = ((Minutas)Application.OpenForms["Minutas"])._MyMethod.MethodParametro;
                            campos = ((Minutas)Application.OpenForms["Minutas"])._listaCamposServico;
                            r = ((Minutas)Application.OpenForms["Minutas"])._Responsavel;
                            if (r.ID_Servico != 0)
                            {
                                dadosServico = TratamentoCampo.ConvertObjectToDataTable(r);
                            }
                        }
                        break;
                    case MethodForm.Main:
                        if (SharedData.isOpenForm(typeof(MainForm), false, false))
                        {
                        }
                        break;
                    case MethodForm.Detalhe:
                        if (SharedData.isOpenForm(typeof(Detalhe), false, false))
                        {
                        }
                        break;
                }

                List<TraducaoValoresImportados> TraducaoValores = new List<TraducaoValoresImportados>();
                TraducaoValores = DataAccess.BuscaTraducaoValoresImportados("Metodo_" + IdMetodo).OrderBy(n => n.Ordem).ToList();
                List<int> Order = TraducaoValores.Select(n => n.Ordem).Distinct().ToList();

                #endregion

                    if (!SharedData.gHomologação)
                    {
                        Loading.EnableStaticTextBox("Processando...");
                        Loading.StaticFormVisible(true);
                    }

                    Log.GravaLog("-------------------- Serviço: " + r.ID_Servico + " Nome: " + r.ServicoName + "  --------------------", "_IntegraFY_Abertura");

                    #region [ navega para pagina inicial ]
                    string[] urls = url.Split(';');
                    if (SharedData.gHomologação)
                    {
                        //url = @"http://intracorp9hom.itau/fyportal/Q9/UIManterModalidade.aspx?IspbVeiculoLegal=60701190";
                        if (urls.Count() >= 3)
                        {
                            url = urls[2];
                        }
                        else
                        {
                            MessageBox.Show("Portal não encontrado");
                            return;
                        }
                    }
                    else
                    {
                        //url = @"http://intracorp9.itau/fyportal/Q9/UIManterModalidade.aspx?IspbVeiculoLegal=60701190";
                        if (urls.Count() >= 2)
                        {
                            url = urls[1];
                        }
                        else
                        {
                            MessageBox.Show("Portal não encontrado");
                            return;
                        }
                    }
                    #endregion

                    #region [ login ]
                    if (!SharedData.gHomologação)
                        Loading.EnableStaticTextBox("Realizando login...");
                    
                    string user = "";
                    string password = "";
                    bool Logado = WebFunctions.LoginMar2(url, user, password, wb, "container",true, "_IntegraFY_Abertura", 60);
                    bool credencialized = Logado;
                    if (!Logado)
                    {
                        if (!SharedData.gHomologação)
                            Loading.StaticFormVisible(false);
                        using (Credentials credenciais = new Credentials())
                        {
                            credenciais.ShowDialog();
                            user = credenciais._user;
                            password = credenciais._password;
                            credencialized = credenciais._credentialized;
                        }
                        if (credencialized)
                        {
                            if (!SharedData.gHomologação)
                                Loading.StaticFormVisible(true);

                            Logado = WebFunctions.LoginMar2(url, user, password, wb, "container", true, "_IntegraFY_Abertura", 60);
                        }
                    }
                    #endregion

                    DateTime Inicio;
                    TimeSpan Diferenca;
                    if (Logado)
                    {
                        bool MessageWebShow = false;
                        bool MessageWebShowLog = false;

                        bool PressionaOK = false;
                        bool PressionaOkLog = false;

                        string txtRetorno = "";

                        bool Fim = false;

                        BackgroundWorker bck = new BackgroundWorker();
                        bck.WorkerSupportsCancellation = false;
                        bck.WorkerReportsProgress = false;
                        bck.DoWork += (s, e) => { MessageWebShow = WebMessage.AguardaMensagem(); while (txtRetorno == "") { txtRetorno = WebMessage.GetAllText(); }; PressionaOK = WebMessage.PressOK(); };
                        bck.RunWorkerCompleted += (s, e) => { Fim = true; };
                        bck.RunWorkerAsync();

                        if (!SharedData.gHomologação)
                            Loading.EnableStaticTextBox("Processando campos...");

                        foreach (int ord in Order)
                        {
                            if (!SharedData.gHomologação)
                                Loading.EnableStaticTextBox("Processando campos... " + ord + "/" + Order.Count);

                            List<TraducaoValoresImportados> Traducao = TraducaoValores.FindAll(n => n.Ordem == ord);

                            bool ValorEncontrado = false;
                            foreach (TraducaoValoresImportados trad in Traducao)
                            {
                                if (trad.Evento.ToUpper() == "NAVIGATE" && trad.ValorCampoExterno != "")
                                {
                                    #region [ navigate ]
                                    Log.GravaLog("Navegando: " + trad.ValorCampoExterno, "_IntegraFY_Abertura");
                                    wb.Navigate(trad.ValorCampoExterno);
                                    Inicio = DateTime.Now;
                                    while (wb.ReadyState != WebBrowserReadyState.Complete || wb.Url == null || wb.Url.ToString().Replace("https", "http") != url.Replace("https", "http"))
                                    {
                                        Diferenca = DateTime.Now.Subtract(Inicio);
                                        Application.DoEvents();
                                        if (Diferenca.TotalSeconds >= 30)
                                        {
                                            Log.GravaLog("TIMEOUT", "_IntegraFY_Abertura");
                                            throw new Exception("TIMEOUT - A navegação para o site ('" + trad.ValorCampoExterno + "') não foi concluída. Tente novamente.");
                                        }
                                        Application.DoEvents();
                                    }
                                    #endregion
                                    ValorEncontrado = true;
                                }
                                else
                                {
                                    if (trad.NomeCampoExterno != "") // se não há nome do campo externo, então não há ação
                                    {
                                        #region [ Busca valor ]
                                        string valor = "";
                                        if (trad.NomeCampoMobios == "") // se não há campo do mobios, adota padrão cadastrado para o campo externo
                                        {
                                            valor = trad.ValorCampoExterno;
                                            ValorEncontrado = true;
                                        }
                                        else if (trad.ValorCampoExterno == "" && trad.ValorCampoMobios == "" && trad.NomeCampoMobios != "") // se há apenas o nome do campo externo e nome do mobios, o valor será o do Mobios
                                        {
                                            if (trad.NomeCampoMobios.StartsWith("[") && trad.NomeCampoMobios.EndsWith("]"))
                                            {
                                                if (dadosServico.Columns.Contains(trad.NomeCampoMobios.Replace("[", "").Replace("]", "")))
                                                {
                                                    valor = dadosServico.Rows[0][trad.NomeCampoMobios.Replace("[", "").Replace("]", "")].ToString();
                                                    ValorEncontrado = true;
                                                }
                                            }
                                            else
                                            {
                                                Campos c = campos.Find(n => n.ID_Campo == Convert.ToInt32(trad.NomeCampoMobios));
                                                if (c != null)
                                                {
                                                    valor = c.ValorCampo;
                                                    ValorEncontrado = true;
                                                }
                                            }
                                        }
                                        else // segue as regras do De/Para
                                        {
                                            if (trad.NomeCampoMobios.StartsWith("[") && trad.NomeCampoMobios.EndsWith("]"))
                                            {
                                                if (dadosServico.Rows[0][trad.NomeCampoMobios.Replace("[", "").Replace("]", "")].ToString().ToUpper() == trad.ValorCampoMobios.ToUpper())
                                                {
                                                    valor = trad.ValorCampoExterno;
                                                    ValorEncontrado = true;
                                                }
                                            }
                                            else
                                            {
                                                Campos c = campos.Find(n => n.ID_Campo == Convert.ToInt32(trad.NomeCampoMobios) && n.ValorCampo.ToUpper() == trad.ValorCampoMobios.ToUpper());
                                                if (c != null)
                                                {
                                                    valor = trad.ValorCampoExterno;
                                                    ValorEncontrado = true;
                                                }
                                            }
                                        }
                                        #endregion

                                        if (ValorEncontrado)
                                        {
                                            valor = TratamentoCampo.Splitter(valor, trad.Separadores, trad.Posicao);
                                        }

                                        if (ValorEncontrado)
                                        {
                                            Log.GravaLog("Nome Campo: " + trad.NomeCampoExterno + " - Valor: " + valor + " - Evento: " + trad.Evento, "_IntegraFY_Abertura");
                                            try
                                            {
                                                WebFunctions.PreenchePaginaWebById(wb, trad.NomeCampoExterno, valor, trad.Evento, 5);
                                            }
                                            catch (Exception errTransc)
                                            {
                                                Log.GravaLog("Erro: " + errTransc.Message, "_IntegraFY_Abertura");
                                                if (!Fim)
                                                {
                                                    // Se não encontrou nenhuma janela de resposta da web, quer dizer que deu erro de timeout
                                                    throw new Exception("Erro: " + errTransc.Message + "Campo " + trad.NomeCampoExterno);
                                                }
                                                else
                                                {
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                                if (ValorEncontrado)
                                    break;
                            }

                            if (Fim)
                            {
                                //encontrou resposta da web, finaliza o processo
                                Log.GravaLog("Retorno: " + txtRetorno, "_IntegraFY_Abertura");
                                Log.GravaLog("-------------------- Processo Concluído --------------------", "_IntegraFY_Abertura");
                                if (!SharedData.gHomologação)
                                    Loading.StaticFormVisible(false);
                                MessageBox.Show(txtRetorno, "Transcrição FY Abertura", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                try
                                {
                                    l.Close();
                                }
                                catch { }
                                return;
                            }
                        }
                        bck.Dispose();

                        //espera mensagem de confirmação do cadastro
                        MessageWebShow = false;
                        MessageWebShowLog = false;

                        PressionaOK = false;
                        PressionaOkLog = false;

                        txtRetorno = "";

                        Fim = false;

                        bck = new BackgroundWorker();
                        bck.WorkerSupportsCancellation = false;
                        bck.WorkerReportsProgress = false;
                        bck.DoWork += (s, e) => { MessageWebShow = WebMessage.AguardaMensagem(); while (txtRetorno == "") { txtRetorno = WebMessage.GetAllText(); }; PressionaOK = WebMessage.PressOK(); };
                        bck.RunWorkerCompleted += (s, e) => { Fim = true; };
                        bck.RunWorkerAsync();

                        while (Fim != true)
                        {
                            if (MessageWebShow && !MessageWebShowLog)
                            {
                                Log.GravaLog("Mensagem da web encontrada", "_IntegraFY_Abertura");
                                MessageWebShowLog = true;
                            }
                            if (PressionaOK && !PressionaOkLog)
                            {
                                Log.GravaLog("Botão OK clicado", "_IntegraFY_Abertura");
                                PressionaOkLog = true;
                            }
                            Application.DoEvents();
                        }
                        bck.Dispose();
                        Log.GravaLog("Retorno: " + txtRetorno, "_IntegraFY_Abertura");
                        Log.GravaLog("-------------------- Processo Concluído --------------------", "_IntegraFY_Abertura");
                        if (!SharedData.gHomologação)
                            Loading.StaticFormVisible(false);
                        MessageBox.Show(txtRetorno, "Transcrição FY Abertura", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        if (credencialized)
                        {
                            MessageBox.Show("Não foi possível logar.\n\nConfira seus acessos.", "Login Mar2", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                    }
                try
                {
                    l.Close();
                }
                catch { }
            }
            catch (Exception err)
            {
                if (!SharedData.gHomologação)
                    Loading.StaticFormVisible(false);
                try
                {
                    l.Close();
                }
                catch { }
                throw new Exception(err.Message);
            }
            
        }
        #endregion

        #region [ CAGI ]
        public static void IntegracaoCAGI()
        {
            #region [ Parametros ]
            string CaminhoCarregamento = ""; //ConfigurationManager.AppSettings["CaminhoCarregamento"].ToString()
            //\\bbaprod3\bo\Ativas\ativas - formalizacao\Comum\__Sistema VOBERG\Arquivo de Carregamento
            string ArquivoCopiaCPE = ""; //ConfigurationManager.AppSettings["ArquivoCopiaCPE"].ToString()
            //\\bbaprod3\bo\Ativas\ativas - formalizacao\Comum\__Sistema VOBERG\System\CPE.xlsx

            switch (_CallerForm)
            {
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false, false))
                    {
                        string[] parameters = ((MainForm)Application.OpenForms["MainForm"])._MyMethod.MethodParametro.Split(';');
                        CaminhoCarregamento = parameters[0];
                        ArquivoCopiaCPE = parameters[1];
                    }
                    break;
                case MethodForm.MainBackGround:
                    if (SharedData.isOpenForm(typeof(MainForm), false, false))
                    {
                        string[] parameters = ((MainForm)Application.OpenForms["MainForm"])._MyMethodBackground.MethodParametro.Split(';');
                        CaminhoCarregamento = parameters[0];
                        ArquivoCopiaCPE = parameters[1];
                    }
                    break;
            }
            
            if (SharedData.gHomologação)
            {
                ArquivoCopiaCPE = SharedData.BDPath + "CPEhomologacao.xlsx";
            }
            #endregion

            #region [ Carregamento do arquivo do CPE ]
            string msgLog = "";
            MainForm.EnableStaticTextBox(DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + " - Lendo pasta de carregamento...");
            
            #region [ Pega o relatório do CPE que está na pasta] 
            msgLog = "Buscando arquivos do CPE para cópia e carregamento no diretório";
            Log.GravaLog(msgLog, "_IntegracaoCAGI");

            var directory = new DirectoryInfo(CaminhoCarregamento);
            string[] files = System.IO.Directory.GetFiles(CaminhoCarregamento, "*.*", SearchOption.AllDirectories);
            #endregion

            if (files.Length != 0)
            {
                #region [ Abrir Arquivo CPE ]
                foreach (FileInfo myFile in directory.GetFiles())
                {
                    msgLog = "Carregando o arquivo " + myFile.Name;
                    Log.GravaLog(msgLog, "_IntegracaoCAGI");
                    if (myFile != null && myFile.Extension.ToLower().Contains("xls"))
                    {
                        MainForm.EnableStaticTextBox("Carregando o arquivo " + myFile.Name + "...");

                        //Copia o relatório do CPE para outro excel para que não ocorra erro de arquivo aberto
                        string PathArquivoCopia = ArquivoCopiaCPE.Substring(0, ArquivoCopiaCPE.LastIndexOf(@"\"));
                        Log.CriaDiretorioRede(PathArquivoCopia);

                        File.Copy(myFile.FullName, ArquivoCopiaCPE, true);

                        if (!SharedData.gHomologação)
                        {
                            msgLog = "Deletando o arquivo " + myFile.Name;
                            Log.GravaLog(msgLog, "_IntegracaoCAGI");

                            //Deleta o arquivo da pasta para que outro não faça a mesma leitura.
                            myFile.Delete();
                        }
                        break;
                    }
                }

                //DataTable dtCPE = DataAccess.GetImportacaoCPE();

                msgLog = "Abrindo o arquivo " + ArquivoCopiaCPE;
                Log.GravaLog(msgLog, "_IntegracaoCAGI");

                DataTable dtCPE = null;
                try
                {
                    dtCPE = DataConnector.ExecuteDataTableExcel(ArquivoCopiaCPE);
                }
                catch (Exception errExcel)
                {
                    msgLog = "Erro: " + errExcel.Message;
                    Log.GravaLog(msgLog, "_IntegracaoCAGI");
                    MainForm.EnableStaticTextBox(msgLog);
                    MessageBox.Show("Erro na integração com o arquivo CPE.\n\n" + msgLog, "Integração CPE", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                #endregion

                #region [ Filtra data D-1 ]
                if (dtCPE != null && dtCPE.Rows.Count > 0)
                {
                    DateTime DtExtração = Convert.ToDateTime(dtCPE.Rows[0]["Data Extração"]);
                    DataRow[] dtCPErows = dtCPE.Select("CONVERT([Dt# Inclusão Pendência], 'System.DateTime') = #" + DtExtração.ToString("yyyy/MM/dd") + "#");

                    if (dtCPErows.Count() > 0)
                    {
                        dtCPE = dtCPErows.CopyToDataTable();
                    }
                    else
                    {
                        dtCPE.Rows.Clear();
                        dtCPE = null;
                    }
                }
                #endregion

                List<ResponsavelServico> Serviços = DataAccess.BuscarServicoResponsavel();

                if (dtCPE != null && dtCPE.Rows.Count > 0)
                {
                    #region [ Abrindo Serviços ]
                    List<SharePointServicoRetorno> Parametros = new List<SharePointServicoRetorno>();
                    Parametros = DataAccess.BuscaParametrosServicoImportados("CAGI");

                    List<string> result = new List<string>();
                    foreach (SharePointServicoRetorno Parametro in Parametros)
                    {
                        List<string> resultParcial = new List<string>();

                        #region [ Filtrar DataTable ]
                        string[] CriteriosCampos = Parametro.CamposCriterioSP.Split(';');
                        string[] CriteriosValores = Parametro.ValoresCriterioSP.Split(';');

                        if (CriteriosCampos.Count() != CriteriosValores.Count())
                        {
                            throw new Exception("Falha no cadastro dos parâmetros para importação do CPE.\n\nContate a equipe de Automação de Processos.");
                        }

                        int iMax = CriteriosCampos.Count();
                        string filtro = "";
                        for (int i = 0; i < iMax; i++)
                        {
                            if (filtro != "")
                                filtro += " AND";
                            filtro += "CONVERT([" + CriteriosCampos[i] + "], 'System.String') = '" + CriteriosValores[i] + "'";
                        }

                        DataTable resultDt = new DataTable();
                        if (filtro != "")
                        {
                            DataRow[] resultRows = dtCPE.Select(filtro);
                            if (resultRows.Count() > 0)
                            {
                                resultDt = resultRows.CopyToDataTable();
                            }
                            msgLog = "Filtro: " + filtro;
                            Log.GravaLog(msgLog, "_IntegracaoCAGI");
                        }
                        
                        
                        msgLog = "Operações Filtradas: " + resultDt.Rows.Count;
                        Log.GravaLog(msgLog, "_IntegracaoCAGI");
                        #endregion

                        if (resultDt.Rows.Count > 0)
                        {
                            string camposGerais = Parametro.CampoRetornarSP;
                            string camposGeraisMobios = Parametro.CampoRetornarMobios;
                            string camposOperacao = Parametro.NomeCampoOperacaoSP;
                            string camposMobios = Parametro.CampoOperacaoMobios;

                            #region [ Retira serviços já existentes ]
                            string[] dadosservico =  Parametro.CampoRetornarSP.Split(';');
                            string[] camposservico =  Parametro.CampoRetornarMobios.Split(';');
                            if (dadosservico.Count() == camposservico.Count())
                            {
                                int index = Array.IndexOf(camposservico, "[ServicoName]");

                                if (index != -1)
                                {
                                    string columnName = dadosservico[index];
                                    if (resultDt.Columns.Contains(columnName))
                                    {
                                        for (int i = (resultDt.Rows.Count - 1); i >= 0; i--)
                                        {
                                            string serviconame = resultDt.Rows[i][columnName] == null ? "" : resultDt.Rows[i][columnName].ToString().ToUpper();
                                            if (Serviços.Exists(n => n.ServicoName.ToUpper() == serviconame))
                                            {
                                                resultDt.Rows[i].Delete();
                                                resultDt.AcceptChanges();
                                            }
                                        }
                                    }
                                }
                            }
                            #endregion

                            if (resultDt.Rows.Count > 0)
                            {
                                msgLog = "Abrindo serviços";
                                Log.GravaLog(msgLog, "_IntegracaoCAGI");
                                resultParcial = AbreServico.AbreServicos(resultDt, camposGerais, camposGeraisMobios, Parametro.SharePoint.ToUpper(), camposOperacao, camposMobios, "_IntegracaoCAGI");
                                result.AddRange(resultParcial);
                            }
                        }
                    }
                    msgLog = "Arquivo Carregado";
                    Log.GravaLog(msgLog, "_IntegracaoCAGI");
                    MainForm.EnableStaticTextBox("Arquivo carregado...");
                    msgLog = "Quantidade de Serviços Abertos: " + result.Count();
                    Log.GravaLog(msgLog, "_IntegracaoCAGI");
                    MainForm.EnableStaticTextBox(msgLog);
                    #endregion
                }
                else
                {
                    msgLog = "Nenhum registro localizado";
                    Log.GravaLog(msgLog, "_IntegracaoCAGI");
                    MainForm.EnableStaticTextBox("Nenhum registro localizado");
                }
            }
            else
            {
                msgLog = "Não foi encontrado nenhum arquivo para carregar na base";
                Log.GravaLog(msgLog, "_IntegracaoCAGI");
                MainForm.EnableStaticTextBox("Não foi encontrado nenhum arquivo para carregar...");
            }
            #endregion
        }
        public static void EnviaAlertas()
        {
            #region [ Alertas ]
            string msgLog = "Buscando alertas para serem enviados";
            Log.GravaLog(msgLog, "_IntegracaoCAGI");
            MainForm.EnableStaticTextBox(DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + " - Buscando alertas de FUP para enviar...");
            //pega FUPs com alertas não encerrados do usuário logado
            List<FollowUp> listAlertaFollowUp = DataAccess.GetAlertaFollowUp();

            if (listAlertaFollowUp.Count > 0)
            {
                msgLog = "Foram encontrados " + listAlertaFollowUp.Count.ToString() + " alertas que serão enviados.";
                Log.GravaLog(msgLog, "_IntegracaoCAGI");
                MainForm.EnableStaticTextBox(msgLog);
                MainForm.EnableStaticTextBox("Iniciando envio de alerta de FUP...");

                foreach (FollowUp alertaFollow in listAlertaFollowUp)
                {
                    if (alertaFollow.FUPAlerta != null)
                    {
                        //se a data de alerta é menor que hoje, envia os emails pois ainda não estão fechados
                        if (Convert.ToDateTime(alertaFollow.FUPAlerta.ToString("dd/MM/yyyy")) < Convert.ToDateTime(DateTime.Now.ToString("dd/MM/yyyy")))
                        {
                            #region [PEGA OS CAMPOS DO SERVIÇO PARA COLOCAR NO E-MAIL ]
                            List<Campos> listaCamposServico = DataAccess.buscarCamposDinamicosConjunto(alertaFollow.ID_Servico);
                            string parmBody = "<span style='font-size:12.0pt; color:#003399'>Prezados,</span><br><br><span style='font-size:12.0pt; color:#003399'>O SLA de 5 dias úteis da pendência abaixo não foi cumprido.<br><br>" + alertaFollow.FollowUpEtapa + "<br><br>Peço total atenção. Seguem os dados da garantia:</span><br><br>";

                            parmBody += "<table border=0 cellspacing=0 cellpadding=2 width=450><tr><td colspan=2 width=450><font color=#003399><b>Dados da Garantia</b></font></td></tr>";
                            foreach (Campos valorCampo in listaCamposServico)
                            {
                                switch (valorCampo.CampoTipo.ToUpper())
                                {
                                    case "CHECKBOX":
                                        if (valorCampo.ValorCampo.ToUpper() == "TRUE")
                                        {
                                            parmBody += "<tr bgcolor=#fffff ><td align=right valign=middle width=250>&nbsp;</td><td td align=left valign=middle width=200>" + valorCampo.CampoLabel + "</td></tr>";
                                        };
                                        break;
                                    case "LABEL":
                                        parmBody += "<tr bgcolor=#fffff ><td colspan=2 align=middle valign=middle width=450><b>" + valorCampo.CampoNome + "</b></td></tr>";
                                        break;
                                    default:
                                        if (valorCampo.ValorCampo != "" && valorCampo.ValorCampo != null)
                                        {
                                            parmBody += "<tr bgcolor=#fffff ><td align=right valign=middle width=250>" + valorCampo.CampoLabel + ":</td><td td align=left valign=middle width=200>" + valorCampo.ValorCampo + "</td></tr>";
                                        }
                                        break;
                                }
                            }
                            parmBody += "</table><br>";
                            string subject = "[FUP] PENDÊNCIA: " + alertaFollow.Pendencia;
                            #endregion

                            SharedData.CreateMailItem(subject, alertaFollow.EmailResponsavel, parmBody, "", false, alertaFollow.CCEmail);
                            DataAccess.AtualizarDataAlerta(alertaFollow, 5); //adiciona 5 dias úteis à data alerta. após o prazo será enviado novamente se não for encerrado
                        }
                    }
                }
                msgLog = "Processo de envio de alerta finalizado";
                Log.GravaLog(msgLog, "_IntegracaoCAGI");
                MainForm.EnableStaticTextBox("Processo de envio de alerta finalizado. Foram enviados " + listAlertaFollowUp.Count.ToString() + " alertas...");
            }
            else
            {
                msgLog = "Não foi encontrado nenhum alerta para envio.";
                Log.GravaLog(msgLog, "_IntegracaoCAGI");
                MainForm.EnableStaticTextBox("Não foi encontrado nenhum alerta de FUP para ser enviado...");
            }
            #endregion
        }
        public static void FUPalertas()
        {
            FollowUp ReturnFollow = new FollowUp();

            switch (_CallerForm)
            {
                case MethodForm.FollowUp:
                    if (SharedData.isOpenForm(typeof(FollowUpEtapa), false, false))
                    {
                        ReturnFollow = ((FollowUpEtapa)Application.OpenForms["FollowUpEtapa"])._Follow;
                    }
                    break;
            }

            if (ReturnFollow != null)
            {
                if (!SharedData.isOpenForm(typeof(FUPEtapa), false))
                {
                    Form frm = new FUPEtapa(ReturnFollow);
                    frm.WindowState = FormWindowState.Normal;
                    frm.StartPosition = FormStartPosition.CenterScreen;
                    frm.Left = 0;
                    frm.Top = 0;
                    frm.ShowDialog();
                }
            }
        }
        public static void GarantiasAnaliseRegistrarFUP()
        {
            #region [ Parametros ]
            List<Campos> camposEtapa = null;
            string CamposParametro = "";
            string ValoresParametro = "";
            int IdEtapa = 0;
            int IdServico = 0;

            switch (_CallerForm)
            {
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false, false))
                    {
                        camposEtapa = ((Detalhe)Application.OpenForms["Detalhe"])._listaCamposEtapas;
                        IdEtapa = ((Detalhe)Application.OpenForms["Detalhe"])._Etapa.ID_Etapa;
                        IdServico = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel.ID_Servico;
                        string[] param = ((Detalhe)Application.OpenForms["Detalhe"])._MyMethod.MethodParametro.Split('|');

                        CamposParametro = param[0];
                        ValoresParametro = param[1];
                    }
                    break;
            }

            string[] CamposParametrosArray = CamposParametro.Split(';');
            string[] ValoresParametroArray = ValoresParametro.Split(';');

            #endregion

            //5017 e 5032
            // "Registro - Resultado Analise NOK" || "Validacao - Registro NOK")

            // valida regra qualquer um dos valores passados
            bool validado = false;
            if (CamposParametro != "")
            {
                for (int i = 0; i < CamposParametrosArray.Count(); i++)
                {
                    Campos c = camposEtapa.Find(n => n.ID_Campo == Convert.ToInt32(CamposParametrosArray[i]) && n.ID_Etapa == IdEtapa);

                    if (c != null && Convert.ToInt32(CamposParametrosArray[i]) != 0)
                    {
                        if (c.ValorCampo.ToUpper() == ValoresParametroArray[i].ToUpper())
                        {
                            validado = true;
                            break;
                        }
                    }
                }
            }

            if (validado)
            {
                string msgFUP = "A análise não está OK.\n\nRegistrar um FollowUp para esta garantia?";

                if (MessageBox.Show(msgFUP, "Registrar FollowUp", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    if (IdEtapa > 0)
                    {
                        FollowUp _FollowUp = new FollowUp();
                        _FollowUp.ID_Servico = IdServico;
                        _FollowUp.ID_Fluxo = IdEtapa;
                        _FollowUp.FollowUpEtapa = "";

                        Form frm = new FUPEtapa(_FollowUp);
                        frm.WindowState = FormWindowState.Normal;
                        frm.StartPosition = FormStartPosition.CenterScreen;
                        frm.Left = 0;
                        frm.Top = 0;
                        frm.ShowDialog();
                    }
                }
            }
        }
        public static void CampoFinalizarServico()
        {
            #region [ Parametros ]
            List<Campos> camposEtapa = null;
            string CamposParametro = "";
            string ValoresParametro = "";
            int IdEtapa = 0;
            int IdServico = 0;
            List<FluxoServico> FluxosServico = null;

            switch (_CallerForm)
            {
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false, false))
                    {
                        FluxosServico = ((Detalhe)Application.OpenForms["Detalhe"])._fluxoServico;
                        camposEtapa = ((Detalhe)Application.OpenForms["Detalhe"])._listaCamposEtapas;
                        IdEtapa = ((Detalhe)Application.OpenForms["Detalhe"])._Etapa.ID_Etapa;
                        IdServico = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel.ID_Servico;
                        string[] param = ((Detalhe)Application.OpenForms["Detalhe"])._MyMethod.MethodParametro.Split('|');

                        CamposParametro = param[0];
                        ValoresParametro = param[1];
                    }
                    break;
            }

            string[] CamposParametrosArray = CamposParametro.Split(';');
            string[] ValoresParametroArray = ValoresParametro.Split(';');

            #endregion

            //5012 || 5022 - valor Sim
            bool validado = false;
            for (int i = 0; i < CamposParametrosArray.Count(); i++)
            {
                Campos c = camposEtapa.Find(n => n.ID_Campo == Convert.ToInt32(CamposParametrosArray[i]));

                if (c != null && Convert.ToInt32(CamposParametrosArray[i]) != 0)
                {
                    if (c.ValorCampo.ToUpper() == ValoresParametroArray[i].ToUpper())
                    {
                        validado = true;
                        break;
                    }
                }
            }

            if (validado)
            {
                //foreach (FluxoServico fluxoS in FluxosServico)
                //{
                    //if (fluxoS.ID_Status != 5)
                    //{
                DataAccess.ConcluirServico(IdServico, "_IntegracaoCAGI");
                MessageBox.Show("Serviço " + IdServico + " finalizado.","Concluir serviço",MessageBoxButtons.OK, MessageBoxIcon.Information);
                if (SharedData.isOpenForm(typeof(Detalhe), false, false))
                {
                    try
                    {
                        ((Detalhe)Application.OpenForms["Detalhe"]).Close();
                    }
                    catch { }
                }
                    //}
                //}
            }
        }
        public static void TabelaFollowUp()
        {
            //Campo 5037
            //if (linhaDGV.Cells["NUMERACAO"].Value != "") // validar a numeração - Campo Obrigatório

            #region [ Parametros ]
            int IdCampo = 0;
            int IdServico = 0;
            List<Campos> camposServico = null;

            switch (_CallerForm)
            {
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                        IdServico = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel.ID_Servico;
                        Int32.TryParse(((Detalhe)Application.OpenForms["Detalhe"])._MyMethod.MethodParametro, out IdCampo);
                        camposServico = ((Detalhe)Application.OpenForms["Detalhe"])._listaCamposServico;
                    }
                    break;
            }
            #endregion

            if (IdServico != 0 && IdCampo != 0)
            {
                DataTable dtCampo = DataAccess.BuscarTabela(IdServico, IdCampo);

                //Para cada linha da tabela, atualiza ou cria novo follow-up
                bool validador = true;
                foreach (DataRow linhaDGV in dtCampo.Rows)
                {
                    if (!linhaDGV.Table.Columns.Contains("NUMERACAO") || linhaDGV["NUMERACAO"] == null || linhaDGV["NUMERACAO"].ToString() == "")
                    {
                        validador = false;
                        break;
                    }
                }

                if (validador)
                {
                    if (dtCampo.Rows.Count > 0)
                    {
                        foreach (DataRow linhaDGV in dtCampo.Rows)
                        {
                            string Numeracao = linhaDGV.Table.Columns.Contains("NUMERACAO") ? linhaDGV["NUMERACAO"].ToString() : "";
                            string DtExigencia = linhaDGV.Table.Columns.Contains("DATA EXIGENCIA") ? linhaDGV["DATA EXIGENCIA"].ToString() : "";
                            string Nota = linhaDGV.Table.Columns.Contains("NUM NOTA") ? linhaDGV["NUM NOTA"].ToString() : "";
                            string Descrição = linhaDGV.Table.Columns.Contains("DESCRICAO") ? linhaDGV["DESCRICAO"].ToString() : "";
                            string Analista = linhaDGV.Table.Columns.Contains("ANALISTA INTERNO") ? linhaDGV["ANALISTA INTERNO"].ToString() : "";
                            string Responsavel = linhaDGV.Table.Columns.Contains("NOME RESPONSAVEL") ? linhaDGV["NOME RESPONSAVEL"].ToString() : "";
                            string Email = linhaDGV.Table.Columns.Contains("EMAIL RESPONSAVEL") ? linhaDGV["EMAIL RESPONSAVEL"].ToString() : "";
                            string Data = linhaDGV.Table.Columns.Contains("DATA RESOLVIDO") ? linhaDGV["DATA RESOLVIDO"].ToString() : "";
                            string CPE = linhaDGV.Table.Columns.Contains("CPE") ? linhaDGV["CPE"].ToString() : "";

                            //Busca FollowUps da exigência
                            string sqlCons = "SELECT * FROM tb_0128_FollowUpEtapaServico WHERE ID_Servico = {0} And ID_Exigencia = '{1}'";
                            sqlCons = string.Format(sqlCons, IdServico, Numeracao);
                            DataTable dtCons = DataConnector.ExecuteDataTable(sqlCons, "BDconsulta");

                            if (dtCons.Rows.Count > 0)
                            {
                                //ATUALIZAÇÃO DO FOLLOW UP
                                string sqlUpd = "UPDATE tb_0128_FollowUpEtapaServico SET Responsavel = '{0}', EmailResponsavel = '{1}', FollowUpEtapa = '{2}', FUPEncerrado = {3}, DataAlteracao = #{4}#  WHERE tb_0128_FollowUpEtapaServico.ID_Servico = {5} And tb_0128_FollowUpEtapaServico.ID_Exigencia = '{6}'";
                                sqlUpd = string.Format(sqlUpd, Responsavel, Email, Descrição, (Data != "" ? true : false), DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"), IdServico, Numeracao);
                                DataConnector.ExecuteDataTable(sqlUpd, "BDconsulta");
                            }
                            else
                            {
                                //CRIAÇÃO DE FOLLOW UP
                                string sqlCmd = "INSERT INTO tb_0128_FollowUpEtapaServico (ID_Servico, Pendencia, Responsavel, EmailResponsavel, FollowUpEtapa, FUPEncerrado, DataCriacao, DataAlerta, Login, ID_Exigencia ) ";
                                sqlCmd += "Values ({0}, 'Exigência Cartorária', '{1}', '{2}', '{3}', {4}, #{5}#, IIf(Weekday(Date()+5)=7,Date()+5,IIf(Weekday(Date())=4 Or Weekday(Date())=5 Or Weekday(Date())=6,Date()+5,Date()+5)), '{6}', '{7}') ";
                                //sqlCmd += "FROM vw_TabelaExigencias WHERE IdServico = {1} And NUMERACAO = '{2}'";

                                sqlCmd = string.Format(sqlCmd, IdServico, Responsavel, Email, Descrição, (Data != "" ? true : false), DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"), Environment.UserName.ToUpper(), Numeracao);
                                DataConnector.ExecuteDataTable(sqlCmd, "BDconsulta");

                                //ENVIO DE EMAIL ASSIM QUE A EXIGÊNCIA FOI CRIADA
                                //PEGA OS CAMPOS DO SERVIÇO PARA COLOCAR NO E-MAIL
                                string parmBody = "<span style='font-size:12.0pt; color:#003399'>Prezados,</span><br><br><span style='font-size:12.0pt; color:#003399'>Foi gerada a pendência abaixo.<br><br>" + Descrição + "<br><br>Peço atenção.<br><br>Abaixo seguem os dados da garantia:</span><br><br>";

                                parmBody += "<table border=0 cellspacing=0 cellpadding=2 width=450><tr><td colspan=2 width=450><font color=#003399><b>Dados da Garantia</b></font></td></tr>";

                                foreach (Campos valorCampo in camposServico)
                                {
                                    switch (valorCampo.CampoTipo.ToUpper())
                                    {
                                        case "CHECKBOX":
                                            if (valorCampo.ValorCampo == "True")
                                            {
                                                parmBody += "<tr bgcolor=#fffff ><td align=right valign=middle width=250>&nbsp;</td><td td align=left valign=middle width=200>" + valorCampo.CampoLabel + "</td></tr>";
                                            };
                                            break;
                                        case "LABEL":
                                            parmBody += "<tr bgcolor=#fffff ><td colspan=2 align=middle valign=middle width=450><b>" + valorCampo.CampoNome + "</b></td></tr>";
                                            break;
                                        default:
                                            if (valorCampo.ValorCampo != "" && valorCampo.ValorCampo != null)
                                            {
                                                parmBody += "<tr bgcolor=#fffff ><td align=right valign=middle width=250>" + valorCampo.CampoLabel + ":</td><td td align=left valign=middle width=200>" + valorCampo.ValorCampo + "</td></tr>";
                                            }
                                            break;
                                    }
                                }
                                parmBody += "</table><br>";

                                string subject = "[CAGI - FUP] EXIGÊNCIA CARTORÁRIA";
                                string To = "";
                                if (Email != null)
                                {
                                    To = Email;
                                }
                                SharedData.CreateMailItem(subject, To, parmBody, "", true);
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("O campo Numeração é obrigatório para se registrarem os Follow-Ups", "Follow-Up", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else
            {
                throw new Exception("Os parâmetros de campos IdServiço e IdCampo estão incorretos");
            }
        }
        #endregion

        #region [MiniSimCreditoRural

        /*Necessidades para o MonisimCrédito Rural
         * 1 - Criar tabela LEGO no banco de dados
         * 2 - Incluir coluna de ordem na tabela tb_0602_CamposMinutas
         * 3 - Alterar função de exportaMinuta, pois deverá ocorrer alteração de texto também no corpo do arquivo docx.
         * */


        public static LinhaColuna GetLinhaColuna(string CellName)
        {
            char cellLetter = CellName.Substring(0, 1).ToUpper()[0];
            int xCoordinate = (cellLetter - 'A') + 1;
            int yCoordinate = int.Parse(CellName.Substring(1));
            LinhaColuna MinhaLinhaColuna = new LinhaColuna();
            MinhaLinhaColuna.colIndex = xCoordinate;
            MinhaLinhaColuna.rowIndex = yCoordinate;
            return MinhaLinhaColuna;
        }
        public static void fecharExcel(Microsoft.Office.Interop.Excel.Application xlApp, Microsoft.Office.Interop.Excel.Workbook xlWorkBook, Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet, Microsoft.Office.Interop.Excel.Worksheet xlWorkSheetList)
        {
            #region [ fecha arquivo ]
            string msgLog = "Fechando planilha Excel.";
            Log.GravaLog(msgLog);

            if (xlWorkSheet != null) { Marshal.FinalReleaseComObject(xlWorkSheet); }
            if (xlWorkSheetList != null) { Marshal.FinalReleaseComObject(xlWorkSheetList); }
            if (xlWorkBook != null) { xlWorkBook.Close(false, false); Marshal.FinalReleaseComObject(xlWorkBook); }
            // Fechar
            if (xlApp != null) { xlApp.Quit(); Marshal.FinalReleaseComObject(xlApp); }
            xlWorkBook = null;
            xlWorkSheet = null;
            xlApp = null;

            GC.Collect();
            GC.WaitForPendingFinalizers();
            #endregion
        }
        //Deleta arquivo apenas se estiver dentro da pasta do projeto
        public static void DeletaArquivo(string PathArquivo)
        {
            #region [ Deleta Arquivo Copiado ]
            if (File.Exists(PathArquivo))
            {
                if (Path.GetDirectoryName(PathArquivo) == Application.ExecutablePath)
                {
                    try
                    {
                        File.Delete(PathArquivo);
                    }
                    catch { }
                }
            }
            #endregion
        }


        public static List<string> ReadDropDownValues(Excel.Workbook xlWorkBook, Excel.Range dropDownCell)
        {
            List<string> result = new List<string>();
            try
            {
                string formulaRange = dropDownCell.Validation.Formula1;

                //Estava tentando calcular o resultado da formúla, mas não deu!!!!
                //string currentFormula = formulaRange;//"=Sheet1!$B$3 + Sheet1!$C$3+Sheet1!$D$3+Sheet1!$E$3+Sheet1!$F$3+Sheet1!$G$3";
                //Caculate arithmetic expression about cells
                //object formulaResult = null;
                //formulaResult = xlWorkBook.CaculateFormulaValue(currentFormula);
                //string value = formulaResult.ToString();


                string[] formulaRangeWorkSheetAndCells = formulaRange.Substring(1, formulaRange.Length - 1).Split('!');
                string[] splitFormulaRange = formulaRangeWorkSheetAndCells[1].Split(':');
                Excel.Worksheet xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(formulaRangeWorkSheetAndCells[0]);

                Excel.Range valRange = (Excel.Range)xlWorkSheet.get_Range(splitFormulaRange[0], splitFormulaRange[1]);
                for (int nRows = 1; nRows <= valRange.Rows.Count; nRows++)
                {
                    for (int nCols = 1; nCols <= valRange.Columns.Count; nCols++)
                    {
                        Excel.Range aCell = (Excel.Range)valRange.Cells[nRows, nCols];
                        if (aCell.Value2 != null)
                        {
                            result.Add(aCell.Value2.ToString());
                        }
                    }
                }

            }
            catch
            {
                result.Add("#ERRO#");
            }
            return result;
        }

        //12/04/2017
        //Função pega os dados do Mobios, escreve no arquivo excel e depois pega os dados do mesmo excel e volta a colocar no mobios.
        //Necessários que os campos estejam na tela de Minuta//Detalhe
        public static void LEITURA_LEGO(string PathArquivoLego, int ID_ARQUIVO_TBL_EscreverNoExcel, int ID_PLANILHA)
        {
            Microsoft.Office.Interop.Excel.Application xlApp = null;
            Microsoft.Office.Interop.Excel.Workbook xlWorkBook = null;
            Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet = null;
            Microsoft.Office.Interop.Excel.Worksheet xlWorkSheetList = null;
            string _Arquivo = "";
            ResponsavelServico sv = null;
            #region [ Busca parametros do método ]
            ClassListMethod Metodo = new ClassListMethod();
            ResponsavelServico ResponsavelServico = new ResponsavelServico();
            List<Campos> CamposServico = new List<Campos>();
            List<Campos> CamposEtapa = new List<Campos>();
            ArquivosTratar Tratamento = new ArquivosTratar();

            switch (_CallerForm)
            {
                case MethodForm.Minutas:
                    if (SharedData.isOpenForm(typeof(Minutas), false))
                    {
                        Metodo = ((Minutas)Application.OpenForms["Minutas"])._MyMethod;
                        ResponsavelServico = ((Minutas)Application.OpenForms["Minutas"])._Responsavel;
                        CamposServico = ((Minutas)Application.OpenForms["Minutas"])._listaCamposServico;
                    }
                    break;
                case MethodForm.Main:
                    if (SharedData.isOpenForm(typeof(MainForm), false))
                    {
                    }
                    break;
                case MethodForm.Detalhe:
                    if (SharedData.isOpenForm(typeof(Detalhe), false))
                    {
                        Metodo = ((Detalhe)Application.OpenForms["Detalhe"])._MyMethod;
                        ResponsavelServico = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel;
                        CamposServico = ((Detalhe)Application.OpenForms["Detalhe"])._listaCamposServico;
                        CamposEtapa = ((Detalhe)Application.OpenForms["Detalhe"])._listaCamposEtapas;
                    }
                    break;
            }

            CamposServico.AddRange(CamposEtapa);

            #endregion
            try
            {


                List<CamposEscreverExcel> ListaCamposEscrever = DataAccess.GetCamposEscreverExcel(ID_ARQUIVO_TBL_EscreverNoExcel);

                _Arquivo = PathArquivoLego;


                #region [ Copiar Arquivo ]
                string pathDestino = SharedData.ApplicationPath + DateTime.Now.ToString("ddMMyyyyHHmmss") + Path.GetFileName(_Arquivo);
                if (pathDestino.Length > 250)
                {
                    string Extension = Path.GetExtension(_Arquivo);
                    int lenghtExtension = Extension.Length + 1;

                    pathDestino = pathDestino.Substring(0, 250 - lenghtExtension) + "." + Extension;
                }
                File.Copy(_Arquivo, pathDestino, true);
                _Arquivo = pathDestino;
                #endregion

                xlApp = new Microsoft.Office.Interop.Excel.Application();
                xlApp.Visible = SharedData.gHomologação;
                string msgLog = "Abrindo Excel do LEGO | " + _Arquivo;
                Log.GravaLog(msgLog);

                //Abre o WorkBook
                xlWorkBook = xlApp.Workbooks.Open(_Arquivo, Type.Missing, false);
                StringBuilder sbErroDropDown = new StringBuilder();

                //escrevendo os campos no excel
                foreach (CamposEscreverExcel CampoEscrever in ListaCamposEscrever)
                {
                    //abrindo a planilha
                    xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(CampoEscrever.NomePlanilha);
                    int IdCampo = 0;
                    if (int.TryParse(CampoEscrever.IDcampoMobios.ToString(), out IdCampo))
                    {
                        Campos c = CamposServico.Find(n => n.ID_Campo == IdCampo);
                        if (c != null)
                        {
                            LinhaColuna MinhaLinhaColuna = new LinhaColuna();
                            MinhaLinhaColuna = GetLinhaColuna(CampoEscrever.RefExcelLinCol);

                            Excel.Range MeuRng = xlWorkSheet.Cells[MinhaLinhaColuna.rowIndex, MinhaLinhaColuna.colIndex];

                            List<string> DropDownValues = new List<string>();
                            DropDownValues = ReadDropDownValues(xlWorkBook, MeuRng);

                            //Se DropDownValues for erro, tenta colocar o valor mesmo assim. Provavelmente a formula do dropdown não seja padrão.
                            string ProcuraValor = DropDownValues.Find(n => n.ToString().ToUpper() == c.ValorCampoAntigo.ToUpper() || n.ToString().ToUpper() == "#ERRO#");
                            if (ProcuraValor != null)
                            {
                                xlWorkSheet.Cells[MinhaLinhaColuna.rowIndex, MinhaLinhaColuna.colIndex].Value = c.ValorCampoAntigo;
                            }
                            else
                            {
                                if (sbErroDropDown.Length == 0)
                                    sbErroDropDown.AppendLine("Anteção: Valores abaixo não existem no(s) combo(s) relacionados da Planilha LEGO:");
                                sbErroDropDown.AppendLine("Ref LEGO:" + CampoEscrever.RefExcelLinCol + " | Campo Mobios: " + c.CampoLabel + " | Valor '" + c.ValorCampoAntigo + "' não existe no combo do LEGO.");
                            }





                        }
                    }
                    ((Microsoft.Office.Interop.Excel._Worksheet)xlWorkSheet).Activate();
                    ((Microsoft.Office.Interop.Excel._Worksheet)xlWorkSheet).Calculate();
                }

                xlWorkBook.Save();

                fecharExcel(xlApp, xlWorkBook, xlWorkSheet, xlWorkSheetList);


                if (sbErroDropDown.Length != 0)
                {
                    MessageBox.Show(sbErroDropDown.ToString(), "Erro", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    throw new Exception(sbErroDropDown.ToString());
                }


                //Pegando os campos e salvar no mobios

                if (Tratamento.LerArquivo("Excel", _Arquivo, "1", "1", ID_PLANILHA))
                {

                    if (ResponsavelServico.ID_Servico == 0)
                    {
                        //#region [ novo servico ]
                        /*if (_tipoArquivo != "Base Excel")
                        {
                            Tratamento.RegistraServicoBoleto(_boleto, _sv.IdSegmento, _sv.ID_Objeto, _sv.Prioridade, _sv.ID_Responsavel);
                        }
                        else
                        {
                            Tratamento.RegistraServicoLote(_sv.IdSegmento, _sv.ID_Objeto, _sv.Prioridade, _sv.ID_Responsavel);
                        }
                         * */
                        //#endregion
                    }
                    else
                    {
                        #region [ atualiza serviço existente ]
                        Tratamento.AtualizaServicoBoleto("1", ResponsavelServico.ID_Objeto, ResponsavelServico.ID_Servico, true);
                        #endregion
                    }
                }

                DeletaArquivo(_Arquivo);


            }
            catch (Exception ex)
            {
                fecharExcel(xlApp, xlWorkBook, xlWorkSheet, xlWorkSheetList);
                DeletaArquivo(_Arquivo); //só deleta se for o arquivo dentro da pasta.
                Log.GravaLog(ex.Message);
                throw new Exception(ex.Message);
            }

        }
        public static void atualizar_dados_LEGO()
        {

            //Buscando nome do LEGO
            List<int> ListMethod = new List<int>();
            ListMethod.Add(349);

            List<ClassListMethod> ListMethodInfo = DataAccess.GetListMethod(ListMethod);
            string NomeLEGO = ListMethodInfo[0].MethodParametro;

            List<LEGO> ListLEGO = DataAccess.GetLEGO();
            LEGO ItemLEGO = ListLEGO.Find(n => n.NomeLEGO.Trim().ToUpper() == NomeLEGO.Trim().ToUpper());

            //Se não encontrado o LEGO, sistema não deverá abrir.
            if (ItemLEGO == null)
            {
                MessageBox.Show("Não foi encontrado o NomeLEGO: '" + NomeLEGO + "' na tabela LEGO\nSistema será encerrado.", "LEGO não encontrado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                SharedData.Quit();
                return;
            }

            //Lendo o arquivo LEGO, e preenchendo todos os campos de retorno dentro do Mobios.
            LEITURA_LEGO(ItemLEGO.PathLEGO, ItemLEGO.ID_LEGO, ItemLEGO.ID_PLANILHA);

            MessageBox.Show("Dados LEGO " + NomeLEGO + " atualizados.");

        }
        //12/04/2017
        //Função chama as demais para criar a minuta, que será usada para ser preenchida
        // A tabela tb_0602_CamposMinutas deve ser configurada com a ordem adequada.
        // Primeiro devem ser subistituidos os campos vindos da planilha LEGO, e depois os demais campos.
        public static void GerarMinutaLego()
        {
            try
            {


                ResponsavelServico sv = null;
                #region [ Busca parametros do método ]
                ClassListMethod Metodo = new ClassListMethod();
                ResponsavelServico ResponsavelServico = new ResponsavelServico();
                List<Campos> CamposServico = new List<Campos>();
                List<Campos> CamposEtapa = new List<Campos>();
                ArquivosTratar Tratamento = new ArquivosTratar();

                switch (_CallerForm)
                {
                    case MethodForm.Minutas:
                        if (SharedData.isOpenForm(typeof(Minutas), false))
                        {
                            Metodo = ((Minutas)Application.OpenForms["Minutas"])._MyMethod;
                            ResponsavelServico = ((Minutas)Application.OpenForms["Minutas"])._Responsavel;
                            CamposServico = ((Minutas)Application.OpenForms["Minutas"])._listaCamposServico;
                        }
                        break;
                    case MethodForm.Main:
                        if (SharedData.isOpenForm(typeof(MainForm), false))
                        {
                        }
                        break;
                    case MethodForm.Detalhe:
                        if (SharedData.isOpenForm(typeof(Detalhe), false))
                        {
                            Metodo = ((Detalhe)Application.OpenForms["Detalhe"])._MyMethod;
                            ResponsavelServico = ((Detalhe)Application.OpenForms["Detalhe"])._Responsavel;
                            CamposServico = ((Detalhe)Application.OpenForms["Detalhe"])._listaCamposServico;
                            CamposEtapa = ((Detalhe)Application.OpenForms["Detalhe"])._listaCamposEtapas;
                        }
                        break;
                }

                CamposServico.AddRange(CamposEtapa);

                #endregion

                List<LEGO> ListLEGO = DataAccess.GetLEGO();
                foreach (LEGO itemLego in ListLEGO)
                {
                    string PathArquivoLego = itemLego.PathLEGO;

                    //Lendo o arquivo LEGO, e preenchendo todos os campos de retorno dentro do Mobios.
                    LEITURA_LEGO(itemLego.PathLEGO, itemLego.ID_LEGO, itemLego.ID_PLANILHA);

                    //Escrever os valores dos campos LEGO dentro da minuta Matriz.
                    List<Campos> listaEstrutura = new List<Campos>();
                    #region [ busca campos do serviço ]
                    if (SharedData.gFormOperação == "MINUTAS")
                    {
                        listaEstrutura = DataAccess.buscarCamposDinamicosConjunto(ResponsavelServico.ID_Servico, itemLego.ID_Metodo_Minuta);
                    }
                    else
                    {
                        listaEstrutura = DataAccess.buscarCamposDinamicosConjunto(ResponsavelServico.ID_Servico);
                    }
                    #endregion
                    Campos Matriz = listaEstrutura.Find(n => n.ID_Campo == itemLego.ID_CAMPO_MATRIZ);
                    if (Matriz != null)
                    {
                        //pegar o arquivo matriz, criar uma cópia, escrever os dados dos campos
                        try
                        {
                            //Loading x = new Loading();
                            //Loading.StaticFormVisible(true);
                            //Loading.EnableStaticTextBox("Processando...");

                            //DataConnector.ExecuteNonQuery("insert into tb_0600_Minutas (NomeMinuta,PathMinutas,PathSaida,inclusaoRacf) values ('" + Matriz.ValorCampoAntigo + "','" + itemLego.PathMatrizes + "','" + itemLego.PathSaida + "','" + Environment.UserName.ToString() + "')", "BDdados");
                            //Matriz.ValorCampoAntigo = "Matriz_CREDITO_RURAL_Final.docx";
                            string SQL = "select IdMinuta from tb_0600_Minutas where NomeMinuta='" + Matriz.ValorCampoAntigo + "'";
                            DataTable Dt_Minuta = DataConnector.ExecuteDataTable(SQL, "BDdados");

                            string str_id_minuta = Dt_Minuta.Rows[0][0].ToString();
                            int id_minuta = 0;
                            int.TryParse(str_id_minuta, out id_minuta);


                            Console.WriteLine("Matriz: " + Matriz.ValorCampoAntigo);

                            if (id_minuta != 0)
                            {
                                string[] tipo = DataAccess.GetParametro("MinisimCreditoRural_TipoArquivoMinuta ").Split(';');
                                foreach (string itemtipo in tipo)
                                {
                                    if (itemtipo.ToUpper() == "WORD")
                                    {
                                        ProcessaMinutas.ListaMinutas(ResponsavelServico, listaEstrutura, id_minuta, 1, "Itaú Unibanco -ServiçoName: " + ResponsavelServico.ServicoName, false);
                                        gravar_arquivo_minisimcreditorural(ResponsavelServico.ServicoName);
                                    }
                                    if (itemtipo.ToUpper() == "PDF")
                                    {
                                        ProcessaMinutas.ListaMinutas(ResponsavelServico, listaEstrutura, id_minuta, 2, "Itaú Unibanco -ServiçoName: " + ResponsavelServico.ServicoName, false);
                                        gravar_arquivo_minisimcreditorural(ResponsavelServico.ServicoName);
                                    }
                                }

                            }



                            //x.Close();
                        }
                        catch (Exception err)
                        {
                            Loading.StaticFormVisible(false);
                            StringBuilder sberr = new StringBuilder();
                            MessageBox.Show(SharedData.FormatarErro(sberr, err));
                        }

                        //Obs. A configuração da exportação de dados deve ser feita em sequencia de forma que primeiro são jogadas as informações do lego (Campos gerais), e depois as demais informações


                        //Escrever os demas campos na minuta resultante.
                    }


                }

            }
            catch (Exception ex)
            {
                //throw;
                MessageBox.Show(ex.Message);
            }
        }

        public static void gravar_arquivo_minisimcreditorural(string ServiceName)
        {
            try
            {


                if (File.Exists(SharedData._ArquivoSalvo_Minuta))
                {
                    string path1 = DataAccess.GetParametro("MinisimCreditoRural_Path1");
                    string path2 = DataAccess.GetParametro("MinisimCreditoRural_Path2");
                    path1 = path1.Replace("NNNNNN", ServiceName.PadLeft(6, '0'));
                    path2 = path2.Replace("NNNNNN", ServiceName.PadLeft(6, '0'));

                    string fileName = Path.GetFileName(SharedData._ArquivoSalvo_Minuta);

                    if (Directory.Exists(path1))
                    {
                        //Gravar o arquivo aqui
                        fileName = TratamentoCampo.AdicionaBarraPath(path1) + fileName;
                        File.Copy(SharedData._ArquivoSalvo_Minuta, fileName, true);
                        File.Delete(SharedData._ArquivoSalvo_Minuta);
                    }
                    else if (Directory.Exists(path2))
                    {
                        //Gravar o arquivo aqui
                        fileName = TratamentoCampo.AdicionaBarraPath(path1) + fileName;
                        File.Copy(SharedData._ArquivoSalvo_Minuta, path2, true);
                        File.Delete(SharedData._ArquivoSalvo_Minuta);
                    }
                    else
                    {
                        MessageBox.Show("Não foi possível gravar o arquivo na rede. Favor acessar seguinte caminho:\n\n" + SharedData._ArquivoSalvo_Minuta);
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Informação: " + ex.Message);
                //throw;
            }
        }
        //24/04/2017
        //Função para importar CSV. 
        //Esta função será aberta automaticamente para importar os arquivos csvs gerados pelo Iflow, abrir uma demanda e abrir a tela de minutas, com os dados preenchidos.
        //Regras: Arquivo TXT deve ter o ID do sistema para filtro dos arquivos, e precisa passar o caminho de onde estão os arquivos txts
        //As configurações devem ser feitas nas tabelas tb_0403_GarantiasDiretorioSharePoint ; tb_0405_ServicosSharePoint ; tb_0406_ServicosSharePointValores
        public static void AbrirDemandaFromTxt(int id_method)
        {

            StringBuilder sberro = new StringBuilder();
            //Regras de Configurações das tabelas...
            /********************************
             *  Configurar a tabela LEGO
             *      ID_LEGO
             *      NomeLEGO ( Chave para buscar nas outras tabelas)
             *      PathLEGO - Caminho onde estará o arquivo excel LEGO
             * *      ID_Planilha - ID_Planilha da tabela tb_0015_ParametrosArquivosPlanilha - Usada para mapear os campos da Planilha Excel LEGO e direciona-los para os campos do Mobios.
             *      ID_CAMPO_MATRIZ - ID do campos do Mobios que receberá o nome do arquivo Docx que é informado pela planilha. Este campo será usado posteriormente para gerar a minuta.
             *      ID_Metodo_Minuta - IdMetodo da tabela tb_0006_CamposObjetosMinuta
             *      PathArquivosTXT - Caminho de onde estarão os arquivos TXTs de entrada no Mobios
             *      ArquivosTXT_Nomes - Início dos Nomes dos arquivos TXTs que serão procurados no caminho acima, separados por ";" - São os nomes antes do Termo ID, exemplo: [NOMETXT]ID1234.txt --> O nome será [NOMETXT] e os caracteres a partir do 'ID' serão ignorados.
             *      ArquivosTXT_Nomes_ToMObios - São os campos que irão receber os dados do arquivo. 
             *          O Primeiro arquivo sempre terá os dados gerais, onde são utilizados as configurações da tabela de importação tb_0405_ServicosSharePoint e tb_0406_ServicosSharePointValores
             *          oS demais arquivos são os campos Tabelas, então a configuração é feita informando o ID do campo que deverá receber as informações.
             *          Se o campo for "TABELA", o sistema deverá importar os dados verticalizados.
             *      tb_0021_ParametrosEscreveNoExcel deve ser configurada para mapear os campos que serão escritos no excel - ID_Planilha deve ser igual ao ID_LEGO
             *          
             */
            try
            {



                //Buscando nome do LEGO
                List<int> ListMethod = new List<int>();
                ListMethod.Add(id_method);

                List<ClassListMethod> ListMethodInfo = DataAccess.GetListMethod(ListMethod);
                string NomeLEGO = ListMethodInfo[0].MethodParametro;

                List<LEGO> ListLEGO = DataAccess.GetLEGO();
                LEGO ItemLEGO = ListLEGO.Find(n => n.NomeLEGO.Trim().ToUpper() == NomeLEGO.Trim().ToUpper());

                //Se não encontrado o LEGO, sistema não deverá abrir.
                if (ItemLEGO == null)
                {
                    MessageBox.Show("Não foi encontrado o NomeLEGO: '" + NomeLEGO + "' na tabela LEGO\nSistema será encerrado.", "LEGO não encontrado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    SharedData.Quit();
                    return;
                }

                string pathTxt = ItemLEGO.PathArquivosTXT;

                //DataTable DadosGerais = new DataTable();
                DataTable Pagamentos = new DataTable();
                DataTable Devedores = new DataTable();

                List<CampoAux> ServicosIDsToOpen = new List<CampoAux>(); //Serão os IDs do sistema que está chamando o MobiosMiniSim LEGO
                List<string> ArquivosParaPosteriorImportacao = new List<string>();
                List<string> FilestoDelete = new List<string>();

                string[] ArquivosTxt_NOMES = ItemLEGO.ArquivosTxt_NOMES.Split(';');
                string[] ArquivosTxt_NOMES_ToMobios = ItemLEGO.ArquivosTxt_NOMES_ToMobios.Split(';');

                if (ArquivosTxt_NOMES.Length != ArquivosTxt_NOMES_ToMobios.Length)
                {
                    MessageBox.Show("Configurações da tabela LEGO estão inconsistentes.Coluna ArquivosTxt_NOMES tem parametros diferentes da Coluna ArquivosTxt_NOMES_ToMobios para o NomeLego='" + NomeLEGO + "' ", "LEGO não encontrado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    SharedData.Quit();
                    return;
                }
                string FileName = "";

                foreach (var f in Directory.GetFiles(pathTxt))
                {
                    try
                    {


                        FileName = Path.GetFileNameWithoutExtension(f);
                        string str_IDtoOpen = FileName.Substring(((FileName.IndexOf("ID")) >= 0 ? (FileName.IndexOf("ID") + 2) : 0));
                        string str_NomeArquivoTxt = FileName.Substring(0, FileName.Length - (FileName.Length - ((FileName.IndexOf("ID")) >= 0 ? FileName.IndexOf("ID") : 0)));


                        if (str_NomeArquivoTxt.Length > 0 && ItemLEGO.ArquivosTxt_NOMES.IndexOf(str_NomeArquivoTxt) >= 0)
                        {
                            //arquivo deverá ser lido para dentro da tabela e ação deverá ser realizada.
                            if (ArquivosTxt_NOMES[0].ToUpper() == str_NomeArquivoTxt.ToUpper())
                            {
                                //importar dados do arquivo para o servico e pegar o ID do serviço
                                string filepath = Path.GetFullPath(f);
                                DataTable DadosGerais = new DataTable();
                                DadosGerais = CSVReader.ConvertCSVtoDataTable(filepath, ';');

                                if (DadosGerais != null && DadosGerais.Rows.Count > 0)
                                {
                                    //abrir serviço
                                    List<string> ServicosAbertos = new List<string>();
                                    List<SharePointServicoRetorno> ListaParametrosServico = DataAccess.BuscaParametrosServicoImportados(NomeLEGO);

                                    string CamposServico = ListaParametrosServico[0].CampoRetornarSP;
                                    string CamposServicoMobios = ListaParametrosServico[0].CampoRetornarMobios;
                                    string camposOperacao = ListaParametrosServico[0].NomeCampoOperacaoSP;
                                    string CampoOperacaoMobios = ListaParametrosServico[0].CampoOperacaoMobios;

                                    //Abrindo o serviço
                                    ServicosAbertos = AbreServico.AbreServicos(DadosGerais, CamposServico, CamposServicoMobios, NomeLEGO, camposOperacao, CampoOperacaoMobios, "_LEGO");

                                    if (ServicosAbertos.Count > 0)
                                    {
                                        CampoAux ItemCampoAux = new CampoAux();
                                        ItemCampoAux.ServicoName = str_IDtoOpen;
                                        ItemCampoAux.IDServicoMobios = ServicosAbertos[0];
                                        ServicosIDsToOpen.Add(ItemCampoAux);
                                        FilestoDelete.Add(Path.GetFullPath(f));
                                    }

                                }

                            }
                            else
                            {
                                //reservar o arquivo para posterior importação
                                ArquivosParaPosteriorImportacao.Add(Path.GetFullPath(f));
                            }
                        }

                    }
                    catch (Exception ex)
                    {
                        StringBuilder err = new StringBuilder();
                        Log.GravaLog(SharedData.FormatarErro(err, ex), "_LEGO");
                        sberro.AppendLine("Erro na leitura do arquivo '" + FileName + "'. Erro: " + ex.Message);
                    }
                }

                //tratando os arquivos que foram deixados para posterior importação

                foreach (string arq in ArquivosParaPosteriorImportacao)
                {
                    try
                    {


                        FileName = Path.GetFileNameWithoutExtension(arq);
                        string str_IDtoOpen = FileName.Substring(((FileName.IndexOf("ID")) >= 0 ? (FileName.IndexOf("ID") + 2) : 0));
                        string str_NomeArquivoTxt = FileName.Substring(0, FileName.Length - (FileName.Length - ((FileName.IndexOf("ID")) >= 0 ? FileName.IndexOf("ID") : 0)));

                        int indexArq = -1;
                        for (int i = 0; i < ArquivosTxt_NOMES.Length; i++)
                        {
                            if (str_NomeArquivoTxt == ArquivosTxt_NOMES[i])
                                indexArq = i;
                        }
                        if (indexArq >= 0)
                        {
                            string IDcampoMobios = ArquivosTxt_NOMES_ToMobios[indexArq];

                            CampoAux ItemCampoAux = ServicosIDsToOpen.Find(n => n.ServicoName == str_IDtoOpen);
                            if (ItemCampoAux != null)
                            {

                                string idMobios = ItemCampoAux.IDServicoMobios;

                                DataTable Dados = new DataTable();
                                Dados = CSVReader.ConvertCSVtoDataTable(arq, ';');

                                DataTable result = new DataTable();

                                if (IDcampoMobios.ToUpper() == "TABELA")
                                {
                                    Dados.Columns.Add("IdServico", typeof(String));
                                    Dados.Columns.Add("IdCampo", typeof(String));

                                    List<CamposInfo> CamposTabela = DataAccess.BuscarInfoCampoByTipo("TABELA");

                                    for (int i = 0; i < Dados.Rows.Count; i++)
                                    {
                                        CamposInfo CamposInfoAux = CamposTabela.Find(n => n.CampoNome.ToUpper() == Dados.Rows[i]["NomeTabela"].ToString().ToUpper());
                                        if (CamposInfoAux != null)
                                        {
                                            Dados.Rows[i]["IdCampo"] = CamposInfoAux.ID_Campo.ToString();
                                            Dados.Rows[i]["IdServico"] = idMobios;
                                        }
                                    }

                                    result = Dados.Copy();
                                }
                                else
                                {
                                    //verticalizando a tabela
                                    DataTable DadosVerticalizados = new DataTable();
                                    DadosVerticalizados.Columns.Add("IdServico", typeof(String));
                                    DadosVerticalizados.Columns.Add("IdCampo", typeof(String));
                                    DadosVerticalizados.Columns.Add("NomeTabela", typeof(String));
                                    DadosVerticalizados.Columns.Add("Linha", typeof(String));
                                    DadosVerticalizados.Columns.Add("NomeCampo", typeof(String));
                                    DadosVerticalizados.Columns.Add("ValorCampo", typeof(String));

                                    for (int i = 0; i < Dados.Rows.Count; i++)
                                    {
                                        for (int c = 0; c < Dados.Columns.Count; c++)
                                        {
                                            DadosVerticalizados.Rows.Add(idMobios, IDcampoMobios, str_NomeArquivoTxt, i + 1, Dados.Columns[c].ColumnName, Dados.Rows[i][c].ToString());
                                        }
                                    }

                                    result = DadosVerticalizados.Copy();

                                }

                                SharedData.BulkExportToAccess(result, "tb_0134_DadosTabela", "", "BDdados");

                                FilestoDelete.Add(Path.GetFullPath(arq));
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        StringBuilder err = new StringBuilder();
                        Log.GravaLog(SharedData.FormatarErro(err, ex), "_LEGO");
                        sberro.AppendLine("Erro na leitura do arquivo '" + FileName + "'. Erro: " + ex.Message);
                    }
                }

                //deletando os arquivos lidos
                for (int i = 0; i < FilestoDelete.Count; i++)
                {

                    try
                    {
                        File.Delete(FilestoDelete[i]);
                    }
                    catch (Exception ex)
                    {
                        StringBuilder err = new StringBuilder();
                        Log.GravaLog(SharedData.FormatarErro(err, ex), "_LEGO");
                    }
                }

                //mensagem de erro
                if (sberro.Length > 0)
                {
                    MessageBox.Show(sberro.ToString());
                }


                //Abrindo o PipeLine
                if (!SharedData.isOpenForm(typeof(Pipeline), false, true))
                {
                    Pipeline pipe = new Pipeline();
                    pipe.Show();
                }



            }
            catch (Exception ex)
            {
                StringBuilder err = new StringBuilder();
                Log.GravaLog(SharedData.FormatarErro(err, ex), "_LEGO");
                throw;
            }


        }
        #endregion
    }
}
