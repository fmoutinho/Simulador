﻿namespace Mobios
{
    partial class AcessoBoleto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblPass = new System.Windows.Forms.Label();
            this.txtVersao = new System.Windows.Forms.TextBox();
            this.txPass = new System.Windows.Forms.TextBox();
            this.txUser = new System.Windows.Forms.TextBox();
            this.lblUser = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBoleto = new System.Windows.Forms.TextBox();
            this.wbOQ = new System.Windows.Forms.WebBrowser();
            this.gbWebBrowser = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.gbWebBrowser.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.lblPass);
            this.groupBox1.Controls.Add(this.txtVersao);
            this.groupBox1.Controls.Add(this.txPass);
            this.groupBox1.Controls.Add(this.txUser);
            this.groupBox1.Controls.Add(this.lblUser);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtBoleto);
            this.groupBox1.Location = new System.Drawing.Point(10, 53);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(728, 51);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Boleto";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(334, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 15;
            this.label2.Text = "Versão:";
            // 
            // lblPass
            // 
            this.lblPass.AutoSize = true;
            this.lblPass.Location = new System.Drawing.Point(575, 23);
            this.lblPass.Name = "lblPass";
            this.lblPass.Size = new System.Drawing.Size(41, 13);
            this.lblPass.TabIndex = 20;
            this.lblPass.Text = "Senha:";
            // 
            // txtVersao
            // 
            this.txtVersao.Enabled = false;
            this.txtVersao.Location = new System.Drawing.Point(380, 19);
            this.txtVersao.Name = "txtVersao";
            this.txtVersao.Size = new System.Drawing.Size(20, 20);
            this.txtVersao.TabIndex = 14;
            // 
            // txPass
            // 
            this.txPass.Enabled = false;
            this.txPass.Location = new System.Drawing.Point(622, 19);
            this.txPass.Name = "txPass";
            this.txPass.PasswordChar = '*';
            this.txPass.Size = new System.Drawing.Size(100, 20);
            this.txPass.TabIndex = 18;
            // 
            // txUser
            // 
            this.txUser.Enabled = false;
            this.txUser.Location = new System.Drawing.Point(460, 19);
            this.txUser.Name = "txUser";
            this.txUser.Size = new System.Drawing.Size(112, 20);
            this.txUser.TabIndex = 17;
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Location = new System.Drawing.Point(408, 23);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(46, 13);
            this.lblUser.TabIndex = 19;
            this.lblUser.Text = "Usuário:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Boleto:";
            // 
            // txtBoleto
            // 
            this.txtBoleto.Enabled = false;
            this.txtBoleto.Location = new System.Drawing.Point(61, 18);
            this.txtBoleto.Name = "txtBoleto";
            this.txtBoleto.Size = new System.Drawing.Size(100, 20);
            this.txtBoleto.TabIndex = 0;
            // 
            // wbOQ
            // 
            this.wbOQ.Dock = System.Windows.Forms.DockStyle.Fill;
            this.wbOQ.Location = new System.Drawing.Point(3, 16);
            this.wbOQ.MinimumSize = new System.Drawing.Size(20, 20);
            this.wbOQ.Name = "wbOQ";
            this.wbOQ.Size = new System.Drawing.Size(719, 331);
            this.wbOQ.TabIndex = 0;
            this.wbOQ.Url = new System.Uri("", System.UriKind.Relative);
            // 
            // gbWebBrowser
            // 
            this.gbWebBrowser.Controls.Add(this.wbOQ);
            this.gbWebBrowser.Location = new System.Drawing.Point(10, 135);
            this.gbWebBrowser.Name = "gbWebBrowser";
            this.gbWebBrowser.Size = new System.Drawing.Size(725, 350);
            this.gbWebBrowser.TabIndex = 9;
            this.gbWebBrowser.TabStop = false;
            this.gbWebBrowser.Text = "Web Browser";
            // 
            // AcessoBoleto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(749, 539);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gbWebBrowser);
            this.Name = "AcessoBoleto";
            this.Text = "Acesso";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbWebBrowser.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBoleto;
        private System.Windows.Forms.WebBrowser wbOQ;
        private System.Windows.Forms.GroupBox gbWebBrowser;
        private System.Windows.Forms.Label lblPass;
        private System.Windows.Forms.TextBox txPass;
        private System.Windows.Forms.TextBox txUser;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtVersao;

    }
}