﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Configuration;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Xml;
using System.Threading;

namespace Mobios
{
    public partial class AcessoBoleto : Form
    {
        #region [ Variáveis ]
        BoletoOQ classeOQ = new BoletoOQ();
        PN classePN = new PN();
        int _Sistema=0;
        int _Segmento = 0;
        int _Produto = 0;
        bool _Prioridade=false;
        int _Analista = 0;
        string _Boleto;
        string _User;
        string _Pass;
        string _Versao;
        int _IdServico;
        bool _CamposMinutas;
        int _IdMetodoCampos;
        string _erro;
        #endregion

        public AcessoBoleto(string Boleto, string User, string Pass, int Sistema, int IdSegmento, int IdProduto, bool Prioridade, int IdAnalista, string Versao = "0", int IdServico = 0, bool CamposMinutas = false, int IdMetodoCampos = 0)
        {
            try
            {
                _erro = "";
                _Sistema = Sistema;
                _Segmento = IdSegmento;
                _Produto = IdProduto;
                _Prioridade = Prioridade;
                _Analista = IdAnalista;
                _Boleto = Boleto;
                _User = User;
                _Pass = Pass;
                _Versao = Versao;
                _IdServico = IdServico;
                _CamposMinutas = CamposMinutas;
                _IdMetodoCampos = IdMetodoCampos;

                Thread t = new Thread(IniciarForm);
                t.SetApartmentState(ApartmentState.STA);
                t.Start();
                t.Join();
                try
                {
                    this.Close();
                }
                catch { }
                if (_erro!="")
                {
                    throw new Exception(_erro);
                }
            }
            catch (Exception erro)
            {
                Log.GravaLog("Erro de captura: " + erro.Message);
                //this.Close();
                throw;
            }
        }

        private void IniciarForm()
        {
            try
            {

                InitializeComponent();
                this.Show();
                this.BringToFront();
                Application.DoEvents();
                txtBoleto.Text = _Boleto;
                txUser.Text = _User;
                txPass.Text = _Pass;
                txtVersao.Text = _Versao;

                //this.wbOQ = new System.Windows.Forms.WebBrowser();
                //this.wbOQ.Dock = System.Windows.Forms.DockStyle.Fill;
                //this.wbOQ.Location = new System.Drawing.Point(3, 16);
                //this.wbOQ.MinimumSize = new System.Drawing.Size(20, 20);
                //this.wbOQ.Name = "wbOQ";
                //this.wbOQ.Size = new System.Drawing.Size(719, 331);
                //this.wbOQ.TabIndex = 0;
                //this.wbOQ.Url = new System.Uri("", System.UriKind.Relative);

                wbOQ.Url = new Uri(@"about:blank");

                while (wbOQ.ReadyState != WebBrowserReadyState.Complete)
                {
                    Application.DoEvents();
                }

                Application.DoEvents();

                wbOQ.Document.ExecCommand("ClearAuthenticationCache", false, null);

                while (wbOQ.ReadyState != WebBrowserReadyState.Complete)
                {
                    Application.DoEvents();
                }

                Application.DoEvents();

                if (LoginSistema() == true)
                {
                    if (ProcessaSistema())
                    {
                        LerDados();
                        if (_IdServico != 0)
                        {
                            AtualizaOperacao(_IdServico);
                        }
                        else
                        {
                            RegistraOperacao();
                        }
                    }
                    else
                    {
                        throw new Exception("Erro no login, verifique usuário e senha");
                    }
                    //wbOQ.Refresh(WebBrowserRefreshOption.Completely);
                }
                else
                {
                    throw new Exception("Erro no login, verifique usuário e senha");
                }
            }
            catch (Exception erro)
            {
                //MessageBox.Show("Erro de captura: " +  erro.Message);
                _erro = erro.Message;
                try
                {
                    this.Close();
                }
                catch { }
                
            }

        }

        private bool LoginSistema()
        {
            bool result = false;

            switch (_Sistema)
            {
                case 3:
                    string msgLog = "Inicia Login.";
                    Log.GravaLog(msgLog);

                    classeOQ.LoginOQ(wbOQ, SharedData.gLoginOQ, txUser.Text, txPass.Text);

                    msgLog = "Verifica login concluído.";
                    Log.GravaLog(msgLog);

                    do
                    {
                        Application.DoEvents();
                    } while (wbOQ.Document.Body == null);

                    msgLog = "Pagina carregada.";
                    Log.GravaLog(msgLog);

                    if (classeOQ.LogadoOk(wbOQ, "Em caso de problemas com seu usuário") != false)
                    {
                        msgLog = "Login concluído.";
                        Log.GravaLog(msgLog);
                        result = true;
                    }
                    break;
                //PN
                case 5:
                    msgLog = "Inicia Login.";
                    Log.GravaLog(msgLog);

                    classePN.LoginPN(wbOQ, SharedData.gLoginPN, txUser.Text, txPass.Text);

                    msgLog = "Verifica login concluído.";
                    Log.GravaLog(msgLog);

                    do
                    {
                        Application.DoEvents();
                    } while (wbOQ.Document.Body == null);

                    msgLog = "Pagina carregada.";
                    Log.GravaLog(msgLog);

                    if (classeOQ.LogadoOk(wbOQ, "Em caso de problemas com seu usuário") != false)
                    {
                        msgLog = "Login concluído.";
                        Log.GravaLog(msgLog);
                        result = true;
                    }

                    break;
            }

            return result;
        }

        private bool ProcessaSistema()
        {
            bool result = false;
            string msgLog;
            switch (_Sistema)
            {
                case 3:
                    msgLog = "Verifica Logado.";
                    Log.GravaLog(msgLog);

                    msgLog = "Processa Boleto.";
                    Log.GravaLog(msgLog);
                    classeOQ.ProcessaOQ(txtBoleto.Text.Trim(), txtVersao.Text.Trim(), wbOQ);
                    msgLog = "Boleto Processado.";
                    Log.GravaLog(msgLog);

                    msgLog = "Verifica Logado.";
                    Log.GravaLog(msgLog);
                    if (classeOQ.LogadoOk(wbOQ, "Tela de Autenticação de Usuários") != false)
                    {
                        result = true;
                    }
                    break;
                case 5:
                    msgLog = "Verifica Logado.";
                    Log.GravaLog(msgLog);
                    msgLog = "Processa PN.";
                    Log.GravaLog(msgLog);
                    classePN.BuscarDadosPN(wbOQ, txtBoleto.Text.Trim());
                    msgLog = "PN Processada.";
                    Log.GravaLog(msgLog);

                    msgLog = "Verifica Logado.";
                    Log.GravaLog(msgLog);
                    if (classeOQ.LogadoOk(wbOQ, "Tela de Autenticação de Usuários") != false)
                    {
                        result = true;
                    }
                    break;
            }
            return result;
        }

        private void LerDados()
        {
            Cursor.Current = Cursors.WaitCursor;

            switch (_Sistema)
            {
                case 3:
                    //OQ
                    classeOQ.LerOQ(wbOQ, txtBoleto.Text.Trim(), _Produto.ToString());
                    break;

                case 5:
                    //PN
                    classePN.LerPN(wbOQ, txtBoleto.Text.Trim());
                    break;
            }
            Cursor.Current = Cursors.Default;
        }

        private void RegistraOperacao()
        {
            Cursor.Current = Cursors.WaitCursor;

            switch (_Sistema)
            {
                case 3:
                    //OQ
                    classeOQ.RegistraServicoBoleto(txtBoleto.Text.Trim(), _Segmento, _Produto, _Prioridade, _Analista);
                    break;
                     
                case 5:
                    //PN
                    classePN.RegistraServicoBoleto(txtBoleto.Text.Trim(), _Segmento, _Produto, _Prioridade, _Analista);
                    break;

            }

            Cursor.Current = Cursors.Default;

        }

        private void AtualizaOperacao(int IdServico)
        {
            Cursor.Current = Cursors.WaitCursor;

            switch (_Sistema)
            {
                case 3:
                    //OQ
                    classeOQ.AtualizaServicoBoleto(txtBoleto.Text.Trim(), _Produto, IdServico, _CamposMinutas, _IdMetodoCampos);
                    break;

                case 5:
                    //PN
                    classePN.AtualizaServicoBoleto(txtBoleto.Text.Trim(), _Produto, IdServico, _CamposMinutas, _IdMetodoCampos);
                    break;

            }

            Cursor.Current = Cursors.Default;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            wbOQ.Navigate("http://intranet.itau/Web1/OQ/pasta_virtual/GerarBoleto.aspx?cod=1&nrBoleto=38813&versao=0&codBanco=184",false);
        }
    }
}
