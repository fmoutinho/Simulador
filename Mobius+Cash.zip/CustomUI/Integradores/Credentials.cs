﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Reflection;

namespace Mobios
{
    public partial class Credentials : Form
    {
        public string _user;
        public string _password;
        public bool _credentialized;

        public Credentials()
        {
            InitializeComponent();
            _credentialized = false;
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if (this.txtFuncional.Text.Trim() != "" && this.txtPass.Text.Trim() != "")
            {
                _user = this.txtFuncional.Text;
                _password = this.txtPass.Text;
                _credentialized = true;
                this.Close();
            }
            else
            {
                MessageBox.Show("Preencha usuário e senha!", "Credenciais", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            
        }

    }
}
