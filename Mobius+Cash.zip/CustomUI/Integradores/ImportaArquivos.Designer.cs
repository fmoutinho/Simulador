﻿namespace Mobios
{
    partial class ImportaArquivos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ImportaArquivos));
            this.btnSelecionar = new System.Windows.Forms.Button();
            this.cbModeloExcel = new System.Windows.Forms.ComboBox();
            this.lblPlanilha = new System.Windows.Forms.Label();
            this.btnExecutar = new System.Windows.Forms.Button();
            this.txtIdentificacao = new System.Windows.Forms.TextBox();
            this.lbNomeServico = new System.Windows.Forms.Label();
            this.bgwImportarArquivo = new System.ComponentModel.BackgroundWorker();
            this.SuspendLayout();
            // 
            // btnSelecionar
            // 
            this.btnSelecionar.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnSelecionar.BackColor = System.Drawing.Color.Transparent;
            this.btnSelecionar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSelecionar.BackgroundImage")));
            this.btnSelecionar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSelecionar.FlatAppearance.BorderSize = 0;
            this.btnSelecionar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelecionar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnSelecionar.Location = new System.Drawing.Point(265, 26);
            this.btnSelecionar.Name = "btnSelecionar";
            this.btnSelecionar.Size = new System.Drawing.Size(30, 31);
            this.btnSelecionar.TabIndex = 3;
            this.btnSelecionar.UseVisualStyleBackColor = false;
            this.btnSelecionar.Click += new System.EventHandler(this.btnSelecionar_Click);
            // 
            // cbModeloExcel
            // 
            this.cbModeloExcel.DisplayMember = "NomeArquivo";
            this.cbModeloExcel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbModeloExcel.FormattingEnabled = true;
            this.cbModeloExcel.Location = new System.Drawing.Point(87, 32);
            this.cbModeloExcel.Name = "cbModeloExcel";
            this.cbModeloExcel.Size = new System.Drawing.Size(172, 21);
            this.cbModeloExcel.TabIndex = 19;
            this.cbModeloExcel.ValueMember = "IdArquivo";
            this.cbModeloExcel.SelectedIndexChanged += new System.EventHandler(this.cbModeloExcel_SelectedIndexChanged);
            // 
            // lblPlanilha
            // 
            this.lblPlanilha.AutoSize = true;
            this.lblPlanilha.Location = new System.Drawing.Point(35, 35);
            this.lblPlanilha.Name = "lblPlanilha";
            this.lblPlanilha.Size = new System.Drawing.Size(49, 13);
            this.lblPlanilha.TabIndex = 20;
            this.lblPlanilha.Text = "Arquivo: ";
            // 
            // btnExecutar
            // 
            this.btnExecutar.BackColor = System.Drawing.Color.White;
            this.btnExecutar.Image = ((System.Drawing.Image)(resources.GetObject("btnExecutar.Image")));
            this.btnExecutar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExecutar.Location = new System.Drawing.Point(228, 67);
            this.btnExecutar.Name = "btnExecutar";
            this.btnExecutar.Size = new System.Drawing.Size(67, 23);
            this.btnExecutar.TabIndex = 21;
            this.btnExecutar.Text = "Importar";
            this.btnExecutar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExecutar.UseVisualStyleBackColor = false;
            this.btnExecutar.Click += new System.EventHandler(this.btnExecutar_Click);
            // 
            // txtIdentificacao
            // 
            this.txtIdentificacao.Location = new System.Drawing.Point(87, 67);
            this.txtIdentificacao.Name = "txtIdentificacao";
            this.txtIdentificacao.Size = new System.Drawing.Size(125, 20);
            this.txtIdentificacao.TabIndex = 26;
            this.txtIdentificacao.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtIdentificacao_KeyUp);
            // 
            // lbNomeServico
            // 
            this.lbNomeServico.AutoSize = true;
            this.lbNomeServico.Location = new System.Drawing.Point(13, 71);
            this.lbNomeServico.Name = "lbNomeServico";
            this.lbNomeServico.Size = new System.Drawing.Size(71, 13);
            this.lbNomeServico.TabIndex = 25;
            this.lbNomeServico.Text = "Identificação:";
            // 
            // bgwImportarArquivo
            // 
            this.bgwImportarArquivo.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bgwImportarArquivo_DoWork);
            // 
            // ImportaArquivos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(318, 112);
            this.Controls.Add(this.txtIdentificacao);
            this.Controls.Add(this.lbNomeServico);
            this.Controls.Add(this.btnExecutar);
            this.Controls.Add(this.lblPlanilha);
            this.Controls.Add(this.cbModeloExcel);
            this.Controls.Add(this.btnSelecionar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ImportaArquivos";
            this.Text = "Importação de Arquivos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSelecionar;
        private System.Windows.Forms.ComboBox cbModeloExcel;
        private System.Windows.Forms.Label lblPlanilha;
        private System.Windows.Forms.Button btnExecutar;
        private System.Windows.Forms.TextBox txtIdentificacao;
        private System.Windows.Forms.Label lbNomeServico;
        private System.ComponentModel.BackgroundWorker bgwImportarArquivo;
    }
}