﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Mobios
{
    public partial class ImportaArquivos : Form
    {
        #region [ Variáveis ]
        public static string msgLog;
        ArquivosTratar Tratamento = new ArquivosTratar();
        ResponsavelServico _sv;
        Form frmLoading;
        List<ListaArquivos> listaArquivos = new List<ListaArquivos>();

        bool _concluido;

        string _boleto;
        string _tipoArquivo;
        int _IdTipoArquivo;
        string _Arquivo;
        bool _CampoMinutas;
        int _IdMetodoCampos;
        #endregion

        public ImportaArquivos(ResponsavelServico sv, string tipoArquivo, bool CamposMinutas = false, int IdMetodoCampos = 0)
        {
            #region [ Atualiza Variáveis ]
            _concluido = false;
            InitializeComponent();
            _sv = sv;
            _tipoArquivo = tipoArquivo;
            _Arquivo = "";
            _CampoMinutas = CamposMinutas;
            _IdMetodoCampos = IdMetodoCampos;
            #endregion

            listaArquivos = DataAccess.buscarListaArquivos(_tipoArquivo, _sv.ID_Objeto, _sv.Segmento);
            this.cbModeloExcel.DataSource = listaArquivos;
        }

        private void btnSelecionar_Click(object sender, EventArgs e)
        {
            _IdTipoArquivo = Convert.ToInt32(cbModeloExcel.SelectedValue);

            if (_IdTipoArquivo != 0)
            {
                msgLog = "Iniciando importação do arquivo " + _tipoArquivo + " " + _boleto + " .";
                Log.GravaLog(msgLog);

                OpenFileDialog openFileDialog = new OpenFileDialog();

                #region [ Filtros Dialog ]
                openFileDialog.Multiselect = false;
                openFileDialog.Title = "Selecionar Arquivo";
                //openFileDialog.InitialDirectory = @ConfigurationManager.AppSettings["PathPlanilha"];

                switch (_tipoArquivo)
                {
                    case "Excel":
                        openFileDialog.Filter = "Planilha (*.xls;*.xlsx)|*.xls;*.xlsx";
                        break;
                    case "Base Excel":
                        openFileDialog.Filter = "Planilha (*.xls;*.xlsx)|*.xls;*.xlsx";
                        break;
                    case "PDF":
                        openFileDialog.Filter = "Pdf Files|*.pdf";
                        break;
                }
                openFileDialog.CheckFileExists = true;
                openFileDialog.CheckPathExists = true;
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;
                openFileDialog.ReadOnlyChecked = true;
                openFileDialog.ShowReadOnly = false;
                openFileDialog.FileName = "";
                DialogResult dr = openFileDialog.ShowDialog();
                //DialogResult dr = FileDialogSTA.STAShowDialog(openFileDialog);
                #endregion

                #region [ seleciona arquivo ]
                if (dr == System.Windows.Forms.DialogResult.OK)
                {
                    foreach (String arquivo in openFileDialog.FileNames)
                    {
                        if (arquivo != "")
                        {
                            _Arquivo = arquivo;
                        }
                    }

                    if (_Arquivo == "")
                    {
                        MessageBox.Show("Escolha um arquivo válido", "Importação de Arquivo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
                #endregion
            }
            
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if (_Arquivo != "" && txtIdentificacao.Text != "")
            {
                _boleto = txtIdentificacao.Text;
                frmLoading = new Loading();
                frmLoading.Show();
                bgwImportarArquivo.RunWorkerAsync();
            }
            else
            {
                #region [ mensagens ]
                if (_Arquivo == "")
                {
                    MessageBox.Show("Escolha um arquivo válido", "Importação de Arquivo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    MessageBox.Show("Insira o número de identifição do arquivo (Boleto, Código, Id...)", "Importação de Arquivo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                #endregion
            }
        }

        private void bgwImportarArquivo_DoWork(object sender, DoWorkEventArgs e)
        {
            #region [ Copiar Arquivo ]
            string pathDestino = SharedData.ApplicationPath + DateTime.Now.ToString("ddMMyyyyHHmmss") + Path.GetFileName(_Arquivo);
            if (pathDestino.Length > 250)
            {
                string Extension = Path.GetExtension(_Arquivo);
                int lenghtExtension = Extension.Length + 1;

                pathDestino = pathDestino.Substring(0, 250 - lenghtExtension) + "." + Extension;
            }
            File.Copy(_Arquivo, pathDestino, true);
            _Arquivo = pathDestino;
            #endregion

            msgLog = "Iniciando importação do arquivo " + _tipoArquivo + " " + _boleto + " .";
            Log.GravaLog(msgLog);

            Loading.StaticFormVisible(true);
            Loading.EnableStaticTextBox("Verificando arquivo");

            try
            {
                if (Tratamento.LerArquivo(_tipoArquivo, _Arquivo, "", _boleto, _IdTipoArquivo, listaArquivos.Find(n => n.IdArquivo == _IdTipoArquivo).CampoBoleto))
                {

                    if (_sv.ID_Servico == 0)
                    {
                        #region [ novo servico ]
                        if (_tipoArquivo != "Base Excel")
                        {
                            Tratamento.RegistraServicoBoleto(_boleto, _sv.IdSegmento, _sv.ID_Objeto, _sv.Prioridade, _sv.ID_Responsavel);
                        }
                        else
                        {
                            Tratamento.RegistraServicoLote(_sv.IdSegmento, _sv.ID_Objeto, _sv.Prioridade, _sv.ID_Responsavel);
                        }
                        #endregion
                    }
                    else
                    {
                        #region [ atualiza serviço existente ]
                        Tratamento.AtualizaServicoBoleto(_boleto, _sv.ID_Objeto, _sv.ID_Servico, _CampoMinutas, _IdMetodoCampos);
                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao tentar capturar o boleto.\n\nErro: " + ex.Message, "Importação de Arquivo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Loading.StaticFormVisible(false);
                _concluido = true;
                frmLoading.Invoke((MethodInvoker)delegate
                {
                    frmLoading.Close();
                });
                #region [ Deleta Arquivo Copiado ]
                if (File.Exists(_Arquivo))
                {
                    if (TratamentoCampo.AdicionaBarraPath(Path.GetDirectoryName(_Arquivo)) == SharedData.ApplicationPath)
                    {
                        try
                        {
                            File.Delete(_Arquivo);
                        }
                        catch { }
                    }
                }
                #endregion
            }
        }

        private void cbModeloExcel_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_IdTipoArquivo != Convert.ToInt32(cbModeloExcel.SelectedValue))
            {
                _boleto = "";
                _IdTipoArquivo = 0;
                _Arquivo = "";
            }
        }

        private void txtIdentificacao_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.ToString() == "Return")
            {
                this.btnExecutar.PerformClick();
            }
        }
    }
}
