﻿namespace Mobios
{
    partial class ImportaBoletoOQ
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ImportaBoletoOQ));
            this.btnExecutar = new System.Windows.Forms.Button();
            this.txtIdentificacao = new System.Windows.Forms.TextBox();
            this.lbNomeServico = new System.Windows.Forms.Label();
            this.bgwImportarArquivo = new System.ComponentModel.BackgroundWorker();
            this.txtVersao = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtFuncional = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPass = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnExecutar
            // 
            this.btnExecutar.BackColor = System.Drawing.Color.White;
            this.btnExecutar.Image = ((System.Drawing.Image)(resources.GetObject("btnExecutar.Image")));
            this.btnExecutar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExecutar.Location = new System.Drawing.Point(251, 85);
            this.btnExecutar.Name = "btnExecutar";
            this.btnExecutar.Size = new System.Drawing.Size(67, 23);
            this.btnExecutar.TabIndex = 21;
            this.btnExecutar.Text = "Importar";
            this.btnExecutar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExecutar.UseVisualStyleBackColor = false;
            this.btnExecutar.Click += new System.EventHandler(this.btnExecutar_Click);
            // 
            // txtIdentificacao
            // 
            this.txtIdentificacao.Location = new System.Drawing.Point(96, 22);
            this.txtIdentificacao.MaxLength = 10;
            this.txtIdentificacao.Name = "txtIdentificacao";
            this.txtIdentificacao.Size = new System.Drawing.Size(81, 20);
            this.txtIdentificacao.TabIndex = 1;
            this.txtIdentificacao.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtIdentificacao_KeyUp);
            // 
            // lbNomeServico
            // 
            this.lbNomeServico.AutoSize = true;
            this.lbNomeServico.Location = new System.Drawing.Point(13, 26);
            this.lbNomeServico.Name = "lbNomeServico";
            this.lbNomeServico.Size = new System.Drawing.Size(80, 13);
            this.lbNomeServico.TabIndex = 25;
            this.lbNomeServico.Text = "Número Boleto:";
            // 
            // bgwImportarArquivo
            // 
            this.bgwImportarArquivo.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bgwImportarArquivo_DoWork);
            // 
            // txtVersao
            // 
            this.txtVersao.Location = new System.Drawing.Point(237, 22);
            this.txtVersao.MaxLength = 1;
            this.txtVersao.Name = "txtVersao";
            this.txtVersao.Size = new System.Drawing.Size(33, 20);
            this.txtVersao.TabIndex = 2;
            this.txtVersao.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtIdentificacao_KeyUp);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(188, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 27;
            this.label1.Text = "Versão:";
            // 
            // txtFuncional
            // 
            this.txtFuncional.Location = new System.Drawing.Point(96, 49);
            this.txtFuncional.MaxLength = 9;
            this.txtFuncional.Name = "txtFuncional";
            this.txtFuncional.Size = new System.Drawing.Size(81, 20);
            this.txtFuncional.TabIndex = 3;
            this.txtFuncional.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtIdentificacao_KeyUp);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 29;
            this.label2.Text = "Funcional Itaú:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(188, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 31;
            this.label3.Text = "Senha:";
            // 
            // txtPass
            // 
            this.txtPass.Location = new System.Drawing.Point(235, 50);
            this.txtPass.MaxLength = 6;
            this.txtPass.Name = "txtPass";
            this.txtPass.PasswordChar = '*';
            this.txtPass.Size = new System.Drawing.Size(81, 20);
            this.txtPass.TabIndex = 4;
            this.txtPass.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtIdentificacao_KeyUp);
            // 
            // ImportaBoletoOQ
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(336, 123);
            this.Controls.Add(this.txtPass);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtFuncional);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtVersao);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtIdentificacao);
            this.Controls.Add(this.lbNomeServico);
            this.Controls.Add(this.btnExecutar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ImportaBoletoOQ";
            this.Text = "Boleto OQ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExecutar;
        private System.Windows.Forms.TextBox txtIdentificacao;
        private System.Windows.Forms.Label lbNomeServico;
        private System.ComponentModel.BackgroundWorker bgwImportarArquivo;
        private System.Windows.Forms.TextBox txtVersao;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtFuncional;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPass;
    }
}