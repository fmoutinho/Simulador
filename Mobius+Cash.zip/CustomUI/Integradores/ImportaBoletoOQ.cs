﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Mobios
{
    public partial class ImportaBoletoOQ : Form
    {
        #region [ Variáveis ]
        public static string msgLog;
        ResponsavelServico _sv;
        Form frmLoading;
        bool _concluido;

        string _boleto;
        string _versao;
        string _funcional;
        string _senha;

        bool _CamposMinutas;
        int _IdMetodoCampos;
        #endregion

        public ImportaBoletoOQ(ResponsavelServico sv, bool CamposMinutas = false, int IdMetodoCampos = 0)
        {
            #region [ Atualiza Variáveis ]
            _concluido = false;
            InitializeComponent();
            _sv = sv;
            txtFuncional.Text = SharedData.User.FuncionalResponsavel;
            txtVersao.Text = "0";
            _CamposMinutas = CamposMinutas;
            _IdMetodoCampos = IdMetodoCampos;
            #endregion
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if (txtIdentificacao.Text != "" && txtVersao.Text != "" && txtFuncional.Text != "" && txtPass.Text != "")
            {
                _boleto = txtIdentificacao.Text;
                _versao = txtVersao.Text;
                _funcional = txtFuncional.Text;
                _senha = txtPass.Text;

                frmLoading = new Loading();
                frmLoading.Show();
                bgwImportarArquivo.RunWorkerAsync();
            }
            else
            {
                MessageBox.Show("Preencha todos os campos!", "Importação Boleto OQ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void bgwImportarArquivo_DoWork(object sender, DoWorkEventArgs e)
        {
            msgLog = "Iniciando importação do boleto OQ " + _boleto + " .";
            Log.GravaLog(msgLog);

            Loading.StaticFormVisible(true);
            Loading.EnableStaticTextBox("Verificando boleto");

            try
            {
                AcessoBoleto frm = new AcessoBoleto(_boleto, _funcional, _senha, 3, _sv.IdSegmento, _sv.ID_Objeto, _sv.Prioridade, _sv.ID_Responsavel, _versao, _sv.ID_Servico, _CamposMinutas, _IdMetodoCampos);
                frm.Invoke((MethodInvoker)delegate
                {
                    frm.Close();
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao tentar capturar o boleto.\n\nErro: " + ex.Message, "Importação Boleto OQ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Loading.StaticFormVisible(false);
                _concluido = true;
                frmLoading.Invoke((MethodInvoker)delegate
                {
                    frmLoading.Close();
                });
            }
        }

        #region [ Enter automático ]
        private void txtIdentificacao_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.ToString() == "Return")
            {
                this.btnExecutar.PerformClick();
            }
        }
        #endregion

    }
}
