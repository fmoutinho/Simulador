﻿namespace Mobios
{
    partial class Integradores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Integradores));
            this.lstIntegradores = new System.Windows.Forms.ListBox();
            this.Integ = new System.Windows.Forms.Label();
            this.txUser = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txFuncional = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txPass = new System.Windows.Forms.TextBox();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.txPassConfirma = new System.Windows.Forms.TextBox();
            this.lblConfirma = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstIntegradores
            // 
            this.lstIntegradores.Enabled = false;
            this.lstIntegradores.FormattingEnabled = true;
            this.lstIntegradores.Location = new System.Drawing.Point(25, 47);
            this.lstIntegradores.Name = "lstIntegradores";
            this.lstIntegradores.Size = new System.Drawing.Size(123, 186);
            this.lstIntegradores.TabIndex = 0;
            // 
            // Integ
            // 
            this.Integ.AutoSize = true;
            this.Integ.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Integ.Location = new System.Drawing.Point(28, 31);
            this.Integ.Name = "Integ";
            this.Integ.Size = new System.Drawing.Size(112, 13);
            this.Integ.TabIndex = 1;
            this.Integ.Text = "Meus Integradores";
            // 
            // txUser
            // 
            this.txUser.Enabled = false;
            this.txUser.Location = new System.Drawing.Point(172, 47);
            this.txUser.Name = "txUser";
            this.txUser.Size = new System.Drawing.Size(100, 20);
            this.txUser.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(172, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Usuário";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(172, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Funcional";
            // 
            // txFuncional
            // 
            this.txFuncional.Enabled = false;
            this.txFuncional.Location = new System.Drawing.Point(172, 92);
            this.txFuncional.Name = "txFuncional";
            this.txFuncional.Size = new System.Drawing.Size(100, 20);
            this.txFuncional.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(172, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Senha";
            // 
            // txPass
            // 
            this.txPass.Location = new System.Drawing.Point(172, 135);
            this.txPass.MaxLength = 8;
            this.txPass.Name = "txPass";
            this.txPass.PasswordChar = '*';
            this.txPass.Size = new System.Drawing.Size(100, 20);
            this.txPass.TabIndex = 15;
            this.txPass.TextChanged += new System.EventHandler(this.txPass_TextChanged);
            // 
            // btnSalvar
            // 
            this.btnSalvar.BackColor = System.Drawing.Color.White;
            this.btnSalvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvar.Image = ((System.Drawing.Image)(resources.GetObject("btnSalvar.Image")));
            this.btnSalvar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalvar.Location = new System.Drawing.Point(174, 210);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(98, 23);
            this.btnSalvar.TabIndex = 17;
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.UseVisualStyleBackColor = false;
            this.btnSalvar.Visible = false;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvarServico_Click);
            // 
            // txPassConfirma
            // 
            this.txPassConfirma.Location = new System.Drawing.Point(172, 180);
            this.txPassConfirma.MaxLength = 8;
            this.txPassConfirma.Name = "txPassConfirma";
            this.txPassConfirma.PasswordChar = '*';
            this.txPassConfirma.Size = new System.Drawing.Size(100, 20);
            this.txPassConfirma.TabIndex = 16;
            this.txPassConfirma.Visible = false;
            this.txPassConfirma.TextChanged += new System.EventHandler(this.txPassConfirma_TextChanged);
            // 
            // lblConfirma
            // 
            this.lblConfirma.AutoSize = true;
            this.lblConfirma.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConfirma.Location = new System.Drawing.Point(172, 164);
            this.lblConfirma.Name = "lblConfirma";
            this.lblConfirma.Size = new System.Drawing.Size(100, 13);
            this.lblConfirma.TabIndex = 18;
            this.lblConfirma.Text = "Confirmar Senha";
            this.lblConfirma.Visible = false;
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.White;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.Location = new System.Drawing.Point(172, 164);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(100, 23);
            this.btnClose.TabIndex = 19;
            this.btnClose.Text = "Limpar Senha";
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Visible = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // Integradores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(345, 256);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.txPassConfirma);
            this.Controls.Add(this.lblConfirma);
            this.Controls.Add(this.btnSalvar);
            this.Controls.Add(this.txPass);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txFuncional);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txUser);
            this.Controls.Add(this.Integ);
            this.Controls.Add(this.lstIntegradores);
            this.Name = "Integradores";
            this.Text = "Integradores";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstIntegradores;
        private System.Windows.Forms.Label Integ;
        private System.Windows.Forms.TextBox txUser;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txFuncional;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txPass;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.TextBox txPassConfirma;
        private System.Windows.Forms.Label lblConfirma;
        private System.Windows.Forms.Button btnClose;
    }
}