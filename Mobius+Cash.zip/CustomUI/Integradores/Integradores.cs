﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mobios
{
    public partial class Integradores : Form
    {
        public Integradores(string funcional, string login, List<string> integradores, string pass)
        {
            InitializeComponent();
            txUser.Text = login;
            txFuncional.Text = funcional;
            txPass.Text = pass;
            
            List<string> Integrações = new List<string>();
            
            foreach (string integrador in integradores)
            {
                string[] integradorArray = integrador.Split(';');

                foreach (string integ in integradorArray)
                {
                    if (integ.ToUpper().Contains("=TRUE"))
                    {
                        Integrações.Add(integ.ToUpper().Replace("=TRUE", ""));
                    }
                }
            }

            if (Integrações.Count() > 0)
            {
                Integrações = Integrações.Distinct().ToList();
            }

            foreach (string integrador in Integrações)
            {
                lstIntegradores.Items.Add(integrador);
            }

            if (pass != "")
            {
                txPass.Enabled = false;
                btnClose.Visible = true;
                txPassConfirma.Visible = false;
                lblConfirma.Visible = false;
            }
        }

        private void btnSalvarServico_Click(object sender, EventArgs e)
        {
            if (txPass.Text == txPassConfirma.Text && ((txPass.Text.Length == 6 && txPassConfirma.Text.Length == 6) || (txPass.Text.Length == 8 && txPassConfirma.Text.Length == 8)))
            {
                if (MessageBox.Show("Esta senha será utilizada para acessar os portais do Itaú-Unibanco.\n\nSalvar e prosseguir?", "Integrador", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    MainForm.SalvarSenha(txPass.Text);
                    MessageBox.Show("Senha salva com sucesso\n\nCaso algum login não seja bem-sucedido, nova senha será solicitada", "Integrador", MessageBoxButtons.OK);
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("As senhas são inválidas ou não coincidem", "Integrador", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void txPass_TextChanged(object sender, EventArgs e)
        {
            if (txPass.Text.Length == 6 || txPass.Text.Length == 8)
            {
                txPassConfirma.Visible = true;
                lblConfirma.Visible = true;
            }
            else 
            {
                txPassConfirma.Visible = false;
                lblConfirma.Visible = false;
                btnSalvar.Visible = false;
            }
        }

        private void txPassConfirma_TextChanged(object sender, EventArgs e)
        {
            if (txPassConfirma.Text.Length == 6 || txPassConfirma.Text.Length == 8)
            {
                btnSalvar.Visible = true;
            }
            else
            {
                btnSalvar.Visible = false;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Esta senha é utilizada para acessar os portais do Itaú-Unibanco.\n\nRemovendo não será possível realizar as integrações WEB\n\nSalvar e prosseguir?", "Integrador", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
            {
                txPass.Text = "";
                MainForm.SalvarSenha("");
                MessageBox.Show("Senha removida", "Integrador", MessageBoxButtons.OK);
                this.Close();
            }
        }
    }
}
