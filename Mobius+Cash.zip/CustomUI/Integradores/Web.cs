﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace Mobios
{
    public partial class Web : Form
    {
        string _user;
        string _password;
        string _erro;
        ImportaWeb AcessoWeb = new ImportaWeb();
        string _servicosAbertos;
        List<string> _servicos;
        List<Responsavel> _UserCelulas;

        public Web(string password = "")
        {
            try
            {
                _user = SharedData.User.FuncionalResponsavel;
                _password = password;
                _erro = "";
                _servicos = new List<string>();
                _servicosAbertos = "";
                _UserCelulas = SharedData.UserCelulas;

                Thread t = new Thread(ProcessarWeb);
                t.SetApartmentState(ApartmentState.STA);
                t.Start();
                t.Join();
                try
                {
                    this.Close();
                }
                catch { }
                MainForm.EnableStaticTextBox(_servicosAbertos);
                if (_erro != "")
                {
                    MainForm.SalvarSenha("");
                    throw new Exception("Não foi possível realizar as integrações.\n\nVerifique seus acessos e funcionamento dos sistemas acessados.\n\nPor segurança, o integrador foi desligado para evitar bloqueio de senha.\n\nMensagem de Erro: " + _erro);
                }
            }
            catch (Exception e)
            {
                //MainForm.EnableStaticTextBox(_servicosAbertos);
                throw new Exception(e.Message);
            }
        }

        public void ProcessarWeb()
        {
            InitializeComponent();
            //this.Show();
            //form.EnableStaticTextBox("Capturando dados da Web");


            try
            {
                this.webBrowser1.ScriptErrorsSuppressed = true;
                _servicos = AcessoWeb.BuscaServicosWeb(_UserCelulas, this.webBrowser1, _user, _password);
                _servicosAbertos = "Quantidade de Serviços Abertos: " + _servicos.Count();
            }
            catch (Exception e)
            {
                _servicosAbertos = e.Message.Substring(e.Message.IndexOf("Quantidade de Serviços Abertos: "));
                _erro = e.Message.Substring(0, e.Message.IndexOf("Quantidade de Serviços Abertos: "));
            }

            try
            {
                this.Close();
            }
            catch { }
        }
    }
}
