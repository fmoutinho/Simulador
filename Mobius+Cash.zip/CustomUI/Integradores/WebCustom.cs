﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Reflection;

namespace Mobios
{
    public partial class WebCustom : Form
    {
        string _NomeMetodo;
        string _erro;
        bool _Visible;
        string _user;
        string _password;
        CustomMethod.MethodForm _FormMetodo;

        public WebCustom(string NomeMetodo, CustomMethod.MethodForm FormMetodo, string user = "", string password = "", bool Visible = false)
        {
            _erro = "";
            _NomeMetodo = NomeMetodo;
            _FormMetodo = FormMetodo;
            _Visible = Visible;
            _user = user;
            _password = password;
            //ProcessarWeb();
            try
            {
                Thread t = new Thread(ProcessarWeb);
                t.SetApartmentState(ApartmentState.STA);
                t.Start();
                t.Join();
                try
                {
                    this.Close();
                }
                catch { }
                if (_erro != "")
                {
                    throw new Exception("Não foi possível realizar as integrações.\n\nVerifique seus acessos e funcionamento dos sistemas acessados.\n\nMensagem de Erro: " + _erro);
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public void ProcessarWeb()
        {
            InitializeComponent();
            
            if (SharedData.gHomologação || _Visible)
                this.Show();
            
            try
            {
                Type t = typeof(CustomMethod);
                MethodInfo mMethod = t.GetMethod(_NomeMetodo);
                ParameterInfo[] parameters = mMethod.GetParameters();
                int size = parameters.Length;
                object[] parametersArray = new object[size];

                parametersArray[0] = this.webBrowser1;
                if (_password != "" && _user != "" && _password != null && _user != null)
                {
                    parametersArray[1]= _user;
                    parametersArray[2] = _password;
                }
                this.webBrowser1.ScriptErrorsSuppressed = true;
                CustomMethod.ChamarMetodo(_NomeMetodo, _FormMetodo, parametersArray);
            }
            catch (Exception e)
            {
                _erro = e.Message;
            }
            try
            {
                this.Close();
            }
            catch { }
        }
    }
}
