﻿namespace Mobios
{
    partial class fIntegra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fIntegra));
            this.BK_INTEGRA = new System.ComponentModel.BackgroundWorker();
            this.BK_DISTRIB = new System.ComponentModel.BackgroundWorker();
            this.NI = new System.Windows.Forms.NotifyIcon(this.components);
            this.MN = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.fecharToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblHora = new System.Windows.Forms.Label();
            this.lblUsu = new System.Windows.Forms.Label();
            this.lblMV = new System.Windows.Forms.Label();
            this.lblLast = new System.Windows.Forms.Label();
            this.TM = new System.Windows.Forms.Timer(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.MN.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // BK_INTEGRA
            // 
            this.BK_INTEGRA.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BK_INTEGRA_DoWork);
            // 
            // BK_DISTRIB
            // 
            this.BK_DISTRIB.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BK_DISTRIB_DoWork);
            // 
            // NI
            // 
            this.NI.ContextMenuStrip = this.MN;
            this.NI.Icon = ((System.Drawing.Icon)(resources.GetObject("NI.Icon")));
            this.NI.Text = "Integrador Mobios";
            this.NI.Visible = true;
            this.NI.DoubleClick += new System.EventHandler(this.NI_DoubleClick);
            // 
            // MN
            // 
            this.MN.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fecharToolStripMenuItem});
            this.MN.Name = "MN";
            this.MN.Size = new System.Drawing.Size(108, 26);
            // 
            // fecharToolStripMenuItem
            // 
            this.fecharToolStripMenuItem.Name = "fecharToolStripMenuItem";
            this.fecharToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.fecharToolStripMenuItem.Text = "Fechar";
            this.fecharToolStripMenuItem.Click += new System.EventHandler(this.fecharToolStripMenuItem_Click);
            // 
            // lblHora
            // 
            this.lblHora.AutoSize = true;
            this.lblHora.Location = new System.Drawing.Point(12, 9);
            this.lblHora.Name = "lblHora";
            this.lblHora.Size = new System.Drawing.Size(41, 13);
            this.lblHora.TabIndex = 0;
            this.lblHora.Text = "Horário";
            // 
            // lblUsu
            // 
            this.lblUsu.AutoSize = true;
            this.lblUsu.Location = new System.Drawing.Point(12, 32);
            this.lblUsu.Name = "lblUsu";
            this.lblUsu.Size = new System.Drawing.Size(43, 13);
            this.lblUsu.TabIndex = 1;
            this.lblUsu.Text = "Usuário";
            // 
            // lblMV
            // 
            this.lblMV.AutoSize = true;
            this.lblMV.Location = new System.Drawing.Point(12, 56);
            this.lblMV.Name = "lblMV";
            this.lblMV.Size = new System.Drawing.Size(46, 13);
            this.lblMV.TabIndex = 2;
            this.lblMV.Text = "Estação";
            // 
            // lblLast
            // 
            this.lblLast.AutoSize = true;
            this.lblLast.Location = new System.Drawing.Point(12, 117);
            this.lblLast.Name = "lblLast";
            this.lblLast.Size = new System.Drawing.Size(41, 13);
            this.lblLast.TabIndex = 3;
            this.lblLast.Text = "Horário";
            // 
            // TM
            // 
            this.TM.Enabled = true;
            this.TM.Interval = 10000;
            this.TM.Tick += new System.EventHandler(this.TM_Tick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(239, -12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(197, 118);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // fIntegra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(448, 143);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblLast);
            this.Controls.Add(this.lblMV);
            this.Controls.Add(this.lblUsu);
            this.Controls.Add(this.lblHora);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "fIntegra";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Integrador Mobios";
            this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.fIntegra_FormClosing);
            this.Load += new System.EventHandler(this.fIntegra_Load);
            this.MN.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker BK_INTEGRA;
        private System.ComponentModel.BackgroundWorker BK_DISTRIB;
        private System.Windows.Forms.NotifyIcon NI;
        private System.Windows.Forms.Label lblHora;
        private System.Windows.Forms.Label lblUsu;
        private System.Windows.Forms.Label lblMV;
        private System.Windows.Forms.Label lblLast;
        private System.Windows.Forms.Timer TM;
        private System.Windows.Forms.ContextMenuStrip MN;
        private System.Windows.Forms.ToolStripMenuItem fecharToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;

    }
}