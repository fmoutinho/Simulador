﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using Microsoft.VisualBasic;
using System.Configuration;


namespace Mobios
{
    public partial class fIntegra : Form
    {
        public fIntegra()
        {


            if (SharedData.verExec("ing") == true)
                System.Environment.Exit(0);

            InitializeComponent();
        }

        private string getValor(string[] Dados, string Campo)
        {

            for (int i = 0; i < Dados.Length; i++)
            {
                if (Dados[i].Contains(Campo))
                {

                    return Dados[i].Replace(Campo, "").Trim();
                }
            }

            return "";

        }

        private void BK_INTEGRA_DoWork(object sender, DoWorkEventArgs e)
        {


            //Integra.LerEmailBoletos();

        }

      
        private void BK_DISTRIB_DoWork(object sender, DoWorkEventArgs e)
        {

            //Integra.ExecutarBoletos();

        }

        private void fIntegra_Load(object sender, EventArgs e)
        {

            //Integra.DadosFlag d = new Integra.DadosFlag();
            //d = Integra.Dados();

            //if (d.Tempo == 0 || d.Tempo>Properties.Settings.Default.TempoIntegra)
                //Integra.MarcaFlag();

            lblHora.Text = "Iniciado em " + DateTime.Now.Date.ToShortDateString() + " As " + DateTime.Now.ToShortTimeString();
            lblUsu.Text = Environment.UserName.ToUpper();
            lblMV.Text = Environment.MachineName.ToUpper();
            //lblLast.Text = d.Horario.ToString();

            BK_DISTRIB.RunWorkerAsync();
            BK_INTEGRA.RunWorkerAsync();

        }

        
        private void NI_DoubleClick(object sender, EventArgs e)
        {

            this.StartPosition =FormStartPosition.CenterScreen;
            this.WindowState = FormWindowState.Normal;
            this.Visible = true;
            //Interaction.AppActivate(this.Text);
        }

        private void fIntegra_FormClosing(object sender, FormClosingEventArgs e)
        {

            DialogResult Rt=MessageBox.Show("Tem certeza que deseja parar o integrador?","Atenção", MessageBoxButtons.YesNo,MessageBoxIcon.Question);

            if (Rt == DialogResult.No)
                e.Cancel = true;

        }

        private void TM_Tick(object sender, EventArgs e)
        {

            string En = SharedData.PathObrigarFechamento;

            if (System.IO.File.Exists(En)) 
                Environment.Exit(0);

            //Integra.MarcaFlag();

            //Integra.DadosFlag d = new Integra.DadosFlag();
            //d = Integra.Dados();

            //lblLast.Text = d.Horario.ToString();

        }

        private void fecharToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            //Environment.Exit(0);

        }

       
    }
}
