﻿namespace Mobios
{
    partial class MobiosCash_AjustedeGrupos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.grupo = new System.Windows.Forms.TextBox();
            this.Gravar = new System.Windows.Forms.Button();
            this.carteira_nr = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Grupo:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Carteira Nº:";
            // 
            // grupo
            // 
            this.grupo.Location = new System.Drawing.Point(101, 42);
            this.grupo.Name = "grupo";
            this.grupo.Size = new System.Drawing.Size(545, 20);
            this.grupo.TabIndex = 2;
            // 
            // Gravar
            // 
            this.Gravar.Location = new System.Drawing.Point(571, 118);
            this.Gravar.Name = "Gravar";
            this.Gravar.Size = new System.Drawing.Size(75, 23);
            this.Gravar.TabIndex = 4;
            this.Gravar.Text = "Gravar";
            this.Gravar.UseVisualStyleBackColor = true;
            this.Gravar.Click += new System.EventHandler(this.Gravar_Click);
            // 
            // carteira_nr
            // 
            this.carteira_nr.Location = new System.Drawing.Point(101, 89);
            this.carteira_nr.Mask = "##";
            this.carteira_nr.Name = "carteira_nr";
            this.carteira_nr.Size = new System.Drawing.Size(37, 20);
            this.carteira_nr.TabIndex = 5;
            // 
            // MobiosCash_AjustedeGrupos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(685, 151);
            this.Controls.Add(this.carteira_nr);
            this.Controls.Add(this.Gravar);
            this.Controls.Add(this.grupo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "MobiosCash_AjustedeGrupos";
            this.Text = "MobiosCash_AjustedeGrupos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox grupo;
        private System.Windows.Forms.Button Gravar;
        private System.Windows.Forms.MaskedTextBox carteira_nr;
    }
}