﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mobios
{
    public partial class MobiosCash_AjustedeGrupos : Form
    {
        public MobiosCash_AjustedeGrupos()
        {
            InitializeComponent();
        }

        private void Gravar_Click(object sender, EventArgs e)
        {
            string msg = "";

            

            if (this.grupo.Text != "" && this.carteira_nr.Text != "")
            {
                this.grupo.Text = TratamentoCampo.AntiInjection(this.grupo.Text);
                this.carteira_nr.Text = TratamentoCampo.AntiInjection(this.carteira_nr.Text);

                string sql = "SELECT MOBIOSCASH_TB_AJUSTE_GRUPO.GRUPO, Last(MOBIOSCASH_TB_AJUSTE_GRUPO.CARTEIRA_NR) AS CARTEIRA_NR, Last(MOBIOSCASH_TB_AJUSTE_GRUPO.DATAALTERACAO) AS DATAALTERACAO FROM MOBIOSCASH_TB_AJUSTE_GRUPO GROUP BY MOBIOSCASH_TB_AJUSTE_GRUPO.GRUPO";

                DataTable Retorno = DataConnector.ExecuteDataTable(sql + " having GRUPO='" + this.grupo.Text + "'", "BDdados");
                if (Retorno != null && Retorno.Rows.Count > 0)
                {
                    DialogResult resultDialog = MessageBox.Show("Grupo já existe.\n\nInformação existente:\nCarteira Nr: " + Retorno.Rows[0]["CARTEIRA_NR"].ToString() + "\nAlterado em: " + Retorno.Rows[0]["DATAALTERACAO"].ToString() + "\n\nDeseja atualizar os dados?", "Grupo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (resultDialog == DialogResult.Yes)
                    {
                        //string query = "update MOBIOSCASH_TB_AJUSTE_GRUPO set CARTEIRA_NR='" + this.carteira_nr.Text + "' where GRUPO='" + this.grupo.Text + "'";
                        //DataConnector.ExecuteNonQuery(query, "BDdados");
                        string query = "insert into MOBIOSCASH_TB_AJUSTE_GRUPO (GRUPO,CARTEIRA_NR,RESPALTERACAO) values ('" + this.grupo.Text + "','" + this.carteira_nr.Text + "','" + Environment.UserName.ToUpper() + "')";
                        DataConnector.ExecuteNonQuery(query, "BDdados");
                        msg = "Dado inserido";
                    }
                    else
                    {
                        msg = "";
                    }
                }
                else
                {
                    string query = "insert into MOBIOSCASH_TB_AJUSTE_GRUPO (GRUPO,CARTEIRA_NR,RESPALTERACAO) values ('" + this.grupo.Text + "','" + this.carteira_nr.Text + "','" + Environment.UserName.ToUpper() + "')";
                    DataConnector.ExecuteNonQuery(query, "BDdados");
                    msg = "Dado inserido";
                }
                if (msg != "")
                {
                    MessageBox.Show(msg, "Mobios", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.grupo.Text = "";
                    this.carteira_nr.Text = "";
                }
                
            }
            else
            {
                MessageBox.Show("Necessário entrar com os dados", "Validação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
