﻿namespace Mobios
{
    partial class FotoUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.wbPortal = new System.Windows.Forms.WebBrowser();
            this.SuspendLayout();
            // 
            // wbPortal
            // 
            this.wbPortal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.wbPortal.Location = new System.Drawing.Point(0, 0);
            this.wbPortal.MinimumSize = new System.Drawing.Size(20, 20);
            this.wbPortal.Name = "wbPortal";
            this.wbPortal.ScrollBarsEnabled = false;
            this.wbPortal.Size = new System.Drawing.Size(70, 73);
            this.wbPortal.TabIndex = 0;
            this.wbPortal.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.wbPortal_DocumentCompleted);
            // 
            // FotoUsuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(70, 73);
            this.ControlBox = false;
            this.Controls.Add(this.wbPortal);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FotoUsuario";
            this.Text = "FotoUsuario";
            this.Activated += new System.EventHandler(this.FotoUsuario_Activated);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.WebBrowser wbPortal;
    }
}