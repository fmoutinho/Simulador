﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mobios
{
    public partial class FotoUsuario : Form
    {
        public bool SemAcesso;
        public bool Complete;
        
        protected override bool ShowWithoutActivation
        {
            get { return true; }
        }

        public FotoUsuario()
        {
            SemAcesso = false;
            Complete = false;
            InitializeComponent();
            wbPortal.ScriptErrorsSuppressed = true;
            wbPortal.Navigate(string.Format(@"https://portalcorp.itau-unibanco/_layouts/RecuperaImagemPerfil.aspx?NumeroFuncionalColaborador={0}&tamanho=p",SharedData.User.FuncionalResponsavel));
        }


        private void wbPortal_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            if (e.Url.ToString() != string.Format(@"https://portalcorp.itau-unibanco/_layouts/RecuperaImagemPerfil.aspx?NumeroFuncionalColaborador={0}&tamanho=p", SharedData.User.FuncionalResponsavel))
            {
                SemAcesso = true;
                this.Close();
            }
            Complete = true;
        }

        private void FotoUsuario_Activated(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
        }
    }
}
