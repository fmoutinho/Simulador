﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mobios
{
    public partial class PontoEletronico : Form
    {
        public PontoEletronico()
        {
            InitializeComponent();
            this.webBrowser1.ScriptErrorsSuppressed = true;
            this.AutoSize = true;
            this.webBrowser1.Navigate(SharedData.gPontoEletronicoURL);
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            //this.Height = this.webBrowser1.Document.Window.Size.Height;
            //this.Width = this.webBrowser1.Document.Window.Size.Width;
            mshtml.IHTMLDocument2 docs2 = (mshtml.IHTMLDocument2)webBrowser1.Document.DomDocument;
            mshtml.IHTMLDocument3 docs3 = (mshtml.IHTMLDocument3)webBrowser1.Document.DomDocument;
            mshtml.IHTMLElement2 body2 = (mshtml.IHTMLElement2)docs2.body;
            mshtml.IHTMLElement2 root2 = (mshtml.IHTMLElement2)docs3.documentElement;

            int width = Math.Max(body2.scrollWidth, root2.scrollWidth);
            int height = Math.Max(root2.scrollHeight, body2.scrollHeight);
            this.webBrowser1.ScrollBarsEnabled = false;
            // Resize the control to the exact size to display the page. Also, make sure scroll bars are disabled
            this.Width = width;
            this.Height = height;

        } 
    }
}
