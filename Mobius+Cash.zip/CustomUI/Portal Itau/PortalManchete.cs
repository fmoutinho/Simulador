﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mobios
{
    public partial class PortalManchete : Form
    {
        public bool SemAcesso;
        public bool Complete;

        protected override bool ShowWithoutActivation
        {
            get { return true; }
        }


        public PortalManchete()
        {
            Complete = false;
            SemAcesso = false;
            InitializeComponent();
            wbPortal.ScriptErrorsSuppressed = true;
            wbPortal.Navigate(@"https://portalcorp.itau-unibanco/pt/Paginas/banner_com_manchete/Administração%20Central/banner_com_manchete.htm");
        }

        private void wbPortal_Navigating(object sender, WebBrowserNavigatingEventArgs e)
        {
            if (e.Url.ToString() != @"https://portalcorp.itau-unibanco/pt/Paginas/banner_com_manchete/Administração Central/banner_com_manchete.htm")
            {
                //System.Diagnostics.Process.Start(e.Url.ToString());
                e.Cancel = true;
                SemAcesso = true;
                this.Close();
            }
        }

        private void wbPortal_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            if (e.Url.ToString() != @"https://portalcorp.itau-unibanco/pt/Paginas/banner_com_manchete/Administração Central/banner_com_manchete.htm")
            {
                SemAcesso = true;
                this.Close();
            }
            Complete = true;
        }

        private void PortalManchete_Activated(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
        }
    }
}
