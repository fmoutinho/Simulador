﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using Mobios;
using System.Configuration;
using System.Globalization;

namespace Mobios
{
    public class DataAccess
    {
        #region [ Parametros Gerais ]
        public static string GetParametro(string nome)
        {
            string sql = "SELECT Valor FROM tb_0200_Parametros WHERE Nome = '" + nome + "'";

            DataTable dt = DataConnector.ExecuteDataTable(sql, "BDconsulta");

            if (dt.Rows.Count > 0)
                return dt.Rows[0][0].ToString();
            else
                return "";
        }
        public static string GetParametros()
        {
            string str_return = "";
            string sql = "SELECT * FROM tb_0200_Parametros";

            try
            {


                
                

                DataTable dt = DataConnector.ExecuteDataTable(sql, "BDconsulta");

                if (dt.Rows.Count > 0)
                {
                    SharedData.Parametros = dt.Copy();
                    str_return = "PreCarregarCampos"; SharedData.gPreCarregarCampos = Convert.ToBoolean(dt.Select("NOME = 'PreCarregarCampos'").CopyToDataTable().Rows[0]["VALOR"]);
                    
                    str_return = "VALIDACAORESPONSAVEL"; SharedData.gValidarResponsavel = Convert.ToBoolean(dt.Select("NOME = 'VALIDACAORESPONSAVEL'").CopyToDataTable().Rows[0]["VALOR"]);
                    str_return = "AtribuiResponsavelServico"; SharedData.gAtribuiResponsavelServico = Convert.ToBoolean(dt.Select("NOME = 'AtribuiResponsavelServico'").CopyToDataTable().Rows[0]["VALOR"]);

                    str_return = "VersaoPublish"; SharedData.gVersaoSistemaPublish = dt.Select("NOME = 'VersaoPublish'").CopyToDataTable().Rows[0]["VALOR"].ToString().ToUpper();
                    str_return = "VersaoDebug"; SharedData.gVersaoSistemaDebug = dt.Select("NOME = 'VersaoDebug'").CopyToDataTable().Rows[0]["VALOR"].ToString().ToUpper();
                    str_return = "FormOperação"; SharedData.gFormOperação = dt.Select("NOME = 'FormOperação'").CopyToDataTable().Rows[0]["VALOR"].ToString().ToUpper();
                    str_return = "BoletadorTela"; SharedData.gBoletadorTela = dt.Select("NOME = 'BoletadorTela'").CopyToDataTable().Rows[0]["VALOR"].ToString().ToUpper();

                    str_return = "AtivaPontoEletronico"; SharedData.gPontoEletronico = Convert.ToBoolean(dt.Select("NOME = 'AtivaPontoEletronico'").CopyToDataTable().Rows[0]["VALOR"]);
                    str_return = "PontoEletronico"; SharedData.gPontoEletronicoURL = dt.Select("NOME = 'PontoEletronico'").CopyToDataTable().Rows[0]["VALOR"].ToString();
                    str_return = "PaginasPortalItau"; SharedData.gPaginasPortalItau = Convert.ToBoolean(dt.Select("NOME = 'PaginasPortalItau'").CopyToDataTable().Rows[0]["VALOR"]);

                    str_return = "QRCODE"; SharedData.gQrCode = Convert.ToBoolean(dt.Select("NOME = 'QRCODE'").CopyToDataTable().Rows[0]["VALOR"]);
                    str_return = "QRCODE_TAMANHO"; SharedData.gQrCodeTamanho = dt.Select("NOME = 'QRCODE_TAMANHO'").CopyToDataTable().Rows[0]["VALOR"].ToString();

                    str_return = "PipelineFiltro"; SharedData.gPipelineFiltro = Convert.ToBoolean(dt.Select("NOME = 'PipelineFiltro'").CopyToDataTable().Rows[0]["VALOR"]);
                    str_return = "PipelineAutomatico"; SharedData.gPipelineAutomatico = Convert.ToBoolean(dt.Select("NOME = 'PipelineAutomatico'").CopyToDataTable().Rows[0]["VALOR"]);
                    str_return = "ValidaDependenciaResponsavel"; SharedData.gValidaDependenciaResponsavel = Convert.ToBoolean(dt.Select("NOME = 'ValidaDependenciaResponsavel'").CopyToDataTable().Rows[0]["VALOR"]);
                    str_return = "ValidaMesmoResponsavel"; SharedData.gValidaMesmoResponsavel = Convert.ToBoolean(dt.Select("NOME = 'ValidaMesmoResponsavel'").CopyToDataTable().Rows[0]["VALOR"]);

                    str_return = "GravarLogAoGerarMinuta"; SharedData.gGravarLogAoGerarMinuta = Convert.ToBoolean(dt.Select("NOME = 'GravarLogAoGerarMinuta'").CopyToDataTable().Rows[0]["VALOR"]);

                    str_return = "SuporteAssunto"; SharedData.gSuporteAssunto = dt.Select("NOME = 'SuporteAssunto'").CopyToDataTable().Rows[0]["VALOR"].ToString();
                    str_return = "SuporteEmail"; SharedData.gSuporteEmail = dt.Select("NOME = 'SuporteEmail'").CopyToDataTable().Rows[0]["VALOR"].ToString();
                    str_return = "SuporteMensagem"; SharedData.gSuporteMensagem = dt.Select("NOME = 'SuporteMensagem'").CopyToDataTable().Rows[0]["VALOR"].ToString();

                    str_return = "PipeLinePageSize"; SharedData.gPipeLinePageSize = Convert.ToInt32(dt.Select("NOME = 'PipeLinePageSize'").CopyToDataTable().Rows[0]["VALOR"]);
                    str_return = "PipeLineMaximizar"; SharedData.gPipeLineMaximizar = Convert.ToBoolean(dt.Select("NOME = 'PipelineMaximizar'").CopyToDataTable().Rows[0]["VALOR"]);


                    str_return = "Falar"; SharedData.gFalar = Convert.ToBoolean(dt.Select("NOME = 'Falar'").CopyToDataTable().Rows[0]["VALOR"]);

                    #region [ integrações ]
                    str_return = "LeitorEmail"; SharedData.gLeitorEmail = Convert.ToBoolean(dt.Select("NOME = 'LeitorEmail'").CopyToDataTable().Rows[0]["VALOR"]);
                    str_return = "LeitorSharepoint"; SharedData.gLeitorSharepoint = Convert.ToBoolean(dt.Select("NOME = 'LeitorSharepoint'").CopyToDataTable().Rows[0]["VALOR"]);
                    str_return = "LeitorWEB"; SharedData.gLeitorWEB = Convert.ToBoolean(dt.Select("NOME = 'LeitorWEB'").CopyToDataTable().Rows[0]["VALOR"]);
                    str_return = "LeitorMetodo"; SharedData.gLeitorMetodo = Convert.ToBoolean(dt.Select("NOME = 'LeitorMetodo'").CopyToDataTable().Rows[0]["VALOR"]);
                    str_return = "BackUp"; SharedData.gBackUp = Convert.ToBoolean(dt.Select("NOME = 'BackUp'").CopyToDataTable().Rows[0]["VALOR"]);
                    str_return = "BackUpQuantidade"; SharedData.gBackUpQtd = Convert.ToInt32(dt.Select("NOME = 'BackUpQuantidade'").CopyToDataTable().Rows[0]["VALOR"]);
                    str_return = "BackUpTimer"; SharedData.gBackUpInterval = Convert.ToInt32(dt.Select("NOME = 'BackUpTimer'").CopyToDataTable().Rows[0]["VALOR"]);

                    str_return = "TimerIntervalIntegracoes"; SharedData.gTimerIntervalFechamento = Convert.ToInt32(dt.Select("NOME = 'TimerIntervalIntegracoes'").CopyToDataTable().Rows[0]["VALOR"]);
                    str_return = "TimerIntervalFechamento"; SharedData.gTimerIntervalIntegracoes = Convert.ToInt32(dt.Select("NOME = 'TimerIntervalFechamento'").CopyToDataTable().Rows[0]["VALOR"]);
                    str_return = "TimerIntervalPortal"; SharedData.gTimerIntervalPortal = Convert.ToInt32(dt.Select("NOME = 'TimerIntervalPortal'").CopyToDataTable().Rows[0]["VALOR"]);
                    str_return = "TimerIntervalPipeline"; SharedData.gTimerIntervalPipeline = Convert.ToInt32(dt.Select("NOME = 'TimerIntervalPipeline'").CopyToDataTable().Rows[0]["VALOR"]);
                    str_return = "TimerIntervalDetalhe"; SharedData.gTimerIntervalDetalhe = Convert.ToInt32(dt.Select("NOME = 'TimerIntervalDetalhe'").CopyToDataTable().Rows[0]["VALOR"]);



                    str_return = "ValidaPontoEletronico"; SharedData.gValidaPonto = Convert.ToBoolean(dt.Select("NOME = 'ValidaPontoEletronico'").CopyToDataTable().Rows[0]["VALOR"]);
                    str_return = "ValidaPontoEletronicoLink"; SharedData.gValidaPontoLink = dt.Select("NOME = 'ValidaPontoEletronicoLink'").CopyToDataTable().Rows[0]["VALOR"].ToString();
                    str_return = "ValidaPontoEletronicoTimer"; SharedData.gValidaPontoInterval = Convert.ToInt32(dt.Select("NOME = 'ValidaPontoEletronicoTimer'").CopyToDataTable().Rows[0]["VALOR"]);

                    str_return = "VALIDABOLETO"; SharedData.gValidaBoleto = Convert.ToBoolean(dt.Select("NOME = 'VALIDABOLETO'").CopyToDataTable().Rows[0]["VALOR"]);

                    #region [ BEN ]
                    str_return = "TagCodContrato"; SharedData.gBenTagContrato = dt.Select("NOME = 'TagCodContrato'").CopyToDataTable().Rows[0]["VALOR"].ToString();
                    str_return = "TagSearchKey"; SharedData.gBenTagSearchKey = dt.Select("NOME = 'TagSearchKey'").CopyToDataTable().Rows[0]["VALOR"].ToString();
                    str_return = "XmlResumo"; SharedData.gBenXmlResumo = dt.Select("NOME = 'XmlResumo'").CopyToDataTable().Rows[0]["VALOR"].ToString();
                    str_return = "TrincaPME"; SharedData.gBenTrincaPME = dt.Select("NOME = 'TrincaPME'").CopyToDataTable().Rows[0]["VALOR"].ToString();
                    str_return = "XmlDetalhe"; SharedData.gBenDetalhe = dt.Select("NOME = 'XmlDetalhe'").CopyToDataTable().Rows[0]["VALOR"].ToString();
                    #endregion

                    str_return = "LoginOQ"; SharedData.gLoginOQ = dt.Select("NOME = 'LoginOQ'").CopyToDataTable().Rows[0]["VALOR"].ToString();
                    str_return = "LinkOQ"; SharedData.gLinkOQ = dt.Select("NOME = 'LinkOQ'").CopyToDataTable().Rows[0]["VALOR"].ToString();
                    str_return = "LoginPN"; SharedData.gLoginPN = dt.Select("NOME = 'LoginPN'").CopyToDataTable().Rows[0]["VALOR"].ToString();
                    str_return = "LinkPN"; SharedData.gLinkPN = dt.Select("NOME = 'LinkPN'").CopyToDataTable().Rows[0]["VALOR"].ToString();
                    #endregion

                    str_return = "";

                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Erro no parametro: "  + ex.Message);
            }
            return str_return;
        }
        public static void SalvarParametrosLote(DataTable DtParametros)
        {
            if (DtParametros.Rows.Count > 0)
            {
                string sqlCommandUpdate = @"Update tb_0200_Parametros Set Valor = {0}";

                string sqlCommand = "";

                int auxUpdate = 0;
                string sqlCommandParametro = "";
                foreach (DataRow r in DtParametros.Rows)
                {
                    sqlCommandParametro += string.Format("IIf(Nome='{0}', '{1}',", r["Nome"], r["Valor"]);

                    auxUpdate = auxUpdate + 1;

                    if (auxUpdate == 10)
                    {
                        sqlCommandParametro += "[Valor]" + ("").PadLeft(auxUpdate, ')');

                        sqlCommand = string.Format(sqlCommandUpdate, sqlCommandParametro);

                        DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

                        sqlCommandParametro = "";
                        auxUpdate = 0;
                    }
                }
                sqlCommandParametro += "[Valor]" + ("").PadLeft(auxUpdate, ')');

                sqlCommand = string.Format(sqlCommandUpdate, sqlCommandParametro);
                if (auxUpdate > 0)
                {
                    DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
                }
            }
        }
        public static string BuscaVersao(bool publish)
        {
            string sqlCommand = "";
            if (publish)
                sqlCommand = string.Format("select top 1 Versao from VERSAO where TipoApp='Publish' order by DtCriacao desc");
            else
                sqlCommand = string.Format("select top 1 Versao from VERSAO where TipoApp='Debug' order by DtCriacao desc");

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            if (result.Rows.Count > 0)
            {
                return result.Rows[0][0].ToString();
            }
            else
            {
                return "";
            }

        }
        #endregion

        #region [ Responsável ]
        #region [ Buscar Responsáveis ]
        public static List<Responsavel> BuscarResponsaveis()
        {
            string sqlCommand = @"Select * From vw_ResponsavelArea";
            
            List<Responsavel> list = new List<Responsavel>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new Responsavel(row));

            return list;
        }
        public static List<Responsavel> BuscarResponsaveisArea(List<int> ID_Area, bool Todos = false)
        {
            string sqlCommand = SharedData.GetQueryDefinition("vw_ResponsavelArea");
            //string sqlCommand = @"Select * From vw_ResponsavelArea Where ";

            if (ID_Area.Count > 0)
            {
                string sqlCommandWhere = "";
                foreach (int area in ID_Area)
                {
                    if (sqlCommandWhere == "")
                    {
                        sqlCommandWhere += "[tb_0112_Areas].ID_AREA = " + area;
                    }
                    else
                    {
                        sqlCommandWhere += " OR [tb_0112_Areas].ID_AREA = " + area;
                    }

                }
                //sqlCommand += sqlCommandWhere;

                sqlCommand = TratamentoSQL.AdicionaWhere(sqlCommand, sqlCommandWhere);

                List<Responsavel> list = new List<Responsavel>();
                DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

                if (Todos == true)
                {
                    Responsavel _userTodos = new Responsavel();
                    _userTodos.ID_Area = 0;
                    _userTodos.ID_Responsavel = 0;
                    _userTodos.NomeResponsavel = "Todos";
                    _userTodos.LoginResponsavel = "Todos";
                    _userTodos.FLG_Gestor = false;
                    list.Add(_userTodos);
                }

                foreach (DataRow row in result.Rows)
                    list.Add(new Responsavel(row));

                return list;
            }
            else
            {
                return null;
            }
        }
        public static List<Responsavel> BuscarResponsaveisArea(string username)
        {
            string sqlCommand = string.Format(@"Select * From vw_ResponsavelArea Where LoginResponsavel = '{0}'", username);
            
            List<Responsavel> list = new List<Responsavel>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new Responsavel(row));

            return list;
        }
        public static List<Responsavel> BuscarResponsaveisAreaCelulasAcessadas(string username)
        {
            string sqlCommand = string.Format(@"Select * From vw_ResponsavelAreaCelulasAcessadas Where LoginResponsavel = '{0}'", username);

            List<Responsavel> list = new List<Responsavel>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new Responsavel(row));

            return list;
        }
        public static string BuscaNomeUsuario(string Login)
        {
            string sqlCommand = string.Format("Select [NomeResponsavel] FROM tb_0100_Responsavel WHERE LoginResponsavel = '{0}'", Login);
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            return result.Rows[0][0].ToString();
        }
        public static int BuscarIdResponsavel(string Login)
        {
            string sqlCommand = string.Format("SELECT Id_Responsavel FROM tb_0100_Responsavel WHERE LoginResponsavel = '{0}'", Login);
            int IdResponsavel;

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            IdResponsavel = Convert.ToInt32(result.Rows[0][0]);

            return IdResponsavel;
        }
        #endregion

        public static List<ResponsavelCelula> BuscarResponsaveisCelula(string username)
        {
            string sqlCommand = string.Format(@"SELECT * FROM vw_ResponsavelCelula WHERE LoginResponsavel = '{0}'", username);
            List<ResponsavelCelula> list = new List<ResponsavelCelula>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new ResponsavelCelula(row));

            return list;
        }
        public static List<int> BuscarAcessoCelula(string LoginResponsavel)
        {
            string sqlCommand;
            sqlCommand = string.Format(@"Select * From vw_CelulaAcesso Where LoginResponsavel = '{0}'", LoginResponsavel);

            List<int> list = new List<int>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(Convert.ToInt32(row["CelulaAcessada"]));

            return list;
        }
        public static List<ResponsavelCelula> BuscarAcessoCelula(int IdCelulaAcessada)
        {
            string sqlCommand;
            sqlCommand = string.Format(@"Select * From vw_CelulaAcesso Where CelulaAcessada = {0}",IdCelulaAcessada);

            List<ResponsavelCelula> list = new List<ResponsavelCelula>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new ResponsavelCelula(row));

            return list;
        }
        public static List<ResponsavelCelula> BuscarAcessoCelula(List<int> IdCelulasAcessadas)
        {
            string sqlCommand;
            sqlCommand = @"Select * From vw_CelulaAcesso Where CelulaAcessada in ({0})";

            string sqlCommandWhere = "";

            foreach (int cel in IdCelulasAcessadas)
            {
                if (sqlCommandWhere != "")
                {
                    sqlCommandWhere += ", ";
                }
                sqlCommandWhere += cel.ToString();
            }

            sqlCommand = string.Format(sqlCommand, sqlCommandWhere);

            List<ResponsavelCelula> list = new List<ResponsavelCelula>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new ResponsavelCelula(row));

            return list;
        }

        #region [ Cadastro de Responsáveis ]
        public static List<Responsavel> BuscarAnalistas()
        {
            string sqlCommand = @"SELECT * FROM tb_0100_Responsavel";
            List<Responsavel> list = new List<Responsavel>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new Responsavel(row));

            return list;
        }
        public static void SalvarAnalista(Responsavel obj)
        {
            string sqlCommand = string.Format("INSERT INTO tb_0100_Responsavel (NomeResponsavel, LoginResponsavel, FuncionalResponsavel, FLG_GESTOR) VALUES ('{0}', '{1}', '{2}', {3})", obj.NomeResponsavel, obj.LoginResponsavel, obj.FuncionalResponsavel, obj.FLG_Gestor);
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
        }
        public static void AtualizarAnalista(Responsavel obj)
        {
            string sqlCommand = string.Format("UPDATE tb_0100_Responsavel SET NomeResponsavel = '{0}', FuncionalResponsavel = '{1}', FLG_GESTOR = {2} WHERE LoginResponsavel = '{3}'", obj.NomeResponsavel, obj.FuncionalResponsavel, obj.FLG_Gestor, obj.LoginResponsavel);
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
        }
        
        public static void AtivarUsuario(int IdResponsavel, bool status)
        {
            string msgLog = "";
            if (status)
            {
                msgLog = "Ativar usuário ID: " + IdResponsavel + ".";
            }
            else
            {
                msgLog = "Inativar usuário ID: " + IdResponsavel + ".";
            }
            Log.GravaLog(msgLog);

            string sqlCommand = string.Format("Update tb_0100_Responsavel Set Ativo = {0} where ID_Responsavel = {1}", status.ToString(), IdResponsavel.ToString());
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
        }
        public static void AtivarUsuarioLote(List<int> IdResponsavel, bool status)
        {
            string sqlCommand = string.Format("Update tb_0100_Responsavel Set Ativo = {0} where ", status);

            string sqlCommandWhere = "";
            foreach (int IdServ in IdResponsavel)
            {
                if (sqlCommandWhere == "")
                {
                    sqlCommandWhere += ("Id_Responsavel = " + IdServ);
                }
                else
                {
                    sqlCommandWhere += " OR " + ("Id_Responsavel = " + IdServ);
                }
            }

            sqlCommand += sqlCommandWhere;

            string msgLog = sqlCommand;
            Log.GravaLog(msgLog);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

        }
        public static void AtivarUsuarioGestor(int IdResponsavel, bool gestor)
        {
            string msgLog = "";
            if (gestor)
            {
                msgLog = "Conceder acesso gestor ao usuário ID: " + IdResponsavel + ".";
            }
            else
            {
                msgLog = "Restirar acesso gestor ao usuário ID: " + IdResponsavel + ".";
            }

            Log.GravaLog(msgLog);

            string sqlCommand = string.Format("Update tb_0100_Responsavel Set FLG_Gestor = {0} where ID_Responsavel = {1}", gestor.ToString(), IdResponsavel.ToString());

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

        }
        public static void ExcluirUsuario(int IdResponsavel)
        {
            DataAccess.DeletarServico("tb_0100_Responsavel", "ID_Responsavel", IdResponsavel, "BDconsulta");
            DataAccess.DeletarServico("tb_0116_ResponsavelCelula", "ID_Responsavel", IdResponsavel, "BDconsulta");
        }
        public static void ExcluirUsuarioLote(List<int> IdResponsavel)
        {
            DataAccess.DeletarServicoLote("tb_0100_Responsavel", "ID_Responsavel", IdResponsavel, "BDconsulta");
            DataAccess.DeletarServicoLote("tb_0116_ResponsavelCelula", "ID_Responsavel", IdResponsavel, "BDconsulta");
        }
        public static void SalvaCelulaAnalista(int IdCelula, int IdResponsavel)
        {
            string sqlCommand = string.Format("INSERT INTO tb_0116_ResponsavelCelula (ID_Celula, ID_Responsavel) VALUES ({0}, {1})", IdCelula, IdResponsavel);
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
        }
        public static void SalvaCelulaAnalistaLote(List<int> IdCelula, int IdResponsavel)
        {
            string sqlCommandInsert = "INSERT INTO tb_0116_ResponsavelCelula ";
            sqlCommandInsert += "(ID_Celula, ID_Responsavel) ";
            sqlCommandInsert += "SELECT * FROM ({0}) ";

            int auxInsert = 0;
            string sqlCommandTemporary = "";
            foreach (int IdCel in IdCelula)
            {
                sqlCommandTemporary = sqlCommandTemporary + string.Format("SELECT {0} As ID_Celula, {1} As ID_Responsavel FROM tb_0080_AuxInsertDadosServico UNION ", IdCel, IdResponsavel);
                auxInsert = auxInsert + 1;
            }

            sqlCommandTemporary = sqlCommandTemporary.Remove(sqlCommandTemporary.Length - 6);

            sqlCommandInsert = string.Format(sqlCommandInsert, sqlCommandTemporary);

            if (auxInsert > 0)
            {
                DataConnector.ExecuteDataTable(sqlCommandInsert, "BDconsulta");
            }
        }
        public static void ExcluiCelulaAnalista(int IdCelula, int IdResponsavel)
        {
            string sqlCommand = string.Format("DELETE * FROM tb_0116_ResponsavelCelula WHERE ID_Celula = {0} AND ID_Responsavel = {1}", IdCelula, IdResponsavel);
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
        }
        public static void ExcluiCelulaAnalistaLote(List<int> IdCelula, int IdResponsavel)
        {
            if (IdCelula.Count > 0)
            {
                string sqlCommand = "DELETE * FROM tb_0116_ResponsavelCelula WHERE ";

                string sqlCommandWhere = "";
                foreach (int IdCel in IdCelula)
                {
                    if (sqlCommandWhere == "")
                    {
                        sqlCommandWhere += ("(ID_Celula = " + IdCel + " AND ID_Responsavel = " + IdResponsavel + ")");
                    }
                    else
                    {
                        sqlCommandWhere += " OR " + ("(ID_Celula = " + IdCel + " AND ID_Responsavel = " + IdResponsavel + ")");
                    }
                }

                sqlCommand += sqlCommandWhere;

                string msgLog = "ExcluiCelulaAnalistaLote: " + sqlCommand;
                Log.GravaLog(msgLog);

                DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            }
        }
        #endregion

        #region [ Área ]
        public static List<Area> buscarAreas(string NomeArea = "")
        {
            string sqlCommand;
            if (NomeArea != "")
            {
                sqlCommand = string.Format(@"SELECT * FROM tb_0112_Areas Where NomeArea = '{0}'", NomeArea);
            }
            else
            {
                sqlCommand = @"SELECT * FROM tb_0112_Areas";
            }
            List<Area> list = new List<Area>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new Area(row));

            return list;
        }
        public static void SalvarArea(string nome)
        {
            string sqlCommand = string.Format("INSERT INTO tb_0112_Areas (NomeArea) VALUES ('{0}')", nome);
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
        }
        public static void AtualizaArea(int Id, string nome)
        {
            string sqlCommand = string.Format("UPDATE tb_0112_Areas SET NomeArea = '{0}' WHERE id_area = {1}", nome, Id);
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
        }
        public static void AtivarArea(int IdResponsavel, bool status)
        {
            string msgLog = "";
            if (status)
            {
                msgLog = "Ativar usuário ID: " + IdResponsavel + ".";
            }
            else
            {
                msgLog = "Inativar usuário ID: " + IdResponsavel + ".";
            }

            Log.GravaLog(msgLog);

            string sqlCommand = string.Format("Update tb_0112_Areas Set AtivoArea = {0} where Id_Area = {1}", status.ToString(), IdResponsavel.ToString());

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

        }
        public static void AtivarAreaLote(List<int> IdResponsavel, bool status)
        {
            string sqlCommand = string.Format("Update tb_0112_Areas Set AtivoArea = {0} where ", status);

            string sqlCommandWhere = "";
            foreach (int IdServ in IdResponsavel)
            {
                if (sqlCommandWhere == "")
                {
                    sqlCommandWhere += ("Id_Area = " + IdServ);
                }
                else
                {
                    sqlCommandWhere += " OR " + ("Id_Area = " + IdServ);
                }
            }

            sqlCommand += "AtivarAreaLote: " + sqlCommandWhere;

            string msgLog = sqlCommand;
            Log.GravaLog(msgLog);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

        }
        public static void ExcluirArea(int IdArea)
        {
            DataAccess.DeletarServico("tb_0004_ObjetosAreas", "ID_Area", IdArea, "BDconsulta");
            DataAccess.DeletarServico("tb_0109_SegmentoAreas", "ID_Area", IdArea, "BDconsulta");
            DataAccess.DeletarServico("tb_0112_Areas", "ID_Area", IdArea, "BDconsulta");
        }
        public static void ExcluirAreaLote(List<int> IdArea)
        {
            DataAccess.DeletarServicoLote("tb_0004_ObjetosAreas", "ID_Area", IdArea, "BDconsulta");
            DataAccess.DeletarServicoLote("tb_0109_SegmentoAreas", "ID_Area", IdArea, "BDconsulta");
            DataAccess.DeletarServicoLote("tb_0112_Areas", "ID_Area", IdArea, "BDconsulta");
        }
        #endregion

        public static void Associar(string login, int idProduto)
        {
            string sqlCommand = string.Format("INSERT INTO ANALISTA_PRODUTO (ID_PRODUTO, LOGIN) VALUES ({0}, '{1}')", idProduto, login);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
        }
        public static List<Produto> BuscarProdutosAssociados(string login)
        {
            string sqlCommand = string.Format(@"SELECT * FROM VW_Produtos_associados WHERE Login = '{0}'", login);
            List<Produto> list = new List<Produto>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new Produto(row));

            return list;
        }
        public static void ApagarAssociacao(string id, string login)
        {
            string sqlCommand = string.Format("DELETE FROM ANALISTA_PRODUTO WHERE ID_PRODUTO = {0} AND LOGIN = '{1}'", id, login);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            string msgLog = "Apagar Associa~ção:" + sqlCommand;
            Log.GravaLog(msgLog);
        }
        #endregion

        #region[ Captura Boletos ]
        #region [ Parametros ]
        public static List<BoletaOQParametros> retornaParametrosOQ()
        {
            string sqlCommand = string.Format("SELECT * FROM vw_ParametrosOQ");

            List<BoletaOQParametros> list = new List<BoletaOQParametros>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDConsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new BoletaOQParametros(row));
            return list;
        }
        public static List<BoletaPNParametros> retornaParametrosPN()
        {
            string sqlCommand = string.Format("SELECT * FROM vw_ParametrosPN");

            List<BoletaPNParametros> list = new List<BoletaPNParametros>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDConsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new BoletaPNParametros(row));
            return list;
        }
        public static List<BoletaParametrosArquivosPlanilha> retornaParametrosArquivosPlanilha(int IdPlanilha)
        {
            string sqlCommand = string.Format("SELECT * FROM vw_ParametrosArquivosPlanilha WHERE ID_PLANILHA = {0}", IdPlanilha);

            List<BoletaParametrosArquivosPlanilha> list = new List<BoletaParametrosArquivosPlanilha>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDConsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new BoletaParametrosArquivosPlanilha(row));
            return list;
        }
        public static List<BoletaParametrosArquivosPDF> retornaParametrosArquivosPDF(int IdPDF)
        {
            string sqlCommand = string.Format("SELECT * FROM vw_ParametrosArquivosPDF WHERE ID_PDF = {0}", IdPDF);

            List<BoletaParametrosArquivosPDF> list = new List<BoletaParametrosArquivosPDF>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDConsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new BoletaParametrosArquivosPDF(row));
            return list;
        }
        #endregion

        #region [ BEN/BE ]
        public static void SaveBoleta(BoletaBEN obj)
        {
            string comandoSql = string.Format("DELETE FROM tb_0210_BoletoBen WHERE Id_Boleta = {0}", obj.Id_Boleta);
            DataConnector.ExecuteDataTable(comandoSql, "BDconsulta");

            comandoSql =
                string.Format("INSERT INTO tb_0210_BoletoBen (Id_Boleta, Boleto, Cod_Contrato, dt_Captura,dt_atualizacao,Id_Produto, nm_produto, nm_modalidade, nm_evento, xml_boleta) "
                + "VALUES ({0},'{1}','{2}','{3}','{4}',{5},'{6}','{7}','{8}','{9}') "
                , obj.Id_Boleta, obj.Boleto, obj.CodigoContrato, obj.DataCaptura, obj.DataAtualizacao, obj.Id_Produto, obj.Produto, obj.Modalidade, obj.Evento, obj.XML);

            DataConnector.ExecuteDataTable(comandoSql, "BDconsulta");

        }
        public static void SaveDado4131(Dados obj)
        {

            string comandoSql =
                string.Format("INSERT INTO tb_0210_BoletoBen_Dados (ID_SEQ, BOLETO, NM_CAMPO, NM_VALOR, ID_Campo) VALUES ({0},{1},'{2}','{3}', {4})", obj.IdSeq, obj.IdBoleto, obj.Campo, obj.Valor, obj.Id_Campo);

            DataConnector.ExecuteDataTable(comandoSql, "BDconsulta");
        }
        public static void SaveDadoLote(List<Dados> obj, string SistemaLog = "")
        {
            string sqlCommandInsert = "INSERT INTO tb_0210_BoletoBen_Dados (ID_SEQ, BOLETO, NM_CAMPO, NM_VALOR, ID_Campo) SELECT * FROM (";

            int auxInsert = 0;
            foreach (Dados d in obj)
            {
                sqlCommandInsert = String.Format(sqlCommandInsert + "SELECT {0} As ID_SEQ, {1} As BOLETO, '{2}' As NM_CAMPO, '{3}' As NM_VALOR, {4} As ID_Campo FROM tb_0080_AuxInsertDadosServico UNION ", d.IdSeq, d.IdBoleto, d.Campo, d.Valor, d.Id_Campo);
                auxInsert = auxInsert + 1;

                if (auxInsert == 30)
                {
                    sqlCommandInsert = sqlCommandInsert.Remove(sqlCommandInsert.Length - 6);
                    sqlCommandInsert = sqlCommandInsert + ")";

                    DataTable multirowinsert = DataConnector.ExecuteDataTable(sqlCommandInsert, "BDconsulta");

                    sqlCommandInsert = "INSERT INTO tb_0210_BoletoBen_Dados (ID_SEQ, BOLETO, NM_CAMPO, NM_VALOR, ID_Campo) SELECT * FROM (";

                    auxInsert = 0;
                }
            }

            sqlCommandInsert = sqlCommandInsert.Remove(sqlCommandInsert.Length - 6);
            sqlCommandInsert = sqlCommandInsert + ")";

            if (auxInsert > 0)
            {
                string msgLog = "Salvando dados BEN: " + sqlCommandInsert;
                Log.GravaLog(msgLog, SistemaLog);
                DataTable multirowinsert = DataConnector.ExecuteDataTable(sqlCommandInsert, "BDconsulta");
            }
        }
        public static void DeleteDado4131(long idBoleto)
        {
            string comandoSql =
                string.Format("DELETE FROM tb_0210_BoletoBen_Dados WHERE BOLETO = '{0}'", idBoleto.ToString());

            DataConnector.ExecuteDataTable(comandoSql, "BDconsulta");
        }
        #endregion

        #region [ Valida Serviço ]
        public static bool BoletoExiste(string boleto, string tabela)
        {
            string sqlCommand = "SELECT * FROM {0} Where Boleto = '{1}' ";
            sqlCommand = String.Format(sqlCommand, tabela, boleto);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            if (result.Rows.Count != 0)
                return true;
            else
                return false;
        }
        public static bool BoletoServicoRegistrado(string chave, string tabela, string campo, string BD)
        {
            string sqlCommand = "SELECT * FROM {0} Where {1} = '{2}' ";
            sqlCommand = String.Format(sqlCommand, tabela, campo, chave);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, BD);

            bool BoletoJaExiste = result.Rows.Count != 0;
            bool Recapturar = SharedData.gValidaBoleto;

            bool Capturar = false;

            if (BoletoJaExiste != true || Recapturar == true)
            {
                if (BoletoJaExiste == true)
                {
                    Loading.StaticFormVisible(false);
                    if (MessageBox.Show("Já há um serviço com nome " + chave + " cadastrado.\nDeseja abrir novo serviço?", "Serviço", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        Capturar = false;
                    }
                    else
                    {
                        Capturar = true;
                    }
                }
            }
            return Capturar;
        }
        public static void DeletaBoleto(string boleto, string tabela, string SistemaLog = "")
        {
            Log.GravaLog("Boleto " + boleto + " na tabela " + tabela + " sendo excluido!", SistemaLog);
            string sqlCommand = string.Format("DELETE FROM {0} WHERE Boleto = '{1}' ", tabela, boleto);
            DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
        }
        #endregion
        #endregion

        #region [ Operação ]
        #region [ Membros ]
        #region [ Serviço ]
        public static List<ResponsavelServico> BuscarServico(string textoProcura, int IdResponsavel)
        {
            string sqlCommand = SharedData.GetQueryDefinition("vw_BuscaOperacao");
            if (sqlCommand != "")
            {
                int IdServ =0;
                if (Int32.TryParse(textoProcura, out IdServ))
                {
                    sqlCommand = TratamentoSQL.AdicionaWhere(sqlCommand, "([tb_0125_Servico].ID_SERVICO = {0} OR [tb_0125_Servico].SERVICONAME Like '%{0}%') AND [tb_0100_Responsavel].ID_Responsavel = {1}");
                }
                else
                {
                    sqlCommand = TratamentoSQL.AdicionaWhere(sqlCommand, "[tb_0125_Servico].SERVICONAME Like '%{0}%' AND [tb_0100_Responsavel].ID_Responsavel = {1}");
                }
                sqlCommand = String.Format(sqlCommand, textoProcura, IdResponsavel);
            }

            //string sqlCommand = "SELECT * FROM vw_BuscaOperacao Where SERVICONAME Like '%{0}%' AND ID_Responsavel = {1}";
            //sqlCommand = String.Format(sqlCommand, textoProcura, IdResponsavel);

            List<ResponsavelServico> lsv = new List<ResponsavelServico>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                lsv.Add(new ResponsavelServico(row));

            return lsv;
        }
        public static ResponsavelServico BuscarServicoResponsavel(int ID_Servico, int ID_Responsavel)
        {
            string sqlCommand = "SELECT * FROM tb_0125_Servico Where {0} = {1} And {2} = {3}";
            sqlCommand = String.Format(sqlCommand, "ID_SERVICO", "" + ID_Servico + "", "ID_RESPONSAVEL", "" + ID_Responsavel + "");

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            if (result.Rows.Count != 0)
                return new ResponsavelServico(result.Rows[0]);
            else
                return null;
        }
        public static List<ResponsavelServico> BuscarServicoResponsavel()
        {
            string sqlCommand = "SELECT * FROM tb_0125_Servico";

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            List<ResponsavelServico> lsv = new List<ResponsavelServico>();

            foreach (DataRow row in result.Rows)
                lsv.Add(new ResponsavelServico(row));

            return lsv;
        }
        public static List<ResponsavelServico> BuscarTodosServicos()
        {
            string sqlCommand = "SELECT * FROM tb_0125_Servico";

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            List<ResponsavelServico> lsv = new List<ResponsavelServico>();

            foreach (DataRow row in result.Rows)
                lsv.Add(new ResponsavelServico(row));

            return lsv;
        }
        public static bool BuscarCancelado(int ID_servico)
        {
            string sqlCommand = @"SELECT Cancelado FROM tb_0125_Servico where ID_Servico={0}";

            DataTable result = DataConnector.ExecuteDataTable(string.Format(sqlCommand, ID_servico), "BDconsulta");
            return Convert.ToBoolean(result.Rows[0]["Cancelado"]);
        }
        #endregion

        #region [ Objeto ]
        public static List<Objeto> BuscarProdutos()
        {
            string sqlCommand = @"SELECT * FROM tb_0001_Objetos";
            List<Objeto> list = new List<Objeto>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new Objeto(row));

            return list;
        }
        public static void SalvarProduto(Objeto obj)
        {
            string sqlCommand = string.Format("INSERT INTO tb_0001_Objetos (NomeObjeto, CategoriaObjeto, AtivoObjeto) VALUES ('{0}','{1}',{2})", obj.NomeObjeto, obj.CategoriaObjeto, obj.AtivoObjeto);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
        }
        public static void ApagarProduto(int id)
        {
            string sqlCommand = string.Format("DELETE FROM tb_0001_Objetos WHERE ID_OBJETO = {0}", id);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            string msgLog = sqlCommand + " Usuário Responsável: " + Environment.UserName.ToUpper();
            Log.GravaLog(msgLog);
        }
        public static int BuscarIdObjeto(int IdServico)
        {
            string sqlCommand = string.Format("SELECT Id_Objeto FROM tb_0125_Servico WHERE Id_Servico = {0}", IdServico);
            int IdObj;

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            IdObj = Convert.ToInt32(result.Rows[0][0]);

            return IdObj;
        }
        public static List<Objeto> buscarProdObjAreaResponsavel(int Id_Responsavel, bool Todos = false)
        {
            //string sqlCommand = @"SELECT * FROM vw_ObjetosAreaResponsavel Where ID_Responsavel = {0}";
            //sqlCommand = String.Format(sqlCommand, Id_Responsavel);

            string sqlCommand = SharedData.GetQueryDefinition("vw_ObjetosAreaResponsavel");
            if (sqlCommand != "")
            {
                sqlCommand = TratamentoSQL.AdicionaWhere(sqlCommand, "[tb_0100_Responsavel].ID_Responsavel = " + Id_Responsavel);
            }

            List<Objeto> list = new List<Objeto>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            if (Todos == true)
            {
                Objeto _objTodos = new Objeto();
                _objTodos.ID_Objeto = 0;
                _objTodos.NomeObjeto = "Todos";
                _objTodos.DescricaoObjeto = "Todos";
                _objTodos.CategoriaObjeto = "Todos";
                _objTodos.AtivoObjeto = true;
                _objTodos.IdSegmento = 0;
                list.Add(_objTodos);
            }
            else
            {
                Objeto _objTodos = new Objeto();
                _objTodos.ID_Objeto = 0;
                _objTodos.NomeObjeto = "";
                _objTodos.DescricaoObjeto = "";
                _objTodos.CategoriaObjeto = "";
                _objTodos.AtivoObjeto = true;
                _objTodos.IdSegmento = 0;
                list.Add(_objTodos);
            }


            foreach (DataRow row in result.Rows)
                list.Add(new Objeto(row));

            return list;
        }
        #endregion

        #region [ Etapas ]
        #region [Etapas Status]
        public static FluxoServico BuscarStatusFluxoServico(int IdServico, int IdEtapa)
        {
            string sqlCommand = "";
            sqlCommand = string.Format("SELECT * FROM vw_ServicoFluxos WHERE ID_Servico = {0} And ID_Fluxo = {1}", IdServico, IdEtapa);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            if (result.Rows.Count != 0)
                return new FluxoServico(result.Rows[0]);
            else
                return null;
        }
        public static List<Status> BuscarStatus(int IdObjeto, int IdEtapa = 0)
        {
            string sqlCommand = SharedData.GetQueryDefinition("vw_StatusEtapas");
            if (sqlCommand != "")
            {
                if (IdEtapa != 0)
                {
                    //sqlCommand = string.Format("SELECT * FROM vw_StatusEtapas WHERE ID_Etapa = {0} AND ID_Objeto = {1} Order By OrdemStatus", IdEtapa, IdObjeto);
                    sqlCommand = TratamentoSQL.AdicionaWhere(sqlCommand, "[tb_0008_Etapas].ID_Etapa = " + IdEtapa + " AND [tb_0119_StatusEtapas].ID_Objeto = " + IdObjeto);
                }
                else
                {
                    //sqlCommand = string.Format("SELECT * FROM vw_StatusEtapas WHERE ID_Objeto = {0} Order By OrdemStatus", IdObjeto);
                    sqlCommand = TratamentoSQL.AdicionaWhere(sqlCommand, "[tb_0119_StatusEtapas].ID_Objeto = " + IdObjeto);
                }
            }


            List<Status> list = new List<Status>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new Status(row));

            return list;
        }
        public static List<Status> BuscarStatus()
        {
            string sqlCommand = SharedData.GetQueryDefinition("vw_StatusEtapas");

            List<Status> list = new List<Status>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new Status(row));

            return list;
        }
        public static void AtualizaStatusEtapa(int ID_Servico, bool ConcluidoEtapa, int ID_Status, int ID_Etapa, string SistemaLog = "", string datahora = "")
        {
            DateTime d = DateTime.Now;

            DateTime t;
            CultureInfo c = TratamentoLinguagem.BuscarLinguagem("pt-BR");
            if (DateTime.TryParse(datahora, c, DateTimeStyles.None, out t))
                d = t;
            
            StringBuilder sb_LogServico = new StringBuilder();

            datahora = d.ToString("yyyy/MM/dd HH:mm:ss");

            string sqlCommand;
            if (ConcluidoEtapa == false)
            {
                sqlCommand = string.Format("Update tb_0127_FluxoServico Set ConcluidoFluxo = {0}, ID_Status = {1}, DataAlteracao = #{2}#, DataConclusao = null, UserAlteracao = '{3}'  Where ID_Servico = {4} And ID_Fluxo = {5} ", ConcluidoEtapa, ID_Status, datahora, Environment.UserName.ToUpper(), ID_Servico, ID_Etapa);
            }
            else
            {
                sqlCommand = string.Format("Update tb_0127_FluxoServico Set ConcluidoFluxo = {0}, ID_Status = {1}, DataAlteracao = #{2}#, DataConclusao = #{2}#, UserAlteracao = '{3}'  Where ID_Servico = {4} And ID_Fluxo = {5} ", ConcluidoEtapa, ID_Status, datahora, Environment.UserName.ToUpper(), ID_Servico, ID_Etapa);
            }
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            sb_LogServico.AppendLine(Log.MontaLogServico("Etapa Status", ID_Servico, ID_Etapa, 0, ID_Status.ToString(), "", datahora, "Update"));

            DataAccess.GravarIndicadorStatus(ID_Servico, ID_Etapa, ID_Status, Convert.ToDateTime(datahora), SistemaLog);

            if (sb_LogServico.ToString() != "")
                Log.GravaLogServico(sb_LogServico.ToString(), ID_Servico);
        }
        public static void AtualizaEtapa(int ID_Servico, bool ConcluidoEtapa, int ID_Status, int ID_Etapa, int ID_Resp)
        {
            StringBuilder sb_LogServico = new StringBuilder();

            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

            string sqlCommand;
            if (ConcluidoEtapa == false)
            {
                sqlCommand = string.Format("Update tb_0127_FluxoServico Set ConcluidoFluxo = {0}, ID_Status = {1}, Id_Responsavel = {4} Where ID_Servico = {2} And ID_Fluxo = {3} ", ConcluidoEtapa, ID_Status, ID_Servico, ID_Etapa, ID_Resp);
            }
            else
            {
                sqlCommand = string.Format("Update tb_0127_FluxoServico Set ConcluidoFluxo = {0}, ID_Status = {1}, DataConclusao = #{2}#, Id_Responsavel = {5}  Where ID_Servico = {3} And ID_Fluxo = {4} ", ConcluidoEtapa, ID_Status, datahora, ID_Servico, ID_Etapa, ID_Resp);
            }
            sb_LogServico.AppendLine(Log.MontaLogServico("Etapa Status", ID_Servico, ID_Etapa, 0, ID_Status.ToString(), "", datahora, "Update"));
            sb_LogServico.AppendLine(Log.MontaLogServico("Etapa Responsável", ID_Servico, ID_Etapa, 0, ID_Resp.ToString(), "", datahora, "Update"));
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            if (sb_LogServico.ToString() != "")
                Log.GravaLogServico(sb_LogServico.ToString(), ID_Servico);
        }
        public static void AtualizaStatusEtapaLote (int ID_Servico, List<FluxoServico> DadosFluxo, string SistemaLog = "")
        {
            StringBuilder sb_LogServico = new StringBuilder();

            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            string sqlCommandUpdate = "Update tb_0127_FluxoServico Set DataAlteracaoStatus = #{0}#, DataAlteracao = #{0}#, UserAlteracao = '{1}', ID_Status = {2}, DataConclusao = {3}, ConcluidoFluxo = {4} ";
            string sqlCommandWhereUpdate = "WHERE ID_Fluxo IN({0}) AND ID_SERVICO=" + ID_Servico;

            string sqlCommand = "";
            string sqlCommandWhere = "";

            int auxUpdate = 0;
            string sqlCommandStatus = "";
            string sqlCommandDataConclusao = "";
            string sqlCommandConcluido = "";
            string sqlCommandWhereFluxos = "";
            foreach (FluxoServico fluxo in DadosFluxo)
            {
                sb_LogServico.AppendLine(Log.MontaLogServico("Etapa Status", ID_Servico, fluxo.ID_Fluxo, 0, fluxo.ID_Status.ToString(), "", datahora, "Update"));

                sqlCommandStatus += string.Format("IIf(ID_Fluxo={0},{1},", fluxo.ID_Fluxo, fluxo.ID_Status);
                if(fluxo.StatusFecha)
                {
                    sqlCommandDataConclusao += string.Format("IIf(ID_Fluxo={0},#{1}#,", fluxo.ID_Fluxo, datahora);
                    sqlCommandConcluido += string.Format("IIf(ID_Fluxo={0},{1},", fluxo.ID_Fluxo, fluxo.StatusFecha);
                }
                else
                {
                    sqlCommandDataConclusao += string.Format("IIf(ID_Fluxo={0},{1},", fluxo.ID_Fluxo, "null");
                    sqlCommandConcluido += string.Format("IIf(ID_Fluxo={0},{1},", fluxo.ID_Fluxo, fluxo.StatusFecha);
                }

                if (sqlCommandWhereFluxos != "")
                {
                    sqlCommandWhereFluxos += ", ";
                }
                sqlCommandWhereFluxos += fluxo.ID_Fluxo.ToString();

                auxUpdate = auxUpdate + 1;

                if (auxUpdate == 10)
                {
                    sqlCommandStatus += "[ID_Status]" + ("").PadLeft(auxUpdate, ')');
                    sqlCommandDataConclusao += "[DataConclusao]" + ("").PadLeft(auxUpdate, ')');
                    sqlCommandConcluido += "[ConcluidoFluxo]" + ("").PadLeft(auxUpdate, ')');

                    sqlCommandWhere = string.Format(sqlCommandWhereUpdate, sqlCommandWhereFluxos);

                    sqlCommand = string.Format(sqlCommandUpdate, datahora, Environment.UserName.ToUpper(), sqlCommandStatus, sqlCommandDataConclusao, sqlCommandConcluido);
                    sqlCommand = sqlCommand + sqlCommandWhere;

                    DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

                    sqlCommandStatus = "";
                    sqlCommandDataConclusao = "";
                    sqlCommandConcluido = "";
                    sqlCommandWhereFluxos = "";
                    auxUpdate = 0;
                }
            }

            sqlCommandStatus += "[ID_Status]" + ("").PadLeft(auxUpdate, ')');
            sqlCommandDataConclusao += "[DataConclusao]" + ("").PadLeft(auxUpdate, ')');
            sqlCommandConcluido += "[ConcluidoFluxo]" + ("").PadLeft(auxUpdate, ')');

            sqlCommandWhere = string.Format(sqlCommandWhereUpdate, sqlCommandWhereFluxos);

            sqlCommand = string.Format(sqlCommandUpdate, datahora, Environment.UserName.ToUpper(), sqlCommandStatus, sqlCommandDataConclusao, sqlCommandConcluido);
            sqlCommand = sqlCommand + sqlCommandWhere;

            if (auxUpdate > 0)
            {
                DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            }

            if (DadosFluxo.Count() > 0)
                DataAccess.GravarIndicadorStatusLote(ID_Servico, DadosFluxo, Convert.ToDateTime(datahora), SistemaLog);

            if (sb_LogServico.ToString() != "")
                Log.GravaLogServico(sb_LogServico.ToString(), ID_Servico);
        }
        #endregion

        #region [Etapas Objeto]
        public static List<EtapasObjeto> BuscarEtapasObjeto(int idObjeto, int idEtapa = 0)
        {
            string sqlCommand = SharedData.GetQueryDefinition("vw_ObjetosEtapas");

            if (sqlCommand != "")
            {
                if (idEtapa == 0)
                {
                    //sqlCommand = String.Format("SELECT * FROM vw_ObjetosEtapas Where ID_Objeto = {0} Order By OrdemEtapa", idObjeto);
                    sqlCommand = TratamentoSQL.AdicionaWhere(sqlCommand, "[tb_0001_Objetos].ID_Objeto = " + idObjeto);
                }
                else
                {
                    //sqlCommand = String.Format("SELECT * FROM vw_ObjetosEtapas Where ID_Objeto = {0} And ID_Etapa = {1} Order By OrdemEtapa", idObjeto, idEtapa);
                    sqlCommand = TratamentoSQL.AdicionaWhere(sqlCommand, "[tb_0001_Objetos].ID_Objeto = " + idObjeto + " And [tb_0008_Etapas].ID_Etapa = " + idEtapa);
                }
            }

            List<EtapasObjeto> list = new List<EtapasObjeto>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new EtapasObjeto(row));

            return list;
        }
        public static List<EtapasObjeto> BuscarEtapasObjeto()
        {
            string sqlCommand = SharedData.GetQueryDefinition("vw_ObjetosEtapas");

            List<EtapasObjeto> list = new List<EtapasObjeto>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new EtapasObjeto(row));

            return list;
        }
        public static List<EtapasObjeto> BuscarEtapasObjetoServico()
        {
            string sqlCommand = "";
                sqlCommand = String.Format("SELECT * FROM vw_ObjetosEtapasServicos Order By OrdemEtapa");

            List<EtapasObjeto> list = new List<EtapasObjeto>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new EtapasObjeto(row));
            
            return list;
        }
        

        public static bool ExisteEtapaServico(int idServico, int idEtapa)
        {
            string sqlCommand = String.Format("SELECT * FROM tb_0127_FluxoServico Where ID_SERVICO = {0} AND ID_Fluxo = {1}", idServico, idEtapa);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            if (result.Rows.Count != 0)
                return true;
            else
                return false;
        }
        #endregion

        #region [ Fluxo Serviço]
        public static string[] BuscaResponsavelFluxo(int IdServico, int IdEtapa)
        {
            string sqlCommand = "";

            sqlCommand += "SELECT tb_0127_FluxoServico.Id_Responsavel, tb_0100_Responsavel.NomeResponsavel ";
            sqlCommand += "FROM tb_0127_FluxoServico INNER JOIN tb_0100_Responsavel ON tb_0127_FluxoServico.Id_Responsavel = tb_0100_Responsavel.ID_Responsavel ";
            sqlCommand += "WHERE tb_0127_FluxoServico.Id_fluxo={0} AND tb_0127_FluxoServico.ID_Servico={1}";

            sqlCommand = String.Format(sqlCommand, IdEtapa, IdServico);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            string[] IdResponsavel = new string[2];

            if (result.Rows.Count > 0)
            {
                IdResponsavel = (result.Rows[0][0].ToString() + ";" + result.Rows[0][1].ToString()).Split(';');
            }
            else
            {
                IdResponsavel = (";").Split(';');
            }

            return IdResponsavel;
        }
        public static List<FluxoValidaResponsavel> BuscaResponsavelValidaFluxo()
        {
            string sqlCommand = "";

            sqlCommand = "Select * from vw_EtapaResponsavelDiferenteFluxo";

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            List<FluxoValidaResponsavel> list = new List<FluxoValidaResponsavel>();

            foreach (DataRow row in result.Rows)
                list.Add(new FluxoValidaResponsavel(row));

            return list;
        }
        public static List<FluxoServico> BuscarFluxoServico(int IdServico)
        {
            //string sqlCommand = "SELECT * FROM vw_ServicoFluxos Where ID_SERVICO = {0}";
            //sqlCommand = String.Format(sqlCommand, IdServico);

            string sqlCommand = SharedData.GetQueryDefinition("vw_ServicoFluxos");
            if (sqlCommand != "")
            {
                sqlCommand = TratamentoSQL.AdicionaWhere(sqlCommand, "[tb_0125_Servico].Id_Servico = " + IdServico);
            }

            List<FluxoServico> list = new List<FluxoServico>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new FluxoServico(row));

            return list;
        }
        public static List<FluxoServico> BuscarFluxoServico()
        {
            string sqlCommand = "SELECT * FROM vw_ServicoFluxos";
            sqlCommand = String.Format(sqlCommand);

            List<FluxoServico> list = new List<FluxoServico>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new FluxoServico(row));

            return list;
        }
        public static List<FluxoServico> BuscarFluxoServicoValidaResponsavel(int IdServico, int IdResponsavel)
        {
//            string sqlCommand = string.Format(@"SELECT tbl1.*, tbl2.ValidaDependente
//                                            FROM (SELECT * FROM vw_ServicoFluxos Where ID_SERVICO = {0}) AS tbl1
//                                            LEFT JOIN (Select * from  vw_EtapaResponsavelDiferente where Id_Servico = {0} And Id_Responsavel = {1}) AS tbl2 
//                                            ON (tbl1.ID_Fluxo = tbl2.ID_Etapa) 
//                                            AND (tbl1.ID_Servico = tbl2.ID_Servico)
//                                            AND (tbl1.IdResponsavelFluxo <> tbl2.Id_Responsavel)", IdServico, IdResponsavel);

            string sqlCommand = "";

            string tbl1 = SharedData.GetQueryDefinition("vw_ServicoFluxos");
            if (tbl1 != "")
            {
                tbl1 = TratamentoSQL.AdicionaWhere(tbl1, "[tb_0125_Servico].Id_Servico = " + IdServico);
            }

            string tbl2 = SharedData.GetQueryDefinition("vw_EtapaResponsavelDiferente");
            if (tbl2 != "")
            {
                tbl2 = TratamentoSQL.AdicionaWhere(tbl2, "[tb_0127_FluxoServico].Id_Servico = " + IdServico + " And [tb_0127_FluxoServico].Id_Responsavel = " + IdResponsavel);
            }


            sqlCommand = string.Format(@"SELECT tbl1.*, tbl2.ValidaDependente
                                            FROM ({0}) AS tbl1
                                            LEFT JOIN ({1}) AS tbl2 
                                            ON (tbl1.ID_Fluxo = tbl2.ID_Etapa) 
                                            AND (tbl1.ID_Servico = tbl2.ID_Servico)
                                            AND (tbl1.IdResponsavelFluxo <> tbl2.Id_Responsavel)", tbl1, tbl2);

            List<FluxoServico> list = new List<FluxoServico>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new FluxoServico(row));

            return list;
        }
        public static void RegistrarFluxoServico(EtapasObjeto etpReg, string SistemaLog = "")
        {
            StringBuilder sb_LogServico = new StringBuilder();
            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            string sqlCommand = String.Format("INSERT INTO tb_0127_FluxoServico (ID_Servico, ID_Fluxo, ID_Status, DataAlteracaoStatus, DataCriacao, DataAlteracao, Id_Responsavel, UserCriacao, UserAlteracao) "
                                              + " VALUES ({0}, {1}, {2}, #{3}#, #{3}#, #{3}#,{4}, '{5}', '{5}')"
                                              , etpReg.ID_Servico, etpReg.ID_Etapa, etpReg.ID_Status, datahora, etpReg.IdResponsavel, Environment.UserName.ToUpper());

            string msgLog = "Criando Fluxos: " + sqlCommand;
            Log.GravaLog(msgLog, SistemaLog);
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            if (!etpReg.StatusNaoInicia)
            {
                DataAccess.GravarIndicadorStatus(etpReg.ID_Servico, etpReg.ID_Etapa, etpReg.ID_Status, Convert.ToDateTime(datahora), SistemaLog);
            }

            sb_LogServico.AppendLine(Log.MontaLogServico("Etapa Status", etpReg.ID_Servico, etpReg.ID_Etapa, 0, etpReg.ID_Status.ToString(), SistemaLog, datahora, "Insert"));
            sb_LogServico.AppendLine(Log.MontaLogServico("Etapa Responsável", etpReg.ID_Servico, etpReg.ID_Etapa, 0, etpReg.IdResponsavel.ToString(), SistemaLog, datahora, "Insert"));
            Log.GravaLogServico(sb_LogServico.ToString(), etpReg.ID_Servico);
        }
        public static void RegistrarFluxoServicoLote(List<EtapasObjeto> etpReg, string SistemaLog = "")
        {
            StringBuilder sb_LogServico = new StringBuilder();
            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            string sqlCommandInsert = "INSERT INTO tb_0127_FluxoServico (ID_Servico, ID_Fluxo, ID_Status, DataAlteracaoStatus, DataCriacao, DataAlteracao, Id_Responsavel, UserCriacao, UserAlteracao) SELECT * FROM (";

            List<FluxoServico> FluxosStatusAlterados = new List<FluxoServico>();
            int auxInsert = 0;
            foreach (EtapasObjeto etp in etpReg)
            {
                sb_LogServico.AppendLine(Log.MontaLogServico("Etapa Status", etp.ID_Servico, etp.ID_Etapa, 0, etp.ID_Status.ToString(), SistemaLog, datahora, "Insert"));
                sb_LogServico.AppendLine(Log.MontaLogServico("Etapa Responsável", etp.ID_Servico, etp.ID_Etapa, 0, etp.IdResponsavel.ToString(), SistemaLog, datahora, "Insert"));

                sqlCommandInsert = String.Format(sqlCommandInsert + "SELECT {0} As ID_Servico, {1} As ID_Fluxo, {2} As ID_Status, #{3}# As DataAlteracaoStatus, #{3}# As DataCriacao, #{3}# As DataAlteracao ,{4} as Id_Responsavel, '{5}' As UserCriacao, '{5}' As UserAlteracao FROM tb_0080_AuxInsertDadosServico UNION ", etp.ID_Servico, etp.ID_Etapa, etp.ID_Status, datahora, etp.IdResponsavel, Environment.UserName.ToUpper());
                auxInsert = auxInsert + 1;

                if (!etp.StatusNaoInicia)
                {
                    FluxoServico FluxoStatusAlterado = new FluxoServico();
                    FluxoStatusAlterado.ID_Servico = etp.ID_Servico;
                    FluxoStatusAlterado.ID_Fluxo = etp.ID_Etapa;
                    FluxoStatusAlterado.ID_Status = etp.ID_Status;
                    FluxosStatusAlterados.Add(FluxoStatusAlterado);
                }
            }

            sqlCommandInsert = sqlCommandInsert.Remove(sqlCommandInsert.Length - 6);
            sqlCommandInsert = sqlCommandInsert + ")";

            if (auxInsert > 0)
            {
                string msgLog = "Criando Fluxos: " + sqlCommandInsert;
                Log.GravaLog(msgLog, SistemaLog);
                DataTable multirowinsert = DataConnector.ExecuteDataTable(sqlCommandInsert, "BDconsulta");
            }

            if (FluxosStatusAlterados.Count > 0)
            {
                DataAccess.GravarIndicadorStatusLote(FluxosStatusAlterados[0].ID_Servico, FluxosStatusAlterados, Convert.ToDateTime(datahora), SistemaLog);
            }

            if (sb_LogServico.ToString() != "")
                Log.GravaLogServico(sb_LogServico.ToString(), etpReg[0].ID_Servico);
        }
        public static void AtribuirResponsavelFluxo(int IdServico, int IdEtapa, int IdResponsavel)
        {
            StringBuilder sb_LogServico = new StringBuilder();
            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            string sqlCommand = String.Format("UPDATE tb_0127_FluxoServico SET tb_0127_FluxoServico.Id_Responsavel = {0}, DataAlteracao = #{1}#, UserAlteracao = '{2}' WHERE tb_0127_FluxoServico.ID_Fluxo={3} AND tb_0127_FluxoServico.ID_Servico={4}", IdResponsavel, datahora, Environment.UserName.ToUpper(), IdEtapa, IdServico);
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            sb_LogServico.AppendLine(Log.MontaLogServico("Etapa Responsável", IdServico, IdEtapa, 0, IdResponsavel.ToString(), "", datahora, "Update"));
            Log.GravaLogServico(sb_LogServico.ToString(), IdServico);

        }
        public static void AtribuirResponsavelFluxoLote(List<FluxoServico> Fluxo)
        {
            StringBuilder sb_LogServico = new StringBuilder();
            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

            string sqlCommandUpdate = @"Update tb_0127_FluxoServico Set DataAlteracao = #{0}#, UserAlteracao = '{1}', Id_Responsavel = {2} ";
            string sqlCommandWhereUpdate = @"WHERE ID_Fluxo IN({0}) AND ID_SERVICO IN({1})";

            string sqlCommand = "";
            string sqlCommandWhere = "";

            int auxUpdate = 0;
            string sqlCommandResponsavel = "";
            string sqlCommandWhereFluxos = "";
            string sqlCommandWhereServico = "";
            foreach (FluxoServico fluxo in Fluxo)
            {
                sb_LogServico.AppendLine(Log.MontaLogServico("Etapa Responsável", fluxo.ID_Servico, fluxo.ID_Fluxo, 0, fluxo.IdResponsavel.ToString(), "", datahora, "Update"));

                sqlCommandResponsavel += string.Format("IIf(ID_Fluxo={0} And ID_Servico={1}, {2},", fluxo.ID_Fluxo, fluxo.ID_Servico, fluxo.IdResponsavel);

                if (sqlCommandWhereFluxos != "")
                {
                    sqlCommandWhereFluxos += ", ";
                }
                sqlCommandWhereFluxos += fluxo.ID_Fluxo.ToString();

                if (sqlCommandWhereServico != "")
                {
                    sqlCommandWhereServico += ", ";
                }
                sqlCommandWhereServico += fluxo.ID_Servico.ToString();

                auxUpdate = auxUpdate + 1;

                if (auxUpdate == 10)
                {
                    sqlCommandResponsavel += "[Id_Responsavel]" + ("").PadLeft(auxUpdate, ')');

                    sqlCommandWhere = string.Format(sqlCommandWhereUpdate, sqlCommandWhereFluxos, sqlCommandWhereServico);

                    sqlCommand = string.Format(sqlCommandUpdate, datahora, Environment.UserName.ToUpper(), sqlCommandResponsavel);
                    sqlCommand = sqlCommand + sqlCommandWhere;

                    DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
                    
                    sqlCommandResponsavel = "";
                    sqlCommandWhereFluxos = "";
                    sqlCommandWhereServico = "";
                    auxUpdate = 0;

                }
                if (sb_LogServico.ToString() != "")
                    Log.GravaLogServico(sb_LogServico.ToString(), fluxo.ID_Servico);

                sb_LogServico.Clear();
            }
            sqlCommandResponsavel += "[Id_Responsavel]" + ("").PadLeft(auxUpdate, ')');

            sqlCommandWhere = string.Format(sqlCommandWhereUpdate, sqlCommandWhereFluxos, sqlCommandWhereServico);

            sqlCommand = string.Format(sqlCommandUpdate, datahora, Environment.UserName.ToUpper(), sqlCommandResponsavel);
            sqlCommand = sqlCommand + sqlCommandWhere;
            if (auxUpdate > 0)
            {
                DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            }
            
        }
        #endregion
        #endregion

        #region [ Campos ]
        #region [ Buscar ]
        public static bool BuscarCampoObjeto(int IdServico, int IdCampo)
        {
            string sqlCommand = string.Format("SELECT * FROM tb_0126_DadosServico Where ID_Servico = {0} AND Id_Campo = {1}", IdServico, IdCampo);
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            if (result.Rows.Count != 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        public static string BuscarCampoObjetoValor(int IdServico, int IdCampo)
        {
            string sqlCommand = string.Format("SELECT * FROM tb_0126_DadosServico Where ID_Servico = {0} AND Id_Campo = {1}", IdServico, IdCampo);
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            if (result.Rows.Count != 0)
            {
                return result.Rows[0]["ValorCampo"].ToString();
            }
            else
            {
                return "";
            }
        }
        public static List<CamposInfo> BuscarInfoCampo(string Id_Campo)
        {
            string sqlCommand = "SELECT Distinct * FROM tb_0003_Campos Where ID_Campo = {0} ";
            sqlCommand = String.Format(sqlCommand, Convert.ToInt32(Id_Campo));

            List<CamposInfo> list = new List<CamposInfo>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new CamposInfo(row));

            return list;
        }
        public static List<CamposInfo> BuscarInfoCampoByTipo(string TipoCampo)
        {
            string sqlCommand = "SELECT Distinct * FROM tb_0003_Campos Where CampoTipo = '{0}' ";
            sqlCommand = String.Format(sqlCommand, TipoCampo);

            List<CamposInfo> list = new List<CamposInfo>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new CamposInfo(row));

            return list;
        }
        
        public static List<DadosCampos> BuscarDadosCampos(int idServico)
        {
            string sqlCommand = string.Format("SELECT NomeCampo, ValorCampo, Id_Campo FROM tb_0126_DadosServico WHERE ID_Servico = {0}", idServico);
            List<DadosCampos> listaValores = new List<DadosCampos>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                listaValores.Add(new DadosCampos(row));

            return listaValores;
        }
        public static List<DadosCamposTabela> BuscarDadosCamposTabela(int idServico, bool TabelaGeral)
        {
            string sqlCommand = string.Format("SELECT NomeCampo, ValorCampo, IdCampo, Linha, IdServico FROM tb_0134_DadosTabela WHERE IdServico = {0}", idServico);
            if (TabelaGeral)
                sqlCommand += " OR IdServico IS NULL";

            List<DadosCamposTabela> listaValores = new List<DadosCamposTabela>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                listaValores.Add(new DadosCamposTabela(row));

            return listaValores;
        }
        public static List<DadosCampos> BuscarDadosCamposEtapas(int idFluxo, int idservico)
        {
            string sqlCommand = string.Format("SELECT NomeCampo, ValorCampo, Id_Campo FROM tb_0126_DadosServico WHERE ID_Fluxo = {0} And ID_Servico = {1}", idFluxo, idservico);
            List<DadosCampos> listaValores = new List<DadosCampos>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                listaValores.Add(new DadosCampos(row));

            return listaValores;
        }

        public static List<Campos> buscarCamposDinamicos(int ID_Objeto)
        {
            string sqlCommand = SharedData.GetQueryDefinition("vw_ObjetosCampos");
            if (sqlCommand != "")
            {

                sqlCommand = TratamentoSQL.AdicionaWhere(sqlCommand, "[tb_0001_Objetos].ID_Objeto = " + ID_Objeto);
            }

            //string sqlCommand = string.Format("SELECT * FROM vw_ObjetosCampos Where ID_Objeto = {0} Order By OrdemTab, CampoLinha, CampoColuna", ID_Objeto);
            List<Campos> list = new List<Campos>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new Campos(row));

            return list;
        }
        public static List<Campos> buscarCamposDinamicos()
        {
            string sqlCommand = SharedData.GetQueryDefinition("vw_ObjetosCampos");

            //string sqlCommand = string.Format("SELECT * FROM vw_ObjetosCampos Where ID_Objeto = {0} Order By OrdemTab, CampoLinha, CampoColuna", ID_Objeto);
            List<Campos> list = new List<Campos>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new Campos(row));

            return list;
        }
        public static List<Campos> buscarCamposDinamicosMinuta()
        {
            string sqlCommand = SharedData.GetQueryDefinition("vw_ObjetosCamposMinuta");
            if (sqlCommand != "")
            {
                sqlCommand = TratamentoSQL.AdicionaWhere(sqlCommand, "[tb_0006_CamposObjetosMinuta].IdMetodo = 0");
            }
            
            List<Campos> list = new List<Campos>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new Campos(row));

            return list;
        }
        public static List<Campos> buscarCamposDinamicos(int ID_Objeto, int IdMetodo)
        {

            string sqlCommand = SharedData.GetQueryDefinition("vw_ObjetosCamposMinuta");
            if (sqlCommand != "")
            {
                sqlCommand = TratamentoSQL.AdicionaWhere(sqlCommand, "[tb_0001_Objetos].ID_Objeto = " + ID_Objeto + " AND [tb_0006_CamposObjetosMinuta].IdMetodo = " + IdMetodo);
            }

            List<Campos> list = new List<Campos>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new Campos(row));

            return list;
        }
        public static List<Campos> buscarCamposDinamicosConjunto(int ID_Servico)
        {
            string sqlCommand = "";
            string tbl1 = SharedData.GetQueryDefinition("vw_ObjetosCamposServico");

            if (tbl1 != "")
            {
                tbl1 = TratamentoSQL.AdicionaWhere(tbl1, "[tb_0125_Servico].Id_Servico = " + ID_Servico);

                sqlCommand = "SELECT tbl1.*, tb_0126_DadosServico.ValorCampo, tb_0126_DadosServico.ValorCampo AS ValorCampoAntigo ";
                sqlCommand += "FROM (" + tbl1 + ") As tbl1 LEFT JOIN tb_0126_DadosServico ON (tbl1.ID_Servico = tb_0126_DadosServico.ID_Servico) AND (tbl1.ID_Campo = tb_0126_DadosServico.Id_Campo) ";
                sqlCommand += "ORDER BY tbl1.OrdemTab, tbl1.CampoLinha, tbl1.CampoColuna";
            }
            
            List<Campos> list = new List<Campos>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new Campos(row));

            return list;
        }
        public static List<Campos> buscarCamposDinamicosConjunto(int ID_Servico, int IdMetodo)
        {
            string sqlCommand = "";
            string tbl1 = SharedData.GetQueryDefinition("vw_ObjetosCamposServicoMinuta");

            if (tbl1 != "")
            {
                tbl1 = TratamentoSQL.AdicionaWhere(tbl1, "[tb_0125_Servico].Id_Servico = " + ID_Servico + " AND [tb_0006_CamposObjetosMinuta].IdMetodo = " + IdMetodo);

                sqlCommand = "SELECT tbl1.*, tb_0126_DadosServico.ValorCampo, tb_0126_DadosServico.ValorCampo AS ValorCampoAntigo ";
                sqlCommand += "FROM (" + tbl1 + ") As tbl1 LEFT JOIN tb_0126_DadosServico ON (tbl1.ID_Servico = tb_0126_DadosServico.ID_Servico) AND (tbl1.ID_Campo = tb_0126_DadosServico.Id_Campo) ";
                sqlCommand += "ORDER BY tbl1.OrdemTab, tbl1.CampoLinha, tbl1.CampoColuna";
            }

            List<Campos> list = new List<Campos>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new Campos(row));

            return list;
        }
        public static List<Campos> buscarCamposDinamicosConjunto(string ViewCampos)
        {
            string sqlCommand = SharedData.GetQueryDefinition(ViewCampos);
            //string sqlCommand = string.Format("SELECT * FROM {0} Order By OrdemTab, CampoLinha, CampoColuna", ViewCampos);
            List<Campos> list = new List<Campos>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new Campos(row));

            return list;
        }
        public static List<Campos> buscarCamposEtapa()
        {
            string sqlCommand = SharedData.GetQueryDefinition("vw_EtapasCampos");

            List<Campos> list = new List<Campos>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new Campos(row));

            return list;
        }
        public static List<Campos> buscarCamposEtapaConjunto(int idservico, int ID_Etapa = 0)
        {
            string sqlCommand = "";
            string tbl1 = SharedData.GetQueryDefinition("vw_EtapasCamposServico");
            if (tbl1 != "")
            {
                if (ID_Etapa == 0)
                {
                    //sqlCommand = string.Format("SELECT * FROM vw_MontarFormularioDadosEtapa Where ID_Servico = {0} And ID_Objeto = {1}", idservico, ID_Objeto);
                    tbl1 = TratamentoSQL.AdicionaWhere(tbl1, "[tb_0125_Servico].Id_Servico = " + idservico);
                }
                else
                {
                    //tbl1 = string.Format("SELECT * FROM vw_MontarFormularioDadosEtapa Where ID_Servico = {0} And ID_Objeto = {1} and ID_Etapa = {2}", idservico, ID_Objeto, ID_Etapa);
                    tbl1 = TratamentoSQL.AdicionaWhere(tbl1, "[tb_0125_Servico].Id_Servico = " + idservico + " AND [tb_0008_Etapas].ID_Etapa = " + ID_Etapa);
                }

                sqlCommand = "SELECT tbl1.*, tb_0126_DadosServico.ValorCampo, tb_0126_DadosServico.ValorCampo AS ValorCampoAntigo ";
                sqlCommand += "FROM (" + tbl1 + ") As tbl1 LEFT JOIN tb_0126_DadosServico ON (tbl1.ID_Servico = tb_0126_DadosServico.ID_Servico) AND (tbl1.ID_Campo = tb_0126_DadosServico.Id_Campo) ";
                sqlCommand += "ORDER BY tbl1.OrdemTab, tbl1.CampoLinha, tbl1.CampoColuna";
            }

            List<Campos> list = new List<Campos>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new Campos(row));

            return list;
        }

        public static List<CamposTabela> BuscarCamposTabela()
        {
            string sqlCommand = "SELECT * FROM tb_0003_CamposTabela";
            List<CamposTabela> listaValores = new List<CamposTabela>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                listaValores.Add(new CamposTabela(row));

            return listaValores;
        }

        public static List<CamposTabela> BuscarCamposTabela(int IdServico, bool TabelaGeral)
        {
            string sqlCommand = "";
            string tbl1 = string.Format("SELECT NomeCampo, ValorCampo, IdCampo, IDServico, Linha FROM tb_0134_DadosTabela WHERE IdServico = {0}", IdServico);
            if (TabelaGeral)
                tbl1 += " OR IdServico IS NULL";

            sqlCommand = "SELECT tbl1.ValorCampo, tbl1.IdServico, tbl1.Linha, tb_0003_CamposTabela.* ";
            sqlCommand += "FROM tb_0003_CamposTabela LEFT JOIN (" + tbl1 + ") As tbl1 ON (tbl1.CampoNome = tb_0003_CamposTabela.CampoNome) AND (tbl1.IdCampo = tb_0003_CamposTabela.IdCampo) ";

            List<CamposTabela> list = new List<CamposTabela>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new CamposTabela(row));

            return list;
        }

        public static DataTable BuscarTabela(int IdServico, int IdCampo)
        {
            string sql = "TRANSFORM First(tb_0134_DadosTabela.ValorCampo) AS PrimeiroDeValorCampo ";
            sql += "SELECT tb_0134_DadosTabela.Linha ";
            sql += "FROM tb_0134_DadosTabela ";
            sql += "WHERE tb_0134_DadosTabela.IdServico={0} AND tb_0134_DadosTabela.IdCampo={1} ";
            sql += "GROUP BY tb_0134_DadosTabela.IdServico, tb_0134_DadosTabela.IdCampo, tb_0134_DadosTabela.Linha ";
            sql += "PIVOT tb_0134_DadosTabela.NomeCampo";

            string sqlCommand = string.Format(sql, IdServico, IdCampo);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            return result;

        }
        public static DataTable BuscarTabela(int IdServico, int IdCampo,string view = "", string campoResult = "*")
        {

            string sql = "SELECT {0} ";
            sql += "FROM vw_DadosTabelaOperacao ";
            sql += "WHERE IdCampo={1} AND IdServico={2} ";

            string sqlCommand = "";
            if (view != "")
            {
                sql += " and {3}";
                sqlCommand = string.Format(sql, campoResult, IdCampo,IdServico, view);
            }
            else
            {
                sqlCommand = string.Format(sql, campoResult, IdCampo, IdServico);
            }
            

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            return result;

        }
        public static DataTable BuscarTabelaGeral(int IdCampo, string view = "", string campoResult = "*")
        {
            string sql = "SELECT {0} ";
            sql += "FROM vw_DadosTabela ";
            sql += "WHERE IdCampo={1}";

            string sqlCommand = "";
            if (view != "")
            {
                sql += " and {2}";
                sqlCommand = string.Format(sql, campoResult, IdCampo, view);
            }
            else
            {
                sqlCommand = string.Format(sql, IdCampo);
            }

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            return result;

        }
        public static int BuscarTabelaMaiorLinha(int IdCampo, int IdServico = 0)
        {
            string sql = "SELECT * ";
            sql += "FROM vw_DadosTabelaMaiorLinha ";
            sql += "WHERE IdCampo={0}";

            if (IdServico != 0)
            {
                sql += " AND IDSERVICO = " + IdServico;
            }

            string sqlCommand = string.Format(sql, IdCampo);

            DataTable dt = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            int result = 1;

            if (dt.Rows.Count > 0)
            {
                result = Convert.ToInt32(dt.Rows[0]["Linhas"]) + 1;
            }

            return result;

        }
        #endregion

        #region [ Salvar Campos ]
        public static void ExcluirDadosServicoLote(int idServico, List<Campos> CamposAtualizar, string SistemaLog = "")
        {
            StringBuilder sb_LogServico = new StringBuilder();
            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

            string sqlCommandDelete = "DELETE * FROM tb_0126_DadosServico WHERE (";

            int auxDelete = 0;
            string sqlCommandDeleteWhere = "";
            foreach (Campos campo in CamposAtualizar)
            {
                sb_LogServico.AppendLine(Log.MontaLogServico("Campos", idServico, 0, campo.ID_Campo, campo.ValorCampo, SistemaLog, datahora, "Delete"));

                if (sqlCommandDeleteWhere != "")
                {
                    sqlCommandDeleteWhere += " OR ";
                }
                sqlCommandDeleteWhere += " (ID_SERVICO = {0} And ID_CAMPO = {1})";

                sqlCommandDeleteWhere = string.Format(sqlCommandDeleteWhere, idServico, campo.ID_Campo);

                auxDelete = auxDelete + 1;
            }


            sqlCommandDelete += sqlCommandDeleteWhere + ")";
            if (auxDelete > 0)
            {
                string msgLog = "Excluindo campos: " + sqlCommandDelete;
                Log.GravaLog(msgLog, SistemaLog);
                DataTable multirowdelete = DataConnector.ExecuteDataTable(sqlCommandDelete, "BDconsulta");
            }
            Log.GravaLogServico(sb_LogServico.ToString(), idServico);
        } 
        public static void AtualizarDadosServico(int idServico, Campos c, string SistemaLog = "")
        {
            StringBuilder sb_LogServico = new StringBuilder();

            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

            string msgLog = "Atualizando dados do servico " + idServico + ": " + c.ID_Campo + " / " + c.CampoNome + "/" + c.ValorCampo + ".";
            Log.GravaLog(msgLog, SistemaLog);
            
            string sqlCommand = "UPDATE tb_0126_DadosServico SET [ValorCampo] = '{0}', [Data Atualizacao] = #{1}# WHERE ID_SERVICO = {2} And ID_CAMPO = {3} ";
            sqlCommand = string.Format(sqlCommand, c.ValorCampo, datahora, idServico, c.ID_Campo);
            DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            sb_LogServico.AppendLine(Log.MontaLogServico("Campos", idServico, 0, c.ID_Campo, c.ValorCampo, SistemaLog, datahora, "Update"));

            Log.GravaLogServico(sb_LogServico.ToString(), idServico);
        }
        public static void AtualizarDadosServicoLote(int idServico, List<Campos> CamposAtualizar, string SistemaLog = "")
        {
            StringBuilder sb_LogServico = new StringBuilder();

            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

            string sqlCommandUpdate = "UPDATE tb_0126_DadosServico SET [Data Atualizacao] = #{0}#, ValorCampo = {1} ";
            string sqlCommandWhereUpdate = "WHERE ID_CAMPO IN({0}) AND ID_SERVICO=" + idServico;

            string sqlCommand = "";
            string sqlCommandWhere = "";

            int auxUpdate = 0;
            string sqlCommandCriteria = "";
            string sqlCommandWhereCampos = "";
            foreach (Campos campo in CamposAtualizar)
            {
                sb_LogServico.AppendLine(Log.MontaLogServico("Campos", idServico, 0, campo.ID_Campo, campo.ValorCampo, SistemaLog, datahora, "update"));

                sqlCommandCriteria += string.Format("IIf(Id_Campo={0},'{1}',", campo.ID_Campo, campo.ValorCampo);

                if (sqlCommandWhereCampos != "")
                {
                    sqlCommandWhereCampos += ", ";
                }
                sqlCommandWhereCampos += campo.ID_Campo.ToString();

                auxUpdate = auxUpdate + 1;

                if (auxUpdate == 10)
                {
                    sqlCommandCriteria += "[ValorCampo]" + ("").PadLeft(auxUpdate, ')');

                    sqlCommandWhere = string.Format(sqlCommandWhereUpdate, sqlCommandWhereCampos);

                    sqlCommand = string.Format(sqlCommandUpdate, datahora, sqlCommandCriteria);
                    sqlCommand = sqlCommand + sqlCommandWhere;

                    DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

                    sqlCommandCriteria = "";
                    sqlCommandWhereCampos = "";
                    auxUpdate = 0;
                }
            }
            sqlCommandCriteria += "[ValorCampo]" + ("").PadLeft(auxUpdate, ')');

            sqlCommandWhere = string.Format(sqlCommandWhereUpdate, sqlCommandWhereCampos);

            sqlCommand = string.Format(sqlCommandUpdate, datahora, sqlCommandCriteria);
            sqlCommand = sqlCommand + sqlCommandWhere;
            if (auxUpdate > 0)
            {
                string msgLog = "Atualizando campos: " + sqlCommand;
                Log.GravaLog(msgLog, SistemaLog);
                DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            }
            if (sb_LogServico.ToString() != "")
                Log.GravaLogServico(sb_LogServico.ToString(), idServico);
        } 
        public static void SalvarDadosServico(Campos c, string SistemaLog = "")
        {
            StringBuilder sb_LogServico = new StringBuilder();

            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

            string msgLog = "Salvando dados do servico " + c.ID_Servico + ": " + c.ID_Campo + " / " + c.CampoNome + "/" + c.ValorCampo + ".";
            Log.GravaLog(msgLog, SistemaLog);

            string sqlCommand = string.Format("INSERT INTO tb_0126_DadosServico (ID_Servico, Id_Campo, NomeCampo, ValorCampo, [Data Criacao], [Data Atualizacao]) VALUES ({0}, {1}, '{2}', '{3}', #{4}#, #{5}#)", c.ID_Servico, c.ID_Campo, c.CampoNome, c.ValorCampo, datahora, datahora);
            
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            sb_LogServico.AppendLine(Log.MontaLogServico("Campos", c.ID_Servico, 0, c.ID_Campo, c.ValorCampo, SistemaLog, datahora, "Insert"));

            if (sb_LogServico.ToString() != "")
                Log.GravaLogServico(sb_LogServico.ToString(), c.ID_Servico);

        }
        public static void SalvarDadosServicoLote(List<Campos> CamposAcrescentar, string SistemaLog = "")
        {

            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            StringBuilder sb_LogServico = new StringBuilder();

            string sqlCommandInsert = "INSERT INTO tb_0126_DadosServico ";
            sqlCommandInsert += "(ID_Servico, Id_Campo, ValorCampo, [Data Criacao], [Data Atualizacao]) ";
            sqlCommandInsert += "SELECT * FROM ({0}) ";

            int auxInsert = 0;
            string sqlCommandTemporary = "";
            
            foreach (Campos campo in CamposAcrescentar)
            {
                if (campo.ValorCampo != "")
                {
                    sb_LogServico.AppendLine(Log.MontaLogServico("Campos", campo.ID_Servico, 0, campo.ID_Campo, campo.ValorCampo, SistemaLog, datahora, "Insert"));

                    sqlCommandTemporary = sqlCommandTemporary + string.Format("SELECT {0} As ID_Servico, {1} As Id_Campo, '{2}' As ValorCampo, #{3}# as [Data Criacao], #{4}# as [Data Atualizacao] FROM tb_0080_AuxInsertDadosServico UNION ", campo.ID_Servico, campo.ID_Campo, campo.ValorCampo, datahora, datahora);

                    auxInsert = auxInsert + 1;

                    if (auxInsert == 30)
                    {
                        sqlCommandTemporary = sqlCommandTemporary.Remove(sqlCommandTemporary.Length - 6);

                        sqlCommandInsert = string.Format(sqlCommandInsert, sqlCommandTemporary);

                        DataTable multirowinsert = DataConnector.ExecuteDataTable(sqlCommandInsert, "BDconsulta");

                        sqlCommandInsert = "INSERT INTO tb_0126_DadosServico ";
                        sqlCommandInsert += "(ID_Servico, Id_Campo, ValorCampo, [Data Criacao], [Data Atualizacao]) ";
                        sqlCommandInsert += "SELECT * FROM ({0}) ";

                        auxInsert = 0;
                        sqlCommandTemporary = "";
                    }
                }
            }


            sqlCommandTemporary = sqlCommandTemporary.Remove(sqlCommandTemporary.Length - 6);

            sqlCommandInsert = string.Format(sqlCommandInsert, sqlCommandTemporary);

            if (auxInsert > 0)
            {
                string msgLog = "Acrescentando campos: " + sqlCommandInsert;
                Log.GravaLog(msgLog, SistemaLog);
                DataConnector.ExecuteDataTable(sqlCommandInsert, "BDconsulta");
            }
            if (sb_LogServico.ToString() != "")
                Log.GravaLogServico(sb_LogServico.ToString(), CamposAcrescentar[0].ID_Servico);
        }

        public static void ExcluirDadosTabelaServicoLote(int idServico, List<CamposTabela> CamposAtualizar, string SistemaLog = "")
        {
            StringBuilder sb_LogServico = new StringBuilder();
            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

            string sqlCommandDelete = "DELETE * FROM tb_0134_DadosTabela WHERE (";

            int auxDelete = 0;
            string sqlCommandDeleteWhere = "";
            foreach (CamposTabela campo in CamposAtualizar)
            {
                sb_LogServico.AppendLine(Log.MontaLogServico("Campos", idServico, 0, campo.ID_Campo, "Linha: " + campo.Linha + "|Coluna: " + campo.CampoNome + "|Valor: " + campo.ValorCampo, SistemaLog, datahora, "Delete"));

                if (sqlCommandDeleteWhere != "")
                {
                    sqlCommandDeleteWhere += " OR ";
                }
                sqlCommandDeleteWhere += " (IdServico = {0} And IdCampo = {1} And Linha = '{2}' And NomeCampo = '{3}')";

                sqlCommandDeleteWhere = string.Format(sqlCommandDeleteWhere, idServico, campo.ID_Campo, campo.Linha, campo.CampoNome);

                auxDelete = auxDelete + 1;
            }


            sqlCommandDelete += sqlCommandDeleteWhere + ")";
            if (auxDelete > 0)
            {
                string msgLog = "Excluindo campos: " + sqlCommandDelete;
                Log.GravaLog(msgLog, SistemaLog);
                DataTable multirowdelete = DataConnector.ExecuteDataTable(sqlCommandDelete, "BDconsulta");
            }
            Log.GravaLogServico(sb_LogServico.ToString(), idServico);
        }
        public static void AtualizarDadosTabelaServicoLote(int idServico, List<CamposTabela> CamposAtualizar, string SistemaLog = "")
        {
            StringBuilder sb_LogServico = new StringBuilder();

            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

            string sqlCommandUpdate = "UPDATE tb_0134_DadosTabela SET [Data Atualizacao] = #{0}#, ValorCampo = {1} ";
            string sqlCommandWhereUpdate = "WHERE IdCampo IN({0}) AND IdServico=" + idServico;

            string sqlCommand = "";
            string sqlCommandWhere = "";

            int auxUpdate = 0;
            string sqlCommandCriteria = "";
            string sqlCommandWhereCampos = "";
            foreach (CamposTabela campo in CamposAtualizar)
            {
                sb_LogServico.AppendLine(Log.MontaLogServico("Campos", idServico, 0, campo.ID_Campo, "Linha: " + campo.Linha + "|Coluna: " + campo.CampoNome + "|Valor: " + campo.ValorCampo, SistemaLog, datahora, "update"));

                sqlCommandCriteria += string.Format("IIf(IdCampo={0} AND Linha='{1}' AND NomeCampo='{2}','{3}',", campo.ID_Campo, campo.Linha, campo.CampoNome, campo.ValorCampo);

                if (sqlCommandWhereCampos != "")
                {
                    sqlCommandWhereCampos += ", ";
                }
                sqlCommandWhereCampos += campo.ID_Campo.ToString();

                auxUpdate = auxUpdate + 1;

                if (auxUpdate == 10)
                {
                    sqlCommandCriteria += "[ValorCampo]" + ("").PadLeft(auxUpdate, ')');

                    sqlCommandWhere = string.Format(sqlCommandWhereUpdate, sqlCommandWhereCampos);

                    sqlCommand = string.Format(sqlCommandUpdate, datahora, sqlCommandCriteria);
                    sqlCommand = sqlCommand + sqlCommandWhere;

                    DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

                    sqlCommandCriteria = "";
                    sqlCommandWhereCampos = "";
                    auxUpdate = 0;
                }
            }
            sqlCommandCriteria += "[ValorCampo]" + ("").PadLeft(auxUpdate, ')');

            sqlCommandWhere = string.Format(sqlCommandWhereUpdate, sqlCommandWhereCampos);

            sqlCommand = string.Format(sqlCommandUpdate, datahora, sqlCommandCriteria);
            sqlCommand = sqlCommand + sqlCommandWhere;
            if (auxUpdate > 0)
            {
                string msgLog = "Atualizando campos: " + sqlCommand;
                Log.GravaLog(msgLog, SistemaLog);
                DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            }
            if (sb_LogServico.ToString() != "")
                Log.GravaLogServico(sb_LogServico.ToString(), idServico);
        } 
        public static void SalvarDadosTabelaServicoLote(List<CamposTabela> CamposAcrescentar, string SistemaLog = "")
        {

            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            StringBuilder sb_LogServico = new StringBuilder();

            string sqlCommandInsert = "INSERT INTO tb_0134_DadosTabela ";
            sqlCommandInsert += "(IdServico, IdCampo, NomeTabela, Linha, NomeCampo, ValorCampo, [Data Criacao], [Data Atualizacao]) ";
            sqlCommandInsert += "SELECT * FROM ({0}) ";

            int auxInsert = 0;
            string sqlCommandTemporary = "";

            foreach (CamposTabela campo in CamposAcrescentar)
            {
                if (campo.ValorCampo != "")
                {
                    sb_LogServico.AppendLine(Log.MontaLogServico("Campos", campo.IdServico, 0, campo.ID_Campo, "Linha: " + campo.Linha + "|Coluna: " + campo.CampoNome + "|Valor: " + campo.ValorCampo, SistemaLog, datahora, "Insert"));

                    sqlCommandTemporary = sqlCommandTemporary + string.Format("SELECT {0} As IdServico, {1} As IdCampo, '{2}' As NomeTabela, '{3}' As Linha, '{4}' As NomeCampo, '{5}' As ValorCampo, #{6}# as [Data Criacao], #{7}# as [Data Atualizacao] FROM tb_0080_AuxInsertDadosServico UNION ", campo.IdServico, campo.ID_Campo, campo.NomeTabela, campo.Linha, campo.CampoNome, campo.ValorCampo, datahora, datahora);

                    auxInsert = auxInsert + 1;

                    if (auxInsert == 30)
                    {
                        sqlCommandTemporary = sqlCommandTemporary.Remove(sqlCommandTemporary.Length - 6);

                        sqlCommandInsert = string.Format(sqlCommandInsert, sqlCommandTemporary);

                        DataTable multirowinsert = DataConnector.ExecuteDataTable(sqlCommandInsert, "BDconsulta");

                        sqlCommandInsert = "INSERT INTO tb_0134_DadosTabela ";
                        sqlCommandInsert += "(IdServico, IdCampo, NomeTabela, Linha, NomeCampo, ValorCampo, [Data Criacao], [Data Atualizacao]) ";
                        sqlCommandInsert += "SELECT * FROM ({0}) ";

                        auxInsert = 0;
                        sqlCommandTemporary = "";
                    }
                }
            }


            sqlCommandTemporary = sqlCommandTemporary.Remove(sqlCommandTemporary.Length - 6);

            sqlCommandInsert = string.Format(sqlCommandInsert, sqlCommandTemporary);

            if (auxInsert > 0)
            {
                string msgLog = "Acrescentando campos: " + sqlCommandInsert;
                Log.GravaLog(msgLog, SistemaLog);
                DataConnector.ExecuteDataTable(sqlCommandInsert, "BDconsulta");
            }
            if (sb_LogServico.ToString() != "")
                Log.GravaLogServico(sb_LogServico.ToString(), CamposAcrescentar[0].IdServico);
        }

        public static void AtualizarDadosCamposGenerico(List<Campos> listaEstrutura, TabControl tabControl, int ID_Servico, string SistemaLog = "", List<CamposTabela> camposTabela = null)
        {
            #region [ Campos Tabela ]
            if (camposTabela == null)
            {
                if ((listaEstrutura != null) && (listaEstrutura.Exists(n => n.CampoTipo.ToUpper() == "TABELA" || n.CampoTipo.ToUpper() == "TABELAGERAL")))
                {
                    camposTabela = new List<CamposTabela>();
                    if (SharedData.gCamposTabela != null && SharedData.gCamposTabela.Count > 0)
                    {
                        foreach (CamposTabela c in SharedData.gCamposTabela)
                        {
                            camposTabela.Add(new CamposTabela(c));
                        }
                    }

                    if (camposTabela == null || camposTabela.Count == 0)
                    {
                        if (listaEstrutura.Exists(n => n.CampoTipo.ToUpper() == "TABELAGERAL"))
                        {
                            camposTabela = DataAccess.BuscarCamposTabela();
                        }
                        else
                        {
                            camposTabela = DataAccess.BuscarCamposTabela();
                        }
                    }
                    else
                    {
                        if (listaEstrutura.Exists(n => n.CampoTipo.ToUpper() == "TABELAGERAL"))
                        {
                            camposTabela = TelaDinamica.RecuperarServico(camposTabela, ID_Servico, true);
                        }
                        else
                        {
                            camposTabela = TelaDinamica.RecuperarServico(camposTabela, ID_Servico, false);
                        }
                    }
                }
            }
            #endregion

            List<Campos> CamposInsert = new List<Campos>();
            List<Campos> CamposUpdate = new List<Campos>();
            List<Campos> CamposDelete = new List<Campos>();

            List<CamposTabela> camposTabelaExcluir = new List<CamposTabela>();
            List<CamposTabela> camposTabelaAcrescentar = new List<CamposTabela>();
            List<CamposTabela> camposTabelaAtualizar = new List<CamposTabela>();

            foreach (Campos c in listaEstrutura)
            {
                if (c.ID_Servico == 0)
                {
                    c.ID_Servico = ID_Servico;
                }

                if (c.CampoHabilitado)
                {
                    #region [ Busca Valores ]
                    if (c.CampoTipo.ToUpper() == "TEXTBOX")
                    {
                        #region [ TextBox ]
                        if (c.CampoDominio.ToUpper() == "NUMERICO")
                        {
                            NumericTextBox numbox = new NumericTextBox();
                            numbox = (NumericTextBox)tabControl.TabPages[c.CampoTab].Controls[c.CampoNome];
                            c.ValorCampo = numbox.Text;
                        }
                        else
                        {
                            MaskedTextBox mskbox = new MaskedTextBox();
                            mskbox = (MaskedTextBox)tabControl.TabPages[c.CampoTab].Controls[c.CampoNome];
                            if ((c.CampoDominio.ToUpper() == "DATA") || (c.CampoDominio.ToUpper() == "DATAHORA") || (c.CampoDominio.ToUpper() == "DATAHOJE") || (c.CampoDominio.ToUpper() == "DATAPASSADA") || (c.CampoDominio.ToUpper() == "DATAFUTURA"))
                            {
                                if (!mskbox.MaskCompleted)
                                {
                                    mskbox.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;
                                }
                                else
                                {
                                    mskbox.TextMaskFormat = MaskFormat.IncludeLiterals;
                                }
                                c.ValorCampo = mskbox.Text;
                            }
                            else
                            {
                                c.ValorCampo = mskbox.Text;
                            }
                        }
                        #endregion
                    }
                    else if (c.CampoTipo.ToUpper() == "MASKEDTEXTBOX")
                    {
                        #region [ Masked Text Box ]
                        MaskedTextBox mskbox = new MaskedTextBox();
                        mskbox = (MaskedTextBox)tabControl.TabPages[c.CampoTab].Controls[c.CampoNome];

                        if (!mskbox.MaskCompleted)
                        {
                            mskbox.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;
                        }
                        else
                        {
                            mskbox.TextMaskFormat = MaskFormat.IncludeLiterals;
                        }
                        c.ValorCampo = mskbox.Text;
                        #endregion
                    }
                    else if (c.CampoTipo.ToUpper() == "CHECKBOX")
                    {
                        #region [ CheckBox ]
                        CheckBox valueCkbox = new CheckBox();
                        valueCkbox = (CheckBox)tabControl.TabPages[c.CampoTab].Controls[c.CampoNome];
                        c.ValorCampo = valueCkbox.Checked.ToString();
                        #endregion
                    }
                    else if (c.CampoTipo.ToUpper() == "MEMO")
                    {
                        #region [ Memo ]
                        RichTextBox valueMemo = new RichTextBox();
                        valueMemo = (RichTextBox)tabControl.TabPages[c.CampoTab].Controls[c.CampoNome];
                        c.ValorCampo = valueMemo.Text;
                        #endregion
                    }
                    else if (c.CampoTipo.ToUpper() == "LABEL")
                    {
                        continue;
                    }
                    else if (c.CampoTipo.ToUpper() == "TABELA")
                    {
                        #region [ Tabela ]
                        DataGridView valueDataGrid = new DataGridView();
                        valueDataGrid = (DataGridView)tabControl.TabPages[c.CampoTab].Controls[c.CampoNome];

                        List<CamposTabela> campoTabela = camposTabela.Where(n => n.ID_Campo == c.ID_Campo && n.IdServico == ID_Servico).ToList();
                        int maiorLinha = 0;
                        if (campoTabela.Count > 0)
                            maiorLinha = Convert.ToInt32(campoTabela.OrderByDescending(n => n.Linha).ToList()[0].Linha);

                        List<DadosCamposTabela> DataGridTransposto = new List<DadosCamposTabela>();
                        #region [ Transpor DataGrid ]
                        foreach (DataGridViewRow dgvRow in valueDataGrid.Rows)
                        {
                            if (!dgvRow.IsNewRow)
                            {
                                if (dgvRow.Cells["Linha"].Value == null)
                                    maiorLinha++;

                                foreach (DataGridViewColumn dgvColumn in valueDataGrid.Columns)
                                {
                                    if (dgvColumn.Name.ToUpper() != "LINHA" && dgvRow.Cells[dgvColumn.Name].Value != null && dgvRow.Cells[dgvColumn.Name].Value.ToString().Trim() != "")
                                    {
                                        DadosCamposTabela NovaLinha = new DadosCamposTabela();
                                        NovaLinha.Linha = dgvRow.Cells["Linha"].Value == null ? maiorLinha : Convert.ToInt32(dgvRow.Cells["Linha"].Value);
                                        NovaLinha.IdServico = ID_Servico;
                                        NovaLinha.IdCampo = c.ID_Campo;
                                        NovaLinha.NomeCampo = dgvColumn.Name;
                                        NovaLinha.ValorCampo = dgvRow.Cells[dgvColumn.Name].Value.ToString().Trim();

                                        DataGridTransposto.Add(NovaLinha);
                                    }
                                }
                            }
                        }
                        #endregion

                        #region [ Adiciona listas Update | Delete | Insert ]
                        foreach (CamposTabela campo in campoTabela)
                        {
                            DadosCamposTabela ctbl = DataGridTransposto.Find(n => n.Linha == campo.Linha && n.NomeCampo == campo.CampoNome);
                            if (ctbl == null)
                            {
                                #region [ delete ]
                                camposTabelaExcluir.Add(campo);
                                #endregion
                            }
                            else
                            {
                                #region [ update ]
                                if (campo.ValorCampo != ctbl.ValorCampo)
                                {
                                    campo.ValorCampo = TelaDinamica.FormatarValorCampo(campo.CampoDominio, ctbl.ValorCampo);
                                    if (campo.ValorCampo != "")
                                        camposTabelaAtualizar.Add(campo);
                                }
                                #endregion
                            }
                        }

                        #region [ insert ]
                        foreach (DadosCamposTabela ctbl in DataGridTransposto)
                        {
                            if (!campoTabela.Exists(n => n.Linha == ctbl.Linha && n.CampoNome == ctbl.NomeCampo))
                            {
                                CamposTabela campoDom = camposTabela.Find(n => n.ID_Campo == ctbl.IdCampo && n.CampoNome == ctbl.NomeCampo);
                                if (campoDom != null)
                                {
                                    string Dominio = campoDom.CampoDominio;
                                    ctbl.ValorCampo = TelaDinamica.FormatarValorCampo(Dominio, ctbl.ValorCampo);
                                    if (ctbl.ValorCampo != "")
                                    {
                                        CamposTabela campoInsert = new CamposTabela();
                                        campoInsert.IdServico = ID_Servico;
                                        campoInsert.ID_Campo = c.ID_Campo;
                                        campoInsert.Linha = ctbl.Linha;
                                        campoInsert.CampoNome = ctbl.NomeCampo;
                                        campoInsert.ValorCampo = ctbl.ValorCampo;
                                        campoInsert.NomeTabela = c.CampoNome;

                                        camposTabelaAcrescentar.Add(campoInsert);
                                    }
                                        
                                }
                            }
                        }
                        #endregion
                        #endregion
                        #endregion
                    }
                    else if (c.CampoTipo.ToUpper() == "TABELAGERAL")
                    {
                        #region [ TabelaGeral ]
                        DataGridView valueDataGrid = new DataGridView();
                        valueDataGrid = (DataGridView)tabControl.TabPages[c.CampoTab].Controls[c.CampoNome];

                        string sqlDT = "";
                        int linha = BuscarTabelaMaiorLinha(c.ID_Campo);
                        foreach (DataGridViewRow linhaDT in valueDataGrid.Rows)
                        {
                            foreach (DataGridViewColumn colunaDT in valueDataGrid.Columns)
                            {
                                if (colunaDT.Name != "Linha" && valueDataGrid[colunaDT.Index, linhaDT.Index].Value != null && valueDataGrid[colunaDT.Index, linhaDT.Index].Value.ToString() != "")
                                {
                                    string Dominio = "";
                                    string vlrCampo = "";
                                    List<CamposTabela> camposTbl = camposTabela.Where(n => n.ID_Campo == c.ID_Campo && n.CampoNome == colunaDT.Name).ToList();

                                    if (camposTbl.Count() > 0)
                                    {
                                        Dominio = camposTbl[0].CampoDominio;
                                        vlrCampo = TelaDinamica.FormatarValorCampo(Dominio, valueDataGrid[colunaDT.Index, linhaDT.Index].Value.ToString());
                                    }
                                    else
                                    {
                                        vlrCampo = valueDataGrid[colunaDT.Index, linhaDT.Index].Value.ToString();
                                    }
                                    sqlDT = string.Format("Insert Into tb_0134_DadosTabela (IdCampo, NomeTabela, Linha, NomeCampo, ValorCampo) Values ({0},'{1}','{2}','{3}','{4}')", c.ID_Campo, c.CampoNome, linha.ToString(), colunaDT.Name, vlrCampo);
                                    DataConnector.ExecuteDataTable(sqlDT, "BDconsulta");
                                }
                            }
                            linha++;
                        }

                        foreach (DataGridViewRow linhaDGV in valueDataGrid.Rows)
                        {
                            DataAccess.DeletarDadosTabelaLinha("tb_0134_DadosTabela", "BDconsulta", c.ID_Campo, Convert.ToInt32(linhaDGV.Cells["Linha"].Value), 0, SistemaLog);
                        }
                        #endregion
                        continue;
                    }
                    else
                    {
                        c.ValorCampo = tabControl.TabPages[c.CampoTab].Controls[c.CampoNome].Text;
                    }
                    #endregion

                    #region [ Salvar ]
                    if (!(c.CampoTipo.ToUpper() == "TABELA" || c.CampoTipo.ToUpper() == "TABELAGERAL"))
                    {
                        c.ValorCampo = TelaDinamica.FormatarValorCampo(c.CampoDominio, c.ValorCampo);

                        #region [ Update ]
                        if ((c.ValorCampoAntigo != null) && (c.ValorCampoAntigo != "") && c.ValorCampoAntigo != c.ValorCampo)
                        {
                            if (c.ValorCampo != "")
                            {
                                #region [ Update ]
                                CamposUpdate.Add(c);
                                #endregion
                            }
                            else
                            {
                                #region [ Delete ]
                                CamposDelete.Add(c);
                                #endregion
                            }
                        }
                        #endregion

                        #region [ Insert ]
                        if (c.ValorCampo != null && c.ValorCampo != "" && (c.ValorCampoAntigo == null || c.ValorCampoAntigo == "") && c.ValorCampoAntigo != c.ValorCampo)
                        {
                            CamposInsert.Add(c);
                        }
                        #endregion

                        #region [ Indicador ]
                        if (c.CampoIndicador == true && c.ValorCampo != c.ValorCampoAntigo)
                        {
                            TratarEventos.GravaLinhaEvento(ID_Servico, c.CampoTipoIndicador, c.CampoRegraCalculo, c.CampoItemIndicador, c.ValorCampo, c.CampoTipoValor, Environment.UserName.ToUpper(), c.CampoEvento, "obs");
                        }
                        #endregion
                    }
                    #endregion
                }
            }

            #region [ Executar MultiQuery ]
            #region [ Campos ]
            if (CamposDelete.Count > 0)
            {
                ExcluirDadosServicoLote(ID_Servico, CamposDelete, SistemaLog);
            }

            if (CamposUpdate.Count > 0)
            {
                AtualizarDadosServicoLote(ID_Servico, CamposUpdate, SistemaLog);
            }

            if (CamposInsert.Count > 0)
            {
                SalvarDadosServicoLote(CamposInsert, SistemaLog);
            }
            #endregion

            #region [ Tabelas ]
            if (camposTabelaExcluir.Count > 0)
            {
                ExcluirDadosTabelaServicoLote(ID_Servico, camposTabelaExcluir, SistemaLog);
            }

            if (camposTabelaAtualizar.Count > 0)
            {
                AtualizarDadosTabelaServicoLote(ID_Servico, camposTabelaAtualizar, SistemaLog);
            }

            if (camposTabelaAcrescentar.Count > 0)
            {
                SalvarDadosTabelaServicoLote(camposTabelaAcrescentar, SistemaLog);
            }
            #endregion
            #endregion
        }

        public static void AtualizarDadosCamposGenerico(List<Campos> listaEstrutura, int ID_Servico, string SistemaLog = "")
        {

            List<Campos> CamposInsert = new List<Campos>();
            List<Campos> CamposUpdate = new List<Campos>();
            List<Campos> CamposDelete = new List<Campos>();

            foreach (Campos c in listaEstrutura)
            {
                if (c.ID_Servico == 0)
                {
                    c.ID_Servico = ID_Servico;
                }
                
                c.ValorCampo = TelaDinamica.FormatarValorCampo(c.CampoDominio, c.ValorCampo);

                #region [ Update ]
                if ((c.ValorCampoAntigo != null) && (c.ValorCampoAntigo != "") && c.ValorCampoAntigo != c.ValorCampo)
                {
                    if (c.ValorCampo != "")
                    {
                        #region [ Update ]
                        CamposUpdate.Add(c);
                        #endregion
                    }
                    else
                    {
                        #region [ Delete ]
                        CamposDelete.Add(c);
                        #endregion
                    }
                }
                #endregion

                #region [ Insert ]
                if (c.ValorCampo != null && c.ValorCampo != "" && (c.ValorCampoAntigo == null || c.ValorCampoAntigo == "") && c.ValorCampoAntigo != c.ValorCampo)
                {
                    CamposInsert.Add(c);
                }
                #endregion



            }

            #region [ Executar MultiQuery ]
            if (CamposDelete.Count > 0)
            {
                ExcluirDadosServicoLote(ID_Servico, CamposDelete, SistemaLog);
            }

            if (CamposUpdate.Count > 0)
            {
                AtualizarDadosServicoLote(ID_Servico, CamposUpdate, SistemaLog);
            }

            if (CamposInsert.Count > 0)
            {
                SalvarDadosServicoLote(CamposInsert, SistemaLog);
            }
            #endregion
        }
       
        #endregion
        #endregion

        #region [ Pipeline ]
        public static DataTable BuscarPipeline(string coluna, int Id, List<PipelineCampos> pipeline)
        {
            string sqlCommand = "";
            DataTable result = new DataTable();

            #region [ Busca campos gerais do pipeline ]
            if (SharedData.gValidaDependenciaResponsavel)
            {

                string tbl1 = SharedData.GetQueryDefinition("vw_PipeLineResponsavel");

                string pipeServ = SharedData.GetQueryDefinition("vw_ServicoFluxosPipeline");
                
                if (tbl1 != "")
                {
                    tbl1 = TratamentoSQL.AdicionaWhere(tbl1, "[tb_0100_Responsavel]." + coluna + " = " + Id);
                }
                tbl1 = tbl1.Replace("FROM (vw_ServicoFluxosPipeline", "FROM ((" + pipeServ + ") AS TBL3").Replace("vw_ServicoFluxosPipeline", "TBL3");

                string tbl2 = SharedData.GetQueryDefinition("vw_EtapaResponsavelDiferente");
                if (tbl2 != "")
                {
                    tbl2 = TratamentoSQL.AdicionaWhere(tbl2, "[tb_0127_FluxoServico]." + coluna + " = " + Id);
                }

                sqlCommand = @"SELECT tbl1.*, tbl2.ValidaDependente ";
                sqlCommand += "FROM (" + tbl1 + ") AS tbl1 ";
                sqlCommand += "LEFT JOIN (" + tbl2 + ") AS tbl2 ";
                sqlCommand += "ON  (tbl1.ID_Responsavel = tbl2.Id_Responsavel) ";
                sqlCommand += "AND (tbl1.ID_Fluxo = tbl2.ID_Etapa) ";
                sqlCommand += "AND (tbl1.ID_Servico = tbl2.ID_Servico) ";
                sqlCommand += "AND (tbl1.IdResponsavelFluxo <> tbl2.Id_Responsavel)";
            }
            else
            {
                sqlCommand = SharedData.GetQueryDefinition("vw_PipeLineResponsavel");
                string pipeServ = SharedData.GetQueryDefinition("vw_ServicoFluxosPipeline");
                
                if (sqlCommand != "")
                {
                    sqlCommand = TratamentoSQL.AdicionaWhere(sqlCommand, "[tb_0100_Responsavel]." + coluna + " = " + Id);
                }
                sqlCommand = sqlCommand.Replace("FROM (vw_ServicoFluxosPipeline", "FROM ((" + pipeServ + ") AS TBL3").Replace("vw_ServicoFluxosPipeline", "TBL3");
            }
            #endregion

            #region [ Busca campos do Serviço ]
            List<PipelineCampos> pipelineCamposServico = new List<PipelineCampos>();

            pipelineCamposServico = pipeline.Where(n => n.IdCampo != 0).ToList();

            string sqlCommandSelect = "";
            string sqlCommandSelectNovo = "";
            if (pipelineCamposServico.Count > 0)
            {
                sqlCommandSelect = "TRANSFORM First(tb_0126_DadosServico.ValorCampo) AS PrimeiroDeValorCampo ";
                sqlCommandSelect += "SELECT tb_0125_Servico.ID_Servico ";
                sqlCommandSelect += "FROM tb_0009_Pipeline INNER JOIN (tb_0125_Servico INNER JOIN tb_0126_DadosServico ON tb_0125_Servico.ID_Servico = tb_0126_DadosServico.ID_Servico) ON tb_0009_Pipeline.IdCampo = tb_0126_DadosServico.Id_Campo ";
                sqlCommandSelect += "WHERE (((tb_0125_Servico.Cancelado)=False) AND ((tb_0125_Servico.CONCLUIDO)=False)) ";
                sqlCommandSelect += "GROUP BY tb_0125_Servico.ID_Servico ";
                sqlCommandSelect += "PIVOT tb_0009_Pipeline.NomeDesign";




                sqlCommandSelectNovo = "TRANSFORM First(DadosTemp.ValorCampo) AS PrimeiroDeValorCampo ";
                sqlCommandSelectNovo += "SELECT ";
                string camposRetornar = "";
                foreach (PipelineCampos p in pipeline)
                {
                    if (p.IdCampo == 0)
                        camposRetornar += "PipelineTemp.[" + p.NomeDesign + "], ";
                }

                sqlCommandSelectNovo += camposRetornar.Remove(camposRetornar.Length - 2) + " ";
                sqlCommandSelectNovo += "FROM ( " + sqlCommand + ")  AS PipelineTemp ";
                sqlCommandSelectNovo += "LEFT JOIN ( ";

                sqlCommandSelectNovo += "SELECT tb_0125_Servico.ID_Servico, tb_0009_Pipeline.NomeDesign, tb_0126_DadosServico.ValorCampo ";
                sqlCommandSelectNovo += "FROM (tb_0126_DadosServico INNER JOIN tb_0009_Pipeline ON tb_0126_DadosServico.Id_Campo = tb_0009_Pipeline.IdCampo) ";
                sqlCommandSelectNovo += "INNER JOIN tb_0125_Servico ON tb_0126_DadosServico.ID_Servico = tb_0125_Servico.ID_Servico ";
                sqlCommandSelectNovo += "WHERE (((tb_0125_Servico.Concluido)=False) AND ((tb_0125_Servico.Cancelado)=False)) ";

                sqlCommandSelectNovo += " )  AS DadosTemp ";
                sqlCommandSelectNovo += "ON PipelineTemp.ID_Servico = DadosTemp.ID_Servico ";
                sqlCommandSelectNovo += "GROUP BY ";
                sqlCommandSelectNovo += camposRetornar.Remove(camposRetornar.Length - 2) + " ";
                sqlCommandSelectNovo += "PIVOT DadosTemp.NomeDesign";

//////SELECT PipelineTemp.ID_Responsavel, PipelineTemp.ID_Servico, PipelineTemp.Prioridade, PipelineTemp.DataCriacao, PipelineTemp.ID_Objeto, PipelineTemp.ServicoName, PipelineTemp.NomeObjeto, PipelineTemp.COD_SEGMENTO, PipelineTemp.ID_AREA, PipelineTemp.NomeResponsavel, PipelineTemp.NomeCelula, PipelineTemp.NomeCelulaResumido, PipelineTemp.ID_Celula, PipelineTemp.ID_SEGMENTO, PipelineTemp.CategoriaObjeto, PipelineTemp.DescricaoObjeto, PipelineTemp.ResponsavelFluxo, PipelineTemp.IdResponsavelFluxo, PipelineTemp.ID_Fluxo, PipelineTemp.CelulaResponsavel, PipelineTemp.AreaResponsavel, PipelineTemp.NomeEtapa, PipelineTemp.DescricaoEtapa, PipelineTemp.ID_Status, PipelineTemp.StatusDescricao, PipelineTemp.ConcluidoFluxo, PipelineTemp.OrdemEtapa, PipelineTemp.Primeiro, PipelineTemp.Paralisa, PipelineTemp.Fecha, PipelineTemp.Cancela, PipelineTemp.NaoInicia, PipelineTemp.IdMesmoResponsavel

//////FROM (SELECT DISTINCT tb_0100_Responsavel.ID_Responsavel, vw_ServicoFluxosPipeline.ID_Servico, vw_ServicoFluxosPipeline.Prioridade, vw_ServicoFluxosPipeline.DataCriacao, vw_ServicoFluxosPipeline.ID_Objeto, vw_ServicoFluxosPipeline.ServicoName, tb_0001_Objetos.NomeObjeto, tb_0110_Segmento.COD_SEGMENTO, tb_0004_ObjetosAreas.ID_AREA, tb_0100_Responsavel.NomeResponsavel, tb_0113_Celula.NomeCelula, tb_0113_Celula.NomeCelulaResumido, tb_0113_Celula.ID_Celula, tb_0110_Segmento.ID_SEGMENTO, tb_0001_Objetos.CategoriaObjeto, tb_0001_Objetos.DescricaoObjeto, vw_ServicoFluxosPipeline.ResponsavelFluxo, vw_ServicoFluxosPipeline.IdResponsavelFluxo, vw_ServicoFluxosPipeline.ID_Fluxo, vw_ServicoFluxosPipeline.CelulaResponsavel, vw_ServicoFluxosPipeline.AreaResponsavel, vw_ServicoFluxosPipeline.NomeEtapa, vw_ServicoFluxosPipeline.DescricaoEtapa, vw_ServicoFluxosPipeline.ID_Status, vw_ServicoFluxosPipeline.StatusDescricao, vw_ServicoFluxosPipeline.ConcluidoFluxo, vw_ServicoFluxosPipeline.OrdemEtapa, vw_ServicoFluxosPipeline.Primeiro, vw_ServicoFluxosPipeline.Paralisa, vw_ServicoFluxosPipeline.Fecha, vw_ServicoFluxosPipeline.Cancela, vw_ServicoFluxosPipeline.NaoInicia, vw_ServicoFluxosPipeline.IdMesmoResponsavel
//////FROM (vw_ServicoFluxosPipeline INNER JOIN (tb_0113_Celula INNER JOIN (((tb_0117_CelulaArea INNER JOIN tb_0112_Areas ON tb_0117_CelulaArea.ID_Area = tb_0112_Areas.ID_Area) INNER JOIN (tb_0001_Objetos INNER JOIN tb_0004_ObjetosAreas ON tb_0001_Objetos.ID_Objeto = tb_0004_ObjetosAreas.ID_OBJETO) ON tb_0112_Areas.ID_Area = tb_0004_ObjetosAreas.ID_AREA) INNER JOIN ((tb_0116_ResponsavelCelula INNER JOIN tb_0100_Responsavel ON tb_0116_ResponsavelCelula.ID_Responsavel = tb_0100_Responsavel.ID_Responsavel) INNER JOIN tb_0107_CelulasInterligadas ON tb_0116_ResponsavelCelula.ID_Celula = tb_0107_CelulasInterligadas.Celula2) ON tb_0117_CelulaArea.ID_Celula = tb_0116_ResponsavelCelula.ID_Celula) ON tb_0113_Celula.ID_Celula = tb_0107_CelulasInterligadas.Celula1) ON (vw_ServicoFluxosPipeline.ID_Objeto = tb_0001_Objetos.ID_Objeto) AND (vw_ServicoFluxosPipeline.CelulaResponsavel = tb_0113_Celula.ID_Celula)) INNER JOIN tb_0110_Segmento ON vw_ServicoFluxosPipeline.ID_SEGMENTO = tb_0110_Segmento.ID_SEGMENTO
//////WHERE (tb_0100_Responsavel.Id_Responsavel = 45) And (((tb_0001_Objetos.AtivoObjeto)=True) AND ((tb_0100_Responsavel.ATIVO)=True) AND ((tb_0112_Areas.AtivoArea)=True) AND ((tb_0113_Celula.CelulaAtiva)=True))
//////ORDER BY vw_ServicoFluxosPipeline.Prioridade DESC , vw_ServicoFluxosPipeline.DataCriacao DESC)  AS PipelineTemp 

//////LEFT JOIN (SELECT tb_0126_DadosServico.*, tb_0009_Pipeline.NomeDesign FROM tb_0009_Pipeline INNER JOIN tb_0126_DadosServico ON tb_0009_Pipeline.IdCampo = tb_0126_DadosServico.Id_Campo)  AS DadosTemp 
//////ON PipelineTemp.ID_Servico = DadosTemp.ID_Servico

//////GROUP BY PipelineTemp.ID_Responsavel, PipelineTemp.ID_Servico, PipelineTemp.Prioridade, PipelineTemp.DataCriacao, PipelineTemp.ID_Objeto, PipelineTemp.ServicoName, PipelineTemp.NomeObjeto, PipelineTemp.COD_SEGMENTO, PipelineTemp.ID_AREA, PipelineTemp.NomeResponsavel, PipelineTemp.NomeCelula, PipelineTemp.NomeCelulaResumido, PipelineTemp.ID_Celula, PipelineTemp.ID_SEGMENTO, PipelineTemp.CategoriaObjeto, PipelineTemp.DescricaoObjeto, PipelineTemp.ResponsavelFluxo, PipelineTemp.IdResponsavelFluxo, PipelineTemp.ID_Fluxo, PipelineTemp.CelulaResponsavel, PipelineTemp.AreaResponsavel, PipelineTemp.NomeEtapa, PipelineTemp.DescricaoEtapa, PipelineTemp.ID_Status, PipelineTemp.StatusDescricao, PipelineTemp.ConcluidoFluxo, PipelineTemp.OrdemEtapa, PipelineTemp.Primeiro, PipelineTemp.Paralisa, PipelineTemp.Fecha, PipelineTemp.Cancela, PipelineTemp.NaoInicia, PipelineTemp.IdMesmoResponsavel

//////PIVOT DadosTemp.NomeDesign;

            }
            #endregion

            #region [ Join Tables ]
            DataTable targetTable = new DataTable();
            if (sqlCommand != "" && (sqlCommandSelect != "" || sqlCommandSelectNovo != ""))
            {
                //targetTable = DataConnector.Join_2SQL_1Column(sqlCommand, sqlCommandSelect, "ID_Servico", "BDconsulta");
                targetTable = DataConnector.ExecuteDataTable(sqlCommandSelectNovo, "BDconsulta");
            }
            else
            {
                targetTable = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            }

            //DataTable targetTable = new DataTable();
            //if (resultPipe.Rows.Count > 0 && result.Rows.Count > 0)
            //{
            //    targetTable = TratamentoCampo.JoinTwoDataTablesOnOneColumn(resultPipe, result, "ID_Servico", TratamentoCampo.JoinType.Left);
            //}
            //else
            //{
            //    targetTable = resultPipe;
            //}
            #endregion

            #region [ Critérios ]
            if (targetTable.Rows.Count > 0 && !SharedData.User.FLG_Gestor)
            {
                string sqlCommandWhereFinal = "";
                pipelineCamposServico = pipeline.Where(n => n.CriterioSQL != null && n.CriterioSQL != "").ToList();

                foreach (PipelineCampos campos in pipelineCamposServico)
                {
                    string WhereCampoAtual = "";

                    if (WhereCampoAtual == "")
                    {
                        if (campos.CriterioSQL.ToString().Contains(@"{0}"))
                        {
                            WhereCampoAtual += string.Format(campos.CriterioSQL.ToString(), campos.NomeDesign);
                        }
                        else
                        {
                            WhereCampoAtual += campos.CriterioSQL.ToString();
                        }
                    }

                    if (sqlCommandWhereFinal == "")
                    {
                        sqlCommandWhereFinal += string.Format("({0}) ", WhereCampoAtual);
                    }
                    else
                    {
                        sqlCommandWhereFinal += string.Format("AND ({0}) ", WhereCampoAtual);
                    }
                }


                DataRow[] targetRows = targetTable.Select(sqlCommandWhereFinal.Replace(@"Date()", "#" + DateTime.Today.ToString("yyyy/MM/dd") + "#").Replace(@"Now()", "#" + DateTime.Now.ToString("yyyy/MM/dd") + "#"));
                if (targetRows.Count() > 0)
                {
                    targetTable = targetRows.CopyToDataTable();
                }
                else
                {
                    targetTable.Rows.Clear();
                }
            }
            #endregion
            
            #region [ Sort ]
            if (targetTable.Rows.Count > 0)
            {
                pipelineCamposServico = pipeline.Where(n => n.Sort != 0 && n.TipoSort != "").OrderBy(n => n.Sort).ToList();

                if (pipelineCamposServico.Count > 0)
                {
                    DataView dv = targetTable.DefaultView;
                    string sort = "";
                    foreach (PipelineCampos campos in pipelineCamposServico)
                    {
                        if (sort == "")
                        {
                            sort += "[" + campos.NomeDesign + "] " + campos.TipoSort;
                        }
                        else
                        {
                            sort += ", [" + campos.NomeDesign + "] " + campos.TipoSort;
                        }
                    }
                    dv.Sort = sort;
                    targetTable = dv.ToTable();
                }
            }
            #endregion

            #region [ Group By ]
            if (targetTable.Rows.Count > 0)
            {
                List<PipelineCampos> pipelineCamposGroupBy = pipeline.Where(n => n.GroupBy == true).ToList();
                if (pipelineCamposGroupBy.Count > 0)
                {
                    string[] arrayColunas = new string[pipelineCamposGroupBy.Count];
                    for (int i = 0; i < pipelineCamposGroupBy.Count; i++)
                    {
                        arrayColunas[i] = pipelineCamposGroupBy[i].NomeDesign;
                    }
                    targetTable = TratamentoCampo.DataTableGroupBy(arrayColunas, targetTable);
                }
            }
            #endregion

            #region [ Formatar Campos ]
            if (targetTable.Rows.Count > 0)
            {
                List<PipelineCampos> pipelineCamposFormatar = pipeline.Where(n => (n.TipoCampo.ToUpper() == "INT" || n.TipoCampo.ToUpper() == "DECIMAL") && n.Formato != "").ToList();

                List<PipelineCampos> pipelineCamposFormatarData = pipeline.Where(n => (n.TipoCampo.ToUpper() == "DATE" || n.TipoCampo.ToUpper() == "DATETIME")).ToList();

                foreach (PipelineCampos campos in pipelineCamposFormatarData)
                {
                    if (targetTable.Columns.Contains(campos.NomeDesign))
                    {
                        if (targetTable.Columns[campos.NomeDesign].GetType().ToString().ToUpper() != "DATETIME")
                        {
                            targetTable.Columns.Add(campos.NomeDesign + "DateTime", typeof(DateTime));
                        }
                    }
                }

                CultureInfo c = TratamentoLinguagem.BuscarLinguagem("pt-BR");
                foreach (DataRow r in targetTable.Rows)
                {
                    foreach (PipelineCampos campos in pipelineCamposFormatar)
                    {
                        if (r[campos.NomeDesign].ToString() != "")
                        {
                            if (campos.Formato.ToUpper() == "CPF/CNPJ")
                            {
                                if (ValidaCNPJ.IsCnpj(r[campos.NomeDesign].ToString()))
                                {
                                    r[campos.NomeDesign] = Convert.ToDecimal(r[campos.NomeDesign], c).ToString(@"00\.000\.000\/0000\-00");
                                }
                                else if (ValidaCPF.IsCpf(r[campos.NomeDesign].ToString()))
                                {
                                    r[campos.NomeDesign] = Convert.ToDecimal(r[campos.NomeDesign], c).ToString(@"000\.000\.000\-00");
                                }
                            }
                            else
                            {
                                r[campos.NomeDesign] = Convert.ToDecimal(r[campos.NomeDesign], c).ToString(campos.Formato);
                            }
                        }
                    }

                    foreach (PipelineCampos campos in pipelineCamposFormatarData)
                    {
                        if (targetTable.Columns.Contains(campos.NomeDesign) && targetTable.Columns.Contains(campos.NomeDesign + "DateTime"))
                        {
                            DateTime d;
                            if (DateTime.TryParse(r[campos.NomeDesign].ToString(), c, DateTimeStyles.None, out d))
                                r[campos.NomeDesign + "DateTime"] = d;
                        }
                    }
                }

                foreach (PipelineCampos campos in pipelineCamposFormatarData)
                {
                    if (targetTable.Columns.Contains(campos.NomeDesign) && targetTable.Columns.Contains(campos.NomeDesign + "DateTime"))
                    {
                        targetTable.Columns.Remove(campos.NomeDesign);
                        targetTable.Columns[campos.NomeDesign + "DateTime"].ColumnName = campos.NomeDesign;
                    }
                }
            }
            #endregion


            return targetTable;
        }
        public static List<PipelineCampos> BuscarPipelineCampos()
        {
            string sqlCommand = String.Format(@"SELECT * FROM tb_0009_Pipeline ORDER BY [Ordem]");

            List<PipelineCampos> list = new List<PipelineCampos>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new PipelineCampos(row));

            return list;
        }
        public static List<PipelineVisual> BuscarPipelineVisual()
        {
            string sqlCommand = String.Format(@"SELECT * FROM tb_0009_PipelineVisual ORDER BY [Ordem]");

            List<PipelineVisual> list = new List<PipelineVisual>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new PipelineVisual(row));

            return list;
        }
        #endregion

        #region [ Workflow ]
        public static List<WorkflowEnty> BuscarWorkflow(DateTime dtInicio, DateTime dtFim, int ID_Responsavel, int ID_Objeto, bool ServConcluido, bool ServCancelado)
        {
            string sqlCommand;
            string DataFimCompleta = dtFim.ToString("yyyy/MM/dd") + " 23:59";

            sqlCommand = "SELECT * FROM vw_WorkFlow Where DataCriacao Between #{0}# And #{1}# ";
            sqlCommand = String.Format(sqlCommand, dtInicio.ToString("yyyy/MM/dd"), DataFimCompleta);
            
            if (ID_Responsavel != 0)
            {
                sqlCommand += "AND ID_Responsavel = " + ID_Responsavel + " ";
            }

            if (ID_Objeto != 0)
            {
                sqlCommand = sqlCommand + "And ID_Objeto = " + ID_Objeto + "  ";
            }

            sqlCommand += "AND Concluido = " + ServConcluido + " ";
            sqlCommand += "AND Cancelado = " + ServCancelado + " ";


            List<WorkflowEnty> list = new List<WorkflowEnty>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new WorkflowEnty(row));

            return list;
        }
        public static DataTable BuscarWorkflowDT(DateTime dtInicio, DateTime dtFim, int ID_Area, int ID_Responsavel = 0, int ID_Objeto = 0, bool ServConcluido = false, bool ServCancelado = false)
        {
            string sqlCommand;
            string DataFimCompleta = dtFim.ToString("yyyy/MM/dd") + " 23:59";

            if (ID_Responsavel == 0)
            {
                sqlCommand = "SELECT * FROM vw_ReportWorkFlow Where DataCriacao Between #{0}# And #{1}# ";
                sqlCommand = String.Format(sqlCommand, dtInicio.ToString("yyyy/MM/dd"), DataFimCompleta);
            }
            else
            {
                sqlCommand = "SELECT * FROM vw_ReportWorkFlow Where DataCriacao Between #{0}# And #{1}# And ID_Responsavel = {2} ";
                sqlCommand = String.Format(sqlCommand, dtInicio.ToString("yyyy/MM/dd"), DataFimCompleta, ID_Responsavel);
            }

            sqlCommand = sqlCommand + "And ID_Area = " + ID_Area + "  ";
            if (ID_Objeto != 0)
            {
                sqlCommand = sqlCommand + "And ID_Objeto = " + ID_Objeto + "  ";
            }
            if (ServConcluido == false)
            {
                sqlCommand = sqlCommand + "And Concluido = " + ServConcluido + "  ";
            }
            if (ServCancelado == false)
            {
                sqlCommand = sqlCommand + "And Cancelado = " + ServCancelado + "  ";
            }

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            return result;

        }
        #endregion

        #region [ Segmento ]
        public static List<Segmento> buscarSegmento(int Id_Responsavel)
        {
            string sqlCommand = SharedData.GetQueryDefinition("Vw_Segmentos");
            if (sqlCommand != "")
            {
                sqlCommand = TratamentoSQL.AdicionaWhere(sqlCommand, "[tb_0100_Responsavel].ID_Responsavel = " + Id_Responsavel);
            }

            //string sqlCommand = @"SELECT * FROM Vw_Segmentos Where ID_Responsavel = {0}";
            //sqlCommand = String.Format(sqlCommand, Id_Responsavel);

            List<Segmento> list = new List<Segmento>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            Segmento _objTodos = new Segmento();
            _objTodos.Codigo = "";
            _objTodos.IdSegmento = 0;
            list.Add(_objTodos);


            foreach (DataRow row in result.Rows)
                list.Add(new Segmento(row));

            return list;
        }
        #endregion

        #region [ Boletador ]
        public static List<Boletador> buscarBoletador()
        {
            string sqlCommand = SharedData.GetQueryDefinition("Vw_Boletador");
            //string sqlCommand = @"SELECT * FROM Vw_Boletador";
            List<Boletador> list = new List<Boletador>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            if (result.Rows.Count > 0)
            {
                Boletador _objTodos = new Boletador();
                _objTodos.NomeBoletador = "";
                _objTodos.IdBoletador = 0;
                list.Add(_objTodos);
            }

            foreach (DataRow row in result.Rows)
                list.Add(new Boletador(row));

            return list;
        }
        public static List<ListaArquivos> buscarListaArquivos(string tipoArquivo, int IdObjeto, string segmento)
        {
            string sqlCommand = string.Format(@"SELECT * FROM Vw_Arquivos where TipoArquivo = '{0}' and IdObjeto = {1} and COD_SEGMENTO = '{2}'", tipoArquivo, IdObjeto, segmento);
            List<ListaArquivos> list = new List<ListaArquivos>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            ListaArquivos _objTodos = new ListaArquivos();
            _objTodos.NomeArquivo = "";
            _objTodos.IdArquivo = 0;
            list.Add(_objTodos);


            foreach (DataRow row in result.Rows)
                list.Add(new ListaArquivos(row));

            return list;
        }
        #endregion
        #endregion

        #region [ Validações ]
        public static int BuscarIDServico(DateTime CreationDate)
        {
            string sqlCommand = string.Format("SELECT MAX(ID_Servico) FROM tb_0125_Servico WHERE Usuario = '{0}' AND DataCriacao = #{1}#", Environment.UserName.ToUpper(), CreationDate.ToString("yyyy/MM/dd HH:mm:ss"));
            int maiorId = 0;

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            if (result.Rows.Count > 0)
            {
                maiorId = Convert.ToInt32(result.Rows[0][0]);
            }

            return maiorId;
        }
        public static int BuscarIDServico(string ServicoName)
        {
            string sqlCommand = string.Format("SELECT ID_Servico FROM tb_0125_Servico WHERE ServicoName = '{0}'", ServicoName);
            int maiorId = 0;

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            if (result != null && result.Rows.Count > 0)
                maiorId = Convert.ToInt32(result.Rows[0][0]);
            
            return maiorId;
        }
        public static bool VerificaServicoExistente(string ServicoName)
        {
            string sqlCommand = string.Format("Select [ServicoName] FROM tb_0125_Servico WHERE [ServicoName] = '{0}'", ServicoName);//[Concluido] = {0} AND [Cancelado] = {1} "False", "False"
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            if (result.Rows.Count > 0)
                return true;
            else
                return false;

        }
        #endregion

        #region [ Salvar Operação ]
        #region [ Salvar ]
        public static void ConcluirServico(int idServico, string SistemaLog = "")
        {
            StringBuilder sb_LogServico = new StringBuilder();

            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            
            string msgLog = "Concluindo o servico " + idServico + ".";
            Log.GravaLog(msgLog, SistemaLog);

            string sqlCommand = string.Format("Update tb_0125_Servico Set Concluido = true, DataConclusao = #{0}#, UsuarioConclusao = '{1}' Where Id_Servico = {2} ", datahora, Environment.UserName.ToUpper(), idServico);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            sb_LogServico.AppendLine(Log.MontaLogServico("Servico", idServico, 0, 0, "CONCLUIDO", SistemaLog, datahora, "Update"));
            if (sb_LogServico.ToString() != "")
                Log.GravaLogServico(sb_LogServico.ToString(), idServico);
        }
        public static void DesConcluirServico(int idServico, string SistemaLog = "")
        {
            StringBuilder sb_LogServico = new StringBuilder();

            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

            string msgLog = "DesConcluindo o servico " + idServico + ".";
            Log.GravaLog(msgLog, SistemaLog);

            string sqlCommand = string.Format("Update tb_0125_Servico Set Concluido = false, DataConclusao = null, UsuarioConclusao = null Where Id_Servico = {0} ", idServico);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDdados");

            sb_LogServico.AppendLine(Log.MontaLogServico("Servico", idServico, 0, 0, "DESCONCLUIDO", SistemaLog, datahora, "Update"));
            if (sb_LogServico.ToString() != "")
                Log.GravaLogServico(sb_LogServico.ToString(), idServico);
        }
        
        public static int SalvarServico(int segmento, int produto, string Identificacao, bool prioridade, DateTime DataCadastro, string SistemaLog = "")
        {
            StringBuilder sb_LogServico = new StringBuilder();

            string datahora = DataCadastro.ToString("yyyy/MM/dd HH:mm:ss");

            string msgLog = "Registrando serviço " + produto + "/" + segmento + "/" + Identificacao + ".";
            Log.GravaLog(msgLog, SistemaLog);

            int IdServico = 0;
            string sqlCommand = string.Format("INSERT INTO tb_0125_Servico (ID_Objeto, DataCriacao, Usuario, ServicoName, ID_SEGMENTO, Prioridade) VALUES ({0}, '{1}', '{2}', '{3}', {4}, {5})", produto, datahora, Environment.UserName.ToUpper(), Identificacao.Replace("'", "''").Replace("\"", "\"\"").Trim(), segmento, prioridade);
            Log.GravaLog(sqlCommand, SistemaLog);

            int i = 0;
            while (i < 5)
            {
                try
                {
                    Log.GravaLog("Tentativa: " + i + 1, SistemaLog);
                    DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

                    IdServico = DataAccess.BuscarIDServico(Convert.ToDateTime(datahora));
                    if (IdServico != 0)
                        break;
                }
                catch { }
                Tempo.pausaMilisegundos(800);
                i++;
            }

            if (IdServico != 0)
            {
                sb_LogServico.AppendLine(Log.MontaLogServico("Servico", IdServico, 0, 0, "CRIADO", SistemaLog, datahora, "Insert"));
                sb_LogServico.AppendLine(Log.MontaLogServico("Servico", IdServico, 0, 0, "OBJETO: " + produto.ToString(), SistemaLog, datahora, "Insert"));
                sb_LogServico.AppendLine(Log.MontaLogServico("Servico", IdServico, 0, 0, "DataCriacao: " + DataCadastro.ToString(), SistemaLog, datahora, "Insert"));
                sb_LogServico.AppendLine(Log.MontaLogServico("Servico", IdServico, 0, 0, "ServicoName: " + Identificacao.ToString(), SistemaLog, datahora, "Insert"));
                sb_LogServico.AppendLine(Log.MontaLogServico("Servico", IdServico, 0, 0, "ID_SEGMENTO: " + segmento.ToString(), SistemaLog, datahora, "Insert"));
                sb_LogServico.AppendLine(Log.MontaLogServico("Servico", IdServico, 0, 0, "Prioridade: " + prioridade.ToString(), SistemaLog, datahora, "Insert"));
                if (sb_LogServico.ToString() != "")
                    Log.GravaLogServico(sb_LogServico.ToString(), IdServico);
            }

            return IdServico;
        }
        public static void AtualizarPrioridadeServico(int Id_Servico, bool prioridade, string SistemaLog = "")
        {
            StringBuilder sb_LogServico = new StringBuilder();
            
            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

            string msgLog = string.Format("Atualizando prioridade do servico {0} para {1}", Id_Servico, prioridade);
            Log.GravaLog(msgLog, SistemaLog);

            string sqlCommand = string.Format("UPDATE tb_0125_Servico SET Prioridade = {0}, DataAlteracao = #{1}#, UsuarioAlteracao = '{2}' WHERE ID_Servico = {3}", prioridade, datahora, Environment.UserName.ToUpper(), Id_Servico);
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            sb_LogServico.AppendLine(Log.MontaLogServico("Servico", Id_Servico, 0, 0, "Prioridade: " + prioridade.ToString(), SistemaLog, datahora, "Update"));
            
            if (sb_LogServico.ToString() != "")
                Log.GravaLogServico(sb_LogServico.ToString(), Id_Servico);
        }
        #endregion

        #region [ Deletar ]
        public static void CancelarServico(int idServico, string SistemaLog = "")
        {

            StringBuilder sb_LogServico = new StringBuilder();

            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

            string msgLog = "Cancelamento de servico ID: " + idServico + ".";
            Log.GravaLog(msgLog, SistemaLog);

            string sqlCommand = string.Format("Update tb_0125_Servico Set Cancelado = true, DataCancelamento = '{0}', UsuarioCancelamento = '{1}' where Id_Servico = {2} ", datahora, Environment.UserName.ToUpper(), idServico);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            sb_LogServico.AppendLine(Log.MontaLogServico("Servico", idServico, 0, 0, "CANCELADO", SistemaLog, datahora, "Update"));

            if (sb_LogServico.ToString() != "")
                Log.GravaLogServico(sb_LogServico.ToString(), idServico);

        }
        public static void CancelarServicoLote(List<int> idServico, string SistemaLog = "")
        {
            StringBuilder sb_LogServico = new StringBuilder();

            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

            string sqlCommand = string.Format("Update tb_0125_Servico Set Cancelado = true, DataCancelamento = '{0}', UsuarioCancelamento = '{1}' where ", datahora, Environment.UserName.ToUpper());

            string sqlCommandWhere = "";
                foreach (int IdServ in idServico)
                {
                    sb_LogServico.AppendLine(Log.MontaLogServico("Servico", IdServ, 0, 0, "CANCELADO", SistemaLog, datahora, "Update"));

                    if (sqlCommandWhere == "")
                    {
                        sqlCommandWhere += ("Id_Servico = " + IdServ);
                    }
                    else
                    {
                        sqlCommandWhere += " OR " + ("Id_Servico = " + IdServ);
                    }

                    if (sb_LogServico.ToString() != "")
                        Log.GravaLogServico(sb_LogServico.ToString(), IdServ);

                    sb_LogServico.Clear();

                }

                sqlCommand += sqlCommandWhere;

            string msgLog = "Cancelamento de serviços: " + sqlCommand;
            Log.GravaLog(msgLog, SistemaLog);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            
        }
        public static void ExcluirServico(int IdServico, string SistemaLog = "")
        {
            

            StringBuilder sb_LogServico = new StringBuilder();
            
            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            
            sb_LogServico.AppendLine(Log.MontaLogServico("Servico", IdServico, 0, 0, "EXCLUINDO", SistemaLog, datahora, "Delete"));

            DataAccess.DeletarServico("tb_0125_Servico", "ID_Servico", IdServico, "BDconsulta", SistemaLog);
            DataAccess.DeletarServico("tb_0126_DadosServico", "ID_Servico", IdServico, "BDconsulta", SistemaLog);
            DataAccess.DeletarServico("tb_0127_FluxoServico", "ID_Servico", IdServico, "BDconsulta", SistemaLog);
            DataAccess.DeletarServico("tb_0128_FollowUpEtapaServico", "ID_Servico", IdServico, "BDconsulta", SistemaLog);
            DataAccess.DeletarServico("tb_0128_FollowUpEtapaServico", "ID_Servico", IdServico, "BDconsulta", SistemaLog);
            DataAccess.DeletarServico("tb_0132_DadosStatusEtapas", "ID_Servico", IdServico, "BDconsulta", SistemaLog);

            sb_LogServico.AppendLine(Log.MontaLogServico("Servico", IdServico, 0, 0, "EXCLUIDO", SistemaLog, datahora, "Delete"));

            if (sb_LogServico.ToString() != "")
            {
                Log.GravaLogServico(sb_LogServico.ToString(), IdServico);
                Log.MoveLogServicoExcluido(IdServico);
            }
        }
        public static void DeletarServico(string tabela, string coluna, int IdServico, string BD, string SistemaLog ="")
        {
            string sqlCommand = string.Format("DELETE * FROM {0} WHERE {1} = {2}", tabela, coluna, IdServico);
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, BD);

            string msgLog = sqlCommand;
            Log.GravaLog(msgLog, SistemaLog);
        }
        public static void ExcluirServicoLote(List<int> IdServico, string SistemaLog = "")
        {
            StringBuilder sb_LogServico = new StringBuilder();
            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            foreach (int s in IdServico)
            {
                sb_LogServico.AppendLine(Log.MontaLogServico("Servico", s, 0, 0, "EXCLUINDO", SistemaLog, datahora, "Delete"));
                if (sb_LogServico.ToString() != "")
                    Log.GravaLogServico(sb_LogServico.ToString(), s);
                sb_LogServico.Clear();
            }
            
            DataAccess.DeletarServicoLote("tb_0125_Servico", "ID_Servico", IdServico, "BDconsulta", SistemaLog);
            DataAccess.DeletarServicoLote("tb_0126_DadosServico", "ID_Servico", IdServico, "BDconsulta", SistemaLog);
            DataAccess.DeletarServicoLote("tb_0127_FluxoServico", "ID_Servico", IdServico, "BDconsulta", SistemaLog);
            DataAccess.DeletarServicoLote("tb_0128_FollowUpEtapaServico", "ID_Servico", IdServico, "BDconsulta", SistemaLog);
            DataAccess.DeletarServicoLote("tb_0131_ContaVinculada", "ID_Servico", IdServico, "BDconsulta", SistemaLog);
            DataAccess.DeletarServicoLote("tb_0132_DadosStatusEtapas", "ID_Servico", IdServico, "BDconsulta", SistemaLog);

            foreach (int s in IdServico)
            {
                sb_LogServico.AppendLine(Log.MontaLogServico("Servico", s, 0, 0, "EXCLUIDO", SistemaLog, datahora, "Delete"));
                if (sb_LogServico.ToString() != "")
                {
                    Log.GravaLogServico(sb_LogServico.ToString(), s);
                    Log.MoveLogServicoExcluido(s);
                }
                sb_LogServico.Clear();
            }
        }
        public static void DeletarServicoLote(string tabela, string coluna, List<int> IdServico, string BD, string SistemaLog = "")
        {
            if (IdServico.Count > 0)
            {
                string sqlCommand = string.Format("DELETE * FROM {0} WHERE ", tabela);
                
                string sqlCommandWhere = "";
                foreach (int IdServ in IdServico)
                {
                    if (sqlCommandWhere == "")
                    {
                        sqlCommandWhere += (coluna + " = " + IdServ);
                    }
                    else
                    {
                        sqlCommandWhere += " OR " + (coluna + " = " + IdServ);
                    }
                }

                sqlCommand += sqlCommandWhere;

                string msgLog = sqlCommand;
                Log.GravaLog(msgLog, SistemaLog);

                DataTable result = DataConnector.ExecuteDataTable(sqlCommand, BD);
            }
        }
        public static void DeletarDadosTabela(String tabela, string coluna, int IdServico, string BD, int IdCampo, string SistemaLog = "")
        {
            string sqlCommand = string.Format("DELETE * FROM {0} WHERE {1} = {2} and IdCampo = {3}", tabela, coluna, IdServico, IdCampo);
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, BD);

            string msgLog = sqlCommand;
            Log.GravaLog(msgLog, SistemaLog);

        }
        public static void DeletarDadosTabelaLinha(String tabela, string BD, int IdCampo, int Linha, int IdServico = 0, string SistemaLog = "")
        {
            string sqlCommand = "";
            if (IdServico != 0)
            {
                sqlCommand = string.Format("DELETE * FROM {0} WHERE IdServico = {1} and IdCampo = {2} and Linha = '{3}'", tabela, IdServico, IdCampo, Linha);
            }
            else
            {
                sqlCommand = string.Format("DELETE * FROM {0} WHERE IdCampo = {1} and Linha = '{2}'", tabela, IdCampo, Linha);
            }
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, BD);

            string msgLog = sqlCommand + " Usuário Responsável: " + Environment.UserName.ToUpper();
            Log.GravaLog(msgLog, SistemaLog);

        }
        public static void DeletarTodasLinhasDadosTabelaByServico(String tabela, string BD, int IdCampo, int IdServico, string SistemaLog = "")
        {
            string sqlCommand = "";
            if (IdServico != 0)
            {
                sqlCommand = string.Format("DELETE * FROM {0} WHERE IdServico = {1} and IdCampo = {2} ", tabela, IdServico, IdCampo);
            }

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, BD);

            string msgLog = sqlCommand;
            Log.GravaLog(msgLog, SistemaLog);

        }
        public static void DeletarServicoString(String tabela, string coluna, string criterio, string BD, string SistemaLog = "")
        {
            string sqlCommand = string.Format("DELETE * FROM {0} WHERE {1} = '{2}'", tabela, coluna, criterio);
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, BD);

            string msgLog = sqlCommand;
            Log.GravaLog(msgLog, SistemaLog);

        }
        #endregion
        #endregion
        #endregion

        #region [ Minutas ]
        public static List<Minuta> buscarMinutas(int ID_Objeto, string NomeSegmento, List<Campos> CamposCriterios = null)
        {
            string sqlCommand = string.Format("SELECT * FROM vw_Minutas Where IdObjeto = {0} And COD_SEGMENTO = '{1}'", ID_Objeto, NomeSegmento);
            List<Minuta> list = new List<Minuta>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            Minuta _objTodos = new Minuta();
            _objTodos.NomeMinuta = "";
            _objTodos.IdMinuta = 0;
            _objTodos.IdObjeto = 0;
            list.Add(_objTodos);
            
            foreach (DataRow row in result.Rows)
                list.Add(new Minuta(row));

            if (CamposCriterios != null)
            {
                List<Minuta> l = list.Where(n => n.CamposCriterios != "" && n.IdMinuta != 0).ToList();
                List<Minuta> removerMinuta = new List<Minuta>();
                foreach (Minuta m in l)
                {
                    string[] criterios = m.CamposCriterios.Split(';');
                    string[] valores = m.ValoresCriterios.Split(';');
                    for (int i = 0; i < criterios.Count(); i++)
                    { 
                        if (!CamposCriterios.Exists(n => n.ID_Campo == Convert.ToInt32(criterios[i]) && n.ValorCampo == valores[i]))
                        {
                            removerMinuta.Add(m);
                            break;
                        }
                    }
                }

                if (removerMinuta.Count > 0)
                {
                    foreach (Minuta m in removerMinuta)
                        list.Remove(m);
                }

            }


            return list;
        }
        public static List<DadosMinuta> BuscaDadosMinutas(int ID_Objeto, int ID_Minuta)
        {
            string sqlCommand = string.Format("SELECT * FROM vw_MinutasDados Where IdObjeto = {0} AND IdMinuta = {1}", ID_Objeto, ID_Minuta);
            List<DadosMinuta> list = new List<DadosMinuta>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new DadosMinuta(row));

            return list;
        }
        public static string BuscarMoeda(string Moeda, string Campo, string Idioma, string SingPlural)
        {
            string sqlCommand = string.Format("SELECT [{0}] FROM tb_0604_MoedaMinuta Where Moeda = '{1}' AND Idioma = '{2}' AND SingPlural = '{3}' ", Campo, Moeda, Idioma, SingPlural);
            List<DadosMinuta> list = new List<DadosMinuta>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            if (result.Rows.Count > 0)
                return result.Rows[0][0].ToString();
            else
                return "[#Moeda não cadastrada#]";
        }
        public static List<MinutaDOC> buscarMinutasDoc()
        {
            string sqlCommand = string.Format("SELECT * FROM vw_MinutasDOC");
            List<MinutaDOC> list = new List<MinutaDOC>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            MinutaDOC _objTodos = new MinutaDOC();
            _objTodos.nomeDOC = "";
            _objTodos.idDOC = 0;
            list.Add(_objTodos);

            foreach (DataRow row in result.Rows)
                list.Add(new MinutaDOC(row));

            return list;
        }
        public static string BuscaDevedoresSolidariosMinutas(int IdServico, string campos, string valorCampo)
        {
            string sqlCommand = string.Format("SELECT * FROM vw_DevedorSolidario where ID_Servico = {0}", IdServico);
            string list = "";

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            string[] CamposArray = campos.Split(';');

            int i = 1;
            foreach (DataRow row in result.Rows)
            {
                foreach (string campo in CamposArray)
                {
                    if (list != "")
                    {
                        if (valorCampo != "" && valorCampo != null)
                        {
                            if (campo != "" && campo != null)
                            {
                                list = list + " " + valorCampo + " " + row[campo].ToString();
                            }
                            else
                            {
                                list = list + " " + valorCampo;
                            }
                        }
                        else
                        {
                            if (campo != "" && campo != null)
                            {
                                list = list + " " + row[campo].ToString();
                            }
                        }
                    }
                    else
                    {
                        if (valorCampo != "" && valorCampo != null)
                        {
                            if (campo != "" && campo != null)
                            {
                                list = valorCampo + " " + row[campo].ToString();
                            }
                            else
                            {
                                list = valorCampo;
                            }
                        }
                        else
                        {
                            if (campo != "" && campo != null)
                            {
                                list = row[campo].ToString();
                            }
                        }
                    }
                }
                i++;
                if (i <= result.Rows.Count)
                {
                    list = list + ";";
                }
            }

            return list;
        }
        public static int BuscaQTDDevedoresSolidariosMinutas(int IdServico, string campos, string valorCampo)
        {
            string sqlCommand = string.Format("SELECT * FROM vw_DevedorSolidario where ID_Servico = {0}", IdServico);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            return result.Rows.Count;
        }
        public static string BuscaTabelaMinuta(int IdServico, int IdCampo, string campos, string valorCampo, string View = "")
        {
            string list = "";

            DataTable result = DataAccess.BuscarTabela(IdServico, IdCampo);

            if (View != "" && result.Rows.Count > 0)
            {
                DataRow[] resultRows = result.Select(View);
                if (resultRows.Count() > 0)
                    result = resultRows.CopyToDataTable();
                else
                    result = new DataTable();
            }

            string[] CamposArray = campos.Split(';');

            int i = 1;
            foreach (DataRow row in result.Rows)
            {
                foreach (string campo in CamposArray)
                {
                    if (list != "")
                    {
                        if (valorCampo != "" && valorCampo != null)
                        {
                            if (campo != "" && campo != null)
                            {
                                list = list + " " + valorCampo + " " + row[campo].ToString();
                            }
                            else
                            {
                                list = list + " " + valorCampo;
                            }
                        }
                        else
                        {
                            if (campo != "" && campo != null)
                            {
                                list = list + " " + row[campo].ToString();
                            }
                        }
                    }
                    else
                    {
                        if (valorCampo != "" && valorCampo != null)
                        {
                            if (campo != "" && campo != null)
                            {
                                list = valorCampo + " " + row[campo].ToString();
                            }
                            else
                            {
                                list = valorCampo;
                            }
                        }
                        else
                        {
                            if (campo != "" && campo != null)
                            {
                                list = row[campo].ToString();
                            }
                        }
                    }
                }
                i++;
                if (i <= result.Rows.Count)
                {
                    list = list + ";";
                }
            }

            return list;
        }
        public static int BuscaTabelaQTD(int IdServico, int IdCampo, string campos, string valorCampo, string View)
        {
            DataTable result = DataAccess.BuscarTabela(IdServico, IdCampo);

            if (View != "" && result.Rows.Count > 0)
            {
                DataRow[] resultRows = result.Select(View);
                if (resultRows.Count() > 0)
                    result = resultRows.CopyToDataTable();
                else
                    result = new DataTable();
            }

            return result.Rows.Count;
        }
        public static string BuscaValorCampoBoletoBEN(string boleto, string campos, string valorCampo)
        {
            string list = "";
            if (boleto != null && boleto != "")
            {
                string sqlCommand = string.Format("SELECT [{0}] FROM tb_0210_BoletoBen where [{1}] = '{2}'", valorCampo, campos, boleto);

                DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

                list = result.Rows[0][0].ToString();
            }
            return list;

        }
        #endregion

        #region [ Telas ]
        public static DataTable GetTelas()
        {
            string sqlCommand = "Select * from tb_0300_Telas Where Ativo = true";

            return DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
        }
        public static string GetTelasMethod(string Tela)
        {
            string sqlCommand = "Select Method_Invoke from tb_0300_Telas Where NomeTela = '" + Tela + "'";
            DataTable dt = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            if (dt.Rows.Count > 0)
            {
                return dt.Rows[0][0].ToString();
            }
            else
                return "";
        }
        #endregion

        #region [ Integrações ]
        #region [ SharePoint ]
        public static List<SharePointParametrosRetorno> BuscaParametrosSharePoint()
        {
            string sqlCommand = String.Format(@"SELECT * FROM vw_RetornoSharePoint");

            List<SharePointParametrosRetorno> list = new List<SharePointParametrosRetorno>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new SharePointParametrosRetorno(row));

            return list;
        }
        
        public static string BuscaURLsharepoint(string NomeSP, string NomeServico)
        {
            string sqlCommand = string.Format("SELECT distinct [SharePointURL] FROM tb_0403_GarantiasDiretorioSharePoint Where SharePoint = '{0}'", NomeSP);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            //return result.Rows[0][0].ToString().Replace("[#ServicoName#]", NomeServico);
            return result.Rows[0][0].ToString();
        }

        public static List<GarantiasValorSP> buscarValoresGarantiasSP(Int32 IdObjeto, string SpNome)
        {
            string sqlCommand = string.Format("SELECT * FROM tb_0402_GarantiasSharePointValores Where ID_Objeto = {0} And SharePoint = '{1}'", IdObjeto, SpNome);
            List<GarantiasValorSP> list = new List<GarantiasValorSP>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new GarantiasValorSP(row));

            return list;
        }
        public static List<TiposGarantias> buscarTiposGarantias(Int32 idservico, string SpNome)
        {
            string sqlCommand = string.Format("SELECT DISTINCT [TIPO_GARANTIA], [BEM_GARANTIA], [NATUREZA_GARANTIA], [SharePointTemplate], [SharePointDiretorio] FROM vw_GarantiasSharePoint Where ID_Servico = {0} And SharePoint = '{1}'", idservico, SpNome);
            List<TiposGarantias> list = new List<TiposGarantias>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new TiposGarantias(row));

            return list;
        }
        public static List<IntegrarGarantiasSP> buscarDadosGarantias(Int32 idservico, string SpNome)
        {
            string sqlCommand = string.Format("SELECT * FROM vw_GarantiasSharePoint Where ID_Servico = {0} And SharePoint = '{1}'", idservico, SpNome);
            List<IntegrarGarantiasSP> list = new List<IntegrarGarantiasSP>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new IntegrarGarantiasSP(row));

            return list;
        }
        #endregion

        public static List<TraducaoValoresImportados> BuscaTraducaoValoresImportados(string Identificador = "")
        {
            string sqlCommand = "";

            if (Identificador == "")
            {
                sqlCommand = String.Format(@"SELECT * FROM tb_0406_ServicosSharePointValores where Ativo = true");
            }
            else
            {
                sqlCommand = String.Format(@"SELECT * FROM tb_0406_ServicosSharePointValores where Ativo = true AND SharePoint = '{0}'", Identificador);
            }
            List<TraducaoValoresImportados> list = new List<TraducaoValoresImportados>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new TraducaoValoresImportados(row));

            return list;
        }
        public static List<SharePointServicoRetorno> BuscaParametrosServicoImportados(string TipoImportacao)
        {
            string sqlCommand = String.Format(@"SELECT * FROM vw_RetornoServicoSharePoint where Tipo = '{0}'", TipoImportacao);

            List<SharePointServicoRetorno> list = new List<SharePointServicoRetorno>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new SharePointServicoRetorno(row));

            return list;
        }
        public static void AtualizaDataImportacao(int Id, DateTime DataUltimaRotina)
        {
            string sqlCommand = "UPDATE tb_0405_ServicosSharePoint SET tb_0405_ServicosSharePoint.DataUltimaRotina = #{0}#";
            sqlCommand += "WHERE (tb_0405_ServicosSharePoint.Id={1})";
            sqlCommand = string.Format(sqlCommand, DataUltimaRotina.ToString("yyyy/MM/dd HH:mm:ss"), Id);
                   
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
        }
        #endregion

        #region [ Follow Up ]
        public static List<FollowUp> RecuperaFollowUpServico(int ID_Servico)
        {
            string sqlCommand = SharedData.GetQueryDefinition("vw_FollowUpEtapaServico");
            if (sqlCommand != "")
            {
                sqlCommand = TratamentoSQL.AdicionaWhere(sqlCommand, "[tb_0128_FollowUpEtapaServico].ID_SERVICO = " + ID_Servico);
            }
            sqlCommand += " Order by [tb_0128_FollowUpEtapaServico].DataCriacao Desc";

            List<FollowUp> list = new List<FollowUp>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new FollowUp(row));

            return list;
        }
        public static List<FollowUp> RecuperaFollowUpEtapaServico(int ID_Servico, int ID_Fluxo)
        {
            string sqlCommand = SharedData.GetQueryDefinition("vw_FollowUpEtapaServico");
            if (sqlCommand != "")
            {
                sqlCommand = TratamentoSQL.AdicionaWhere(sqlCommand, "[tb_0128_FollowUpEtapaServico].ID_SERVICO = " + ID_Servico + " AND [tb_0128_FollowUpEtapaServico].ID_FLUXO = " + ID_Fluxo);
            }
            sqlCommand += " Order by [tb_0128_FollowUpEtapaServico].DataCriacao Desc";

            List<FollowUp> list = new List<FollowUp>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new FollowUp(row));

            return list;
        }
        public static FollowUp RecuperaFollowUpEtapaServicoByID(int ID_Follow)
        {
            string sqlCommand = "SELECT * FROM tb_0128_FollowUpEtapaServico Where {0} = {1}";
            sqlCommand = String.Format(sqlCommand, "ID_Follow", ID_Follow);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            if (result.Rows.Count != 0)
                return new FollowUp(result.Rows[0]);
            else
                return null;

        }
        public static void RegistrarFollowUpEtapaServico(FollowUp FollowUpDados, bool UpdValue)
        {
            StringBuilder sb_LogServico = new StringBuilder();
            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            string tipoquery = "Insert";
            if (UpdValue == true)
            {
                 tipoquery = "Update";
                string sqlCommand = "Update tb_0128_FollowUpEtapaServico Set FollowUpEtapa = '{0}', DataAlteracao = #{1}# Where ID_SERVICO = {2} And ID_FLUXO = {3} And ID_FOLLOW = {4}";
                sqlCommand = String.Format(sqlCommand, FollowUpDados.FollowUpEtapa, datahora, FollowUpDados.ID_Servico, FollowUpDados.ID_Fluxo, FollowUpDados.ID_Follow);
                DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            }
            else
            {
                if (FollowUpDados.ID_Campo != 0)
                {
                    string sqlCommand = string.Format("INSERT INTO tb_0128_FollowUpEtapaServico (ID_Servico, ID_Fluxo, ID_Campo, FollowUpEtapa, DataCriacao, DataAlteracao, Login) VALUES ({0}, {1}, {2}, '{3}', #{4}#, #{5}#, '{6}')", FollowUpDados.ID_Servico, FollowUpDados.ID_Fluxo, FollowUpDados.ID_Campo, FollowUpDados.FollowUpEtapa, datahora, datahora, Environment.UserName.ToUpper());
                    DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

                }
                else
                {
                    string sqlCommand = string.Format("INSERT INTO tb_0128_FollowUpEtapaServico (ID_Servico, ID_Fluxo, FollowUpEtapa, DataCriacao, DataAlteracao, Login) VALUES ({0}, {1}, '{2}', #{3}#, #{4}#, '{5}')", FollowUpDados.ID_Servico, FollowUpDados.ID_Fluxo, FollowUpDados.FollowUpEtapa, datahora, datahora, Environment.UserName.ToUpper());
                    DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
                }
            }

            sb_LogServico.AppendLine(Log.MontaLogServico("Follow-Up", FollowUpDados.ID_Servico, FollowUpDados.ID_Fluxo, FollowUpDados.ID_Campo, FollowUpDados.FollowUpEtapa, "", datahora, tipoquery));
            if (sb_LogServico.ToString() != "")
                Log.GravaLogServico(sb_LogServico.ToString(), FollowUpDados.ID_Servico);
        }
        public static void InserirListaFollowUp(List<FollowUp> FollowUpDados)
        {
            StringBuilder sb_LogServico = new StringBuilder();
            
            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

            string sqlCommandInsert = "INSERT INTO tb_0128_FollowUpEtapaServico (ID_Servico, ID_Fluxo, FollowUpEtapa, DataCriacao, DataAlteracao, Login) SELECT * FROM (";
                            
            int auxInsert = 0;
            foreach (FollowUp Fup in FollowUpDados)
            {
                sb_LogServico.AppendLine(Log.MontaLogServico("Follow-Up", Fup.ID_Servico, Fup.ID_Fluxo, Fup.ID_Campo, Fup.FollowUpEtapa, "", datahora, "Insert"));
                sqlCommandInsert = String.Format(sqlCommandInsert + "SELECT {0} As ID_Servico, {1} As ID_Fluxo, '{2}' As FollowUpEtapa, #{3}# As DataCriacao, #{4}# As DataAlteracao, '{5}' As Login FROM tb_0080_AuxInsertDadosServico UNION ", Fup.ID_Servico, Fup.ID_Fluxo, Fup.FollowUpEtapa, datahora, datahora, Environment.UserName.ToUpper());
                auxInsert = auxInsert + 1;
            }

            sqlCommandInsert = sqlCommandInsert.Remove(sqlCommandInsert.Length - 6);
            sqlCommandInsert = sqlCommandInsert + ")";

            if (auxInsert > 0)
            {
                DataTable multirowinsert = DataConnector.ExecuteDataTable(sqlCommandInsert, "BDconsulta");
            }
            if (sb_LogServico.ToString() != "")
                Log.GravaLogServico(sb_LogServico.ToString(), FollowUpDados[0].ID_Servico);
        }
        #endregion

        #region [ Métodos ]
        public static List<ClassListMethod> GetListMethod()
        {
            string sqlCommand = "SELECT * FROM tb_0400_Method Where (CampoAtivo=True) Order By OrdemMethod";
            
            List<ClassListMethod> list = new List<ClassListMethod>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            ClassListMethod _objTodos = new ClassListMethod();
            _objTodos.ID_Method = 0;
            _objTodos.MethodName = "";
            _objTodos.MethodDescricao = "";
            _objTodos.OrdemMethod = 0;
            _objTodos.CriterioCampo = "";
            _objTodos.CriterioValor = "";
            _objTodos.MethodForm = "";
            list.Add(_objTodos);

            // Adiciona retorno da busca
            foreach (DataRow row in result.Rows)
                list.Add(new ClassListMethod(row));

            return list;
        }
        public static List<ClassListMethod> GetListMethod(List<int> IdMethod)
        {
            string sqlCommand = "SELECT * FROM tb_0400_Method Where ";
            string sqlCommandWhere = "";

            foreach (int id in IdMethod)
            {
                if (sqlCommandWhere == "")
                {
                    sqlCommandWhere += "(Id_Method = " + id;
                }
                else
                {
                    sqlCommandWhere += " Or Id_Method = " + id;
                }
            }

            if (sqlCommandWhere == "")
            {
                return null;
            }
            else
            {
                sqlCommandWhere += ") and (CampoAtivo=True) Order By OrdemMethod";
            }

            sqlCommand += sqlCommandWhere;

            List<ClassListMethod> list = new List<ClassListMethod>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            // Adiciona retorno da busca
            foreach (DataRow row in result.Rows)
                list.Add(new ClassListMethod(row));

            return list;
        }
        public static List<ClassListMethod> GetListMethod(int IdEtapa, int IdObjeto)
        {
            string sqlCommand;
            sqlCommand = "SELECT * FROM tb_0400_Method ";
            sqlCommand += "WHERE (Form='Detalhe') AND ((Id_Etapa={0} AND Id_Objeto={1} AND CampoAtivo=True) OR (Id_Etapa=0 AND Id_Objeto={1} AND CampoAtivo=True)) ";
            sqlCommand += "ORDER BY tb_0400_Method.OrdemMethod";

            sqlCommand = String.Format(sqlCommand, IdEtapa, IdObjeto, 0);

            List<ClassListMethod> list = new List<ClassListMethod>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            //Adiciona um vazio
            ClassListMethod _objTodos = new ClassListMethod();
            _objTodos.ID_Method = 0;
            _objTodos.MethodName = "";
            _objTodos.MethodDescricao = "";
            _objTodos.OrdemMethod = 0;
            _objTodos.CriterioCampo = "";
            _objTodos.CriterioValor = "";
            _objTodos.MethodForm = "";
            list.Add(_objTodos);

            // Adiciona retorno da busca
            foreach (DataRow row in result.Rows)
                list.Add(new ClassListMethod(row));

            return list;
        }
        public static List<ClassListMethod> GetListMethodDetalhe(int IdObjeto)
        {
            string sqlCommand = "SELECT * FROM tb_0400_Method Where ";
            sqlCommand += "(Id_Objeto=" + IdObjeto + " And CampoAtivo=True AND Form='Detalhe') Order By OrdemMethod";

            List<ClassListMethod> list = new List<ClassListMethod>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            //Adiciona um vazio
            ClassListMethod _objTodos = new ClassListMethod();
            _objTodos.ID_Method = 0;
            _objTodos.MethodName = "";
            _objTodos.MethodDescricao = "";
            _objTodos.CriterioCampo = "";
            _objTodos.CriterioValor = "";
            _objTodos.MethodForm = "";
            _objTodos.OrdemMethod = 0;
            list.Add(_objTodos);

            foreach (DataRow row in result.Rows)
                list.Add(new ClassListMethod(row));

            return list;
        }
        public static List<ClassListMethod> GetListMethodMinuta(int IdObjeto, int IdMetodoRef = 0)
        {
            string sqlCommand;
            sqlCommand = "SELECT * FROM tb_0400_Method ";
            sqlCommand += "WHERE (Id_Objeto={0} AND IdMethodFormMinuta = {1} AND CampoAtivo=True AND Form='Minuta') ";
            sqlCommand += "ORDER BY tb_0400_Method.OrdemMethod";

            sqlCommand = String.Format(sqlCommand, IdObjeto, IdMetodoRef);

            List<ClassListMethod> list = new List<ClassListMethod>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            //Adiciona um vazio
            ClassListMethod _objTodos = new ClassListMethod();
            _objTodos.ID_Method = 0;
            _objTodos.MethodName = "";
            _objTodos.MethodDescricao = "";
            _objTodos.OrdemMethod = 0;
            _objTodos.CriterioCampo = "";
            _objTodos.CriterioValor = "";
            _objTodos.MethodForm = "";
            list.Add(_objTodos);

            // Adiciona retorno da busca
            foreach (DataRow row in result.Rows)
                list.Add(new ClassListMethod(row));

            return list;
        }
        public static List<ClassListMethod> GetListMethodPipeline()
        {
            string sqlCommand = "SELECT * FROM tb_0400_Method Where ";
            sqlCommand += "(CampoAtivo=True AND Form='Pipeline') Order By OrdemMethod";

            List<ClassListMethod> list = new List<ClassListMethod>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            //Adiciona um vazio
            ClassListMethod _objTodos = new ClassListMethod();
            _objTodos.ID_Method = 0;
            _objTodos.MethodName = "";
            _objTodos.MethodDescricao = "";
            _objTodos.OrdemMethod = 0;
            _objTodos.CriterioCampo = "";
            _objTodos.CriterioValor = "";
            _objTodos.MethodForm = "";
            list.Add(_objTodos);

            foreach (DataRow row in result.Rows)
                list.Add(new ClassListMethod(row));

            return list;
        }
        public static List<ClassListMethod> GetListMethodMain()
        {
            string sqlCommand = "SELECT * FROM tb_0400_Method Where ";
            sqlCommand += "(CampoAtivo=True AND Form='Main') Order By OrdemMethod";

            List<ClassListMethod> list = new List<ClassListMethod>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new ClassListMethod(row));

            return list;
        }
        public static List<ClassListMethod> GetListMethodFollowUp()
        {
            string sqlCommand = "SELECT * FROM tb_0400_Method Where ";
            sqlCommand += "(CampoAtivo=True AND Form='FollowUp') Order By OrdemMethod";

            List<ClassListMethod> list = new List<ClassListMethod>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            ClassListMethod _objTodos = new ClassListMethod();
            _objTodos.ID_Method = 0;
            _objTodos.MethodName = "";
            _objTodos.MethodDescricao = "";
            _objTodos.OrdemMethod = 0;
            _objTodos.CriterioCampo = "";
            _objTodos.CriterioValor = "";
            _objTodos.MethodForm = "";
            list.Add(_objTodos);

            foreach (DataRow row in result.Rows)
                list.Add(new ClassListMethod(row));

            return list;
        }
        public static DataTable BuscarLinhasPtaxByData(int idCampo, string Data)
        {
            string sql = "SELECT * ";
            sql += "FROM tb_0134_DadosTabela ";
            sql += "WHERE IdCampo= " + idCampo + "";
            sql += " AND ValorCampo = '" + Data + "'";

            string sqlCommand = sql;

            DataTable dt = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            return dt;

        }
        #endregion

        //---------------------------------------- Validar grupos abaixo

        #region [ Relatorios ]
        public static void GravarIndicadorStatus(int ID_Servico, int ID_Etapa, int ID_Status, DateTime DataHora, string SistemaLog = "")
        {
            string datahora = DataHora.ToString("yyyy/MM/dd HH:mm:ss");
            string msgLog = "Gravando Indicador Status " + ID_Servico + "/" + ID_Etapa + "/" + ID_Status + ".";
            Log.GravaLog(msgLog, SistemaLog);

            string sqlCommand = string.Format("INSERT INTO tb_0132_DadosStatusEtapas (ID_Servico, ID_Etapa, ID_Status, DataAlteracao, Responsavel) VALUES ({0}, {1}, {2}, #{3}#, '{4}')", ID_Servico, ID_Etapa, ID_Status, datahora, Environment.UserName.ToUpper());
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

        }
        public static void GravarIndicadorStatusLote(int ID_Servico, List<FluxoServico> fluxo, DateTime DataHora, string SistemaLog = "")
        {
            string datahora = DataHora.ToString("yyyy/MM/dd HH:mm:ss");

            string sqlCommandInsert = "INSERT INTO tb_0132_DadosStatusEtapas (ID_Servico, ID_Etapa, ID_Status, DataAlteracao, Responsavel) SELECT * FROM ("; 

            int auxInsert = 0;
            foreach (FluxoServico flx in fluxo)
            {
                sqlCommandInsert = String.Format(sqlCommandInsert + "SELECT {0} As ID_Servico, {1} As ID_Etapa, {2} As ID_Status, #{3}# As DataAlteracao, '{4}' As Responsavel FROM tb_0080_AuxInsertDadosServico UNION ", ID_Servico, flx.ID_Fluxo, flx.ID_Status, datahora, Environment.UserName.ToUpper());
                auxInsert = auxInsert + 1;

                if (auxInsert == 30)
                {
                    sqlCommandInsert = sqlCommandInsert.Remove(sqlCommandInsert.Length - 6);
                    sqlCommandInsert = sqlCommandInsert + ")";

                    DataTable multirowinsert = DataConnector.ExecuteDataTable(sqlCommandInsert, "BDconsulta");

                    sqlCommandInsert = "INSERT INTO tb_0132_DadosStatusEtapas (ID_Servico, ID_Etapa, ID_Status, DataAlteracao, Responsavel) SELECT * FROM (";

                    auxInsert = 0;
                }
            }

            sqlCommandInsert = sqlCommandInsert.Remove(sqlCommandInsert.Length - 6);
            sqlCommandInsert = sqlCommandInsert + ")";

            if (auxInsert > 0)
            {
                string msgLog = "Salvando indicadores de status de etapa: " + sqlCommandInsert;
                Log.GravaLog(msgLog, SistemaLog);
                DataTable multirowinsert = DataConnector.ExecuteDataTable(sqlCommandInsert, "BDconsulta");
            }
        }

        public static string RecupertaIndicadorServico(int idServico, string itemIndicador)
        {
            string sqlCommand = "SELECT Distinct Valor From TB_0500_Indicadores where idServico = {0} And ItemIndicador = '{1}'";
            sqlCommand = string.Format(sqlCommand, Convert.ToInt32(idServico), itemIndicador);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            if (result.Rows.Count != 0)
                return (result.Rows[0][0].ToString());
            else
                return "";
        }
        public static void IncluirIndicador(string idServico, string tipoIndicador, string Regra, string itemIndicador, string valorCampo, string chaveTimeStamp = "")
        {
            //Insere Indicador
            string sqlCommand = "";
            try
            {
                if (valorCampo != "") // se vier valor vazio, não faz nada.
                {
                    // Recupera o valor indicador
                    string ValorIndicador = RecupertaIndicadorServico(Convert.ToInt32(idServico), itemIndicador);

                    // Se valor ValorIndicador for nulo, incluo porque ainda não tem valor de referência;
                    if (ValorIndicador == "")
                    {
                        if (Regra == "CONTAR")
                        {
                            sqlCommand = "INSERT INTO tb_0500_Indicadores(idServico, TipoIndicador, ItemIndicador, Valor, DataGeracao, Chave) VALUES ({0}, '{1}', '{2}', '{3}', '{4}', '{5}')";
                            sqlCommand = string.Format(sqlCommand, Convert.ToInt32(idServico), tipoIndicador, itemIndicador, "1", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"), chaveTimeStamp);
                        }
                        else
                        {
                            sqlCommand = "INSERT INTO tb_0500_Indicadores(idServico, TipoIndicador, ItemIndicador, Valor, DataGeracao, Chave) VALUES ({0}, '{1}', '{2}', '{3}', '{4}' , '{5}')";
                            sqlCommand = string.Format(sqlCommand, Convert.ToInt32(idServico), tipoIndicador, itemIndicador, valorCampo, DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"), chaveTimeStamp);
                        }
                    }
                    else
                    {
                        if (Regra == "CONTAR")
                        {
                            ValorIndicador = (Convert.ToInt32(ValorIndicador) + 1).ToString();
                            sqlCommand = "UPDATE tb_0500_Indicadores SET Valor = '{0}' Where IdServico = {1} And ItemIndicador = '{2}'";
                            sqlCommand = string.Format(sqlCommand, ValorIndicador, Convert.ToInt32(idServico), itemIndicador);
                        }
                        else if (Regra == "MINIMO")
                        {
                            ValorIndicador = ((Convert.ToDateTime(ValorIndicador) < Convert.ToDateTime(valorCampo)) ? ValorIndicador : valorCampo);
                            sqlCommand = "UPDATE tb_0500_Indicadores SET Valor = '{0}' Where IdServico = {1} And ItemIndicador = '{2}'";
                            sqlCommand = string.Format(sqlCommand, ValorIndicador, Convert.ToInt32(idServico), itemIndicador);
                        }
                        else if (Regra == "MAXIMO")
                        {
                            ValorIndicador = ((Convert.ToDateTime(ValorIndicador) > Convert.ToDateTime(valorCampo)) ? ValorIndicador : valorCampo);
                            sqlCommand = "UPDATE tb_0500_Indicadores SET Valor = '{0}' Where IdServico = {1} And ItemIndicador = '{2}'";
                            sqlCommand = string.Format(sqlCommand, ValorIndicador, Convert.ToInt32(idServico), itemIndicador);
                        }
                        else if (Regra == "INSERT")
                        {
                            ValorIndicador = valorCampo;
                            sqlCommand = "INSERT INTO tb_0500_Indicadores(idServico, TipoIndicador, ItemIndicador, Valor, DataGeracao, Chave) VALUES ({0}, '{1}', '{2}', '{3}', '{4}', '{5}')";
                            sqlCommand = string.Format(sqlCommand, Convert.ToInt32(idServico), tipoIndicador, itemIndicador, valorCampo, DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"), chaveTimeStamp);
                        }
                        else if (Regra == "UPDATE")
                        {
                            ValorIndicador = valorCampo;
                            sqlCommand = "UPDATE tb_0500_Indicadores SET Valor = '{0}' Where IdServico = {1} And ItemIndicador = '{2}'";
                            sqlCommand = string.Format(sqlCommand, ValorIndicador, Convert.ToInt32(idServico), itemIndicador);
                        }
                        else // pensar melhor
                        {
                            ValorIndicador = valorCampo;
                            sqlCommand = "UPDATE tb_0500_Indicadores SET Valor = '{0}' Where IdServico = {1} And ItemIndicador = '{2}'";
                            sqlCommand = string.Format(sqlCommand, ValorIndicador, Convert.ToInt32(idServico), itemIndicador);
                        }
                    }
                }
                // Executa
                if (sqlCommand != "")
                {
                    DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public static DataTable Listagem(int IdServico, DateTime dtInicio, DateTime dtFim)
        {
            string sqlCommand;
            string DataFimCompleta = dtFim.ToString("yyyy/MM/dd") + " 23:59";

            if (IdServico != 0)
            {
                sqlCommand = "SELECT * FROM vw_IndicadorLista Where Id_Servico = {0} ";
                sqlCommand = String.Format(sqlCommand, IdServico);
            }
            else
            {
                sqlCommand = "SELECT * FROM vw_IndicadorLista Where DataCriacao Between #{0}# And #{1}# ";
                sqlCommand = String.Format(sqlCommand, dtInicio.ToString("yyyy/MM/dd"), DataFimCompleta);
            }

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            return result;

        }
        public static DataTable GetRelatorio(string relName)
        {
            string sqlCommand = string.Format("Select * from tb_0300_Relatorios where Nome = '{0}'", relName);

            DataTable dt = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            if (dt.Rows.Count > 0)
            {
                sqlCommand = "Select * from " + dt.Rows[0][0];

                return DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            }

            return null;
        }
        public static DataTable GetIndicadoresEtapas(int IdServico)
        {
            string sqlCommand = string.Format("SELECT * FROM vw_IndicadorEtapas WHERE ID_Servico = {0}", IdServico);

            DataTable dt = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            return dt;
        }
        public static DataTable GetIndicadoresDados(int IdServico)
        {
            string sqlCommand = string.Format("SELECT * FROM vw_IndicadorDados WHERE ID_Servico = {0}", IdServico);

            DataTable dt = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            return dt;
        }
        public static DataTable GetRelatorioParm(string relName, DateTime dtInicio, DateTime dtFim)
        {
            string sqlCommand = string.Format("Select * from tb_0300_Relatorios where Nome = '{0}'", relName);

            DataTable dt = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            if (dt.Rows.Count > 0)
            {
                string DataFimCompleta = dtFim.ToString("yyyy/MM/dd") + " 23:59";
                if (dt.Rows[0][3].ToString() != "")
                {
                    sqlCommand = "Select * from " + dt.Rows[0][0] + " Where " + dt.Rows[0][3] + " Between #" + dtInicio.ToString("yyyy/MM/dd") + "# And #" + DataFimCompleta + "# "; ;
                }
                else
                {
                    sqlCommand = "Select * from " + dt.Rows[0][0];
                }

                return DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            }

            return null;
        }
        public static DataTable GetRelatorios()
        {
            string sqlCommand = "Select * from tb_0300_Relatorios Where Ativo = true";

            return DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
        }
        #endregion

        #region [Email Form parâmetros]
        /// <summary>
        /// Recupera Dados para criação dos e-mails
        /// </summary>
        /// <returns></returns>
        public static List<ClassListEmail> RetornaParametrosFormEmail(string parmEmail)
        {
            string sqlCommand = @"Select * From tb_0140_EmailParametros Where emailParametro = '{0}'";
            sqlCommand = String.Format(sqlCommand, parmEmail);

            List<ClassListEmail> list = new List<ClassListEmail>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new ClassListEmail(row));

            return list;
        }

        public static List<string> RetornaEmailsCannotRead()
        {
            string sqlCommand = @"SELECT * FROM vw_CannotReadEmail";

            List<string> list = new List<string>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(row[0].ToString());

            return list;
        }
        #endregion

        #region [Contas Vinculadas]
        public static List<ContasVinculadasGarantias> BuscarContasVinculadas(int ID_Servico)
        {
            string sqlCommand = String.Format(@"SELECT * FROM tb_0131_ContaVinculada WHERE ID_Servico = {0}", ID_Servico);

            List<ContasVinculadasGarantias> list = new List<ContasVinculadasGarantias>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new ContasVinculadasGarantias(row));

            return list;
        }

        public static void UpdateContasVinculadas(int ID_Servico, string Tipo, string Bem, string Natureza, string Agencia, string Conta, string AgVinc, string ContaVinc, string CNPJ, string SharePointNome, string IdConta, bool NovaLinha = false)
        {
            string sqlCommand = "";
            if (Tipo == "---" && Bem == "---" && Natureza == "---" && CNPJ == "---" && SharePointNome == "" && NovaLinha)
            {
                sqlCommand = String.Format(@"INSERT INTO tb_0131_ContaVinculada (Id_Servico, CNPJ, Tipo_Garantia, Bem_Garantia, Natureza_Garantia) values ({0}, '---','---','---','---')", ID_Servico);
            }
            else
            {
                sqlCommand = String.Format(@"UPDATE tb_0131_ContaVinculada SET Agencia = '{0}', Conta = '{1}', Ag_Vinculada = '{2}', CC_Vinculada = '{3}', SharePoint = '{4}' WHERE ID_ContaVinculada = {5}", Agencia, Conta, AgVinc, ContaVinc, SharePointNome, IdConta);
            }

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
        }

        public static void DeleteContasVinculadas(int ID_Servico)
        {
            string sqlCommand = String.Format(@"DELETE * FROM tb_0131_ContaVinculada WHERE (SharePoint = '' OR SharePoint is null) AND (Tipo_Garantia = '' OR Tipo_Garantia is null or Tipo_Garantia = '---') AND (Bem_Garantia = '' OR Bem_Garantia is null or Bem_Garantia = '---') AND (Natureza_Garantia = '' OR Natureza_Garantia is null or Natureza_Garantia = '---') AND (CNPJ = '' OR CNPJ is null or CNPJ = '---') AND ID_Servico = {0}", ID_Servico);
            DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
        }

        public static List<ContasVinculadasGarantias> PesquisarContasVinculadas()
        {
            string sqlCommand = @"SELECT * FROM VW_ContasVinculadasCNPJ";

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            List<ContasVinculadasGarantias> list = new List<ContasVinculadasGarantias>();

            foreach (DataRow row in result.Rows)
                list.Add(new ContasVinculadasGarantias(row));

            return list;
        }
        #endregion

        //integração de excel - POG
        #region [Inserir Dados Fluxo]
        public static void InserirDadoFluxo(int? idServico, int? idFluxo, int idCampo, string nomeCampo, string valorCampo)
        {

            string sqlCommand = "SELECT Id_Campo FROM tb_0126_DadosServico Where {0} = {1} And {2} = {3} and {4} = {5}";
            sqlCommand = String.Format(sqlCommand, "ID_Servico", idServico, "ID_Fluxo", idFluxo, "Id_Campo", idCampo);
            DataTable resultConsulta = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            if (resultConsulta.Rows.Count > 0)
            {
                sqlCommand = string.Format("UPDATE tb_0126_DadosServico SET ValorCampo = '{0}' WHERE ID_Servico = {1} AND ID_Fluxo = {2} AND Id_Campo = {3}", valorCampo, idServico, idFluxo, idCampo);
            }
            else
            {
                sqlCommand = string.Format("INSERT INTO tb_0126_DadosServico (ID_Servico, ID_Fluxo, Id_Campo, NomeCampo, ValorCampo, [Data Criacao]) Values ({0}, {1}, {2}, '{3}', '{4}', '{5}')", idServico, idFluxo, idCampo, nomeCampo, valorCampo, DateTime.Now);
            }
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
        }
        public static List<DadosCamposServico> buscarNumsWAO()
        {
            string sqlCommand = string.Format("SELECT * FROM tb_0126_DadosServico WHERE Id_Campo = 5090 Or Id_Campo = 5091");
            List<DadosCamposServico> list = new List<DadosCamposServico>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new DadosCamposServico(row));

            return list;
        }
        #endregion

        #region [ Mobios Cash ]
        public static void RegistrarFluxoServico(int idAnalista, EtapasObjeto etpReg, string SistemaLog = "")
        {
            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

            string sqlCommand = String.Format("INSERT INTO tb_0127_FluxoServico (ID_Servico, ID_Fluxo, ID_Status, DataAlteracaoStatus, DataCriacao, DataAlteracao, Id_Responsavel) "
                                              + " VALUES ({0}, {1}, {2}, '{3}', '{4}', '{5}', {6})"
                                              , etpReg.ID_Servico, etpReg.ID_Etapa, etpReg.ID_Status, datahora, datahora, datahora, idAnalista);
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            if (!etpReg.StatusNaoInicia)
            {
                DataAccess.GravarIndicadorStatus(etpReg.ID_Servico, etpReg.ID_Etapa, etpReg.ID_Status, Convert.ToDateTime(datahora), SistemaLog);
            }
        }
        public static void AtualizaIdObjetoServico(int ID_Servico, int ID_Objeto)
        {

            string sqlCommand = string.Format("Update tb_0125_Servico Set ID_Objeto = {0}, DataAlteracao=#{2}# Where ID_Servico = {1}", ID_Objeto, ID_Servico, DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss"));

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
        }
        public static void AtualizaDemaisEtapas(int ID_Servico, int ID_Status, int ID_Etapa)
        {
            string sqlCommand;

            sqlCommand = string.Format("Update tb_0127_FluxoServico Set ID_Status = {0}, DataAlteracao = #{1}#, UserAlteracao = '{2}'  Where ID_Servico = {3} And ID_Fluxo not in ({4}) And ID_Status not in (0) ", ID_Status, DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"), Environment.UserName.ToUpper(), ID_Servico, ID_Etapa);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
        }
        #endregion

        #region [ CAGI ]
        #region [Importacao CPE]
        public static DataTable GetImportacaoCPE()
        {
            string tbl1 = "SELECT CPE.[Data Extração], CPE.[Nº Contrato], CStr([ID# Pendência]) AS [ID Pendencia], CPE.[Tipo Pendência], CPE.Garantia, CPE.Observação, CPE.[Dt# Abertura], CPE.[Dt# Vencimento], CPE.Produto, CPE.[Grupo Cliente], CPE.Cliente, CPE.[Rating Cliente], CPE.CNPJ, CPE.[Cód# Centro de Custo do Officer], CPE.[Centro de Custo do Officer], CPE.[Filial (Diretoria)], CPE.Moeda, CPE.Valor, CPE.[Dt# Inclusão Pendência], CPE.[Vl# Risco] ";
            tbl1 += "FROM CPE";

            string tbl2 = "TBL1.[Nº Contrato], TBL1.[ID Pendencia], TBL1.[Tipo Pendência], TBL1.Garantia, TBL1.Observação, TBL1.[Dt# Abertura], TBL1.[Dt# Vencimento], TBL1.Produto, TBL1.[Grupo Cliente], TBL1.Cliente, TBL1.[Rating Cliente], TBL1.CNPJ, TBL1.[Cód# Centro de Custo do Officer], TBL1.[Centro de Custo do Officer], TBL1.[Filial (Diretoria)], TBL1.Moeda, TBL1.Valor, TBL1.[Dt# Inclusão Pendência], IIf(IsNull([TBL1]![Vl# Risco]),0,CDbl([TBL1]![Vl# Risco])) AS [Vlr Risco], tb_0405_ServicosSharePoint.Tipo ";
            tbl2 += "FROM ((" + tbl1 + ") as TBL1 LEFT JOIN tb_0125_Servico ON TBL1.[ID Pendencia] = tb_0125_Servico.ServicoName) INNER JOIN tb_0405_ServicosSharePoint ON TBL1.[Tipo Pendência] = tb_0405_ServicosSharePoint.ValoresCriterioSP ";
            tbl2 += "WHERE (((TBL1.[Dt# Inclusão Pendência])=CDate([vw_CPEFormatted]![Data Extração])-1) AND ((tb_0125_Servico.ServicoName) Is Null) AND ((tb_0405_ServicosSharePoint.Tipo)='CAGI')) ";

            string sql = string.Format("SELECT * FROM ("+ tbl2+") as tbl2 WHERE [Garantia] Not Like '%Aval%' And [Garantia] Not Like '%Devedor Solidário%' And [Garantia] Not Like '%Nota Promissória%' And [Garantia] Not Like '%Fiança%' And [Garantia] Not Like '%Guarantee Letter%'");
            
            DataTable dt = DataConnector.ExecuteDataTable(sql, "BDconsulta");
            return dt;
        }
        #endregion

        #region [ follow up ]
        public static List<FollowUp> GetAlertaFollowUp()
        {
            string sqlCommand = SharedData.GetQueryDefinition("vw_FollowUpEtapaServico");
            if (sqlCommand != "")
            {
                sqlCommand = TratamentoSQL.AdicionaWhere(sqlCommand, "Login = '" + Environment.UserName.ToUpper() + "' And FUPEncerrado = false");
            }

            List<FollowUp> list = new List<FollowUp>();
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new FollowUp(row));

            return list;
        }
        public static void AtualizarDataAlerta(FollowUp FollowUpDados, int AddWorkDays)
        {
            string sqlCommand = "UPDATE tb_0128_FollowUpEtapaServico Set DataAlerta = '{0}' Where ID_SERVICO = {1} And ID_FOLLOW = {2}";
            sqlCommand = string.Format(sqlCommand, SharedData.AddWorkdays(DateTime.Now, AddWorkDays), FollowUpDados.ID_Servico, FollowUpDados.ID_Follow);
            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
        }
        public static void RegistrarFollowUpEtapaServico(FollowUp FollowUpDados, bool UpdValue, bool FUPEncerrado, int AddWorkDaysAlerta = 0)
        {
            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            if (UpdValue)
            {
                string sqlCommand = "Update tb_0128_FollowUpEtapaServico Set FollowUpEtapa = '{0}', Pendencia = '{1}', Responsavel = '{2}', EmailResponsavel = '{3}', DataAlteracao = #{4}#, FUPEncerrado = {5} Where ID_SERVICO = {6} And ID_FOLLOW = {7}";
                sqlCommand = String.Format(sqlCommand, FollowUpDados.FollowUpEtapa, FollowUpDados.Pendencia, FollowUpDados.Responsavel, FollowUpDados.EmailResponsavel, datahora, FUPEncerrado, FollowUpDados.ID_Servico, FollowUpDados.ID_Follow);
                DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            }
            else
            {
                string sqlCommand = "INSERT INTO tb_0128_FollowUpEtapaServico (ID_Servico, ID_Fluxo, ID_Campo, Pendencia, Responsavel, EmailResponsavel, FollowUpEtapa, FUPEncerrado, DataCriacao, DataAlteracao, DataAlerta, Login) VALUES ({0}, {1}, {2}, '{3}', '{4}', '{5}', '{6}', {7}, #{8}#, #{9}#, #{10}#, '{11}')";
                sqlCommand = string.Format(sqlCommand, FollowUpDados.ID_Servico, FollowUpDados.ID_Fluxo, FollowUpDados.ID_Campo, FollowUpDados.Pendencia, FollowUpDados.Responsavel, FollowUpDados.EmailResponsavel, FollowUpDados.FollowUpEtapa, FUPEncerrado, datahora, datahora, SharedData.AddWorkdays(DateTime.Now, AddWorkDaysAlerta).ToString("yyyy/MM/dd HH:mm:ss"), Environment.UserName.ToUpper());
                DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            }
        }
        #endregion
        #endregion

        #region [MiniSimCreditoRural]
        public static List<CamposEscreverExcel> GetCamposEscreverExcel(int ID_Arquivo)
        {
            string sqlCommand = string.Format(@"SELECT * FROM tb_0021_ParametrosEscreveNoExcel where ID_ARQUIVO = {0} AND ATIVO=TRUE", ID_Arquivo);
            List<CamposEscreverExcel> list = new List<CamposEscreverExcel>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new CamposEscreverExcel(row));

            return list;
        }
        public static List<LEGO> GetLEGO()
        {
            string sqlCommand = string.Format(@"SELECT * FROM LEGO where ATIVO=TRUE");
            List<LEGO> list = new List<LEGO>();

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");

            foreach (DataRow row in result.Rows)
                list.Add(new LEGO(row));

            return list;
        }
        #endregion
    }
}
