﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO; // USED ONLY FOR THE DAO METHOD
using System.Linq;
using System.Text;
using DAO = Microsoft.Office.Interop.Access.Dao;

namespace Mobios
{
    public class DataConnector
    {
        // Não esta sendo usada ainda
        public static Int32 ExecuteDataTableScalar(string query, string DB)
        {
            string msgLog = "";
            int cod = 0;
            string connectionString = string.Empty;
            connectionString = string.Format(ConfigurationManager.ConnectionStrings["ConnectionStringOffice2010"].ConnectionString, SharedData.BDPath + ConfigurationManager.ConnectionStrings[DB].ConnectionString);
            OleDbConnection conn = new OleDbConnection(connectionString);
            string sql = query;

            //OleDbCommand cmd = new OleDbCommand(sql, conn);
            bool connect2013 = false;
            try
            {
                try
                {
                    conn.Open();
                }
                catch (Exception ex)
                {
                    msgLog = ex.Message;
                    Log.GravaLog(msgLog);
                    connect2013 = true;
                }
                finally
                {
                    if (connect2013)
                    {
                        connectionString = string.Format(ConfigurationManager.ConnectionStrings["ConnectionStringOffice2013"].ConnectionString, ConfigurationManager.ConnectionStrings[DB].ConnectionString);
                        conn = new OleDbConnection(connectionString);
                        conn.Open();
                    }
                }

                OleDbCommand cmd = new OleDbCommand(sql, conn);
                //OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                //DataTable table = new DataTable();
                //da.Fill(table);
                cod = Convert.ToInt32(cmd.ExecuteScalar());
                conn.Close();
                return cod;
            }
            catch(Exception exp)
            {
                msgLog = exp.Message;
                Log.GravaLog(msgLog);
                conn.Close();
                return 0;
            }
            

            
        }
        public static OleDbConnection ReturnOpenConnection(string DB)
        {
            int i = 0;

            OleDbConnection conn = new OleDbConnection();
            string connectionString = string.Empty;

            if (SharedData.gHomologação)
            {
                DB = DB + "Homologacao";
            }

            if (!SharedData.ValidaBD())
            {
                SharedData.Quit();
            }

            connectionString = string.Format(ConfigurationManager.ConnectionStrings["ConnectionStringOffice2010"].ConnectionString, SharedData.BDPath + ConfigurationManager.ConnectionStrings[DB].ConnectionString);
            conn = new OleDbConnection(connectionString);
            while (i < 5)
            {
                string msgLog = "";
                try
                {
                    bool connect2013 = false;
                    try
                    {
                        //Tenta abrir conexão com Office2010
                        conn.Open();
                        i = 5; //Faz sair do while!
                    }
                    catch (Exception ex)
                    {
                        //Se erro, faz o log e define connect2013=True
                        msgLog = ex.Message;
                        if (msgLog.IndexOf("file already in use") >= 0 || msgLog.IndexOf("O arquivo já está em uso") >= 0)
                        {
                            Tempo.pausaMilisegundos(800);
                        }
                        else
                        {
                            connect2013 = true;
                            Log.GravaLog(msgLog);
                        }

                    }
                    finally
                    {
                        if (connect2013)
                        {
                            msgLog = "Iteração Número: " + i + 1 + " | Tentando conectar com ConnectionStringOffice2013";
                            Log.GravaLog(msgLog);
                            connectionString = string.Format(ConfigurationManager.ConnectionStrings["ConnectionStringOffice2013"].ConnectionString, SharedData.BDPath + ConfigurationManager.ConnectionStrings[DB].ConnectionString);
                            conn = new OleDbConnection(connectionString);
                            conn.Open();
                            i = 5;
                        }

                    }

                }
                catch (Exception exp)
                {

                    msgLog = "Iteração Número: " + i + 1 + " | Erro: " + exp.Message;
                    Log.GravaLog(msgLog);

                    if (!((i + 1) < 5))
                    {
                        msgLog = "Erro de acesso ao banco de dados.\n\n";
                        msgLog += "Favor verificar possíveis problemas de instalação do Office.";
                        msgLog += "\n1 - Windows 64Bits e Office 32Bits.";
                        msgLog += "\n2 - Office não instalado.";
                        msgLog += "\n2 - Erro de instalação do Office.";
                        msgLog += "\n\n Erro: " + exp.Message;
                        msgLog += "\n Fonte: " + exp.Source;
                        //MessageBox.Show(msgLog, "Erro acesso ao banco de dados", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        //conn.Close();
                        throw new Exception(msgLog);
                    }
                }
                i++;
            }

            return conn;


        }
        public static DataTable ExecuteDataTable(string query, string DB)
        {
            DataTable table = new DataTable();
            using (OleDbConnection conn = ReturnOpenConnection(DB))
            {
                if (conn.State == ConnectionState.Open)
                {
                    int i = 0;
                    while (i < 5)
                    {
                        try
                        {
                            OleDbCommand cmd = new OleDbCommand(query, conn);
                            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                            da.Fill(table);
                            //var reader = cmd.ExecuteReader();
                            //table.Load(reader);

                            i = 5;
                        }
                        catch (Exception err)
                        {
                            if (!((i + 1) < 5))
                            {
                                Log.GravaLog("Erro: " + err.Message);
                                throw new Exception("Erro ao buscar informações no banco de dados.\n\nErro: " + err.Message);
                            }
                            Tempo.pausaMilisegundos(800);
                            i++;
                        }
                    }
                }
                conn.Close();
            }
            return table;
        }
        public static void ExecuteProcedure(string Procedure, string DB)
        {
            using (OleDbConnection conn = ReturnOpenConnection(DB))
            {
                if (conn.State == ConnectionState.Open)
                {
                    int i = 0;
                    while (i < 5)
                    {
                        try
                        {

                            OleDbCommand cmd = new OleDbCommand(Procedure, conn);
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.ExecuteNonQuery();
                            i = 5;
                        }
                        catch (Exception err)
                        {
                            if (!((i + 1) < 5))
                            {
                                Log.GravaLog("Erro: " + err.Message);
                                throw new Exception("Erro ao buscar informações no banco de dados.\n\nErro: " + err.Message);
                            }
                            Tempo.pausaMilisegundos(800);
                            i++;
                        }
                    }

                }
                conn.Close();
            }
        }
        public static void ExecuteNonQuery(string Query, string DB)
        {
            OleDbConnection conn = ReturnOpenConnection(DB);
            if (conn.State == ConnectionState.Open)
            {
                int i = 0;
                while (i < 5)
                {
                    try
                    {
                        OleDbCommand cmd = new OleDbCommand(Query, conn);
                        cmd.ExecuteNonQuery();
                        i = 5;
                    }
                    catch (Exception err)
                    {
                        if (!((i + 1) < 5))
                        {
                            Log.GravaLog("Erro: " + err.Message);
                            throw new Exception("Erro ao buscar informações no banco de dados.\n\nErro: " + err.Message);
                        }
                        Tempo.pausaMilisegundos(800);
                        i = i + 1;
                    }


                }
            }
            conn.Close();
        }
        public static void BulkExportToAccess(DataTable dtOutData, String DBPath, String TableNm)
        {
            DAO.DBEngine dbEngine = new DAO.DBEngine();
            Boolean CheckFl = false;
            Int32 colNumber = 0;
            DAO.Database db = null;
            try
            {
                int i = 0;
                while (i < 5)
                {
                    try
                    {
                        db = dbEngine.OpenDatabase(DBPath);
                        i = 5;
                    }
                    catch (Exception)
                    {
                        Tempo.pausaMilisegundos(800);
                        i = i + 1;
                    }
                }

                DAO.Recordset AccesssRecordset = db.OpenRecordset(TableNm);
                DAO.Field[] AccesssFields = new DAO.Field[dtOutData.Columns.Count];

                //Loop on each row of dtOutData
                for (Int32 rowCounter = 0; rowCounter < dtOutData.Rows.Count; rowCounter++)
                {
                    AccesssRecordset.AddNew();
                    //Loop on column
                    for (Int32 colCounter = 0; colCounter < dtOutData.Columns.Count; colCounter++)
                    {
                        // for the first time... setup the field name.
                        colNumber = colCounter;
                        if (!CheckFl)
                            AccesssFields[colCounter] = AccesssRecordset.Fields[dtOutData.Columns[colCounter].ColumnName];
                        AccesssFields[colCounter].Value = dtOutData.Rows[rowCounter][colCounter];
                    }

                    AccesssRecordset.Update();
                    CheckFl = true;
                }

                AccesssRecordset.Close();
                db.Close();
            }
            catch (Exception ex)
            {
                Log.GravaLog(ex.Message + " | TableNm = " + TableNm + " | ColIndex = " + colNumber);
            }
            finally
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(dbEngine);
                dbEngine = null;
            }
        }

        public static DataTable ExecuteDataTableExcel(string filePath, List<string> ColunasNecessarias = null, string planilha = "")
        {
            DataTable dtexcel = new DataTable();
            bool hasHeaders = true;
            string HDR = hasHeaders ? "Yes" : "No";

            string strConn;
            if (Path.GetExtension(filePath).ToLower() == ".xlsx" ||Path.GetExtension(filePath).ToLower() == ".xlsb")
                strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties=\"Excel 12.0;HDR=" + HDR + ";IMEX=0\"";
            else
                strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath + ";Extended Properties=\"Excel 8.0;HDR=" + HDR + ";IMEX=0\"";

            using (OleDbConnection conn = new OleDbConnection(strConn))
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    DataTable schemaTable = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });



                    //Looping Total Sheet of Xl File
                    /*foreach (DataRow schemaRow in schemaTable.Rows)
                    {
                    }*/
                    //Looping a first Sheet of Xl File
                    int NumPla = 0;

                    if (planilha != "")
                    {

                        #region [ Valida se a aba informada existe ]
                        bool PlanilhaExiste = false;

                        for (int i = 0; i < schemaTable.Rows.Count; i++)
                        {
                            DataRow schemaRowaux = schemaTable.Rows[i];
                            string sheetaux = schemaRowaux["TABLE_NAME"].ToString();
                            if (sheetaux.ToUpper() == (planilha + "$").ToUpper())
                            {
                                NumPla = i;
                                PlanilhaExiste = true;
                            }

                        }
                        #endregion

                        if (!PlanilhaExiste)
                        {
                            string msgShow = "Planilha '" + planilha + "' não econtrada no arquivo '" + filePath.Substring(filePath.LastIndexOf(@"\")) + "'";
                            msgShow += "\n\nImportação cancelada.";
                            throw new Exception(msgShow);
                        }
                    }


                    #region [ Ajustar nome das colunas ]
                    //Verificando as colunas do arquico (Apenas as primeira coluna)
                    DataTable tableColumns = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Columns, new object[] { null, null, planilha + "$", null });

                    List<string> TodasColunasArquivo = new List<string>();
                    foreach (DataRow row in tableColumns.Rows)
                    {
                        var columnNameColumn = row["COLUMN_NAME"];
                        TodasColunasArquivo.Add(Replace_Tag_por_ponto(columnNameColumn.ToString().Trim()));

                        //var dateTypeColumn = row["DATA_TYPE"];
                        //var ordinalPositionColumn = row["ORDINAL_POSITION"];
                    }
                    #endregion

                    #region [ Valida se as colunas obrigatórias existem ]
                    if (ColunasNecessarias != null && ColunasNecessarias.Count > 0)
                    {
                        for (int col = 0; col < ColunasNecessarias.Count; col++)
                        {
                            string buscar = Replace_Tag_por_ponto(ColunasNecessarias[col].ToString().ToUpper());
                            int indexColuna = TodasColunasArquivo.FindIndex(n => n.ToString().ToUpper() == buscar);
                            if (indexColuna >= 0)
                            {
                                //Coluna existe no arquivo
                            }
                            else
                            {
                                //Coluna não existe no arquivo
                                //string msgShow = "Coluna " + ColunasNecessarias[col].ToString() + " não encontrada na planilha " + planilha;
                                string msgShow = "Era esperada a coluna '" + ColunasNecessarias[col].ToString() + "' na planilha '" + planilha + "'";
                                msgShow += "\nPorém a mesma não foi encontrada no arquivo " + filePath.Substring(filePath.LastIndexOf(@"\"));
                                msgShow += "\n\nImportação cancelada.";
                                throw new Exception(msgShow);
                            }
                        }
                    }
                    #endregion

                    DataRow schemaRow = schemaTable.Rows[NumPla];
                    string sheet = schemaRow["TABLE_NAME"].ToString();
                    if (!sheet.EndsWith("_"))
                    {
                        string query = "SELECT  * FROM [" + sheet + "]";
                        OleDbDataAdapter daexcel = new OleDbDataAdapter(query, conn);
                        dtexcel.Locale = CultureInfo.CurrentCulture;
                        daexcel.Fill(dtexcel);
                    }
                    conn.Close();
                }
                else
                {
                    throw new Exception("Não foi possível estabelecer uma conexão com o excel: " + filePath);
                }
            }
            return dtexcel;

        }
        private static string Replace_Tag_por_ponto(string Entrada)
        {
            Entrada = Entrada.Replace("#", ".");
            Entrada = Entrada.Replace(" ", "");
            Entrada = Entrada.Replace("\n", "");
            Entrada = Entrada.Replace("\r", "");
            return Entrada;
        }



        public static DataTable Join_2SQL_1Column(string query1, string query2, string fieldRef, string DB)
        {
            DataTable targetTable = new DataTable();
            using (OleDbConnection conn = ReturnOpenConnection(DB))
            {
                if (conn.State == ConnectionState.Open)
                {
                    DataTable result1 = new DataTable();
                    DataTable result2 = new DataTable();

                    for (int query = 0; query < 2; query++)
                    {

                        int i = 0;
                        while (i < 5)
                        {
                            try
                            {
                                if (query == 0)
                                {
                                    OleDbCommand cmd = new OleDbCommand(query1, conn);
                                    OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                                    da.Fill(result1);
                                }
                                else
                                {
                                    if (result1.Rows.Count > 0)
                                    {
                                        OleDbCommand cmd = new OleDbCommand(query2, conn);
                                        OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                                        da.Fill(result2);
                                    }
                                }
                                //var reader = cmd.ExecuteReader();
                                //table.Load(reader);

                                i = 5;
                            }
                            catch (Exception err)
                            {
                                if (!((i + 1) < 5))
                                {
                                    Log.GravaLog("Erro: " + err.Message);
                                    throw new Exception("Erro ao buscar informações no banco de dados.\n\nErro: " + err.Message);
                                }
                                Tempo.pausaMilisegundos(800);
                                i++;
                            }
                        }
                    }

                    if (result1.Rows.Count > 0 && result2.Rows.Count > 0)
                    {
                        targetTable = TratamentoCampo.JoinTwoDataTablesOnOneColumn(result1, result2, fieldRef, TratamentoCampo.JoinType.Left);
                    }
                    else
                    {
                        targetTable = result1;
                    }

                }
                conn.Close();
            }
            return targetTable;
        }

        public static DataTable GetQueries(string DB)
        {
            DataTable schema = new DataTable();
            using (OleDbConnection conn = ReturnOpenConnection(DB))
            {
                if (conn.State == ConnectionState.Open)
                {
                    //conn.Open();
                    //string[] restrictions = new string[] { null, null, "myQuery" };
                    //DataTable schema = conn.GetSchema("Views", restrictions);
                    schema = conn.GetSchema("Views");
                    //if (schema.Rows.Count > 0)
                    //{
                    //    DataRow row = schema.Rows[0];
                    //    string queryText = (string)row["VIEW_DEFINITION"];
                    //    Console.WriteLine(queryText);
                    //}
                    conn.Close();
                }
            }

            foreach (DataRow r in schema.Rows)
            {
                int LastIndex = r["VIEW_DEFINITION"].ToString().LastIndexOf(';');
                if (LastIndex != -1)
                    r["VIEW_DEFINITION"] = r["VIEW_DEFINITION"].ToString().Substring(0, LastIndex);

                r["VIEW_DEFINITION"] = r["VIEW_DEFINITION"].ToString().Replace("\r\n", " ").Replace("\"", "'");
            }

            return schema;
        }
    }
}
