﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Mobios
{
    public class Analista
    {
        public string Login { get; set; }
        public string Nome { get; set; }
        public Boolean Gestor { get; set; }
        
        public Analista()
        { }

        public Analista(DataRow row)
        {
            this.Login = row[0].ToString();
            this.Nome = row[1].ToString();
            this.Gestor = Convert.ToBoolean(row[2]);
        }
    }
}
