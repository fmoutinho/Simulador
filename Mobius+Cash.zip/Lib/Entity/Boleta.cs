﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;

namespace Mobios
{
    // Dados do boleto
    public class Dados : IEquatable<Dados>
    {
        public int IdSeq { get; set; }
        public long IdBoleto { get; set; }
        public string Campo { get; set; }
        public string Valor { get; set; }
        public int Id_Campo { get; set; }

        public bool Equals(Dados other)
        {
            if (this.ToString() == other.ToString())
                return true;
            else
                return false;
        }

        public override string ToString()
        {
            return string.Join(";",IdBoleto.ToString(), Campo, Valor);
        }
    }

    public class Boletador
    {
        public int IdBoletador { get; set; }
        public string NomeBoletador { get; set; }
        public bool Senha { get; set; }
        public bool NumeroOperacao { get; set; }
        public bool Versao { get; set; }
        public string NomeMetodo { get; set; }

        public Boletador()
        {

        }

        public Boletador(DataRow row)
        {
            this.IdBoletador = Convert.ToInt32(row["IdBoletador"]);
            this.NomeBoletador = row["Boletador"].ToString();
            this.Senha = Convert.ToBoolean(row["Senha"].ToString());
            this.NumeroOperacao = Convert.ToBoolean(row["NumeroOperacao"].ToString());
            this.Versao = Convert.ToBoolean(row["Versao"].ToString());
            this.NomeMetodo = row["NomeMetodo"].ToString();
        }
    }

    public class ListaArquivos
    {
        public int IdArquivo { get; set; }
        public string NomeArquivo { get; set; }
        public int CampoBoleto { get; set; }

        public ListaArquivos()
        {

        }

        public ListaArquivos(DataRow row)
        {
            this.IdArquivo = Convert.ToInt32(row["IdArquivo"]);
            this.NomeArquivo = row["NomeArquivo"].ToString();
            try
            {
                this.CampoBoleto = Convert.ToInt32(row["CampoBoleto"].ToString());
            }
            catch { }
        }
    }

    #region [ BEN / BE ]
    // Boleto 4131
    public class BoletaBEN
    {
        public long Id_Boleta { get; set; }
        public string Boleto { get; set; }
        public string CodigoContrato { get; set; }
        public DateTime DataCaptura { get; set; }
        public DateTime DataAtualizacao { get; set; }
        public int Id_Produto { get; set; }
        public string Produto { get; set; }
        public string Modalidade { get; set; }
        public string Evento { get; set; }
        public string XML { get; set; }

        public BoletaBEN()
        {

        }

        public BoletaBEN(DataRow row)
        {
            this.Id_Boleta = Convert.ToInt64(row["Id_Boleta"]);
            this.Boleto = row["Boleto"].ToString();
            this.CodigoContrato = row["Cod_Contrato"].ToString();
            this.DataCaptura = Convert.ToDateTime(row["dt_Captura"]);
            this.DataAtualizacao = Convert.ToDateTime(row["dt_atualizacao"]);
            this.Id_Produto = Convert.ToInt32(row["Id_Produto"]);
            this.Produto = row["nm_produto"].ToString();
            this.Modalidade = row["nm_modalidade"].ToString();
            this.Evento = row["nm_evento"].ToString();
            this.XML = row["xml_boleta"].ToString();
        }
    }

    // Boleto Dados 4131
    public class Boleta4131Dados
    {
        public long ID_SEQ { get; set; }
        public string ID_BOLETO { get; set; }
        public string NM_CAMPO { get; set; }
        public string NM_VALOR { get; set; }

        public Boleta4131Dados()
        {

        }

        public Boleta4131Dados(DataRow row)
        {
            this.ID_SEQ = Convert.ToInt64(row["ID_SEQ"]);            
            this.ID_BOLETO = row["BOLETO"].ToString();
            this.NM_CAMPO = row["NM_CAMPO"].ToString();
            this.NM_VALOR = row["NM_VALOR"].ToString();
        }
    }

    // Mapeamento XML
    public class MapeamentoXML
    {
        public int IdReport { get; set; }
        public string XPath { get; set; }
        public int IdCampo { get; set; }
        public string NomeCampo { get; set; }
        public string ValorCampo { get; set; }
        public string XPathPai { get; set; }
        public string XPathFilhos { get; set; }


        public MapeamentoXML()
        {

        }

        public MapeamentoXML(DataRow row)
        {
            this.IdReport = Convert.ToInt32(row["id_report"]);
            this.XPath = row["xml_xpath"].ToString();
            this.IdCampo = Convert.ToInt32(row["Id_Campo"]);
            this.NomeCampo = row["nm_campo"].ToString();
            this.XPathPai = row["xml_xPathPai"].ToString();
            this.XPathFilhos = row["xml_xPathFilho"].ToString();
        }
    }

    public class PMEReport
    {
        public int IdPME { get; set; }
        public string NomeReport { get; set; }
        public bool FlagAtualiza { get; set; }
        public int IdReport { get; set; }

        public PMEReport() { }

        public PMEReport(DataRow row)
        {
            this.IdPME = Convert.ToInt32(row[0]);
            this.NomeReport = row[1].ToString();
            this.FlagAtualiza = Convert.ToBoolean(row[2]);
            this.IdReport = Convert.ToInt32(row[7]);
        }
    }
    #endregion

    #region [ Boleto OQ ]
    public class BoletaOQParametros
    {
        public long ID_ParmaOQ { get; set; }
        public string NomeCampo { get; set; }
        public string ReferenciaCorte { get; set; }
        public string ReferenciaInicial { get; set; }
        public string ReferenciaFinal { get; set; }
        public int TamanhoCampo { get; set; }
        public string TipoCampo { get; set; }
        public bool Ativo { get; set; }
        public string IdCampo { get; set; }
        public string Separador { get; set; }
        public string Posicao { get; set; }
        public string IdObjeto { get; set; }

        public BoletaOQParametros()
        {

        }

        public BoletaOQParametros(DataRow row)
        {
            this.ID_ParmaOQ = Convert.ToInt64(row["ID_ParmaOQ"]);
            this.NomeCampo = row["NomeCampo"].ToString();
            this.ReferenciaCorte = row["ReferenciaCorte"].ToString();
            this.ReferenciaInicial = row["ReferenciaInicial"].ToString();
            this.ReferenciaFinal = row["ReferenciaFinal"].ToString();
            this.TamanhoCampo = Convert.ToInt32(row["TamanhoCampo"]);
            this.TipoCampo = row["TipoCampo"].ToString();
            this.Ativo = Convert.ToBoolean(row["Ativo"]);
            this.IdCampo = row["IDCampo"].ToString();
            this.Separador = row["Separador"].ToString();
            this.Posicao = row["Posicao"].ToString();
            //this.IdObjeto = row["IdObjeto"].ToString();
        }
    }
    #endregion

    #region [ Arquivos PDF ]
    public class BoletaParametrosArquivosPDF
    {
        public long ID_Parametro { get; set; }
        public string NomeCampo { get; set; }
        public string ReferenciaCorte { get; set; }
        public string ReferenciaCorteFim { get; set; }
        public string ReferenciaInicial { get; set; }
        public string ReferenciaFinal { get; set; }
        public int TamanhoCampo { get; set; }
        public string TipoCampo { get; set; }
        public bool Ativo { get; set; }
        public string IdCampo { get; set; }
        public string Separador { get; set; }
        public string Posicao { get; set; }
        public string IdObjeto { get; set; }
        public string NomeCamposTabela { get; set; }
        public string ChrEliminar { get; set; }

        public BoletaParametrosArquivosPDF()
        {

        }

        public BoletaParametrosArquivosPDF(DataRow row)
        {
            this.ID_Parametro = Convert.ToInt64(row["ID_Parametro"]);
            this.NomeCampo = row["NomeCampo"].ToString();
            this.ReferenciaCorte = row["ReferenciaCorte"].ToString();
            this.ReferenciaCorteFim = row["ReferenciaCorteFim"].ToString();
            this.ReferenciaInicial = row["ReferenciaInicial"].ToString();
            this.ReferenciaFinal = row["ReferenciaFinal"].ToString();
            this.TamanhoCampo = Convert.ToInt32(row["TamanhoCampo"]);
            this.TipoCampo = row["TipoCampo"].ToString();
            this.Ativo = Convert.ToBoolean(row["Ativo"]);
            this.IdCampo = row["IDCampo"].ToString();
            this.Separador = row["Separador"].ToString();
            this.Posicao = row["Posicao"].ToString();
            this.ChrEliminar = row["ChrEliminar"].ToString();
            this.NomeCamposTabela = row["NomeCamposTabela"].ToString();
            //this.IdObjeto = row["IdObjeto"].ToString();
        }
    }
    #endregion

    #region [ Arquivos Excel ]
    public class BoletaParametrosArquivosPlanilha
    {
        public long ID_Parametro { get; set; }
        public string NomeCampo { get; set; }
        public string TipoCampo { get; set; }
        public bool Ativo { get; set; }
        public int OrdemCampos { get; set; }
        public string IdCampo { get; set; }
        public string ReferenciaServico { get; set; }
        public string ReferenciaExcel { get; set; }
        public string ReferenciaPlanilha { get; set; }
        public string Separador { get; set; }
        public string Posicao { get; set; }

        public BoletaParametrosArquivosPlanilha()
        {

        }

        public BoletaParametrosArquivosPlanilha(DataRow row)
        {
            this.ID_Parametro = Convert.ToInt64(row["ID_Parametro"]);
            this.NomeCampo = row["NomeCampo"].ToString();
            this.TipoCampo = row["TipoCampo"].ToString();
            this.OrdemCampos = Convert.ToInt32(row["OrdemCampos"]);
            this.IdCampo = row["IdCampo"].ToString();
            this.ReferenciaServico = row["ReferenciaServico"].ToString();
            this.ReferenciaExcel = row["ReferenciaExcel"].ToString();
            this.ReferenciaPlanilha = row["ReferenciaPlanilha"].ToString();
            this.Separador = row["Separador"].ToString();
            this.Posicao = row["Posicao"].ToString();
        }
    }
    #endregion

    #region [ PN ] 
    public class BoletaPNParametros
    {
        public long ID_ParmaOQ { get; set; }
        public string NomeCampo { get; set; }
        public string ReferenciaCorte { get; set; }
        public string ReferenciaInicial { get; set; }
        public string ReferenciaFinal { get; set; }
        public int TamanhoCampo { get; set; }
        public string TipoCampo { get; set; }        
        public string IdCampo { get; set; }
        public string Separador { get; set; }
        public string Posicao { get; set; }
        public string NomeCamposTabela { get; set; }
        public string IdObjeto { get; set; }

        public BoletaPNParametros()
        {

        }

        public BoletaPNParametros(DataRow row)
        {
            this.ID_ParmaOQ = Convert.ToInt64(row["ID_ParmaOQ"]);
            this.NomeCampo = row["NomeCampo"].ToString();
            this.ReferenciaCorte = row["ReferenciaCorte"].ToString();
            this.ReferenciaInicial = row["ReferenciaInicial"].ToString();
            this.ReferenciaFinal = row["ReferenciaFinal"].ToString();
            this.TamanhoCampo = Convert.ToInt32(row["TamanhoCampo"]);
            this.TipoCampo = row["TipoCampo"].ToString();
            this.IdCampo = row["IDCampo"].ToString();
            this.Separador = row["Separador"].ToString();
            this.NomeCamposTabela = row["NomeCamposTabela"].ToString();
            this.Posicao = row["Posicao"].ToString();
            //this.IdObjeto = row["IdObjeto"].ToString();
        }
    }
    #endregion
}






