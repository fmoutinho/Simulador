﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Mobios
{

    public class ListEnderecoCliente
    {
        public int ID_Objeto { get; set; }
        public int ID_Endereco { get; set; }
        public string NmCliente { get; set; }
        public string NmSegmento { get; set; }
        public string UF { get; set; }
        public string Cidade { get; set; }
        public string CEP { get; set; }
        public string Endereco { get; set; }
        public string Numero { get; set; }
        public string Complemento { get; set; }
        public string Bairro { get; set; }
        public string DiaFrequencia1 { get; set; }
        public string DiaFrequencia2 { get; set; }
        public string DiaFrequencia3 { get; set; }
        public string DiaFrequencia4 { get; set; }
        public string DiaFrequencia5 { get; set; }
        public string DiaFrequencia6 { get; set; }
        public string DiaFrequencia7 { get; set; }
        public string AtendimentoFeriado { get; set; }
        public string HorarioSemanaINI { get; set; }
        public string HorarioSemanaFIM { get; set; }
        public string HorarioSabDomFerINI { get; set; }
        public string HorarioSabDomFerFIM { get; set; }
        public string ColetaCheques { get; set; }
        public string Observacao { get; set; }
        public bool AtivoEndereco { get; set; }


        public ListEnderecoCliente()
        { }

        public ListEnderecoCliente(DataRow row)
        {
            this.ID_Objeto = Convert.ToInt32(row["ID_Objeto"]);
            this.ID_Endereco = Convert.ToInt32(row["ID_Endereco"]);
            this.NmCliente = row["NmCliente"].ToString();
            this.NmSegmento = row["NmSegmento"].ToString();
            this.UF = row["UF"].ToString();
            this.Cidade = row["Cidade"].ToString();
            this.CEP = row["CEP"].ToString();
            this.Endereco = row["Endereco"].ToString();
            this.Numero = row["Numero"].ToString();
            this.Complemento = row["Complemento"].ToString();
            this.Bairro = row["Bairro"].ToString();
            this.DiaFrequencia1 = row["DiaFrequencia1"].ToString();
            this.DiaFrequencia2 = row["DiaFrequencia2"].ToString();
            this.DiaFrequencia3 = row["DiaFrequencia3"].ToString();
            this.DiaFrequencia4 = row["DiaFrequencia4"].ToString();
            this.DiaFrequencia5 = row["DiaFrequencia5"].ToString();
            this.DiaFrequencia6 = row["DiaFrequencia6"].ToString();
            this.DiaFrequencia7 = row["DiaFrequencia7"].ToString();
            this.AtendimentoFeriado = row["AtendimentoFeriado"].ToString();
            this.HorarioSemanaINI = row["HorarioSemanaINI"].ToString();
            this.HorarioSemanaFIM = row["HorarioSemanaFIM"].ToString();
            this.HorarioSabDomFerINI = row["HorarioSabDomFerINI"].ToString();
            this.HorarioSabDomFerFIM = row["HorarioSabDomFerFIM"].ToString();
            this.ColetaCheques = row["ColetaCheques"].ToString();
            this.Observacao = row["Observacao"].ToString();
            this.AtivoEndereco = Convert.ToBoolean(row["AtivoEndereco"]);
        }
    }

    public class ListCotacoesNumerario
    {
        public int IDProdObj { get; set; }
        public string NomeObjeto { get; set; }
        public string Descricao { get; set; }
        public string Tipo { get; set; }


        public ListCotacoesNumerario()
        { }

        public ListCotacoesNumerario(DataRow row)
        {
            this.IDProdObj = Convert.ToInt32(row[0]);
            this.NomeObjeto = row[1].ToString();
            this.Descricao = row[2].ToString();
            this.Tipo = row[3].ToString();
        }
    }
}
