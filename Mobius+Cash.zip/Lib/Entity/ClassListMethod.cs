﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Mobios
{
    public class ClassListMethod
    {
        public int ID_Objeto { get; set; }
        public int ID_Etapa { get; set; }
        public int ID_Method { get; set; }
        public string MethodName { get; set; }
        public string MethodDescricao { get; set; }
        public string MethodParametro { get; set; }
        public string MethodForm { get; set; }
        public int IdMethodForm { get; set; }
        public string CriterioCampo { get; set; }
        public string CriterioValor { get; set; }
        public int MethodCampoID { get; set; }
        public int OrdemMethod { get; set; }
        
        //email
        public string MethodCamposServicoBody { get; set; }
        public string MethodCamposEtapasBody { get; set; }
        public string MethodPergunta { get; set; }
        public string MethodEvento { get; set; }
        
        //follow-up
        public bool MethodFUP { get; set; }

        //sharepoint
        public string SharepointSite { get; set; }
        public string SharepointTabelaGUID { get; set; }
        public string SharePointCriterio{ get; set; }
        public string MobiosCriterio { get; set; }
        public string TipoCriterio { get; set; }
        public string SharepointCampos { get; set; }
        public string MobiosCampos { get; set; }
        
        
        //etapa
        public int MethodStatusEtapa { get; set; }

        public ClassListMethod()
        { }

        public ClassListMethod(ClassListMethod c)
        {
            this.ID_Objeto = c.ID_Objeto;
            this.ID_Etapa = c.ID_Etapa;
            this.ID_Method = c.ID_Method;
            this.MethodName = c.MethodName;
            this.MethodDescricao = c.MethodDescricao;
            this.MethodParametro = c.MethodParametro;
            this.MethodForm = c.MethodForm;
            this.IdMethodForm = c.IdMethodForm;
            this.CriterioCampo = c.CriterioCampo;
            this.CriterioValor = c.CriterioValor;
            this.MethodCampoID = c.MethodCampoID;
            this.OrdemMethod = c.OrdemMethod;
            this.MethodCamposServicoBody = c.MethodCamposServicoBody;
            this.MethodCamposEtapasBody = c.MethodCamposEtapasBody;
            this.MethodPergunta = c.MethodPergunta;
            this.MethodEvento = c.MethodEvento;
            this.MethodFUP = c.MethodFUP;
            this.SharepointSite = c.SharepointSite;
            this.SharepointTabelaGUID = c.SharepointTabelaGUID;
            this.SharePointCriterio = c.SharePointCriterio;
            this.MobiosCriterio = c.MobiosCriterio;
            this.TipoCriterio = c.TipoCriterio;
            this.SharepointCampos = c.SharepointCampos;
            this.MobiosCampos = c.MobiosCampos;
        }

        public ClassListMethod(DataRow row)
        {
            this.ID_Objeto = Convert.ToInt32(row["ID_Objeto"]);
            this.ID_Etapa = Convert.ToInt32(row["ID_Etapa"]);
            this.ID_Method = Convert.ToInt32(row["ID_Method"]);
            this.MethodName = row["MethodName"].ToString();
            this.MethodDescricao = row["MethodDescricao"].ToString();
            this.MethodParametro = row["MethodParametro"].ToString();
            this.MethodForm = row["Form"].ToString();
            if (row["IdMethodFormMinuta"] != System.DBNull.Value)
                this.IdMethodForm = Convert.ToInt32(row["IdMethodFormMinuta"]);
            this.CriterioCampo = row["CriterioMetodoCampo"].ToString();
            this.CriterioValor = row["CriterioMetodoValor"].ToString();
            if (row["MethodCampoID"] != System.DBNull.Value)
                this.MethodCampoID = Convert.ToInt32(row["MethodCampoID"]);
            this.MethodCamposServicoBody = row["MethodCamposServicoBody"].ToString();
            this.MethodCamposEtapasBody = row["MethodCamposEtapasBody"].ToString();
            this.OrdemMethod = Convert.ToInt32(row["OrdemMethod"]);
            this.MethodPergunta = row["MethodPergunta"].ToString();
            this.MethodEvento = row["MethodEvento"].ToString();
            this.MethodFUP = Convert.ToBoolean(row["MethodFUP"]);
            
            this.SharepointSite = row["SharepointSite"].ToString();
            this.SharepointTabelaGUID = row["SharepointTabelaGUID"].ToString();
            this.SharePointCriterio = row["SharePointCampoChave"].ToString();
            this.MobiosCriterio = row["MobiosCampoChave"].ToString();
            this.TipoCriterio = row["TipoCampoChave"].ToString();
            this.SharepointCampos = row["SharepointCamposNome"].ToString();
            this.MobiosCampos = row["MobiosIdCampos"].ToString();

            if (row["MethodStatusEtapa"] != System.DBNull.Value)
                this.MethodStatusEtapa = Convert.ToInt32(row["MethodStatusEtapa"]);
        }

    }

    public class ClassListEmail
    {
        public string emailParametro { get; set; }
        public string emailAccount { get; set; }
        public string emailSubject { get; set; }
        public string emailBodyHTMLHeader { get; set; }
        public string emailBodyHTMLBody { get; set; }        
        public string emailBodyHTMLFooter { get; set; }        
        public string emailSharepointLink { get; set; }
        //public string emailChaveTimeStamp { get; set; }
        public string emailBodyHeaderInfoOp { get; set; }
        public string emailBodyHeaderInfoEtapa { get; set; }
        public string emailBodyHeaderResposta { get; set; }

        public ClassListEmail()
        { }

        public ClassListEmail(DataRow row)
        {
            this.emailParametro = row["emailParametro"].ToString();
            this.emailAccount = row["emailAccount"].ToString();
            this.emailSubject = row["emailSubject"].ToString();
            this.emailBodyHTMLHeader = row["emailBodyHTMLHeader"].ToString();
            this.emailBodyHTMLBody = row["emailBodyHTMLBody"].ToString();
            this.emailBodyHTMLFooter = row["emailBodyHTMLFooter"].ToString();
            this.emailSharepointLink = row["emailSharepointLink"].ToString();
            //this.emailChaveTimeStamp = row["emailChaveTimeStamp"].ToString();           
            this.emailBodyHeaderInfoOp = row["emailBodyHeaderInfoOp"].ToString();
            this.emailBodyHeaderInfoEtapa = row["emailBodyHeaderInfoEtapa"].ToString();
            this.emailBodyHeaderResposta = row["emailBodyHeaderResposta"].ToString();
        }

    }

    

    #region [ Garantias Offshore ]
    public class IntegrarGarantiasSP
    {
        public int Agencia { get; set; }
        public int Conta { get; set; }
        public int Ag_Vinculada { get; set; }
        public int CC_Vinculada { get; set; }
        public string NomeGarantidor { get; set; }
        public string CNPJ { get; set; }
        public string TipoGarantia { get; set; }
        public string BemGarantia { get; set; }
        public string NaturezaGarantia { get; set; }
        public string ValorGarantia { get; set; }
        public string NomeCampoSP { get; set; }
        public string TipoCampoSP { get; set; }
        public string TipoDados { get; set; }
        public string FormatoCampo { get; set; }
        public string ID_Campo { get; set; }
        public string ID_Etapa { get; set; }
        public string ID_Objeto { get; set; }
        public string ValorCampo { get; set; }
        public bool CampoLista { get; set; }
        public string Produto { get; set; }
        public string Modalidade { get; set; }
        public string Evento { get; set; }
        public string ValorPadraoSP { get; set; }

        public IntegrarGarantiasSP(DataRow row)
        {
            if (row["Agencia"].ToString() != null && row["Agencia"].ToString() != "")
            {
                this.Agencia = Convert.ToInt32(row["Agencia"]);
            }
            if (row["Conta"].ToString() != null && row["Conta"].ToString() != "")
            {
                this.Conta = Convert.ToInt32(row["Conta"]);
            }
            if (row["Ag_Vinculada"].ToString() != null && row["Ag_Vinculada"].ToString() != "")
            {
                this.Ag_Vinculada = Convert.ToInt32(row["Ag_Vinculada"]);
            }
            if (row["CC_Vinculada"].ToString() != null && row["CC_Vinculada"].ToString() != "")
            {
                this.CC_Vinculada = Convert.ToInt32(row["CC_Vinculada"]);
            }
            this.NomeGarantidor = row["NomeGarantidor"].ToString();
            this.CNPJ = row["CNPJ"].ToString();
            this.TipoGarantia = row["Tipo_Garantia"].ToString();
            this.BemGarantia = row["Bem_Garantia"].ToString();
            this.NaturezaGarantia = row["Natureza_Garantia"].ToString();
            this.ValorGarantia = row["Valor_Garantia"].ToString();
            this.NomeCampoSP = row["NomeCampoSP"].ToString();
            this.TipoCampoSP = row["TipoCampoSP"].ToString();
            this.TipoDados = row["TipoDados"].ToString();
            this.FormatoCampo = row["Formato"].ToString();
            this.ID_Campo = row["ID_Campo"].ToString();
            //this.ID_Etapa = row["ID_Etapa"].ToString();
            this.ID_Objeto = row["ID_Objeto"].ToString();
            this.CampoLista = Convert.ToBoolean(row["CampoLista"]);
            this.Produto = row["Produto"].ToString();
            this.Modalidade = row["Modalidade"].ToString();
            this.Evento = row["Evento"].ToString();
            this.ValorPadraoSP = row["ValorPadraoSP"].ToString();
        }
    }
    public class GarantiasValorSP
    {
        public string Objeto { get; set; }
        public string Campo { get; set; }
        public string ValorMobios { get; set; }
        public string ValorSP { get; set; }

        public GarantiasValorSP(DataRow row)
        {
            this.Objeto = row["ID_Objeto"].ToString();
            this.Campo = row["ID_Campo"].ToString();
            this.ValorMobios = row["ValorCampoMobios"].ToString();
            this.ValorSP = row["ValorCampoShare"].ToString();

        }
    }
    public class TiposGarantias
    {
        public string Tipo { get; set; }
        public string Bem { get; set; }
        public string Natureza { get; set; }
        public string Template { get; set; }
        public string Destino { get; set; }

        public TiposGarantias(DataRow row)
        {
            this.Tipo = row["Tipo_Garantia"].ToString();
            this.Bem = row["Bem_Garantia"].ToString();
            this.Natureza = row["Natureza_Garantia"].ToString();
            this.Template = row["SharePointTemplate"].ToString();
            this.Destino = row["SharePointDiretorio"].ToString();

        }
    }
    public class BENgarantias
    {
        public int IdBoleta { get; set; }
        public int IdSeq { get; set; }
        public string Natureza { get; set; }
        public string Bem { get; set; }
        public string TipoGarantia { get; set; }

        public BENgarantias(DataRow row)
        {
            this.IdBoleta = Convert.ToInt32(row["Id_Boleta"]);
            this.IdSeq = Convert.ToInt32(row["ID_SEQ"]);
            this.Natureza = row["tb0131_ContaVinculada;DS_NATUREZA"].ToString();
            this.Bem = row["tb0131_ContaVinculada;DS_BEM"].ToString();
            this.TipoGarantia = row["tb0131_ContaVinculada;DS_TIPO_GARANTIA"].ToString();

        }
    }
    public class BENgarantidores
    {
        public int IdBoleta { get; set; }
        public int IdSeq { get; set; }
        public string CNPJ { get; set; }
        public string Nome { get; set; }
        public string Valor { get; set; }
        public string Percentual { get; set; }

        public BENgarantidores(DataRow row)
        {
            this.IdBoleta = Convert.ToInt32(row["Id_Boleta"]);
            this.IdSeq = Convert.ToInt32(row["ID_SEQ"]);
            this.CNPJ = row["tb0131_ContaVinculada;DS_CNPJ"].ToString();
            this.Nome = row["tb0131_ContaVinculada;DS_NOME"].ToString();
            this.Valor = row["tb0131_ContaVinculada;DS_VALOR"].ToString();
            this.Percentual = row["tb0131_ContaVinculada;DS_PERCENTUAL"].ToString();
        }
    }
    public class ContasVinculadasGarantias
    {
        public int ID_Servico { get; set; }
        public string Agencia { get; set; }
        public string Conta { get; set; }
        public string AgVinc { get; set; }
        public string ContaVinc { get; set; }
        public string CNPJ { get; set; }
        public string NomeGarantidor { get; set; }
        public string Tipo { get; set; }
        public string Bem { get; set; }
        public string Natureza { get; set; }
        public string Porcentagem { get; set; }
        public string Valor { get; set; }
        public string SharePoint { get; set; }
        public string Data_Emissao { get; set; }
        public string IdContaVinculada { get; set; }


        public ContasVinculadasGarantias()
        { }

        public ContasVinculadasGarantias(DataRow row)
        {
            this.ID_Servico = Convert.ToInt32(row["ID_Servico"]);
            this.Tipo = row["Tipo_Garantia"].ToString();
            this.Bem = row["Bem_Garantia"].ToString();
            this.Natureza = row["Natureza_Garantia"].ToString();
            this.CNPJ = row["CNPJ"].ToString();
            this.NomeGarantidor = row["NomeGarantidor"].ToString();
            this.Porcentagem = row["Porcentagem"].ToString();
            this.Valor = row["Valor"].ToString();
            this.IdContaVinculada = row["ID_ContaVinculada"].ToString();


            try
            {
                this.Agencia = row["Agencia"].ToString();
                this.Conta = row["Conta"].ToString();
                this.AgVinc = row["Ag_Vinculada"].ToString();
                this.ContaVinc = row["CC_Vinculada"].ToString();
                this.SharePoint = row["SharePoint"].ToString();
                this.Data_Emissao = row["Data_Emissao"].ToString();
            }
            catch { }
        }
    }
    #endregion
}

