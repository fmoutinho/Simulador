﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using MSXML2;  // Need to add a reference to C:\Windows\System32\msxml3.dll
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Net;
using System.Data;
using System.Configuration;

namespace Mobios
{

    public class TraducaoValoresImportados
    {
        public int Ordem { get; set; }
        public string Identificação { get; set; }
        public string NomeCampoExterno { get; set; }
        public string ValorCampoExterno { get; set; }
        public string NomeCampoMobios { get; set; }
        public string ValorCampoMobios { get; set; }
        public string Evento { get; set; }
        public string Separadores { get; set; }
        public string Posicao { get; set; }

        public TraducaoValoresImportados(DataRow row)
        {
            this.Ordem = Convert.ToInt32(row["Ordem"]);
            this.Identificação = row["SharePoint"].ToString();
            this.NomeCampoExterno = row["NomeCampoSP"].ToString();
            this.ValorCampoExterno = row["ValorCampoSP"].ToString();
            this.NomeCampoMobios = row["NomeCampoMobios"].ToString();
            this.ValorCampoMobios = row["ValorCampoMobios"].ToString();
            this.Evento = row["Evento"].ToString();
            this.Separadores = row["Separadores"].ToString();
            this.Posicao = row["Posicao"].ToString();
        }
    }

    public class SharePointServicoRetorno
    {
        public int Id { get; set; }
        public string CamposCriterioSP { get; set; }
        public string ValoresCriterioSP { get; set; }
        public string TipoCriterioSP { get; set; }
        public string CampoRetornarSP { get; set; } // Para abrir serviço
        public string CampoRetornarMobios { get; set; } // Para abrir serviço
        public string NomeCampoOperacaoSP { get; set; } //Após o serviço aberto | "de"
        public string CampoOperacaoMobios { get; set; } //Após o serviço aberto | "Para"
        public string SharePoint { get; set; }
        public string SharePointIntegracaoURL { get; set; }
        public string SharePointListNameGUID { get; set; }
        public DateTime DataUltimaRotina { get; set; }
        public string CampoAtualizarSP { get; set; }
        public string ValorAtualizarSP { get; set; }
        public string PathMoverAnexo { get; set; }

        public SharePointServicoRetorno(DataRow row)
        {
            this.Id = Convert.ToInt32(row["Id"].ToString());
            this.CamposCriterioSP = row["CamposCriterioSP"].ToString();
            this.ValoresCriterioSP = row["ValoresCriterioSP"].ToString();
            this.TipoCriterioSP = row["TipoCriterioSP"].ToString();
            this.CampoRetornarSP = row["NomeCampoServicoSP"].ToString();
            this.CampoRetornarMobios = row["CampoServicoMobios"].ToString();
            this.NomeCampoOperacaoSP = row["NomeCampoOperacaoSP"].ToString();
            this.CampoOperacaoMobios = row["CampoOperacaoMobios"].ToString();
            this.SharePoint = row["SharePoint"].ToString();
            this.SharePointIntegracaoURL = row["SharePointIntegracaoURL"].ToString();
            this.SharePointListNameGUID = row["SharePointListNameGUID"].ToString();
            if(row["DataUltimaRotina"].ToString() != "")
            {
                this.DataUltimaRotina = Convert.ToDateTime(row["DataUltimaRotina"]);
            }
            this.CampoAtualizarSP = row["CampoAtualizarSP"].ToString();
            this.ValorAtualizarSP = row["ValorAtualizarSP"].ToString();
            this.PathMoverAnexo = row["PathMoverAnexos"].ToString();
        }
    }

    public class SharePointParametrosRetorno
    {
        public string TabelaMobios { get; set; }
        public string CamposCriteriosMobios { get; set; }
        public string ValoresCriteriosMobios { get; set; }
        public string CamposChaveMobios { get; set; }
        public string CamposChaveSP { get; set; }
        public string TipoChaveSP { get; set; }
        public string CamposCriterioSP { get; set; }
        public string ValoresCriterioSP { get; set; }
        public string TipoCriterioSP { get; set; }
        public string CampoRetornarSP { get; set; }
        public string SharePoint { get; set; }
        public string SharePointIntegracaoURL { get; set; }
        public string SharePointListNameGUID { get; set; }
        public string InfoPath { get; set; }
        public string TagRetorno { get; set; }
        public string TipoRetorno { get; set; }
        public string TabelaAtualizar { get; set; }
        public string CamposCriteriosAtualizar { get; set; }
        public string TipoCamposCriteriosAtualizar { get; set; }
        public string CampoAtualizar { get; set; }
        public int StatusRetorno { get; set; }
        public int EtapaStatusRetorno { get; set; }


        //public string SharePoint { get; set; }
        //public string SharePointIntegracaoURL { get; set; }
        //public string SharePointListNameGUID { get; set; }
        //public string CamposCriterioSP { get; set; }
        //public string ValoresCriterioSP { get; set; }
        //public string TipoCriterioSP { get; set; }

        //public string CamposChaveSP { get; set; }
        //public string CamposChaveMobios { get; set; }

        //public string CamposCriteriosMobios { get; set; }
        //public string ValoresCriteriosMobios { get; set; }
        
        //public string CampoRetornarSP { get; set; }
        //public string CampoRetornarMobios { get; set; }

        //public string CamposServicoAtualizar { get; set; }
        //public string ValoresServicoAtualizar { get; set; }

        //public string EtapasStatusAtualizar { get; set; }
        //public string ValoresStatusAtualizar { get; set; }

        //public bool FollowUp { get; set; }

        public SharePointParametrosRetorno(DataRow row)
        {
            this.TabelaMobios = row["TabelaMobios"].ToString();
            this.CamposCriteriosMobios = row["CamposCriteriosMobios"].ToString();
            this.ValoresCriteriosMobios = row["ValoresCriteriosMobios"].ToString();
            this.CamposChaveMobios = row["CamposChaveMobios"].ToString();
            this.CamposChaveSP = row["CamposChaveSP"].ToString();
            this.TipoChaveSP = row["TipoCamposChaveSP"].ToString();
            this.CamposCriterioSP = row["CamposCriterioSP"].ToString();
            this.ValoresCriterioSP = row["ValoresCriterioSP"].ToString();
            this.TipoCriterioSP = row["TipoCriterioSP"].ToString();
            this.CampoRetornarSP = row["CampoRetornarSP"].ToString();
            this.SharePoint = row["SharePoint"].ToString();
            this.SharePointIntegracaoURL = row["SharePointIntegracaoURL"].ToString();
            this.SharePointListNameGUID = row["SharePointListNameGUID"].ToString();
            this.InfoPath = row["InfoPath"].ToString();
            this.TagRetorno = row["TagRetorno"].ToString();
            this.TipoRetorno = row["TipoRetorno"].ToString();
            this.TabelaAtualizar = row["TabelaAtualizar"].ToString();
            this.CamposCriteriosAtualizar = row["CamposCriteriosAtualizar"].ToString();
            this.TipoCamposCriteriosAtualizar = row["TipoCamposCriteriosAtualizar"].ToString();
            this.CampoAtualizar = row["CampoAtualizar"].ToString();
            if (row["StatusRetorno"].ToString() == "")
            {
                this.StatusRetorno = 0;
            }
            else
            {
                this.StatusRetorno = Convert.ToInt32(row["StatusRetorno"]);
            }
            if (row["EtapaStatusRetorno"].ToString() == "")
            {
                this.EtapaStatusRetorno = 0;
            }
            else
            {
                this.EtapaStatusRetorno = Convert.ToInt32(row["EtapaStatusRetorno"]);
            }
        }
    }
    
}
