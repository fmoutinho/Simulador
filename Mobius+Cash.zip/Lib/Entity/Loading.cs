﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mobios
{
    public partial class Loading : Form
    {
            // Static form. Null if no form created yet.
        private static Loading form = null;

        private delegate void EnableDelegate(string texto);
        private delegate void EnableForm(bool visible);

        public Loading()
        {
            InitializeComponent();
            form = this;
        }

        // Static method, call the non-static version if the form exist.
        public static void EnableStaticTextBox(string texto)
        {
            if (form != null)
                form.EnableTextBox(texto);
        }
        private void EnableTextBox(string texto)
        {
            // If this returns true, it means it was called from an external thread.
            if (InvokeRequired)
            {
                // Create a delegate of this method and let the form run it.
                this.Invoke(new EnableDelegate(EnableTextBox), new object[] { texto });
                return; // Important
            }

            // Set textBox
            //label1.Enabled = enable;
            label1.Text = texto;
            Application.DoEvents();
        }

        public static void StaticFormVisible(bool visible)
        {
            if (form != null)
                form.FormVisible(visible);
        }
        private void FormVisible(bool visible)
        {
            // If this returns true, it means it was called from an external thread.
            if (InvokeRequired)
            {
                // Create a delegate of this method and let the form run it.
                this.Invoke(new EnableForm(FormVisible), new object[] { visible });
                return; // Important
            }

            // Set textBox
            //label1.Enabled = enable;
            if (visible == true)
            {
                form.Show();
            }
            else
            {
                form.Hide();
            }

            Application.DoEvents();
        }

        private void Loading_Load(object sender, EventArgs e)
        {

        }
    }

}
