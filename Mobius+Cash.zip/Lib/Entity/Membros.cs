﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Mobios
{
    public class Objeto
    {
        public int ID_Objeto { get; set; }
        public string NomeObjeto { get; set; }
        public string DescricaoObjeto { get; set; }
        public string CategoriaObjeto { get; set; }
        public bool AtivoObjeto { get; set; }
        public int IdSegmento { get; set; }

        public Objeto()
        { }

        public Objeto(DataRow row)
        {
            this.ID_Objeto = Convert.ToInt32(row["ID_Objeto"]);
            this.NomeObjeto = row["NomeObjeto"].ToString();
            this.DescricaoObjeto = row["DescricaoObjeto"].ToString();
            this.CategoriaObjeto = row["CategoriaObjeto"].ToString();
            this.AtivoObjeto = Convert.ToBoolean(row["AtivoObjeto"]);
            this.IdSegmento = row.Table.Columns.Contains("ID_SEGMENTO") ? (row["ID_SEGMENTO"].ToString() == "" ? 0 : Convert.ToInt32(row["ID_SEGMENTO"])) : 0;
        }
    }

    public class FluxoServico
    {
        public int ID_Servico { get; set; }
        public int ID_Objeto { get; set; }
        public int ID_Fluxo { get; set; }
        public string NomeEtapa { get; set; }
        public int ID_Status { get; set; }
        public bool StatusFecha { get; set; }
        public bool StatusPrimeiro { get; set; }
        public bool StatusParalisa { get; set; }
        public bool StatusCancela { get; set; }
        public bool StatusNaoInicia { get; set; }
        public string StatusDescricao { get; set; }
        public int IdResponsavel { get; set; }
        public string NomeResponsavel { get; set; }
        public int AreaResponsavel { get; set; }
        public int CelulaResponsavel { get; set; }
        public int IdMesmoResponsavel { get; set; }
        public bool ValidaResponsavel { get; set; }

        public FluxoServico()
        { }


        public FluxoServico(DataRow row)
        {
            this.ID_Servico = Convert.ToInt32(row["ID_Servico"]);
            this.ID_Fluxo = Convert.ToInt32(row["ID_Fluxo"]);
            this.NomeEtapa = row["NomeEtapa"].ToString();
            this.ID_Status = Convert.ToInt32(row["ID_Status"]);
            this.StatusDescricao = row["StatusDescricao"].ToString();
            this.StatusFecha = Convert.ToBoolean(row["Fecha"]);
            this.StatusPrimeiro = Convert.ToBoolean(row["Primeiro"]);
            this.StatusParalisa = Convert.ToBoolean(row["Paralisa"]);
            this.StatusCancela = Convert.ToBoolean(row["Cancela"]);
            this.StatusNaoInicia = Convert.ToBoolean(row["NaoInicia"]);

            this.IdResponsavel = row.Table.Columns.Contains("IdResponsavelFluxo") ? (row["IdResponsavelFluxo"].ToString() == "" ? 0 : Convert.ToInt32(row["IdResponsavelFluxo"])) : 0;
            this.IdMesmoResponsavel = row.Table.Columns.Contains("IdMesmoResponsavel") ? (row["IdMesmoResponsavel"].ToString() == "" ? 0 : Convert.ToInt32(row["IdMesmoResponsavel"])) : 0;
            
            this.NomeResponsavel = row["ResponsavelFluxo"].ToString();
            this.AreaResponsavel = Convert.ToInt32(row["AreaResponsavel"]);
            this.CelulaResponsavel = Convert.ToInt32(row["CelulaResponsavel"]);

            this.ValidaResponsavel = row.Table.Columns.Contains("ValidaDependente") ? (row["ValidaDependente"].ToString() != "NÃO" ? true : false) : true;
            
        }
    }

    public class FluxoValidaResponsavel
    {
        public int ID_Servico { get; set; }
        public int ID_Etapa { get; set; }
        public int ID_Fluxo { get; set; }
        public int IdResponsavel { get; set; }

        public FluxoValidaResponsavel()
        { }


        public FluxoValidaResponsavel(DataRow row)
        {
            this.ID_Servico = Convert.ToInt32(row["ID_Servico"]);
            this.ID_Etapa = Convert.ToInt32(row["ID_Etapa"]);
            this.ID_Fluxo = Convert.ToInt32(row["ID_Fluxo"]);
            this.IdResponsavel = Convert.ToInt32(row["Id_Responsavel"]);
        }
    }

    public class EtapasObjeto
    {
        public int ID_Objeto { get; set; }
        public string NomeObjeto { get; set; }
        public string DescricaoObjeto { get; set; }
        public int ID_Etapa { get; set; }
        public string NomeEtapa { get; set; }
        public string DescricaoEtapa { get; set; }
        public int OrdemEtapa { get; set; }
        public int ID_Servico { get; set; }
        public int ID_Status { get; set; }
        public int StatusInicial { get; set; }
        public bool StatusFecha { get; set; }
        public bool StatusPrimeiro { get; set; }
        public bool StatusParalisa { get; set; }
        public bool StatusCancela { get; set; }
        public bool StatusNaoInicia { get; set; }
        public int IdMesmoResponsavel { get; set; }
        public int Id_Celula_Responsavel { get; set; }
        public int Id_Area_Responsavel { get; set; }
        public int IdResponsavel { get; set; }
        public string NomeResponsavel { get; set; }
        public bool ValidaResponsavel { get; set; }


        // Geração de indicadores
        //public Boolean EtapaTemIndicador { get; set; }
        //public string EtapaTipoIndicador { get; set; }
        //public string EtapaItemIndicador { get; set; }
        //public string EtapaRegraCalculo { get; set; }
        //public string EtapaEvento { get; set; }
        //public string EtapaAcaoRetorno { get; set; }
        //public string EtapaCampoAtualizar { get; set; }
        //public string EtapaTipoValor { get; set; }

        public EtapasObjeto()
        { }

        public EtapasObjeto(DataRow row)
        {
            this.ID_Objeto = Convert.ToInt32(row["ID_Objeto"]);
            this.ID_Servico = row.Table.Columns.Contains("ID_Servico") ? (row["ID_Servico"].ToString() == "" ? 0 : Convert.ToInt32(row["ID_Servico"])) : 0;
            this.NomeObjeto = row["NomeObjeto"].ToString();
            this.DescricaoObjeto = row["DescricaoObjeto"].ToString();
            this.ID_Etapa = Convert.ToInt32(row["ID_Etapa"]);
            this.NomeEtapa = row["NomeEtapa"].ToString();
            this.DescricaoEtapa = row["DescricaoEtapa"].ToString();
            this.OrdemEtapa = Convert.ToInt32(row["OrdemEtapa"]);
            this.StatusInicial = Convert.ToInt32(row["StatusInicial"]);
            this.StatusPrimeiro = Convert.ToBoolean(row["Primeiro"]);
            this.StatusFecha = Convert.ToBoolean(row["Fecha"]);
            this.StatusParalisa = Convert.ToBoolean(row["Paralisa"]);
            this.StatusCancela = Convert.ToBoolean(row["Cancela"]);
            this.StatusNaoInicia = Convert.ToBoolean(row["NaoInicia"]);
            this.IdMesmoResponsavel = row.Table.Columns.Contains("IdMesmoResponsavel") ? (row["IdMesmoResponsavel"].ToString() == "" ? 0 : Convert.ToInt32(row["IdMesmoResponsavel"])) : 0;
            this.Id_Celula_Responsavel = Convert.ToInt32(row["CelulaResponsavel"]);
            this.Id_Area_Responsavel = Convert.ToInt32(row["AreaResponsavel"]);

            // Geração de indicadores
            //this.EtapaTemIndicador = Convert.ToBoolean(row["EtapaTemIndicador"]);
            //this.EtapaTipoIndicador = row["EtapaTipoIndicador"].ToString();
            //this.EtapaItemIndicador = row["EtapaItemIndicador"].ToString();
            //this.EtapaRegraCalculo = row["EtapaRegraCalculo"].ToString();
            //this.EtapaEvento = row["EtapaEvento"].ToString();
            //this.EtapaAcaoRetorno = row["EtapaAcaoRetorno"].ToString();
            //this.EtapaCampoAtualizar = row["EtapaCampoAtualizar"].ToString();
            //this.EtapaTipoValor = row["EtapaTipoValor"].ToString();


        }
        public EtapasObjeto(EtapasObjeto etp)
        {
            this.ID_Objeto = etp.ID_Objeto;
            this.NomeObjeto = etp.NomeObjeto;
            this.DescricaoObjeto = etp.DescricaoObjeto;
            this.ID_Etapa = etp.ID_Etapa;
            this.NomeEtapa = etp.NomeEtapa;
            this.DescricaoEtapa = etp.DescricaoEtapa;
            this.OrdemEtapa = etp.OrdemEtapa;
            this.ID_Servico = etp.ID_Servico;
            this.ID_Status = etp.ID_Status;
            this.StatusInicial = etp.StatusInicial;
            this.StatusFecha = etp.StatusFecha;
            this.StatusPrimeiro = etp.StatusPrimeiro;
            this.StatusParalisa = etp.StatusParalisa;
            this.StatusCancela = etp.StatusCancela;
            this.StatusNaoInicia = etp.StatusNaoInicia;
            this.IdMesmoResponsavel = etp.IdMesmoResponsavel;
            this.Id_Celula_Responsavel = etp.Id_Celula_Responsavel;
            this.Id_Area_Responsavel = etp.Id_Area_Responsavel;
            this.IdResponsavel = etp.IdResponsavel;
            this.NomeResponsavel = etp.NomeResponsavel;
            this.ValidaResponsavel = etp.ValidaResponsavel;
        }
    }

    #region [ Follow Up ]
    public class FollowUp
    {
        public int ID_Follow { get; set; }
        public int ID_Servico { get; set; }
        public int ID_Fluxo { get; set; }
        public int ID_Campo { get; set; }
        public string FollowUpEtapa { get; set; }
        public string LOGIN { get; set; }
        public string Nome { get; set; }

        public DateTime DataCriacao { get; set; }
        public DateTime DataAlteracao { get; set; }
        
        #region [ CAGI ]
        public DateTime FUPAlerta { get; set; }
        public string CCEmail { get; set; }
        public string Pendencia { get; set; }
        public string Responsavel { get; set; }
        public string EmailResponsavel { get; set; }
        public bool FUPEncerrado { get; set; }
        #endregion

        public FollowUp()
        { }

        public FollowUp(DataRow row)
        {
            this.ID_Follow = Convert.ToInt32(row["ID_Follow"]);
            this.ID_Servico = Convert.ToInt32(row["ID_Servico"]);
            this.ID_Fluxo = row.Table.Columns.Contains("ID_Fluxo") ? (row["ID_Fluxo"].ToString() == "" ? 0 : Convert.ToInt32(row["ID_Fluxo"])) : 0;

            this.ID_Campo = row.Table.Columns.Contains("ID_Campo") ? (row["ID_Campo"].ToString() == "" ? 0 : Convert.ToInt32(row["ID_Campo"])) : 0;
                
            this.FollowUpEtapa = row["FollowUpEtapa"].ToString();
            this.DataCriacao = Convert.ToDateTime(row["DataCriacao"]);
            
            if (row["DataAlteracao"] != System.DBNull.Value)
                this.DataAlteracao = Convert.ToDateTime(row["DataAlteracao"]);

            this.LOGIN = row["Login"].ToString();
            this.Nome = row.Table.Columns.Contains("NomeResponsavel") ? row["NomeResponsavel"].ToString() : "";

            #region [ CAGI ]
            if (row.Table.Columns.Contains("DataAlerta"))
            {
                if (row["DataAlerta"] != System.DBNull.Value)
                    this.FUPAlerta = Convert.ToDateTime(row["DataAlerta"]);
            }
            this.CCEmail = row.Table.Columns.Contains("EmailAccount") ? row["EmailAccount"].ToString() : "";
            this.Pendencia = row.Table.Columns.Contains("Pendencia") ? row["Pendencia"].ToString() : "";
            this.Responsavel = row.Table.Columns.Contains("Responsavel") ? row["Responsavel"].ToString() : "";
            this.EmailResponsavel = row.Table.Columns.Contains("EmailResponsavel") ? row["EmailResponsavel"].ToString() : "";
            this.FUPEncerrado = row.Table.Columns.Contains("FUPEncerrado") ? (row["FUPEncerrado"].ToString() == "" ? false : Convert.ToBoolean(row["FUPEncerrado"])) : false;
            #endregion
        }
    }
    #endregion

    public class Segmento
    {
        public int IdSegmento { get; set; }
        public string Codigo { get; set; }

        public Segmento()
        {

        }

        public Segmento(DataRow row)
        {
            this.IdSegmento = Convert.ToInt32(row["ID_SEGMENTO"]);
            this.Codigo = row["COD_SEGMENTO"].ToString();
        }
    }

    public class Status
    {
        public int ID_Objeto { get; set; }
        public int IdEtapa { get; set; }
        public int ID_Status { get; set; }
        public string StatusDescricao { get; set; }
        public int OrdemStatus { get; set; }
        public string CorStatus { get; set; }
        public bool Primeiro { get; set; }
        public bool Fecha { get; set; }
        public bool Paralisa { get; set; }
        public bool Cancela { get; set; }
        public bool NaoInicia { get; set; }
        public string IdEtapaAlterar { get; set; }
        public string IdStatusAlterar { get; set; }
        public bool FollowUp { get; set; }
        public bool FollowUpObrigatorio { get; set; }
        public bool CustomMethod { get; set; }
        public string IdMethod { get; set; }

        public Status()
        { }

        public Status(Status c)
        {
            this.ID_Objeto = c.ID_Objeto;
            this.ID_Status = c.ID_Status;
            this.StatusDescricao = c.StatusDescricao;
            this.OrdemStatus = c.OrdemStatus;
            this.CorStatus = c.CorStatus;
            this.Primeiro = c.Primeiro;
            this.Fecha = c.Fecha;
            this.Paralisa = c.Paralisa;
            this.Cancela = c.Cancela;
            this.NaoInicia = c.NaoInicia;
            this.IdEtapa = c.IdEtapa;
            this.IdEtapaAlterar = c.IdEtapaAlterar;
            this.IdStatusAlterar = c.IdStatusAlterar;
            this.FollowUp = c.FollowUp;
            this.FollowUpObrigatorio = c.FollowUpObrigatorio;
            this.CustomMethod = c.CustomMethod;
            this.IdMethod = c.IdMethod;
        }

        public Status(DataRow row)
        {
            this.ID_Objeto = Convert.ToInt32(row["ID_Objeto"]);
            this.ID_Status = Convert.ToInt32(row["ID_Status"]);
            this.StatusDescricao = row["StatusDescricao"].ToString();
            this.OrdemStatus = Convert.ToInt32(row["OrdemStatus"]);
            this.CorStatus = row["CorStatus"].ToString();
            this.Primeiro = Convert.ToBoolean(row["Primeiro"]);
            this.Fecha = Convert.ToBoolean(row["Fecha"]);
            this.Paralisa = Convert.ToBoolean(row["Paralisa"]);
            this.Cancela = Convert.ToBoolean(row["Cancela"]);
            this.NaoInicia = Convert.ToBoolean(row["NaoInicia"]);
            this.IdEtapa = Convert.ToInt32(row["ID_Etapa"]);
            this.IdEtapaAlterar = row["ID_Etapa_Alterar"].ToString();
            this.IdStatusAlterar = row["ID_Status_Alterar"].ToString();
            this.FollowUp = Convert.ToBoolean(row["FollowUp"]);
            this.FollowUpObrigatorio = Convert.ToBoolean(row["FollowUpObrigatorio"]);
            this.CustomMethod = Convert.ToBoolean(row["CustomMethod"]);
            this.IdMethod = row["Id_Method"].ToString();
        }

    }

    public class WorkflowEnty
    {
        public int ID_Objeto { get; set; }
        public int ID_Servico { get; set; }
        public int ID_Fluxo { get; set; }
        public int ID_Responsavel { get; set; }
        public int ID_Area { get; set; }
        public int ID_Status { get; set; }
        public int ID_Segmento { get; set; }
        public string NomeObjeto { get; set; }
        public string ServicoName { get; set; }
        public string NomeResponsavel { get; set; }
        public DateTime DataCriacao { get; set; }
        public bool Concluido { get; set; }
        public string NomeEtapa { get; set; }
        public bool ConcluidoFluxo { get; set; }
        public string StatusDescricao { get; set; }

        public WorkflowEnty()
        { }

        public WorkflowEnty(DataRow row)
        {
            this.ID_Objeto = Convert.ToInt32(row["ID_Objeto"]);
            this.ID_Servico = Convert.ToInt32(row["ID_Servico"]);
            this.ID_Fluxo = Convert.ToInt32(row["ID_Fluxo"]);
            this.ID_Responsavel = Convert.ToInt32(row["ID_Responsavel"]);
            this.ID_Area = Convert.ToInt32(row["ID_Area"]);
            this.ID_Status = Convert.ToInt32(row["ID_Status"]);
            //this.ID_Segmento = Convert.ToInt32(row["ID_Segmento"]);
            this.NomeObjeto = row["NomeObjeto"].ToString();
            this.ServicoName = row["ServicoName"].ToString();
            this.NomeResponsavel = row["NomeResponsavel"].ToString();
            this.DataCriacao = Convert.ToDateTime(row["DataCriacao"]);
            this.Concluido = Convert.ToBoolean(row["Concluido"]);
            this.NomeEtapa = row["NomeEtapa"].ToString();
            this.ConcluidoFluxo = Convert.ToBoolean(row["ConcluidoFluxo"]);
            this.StatusDescricao = row["StatusDescricao"].ToString();
        }

    }

    #region [ Pipeline ]
    public class PipelineCampos
    {
        public int Ordem { get; set; }
        public string NomeHeader { get; set; }
        public string NomeDesign { get; set; }
        public string TipoCampo { get; set; }
        public string Formato { get; set; }
        public string MembroLista { get; set; }
        public bool GroupBy { get; set; }
        public bool Visivel { get; set; }
        public int IdCampo { get; set; }
        public string CriterioSQL { get; set; }
        public int Width { get; set; }
        public int Sort { get; set; }
        public string TipoSort { get; set; }
        
        //Informações para filtro
        public bool MostrarFiltro { get; set; }
        public int FiltroLinha { get; set; }
        public int FiltroColuna { get; set; }
        public int FiltroWidth { get; set; }
        public int FiltroHeight { get; set; }
        public int FiltroLabelWidth { get; set; }
        public string FiltroToolTipText { get; set; }
        public string FiltroTIPO { get; set; }
        public string FiltroDominio { get; set; }

        public PipelineCampos()
        { }

        public PipelineCampos(DataRow row)
        {
            this.Ordem = Convert.ToInt32(row["Ordem"]);
            this.NomeHeader = row["NomeHeader"].ToString();
            this.NomeDesign = row["NomeDesign"].ToString();
            this.TipoCampo = row["TipoCampo"].ToString();
            this.Formato = row["Formato"].ToString();
            this.MembroLista = row["MembroLista"].ToString();
            this.GroupBy = Convert.ToBoolean(row["GroupBy"]);
            this.Visivel = Convert.ToBoolean(row["Visivel"]);
            this.IdCampo = row.Table.Columns.Contains("IdCampo") ? (row["IdCampo"].ToString() == "" ? 0 : Convert.ToInt32(row["IdCampo"])) : 0;
            this.Width = row.Table.Columns.Contains("Width") ? (row["Width"].ToString() == "" ? 100 : Convert.ToInt32(row["Width"])) : 100;
            this.CriterioSQL = row["CriterioSQL"].ToString();
            this.Sort = row.Table.Columns.Contains("Sort") ? (row["Sort"].ToString() == "" ? 0 : Convert.ToInt32(row["Sort"])) : 0;
            this.TipoSort = row["TipoSort"].ToString();
            //Filtro
            this.MostrarFiltro = row.Table.Columns.Contains("MostrarFiltro") ? (row["MostrarFiltro"].ToString() == "" ? false : Convert.ToBoolean(row["MostrarFiltro"])) : false;
            this.FiltroLinha = row.Table.Columns.Contains("FiltroLinha") ? (row["FiltroLinha"].ToString() == "" ? 1 : Convert.ToInt32(row["FiltroLinha"])) : 1;
            this.FiltroColuna = row.Table.Columns.Contains("FiltroColuna") ? (row["FiltroColuna"].ToString() == "" ? 1 : Convert.ToInt32(row["FiltroColuna"])) : 1;
            this.FiltroWidth = row.Table.Columns.Contains("FiltroWidth") ? (row["FiltroWidth"].ToString() == "" ? 80 : Convert.ToInt32(row["FiltroWidth"])) : 80;
            this.FiltroHeight = row.Table.Columns.Contains("FiltroHeight") ? (row["FiltroHeight"].ToString() == "" ? 10 : Convert.ToInt32(row["FiltroHeight"])) : 10;
            this.FiltroLabelWidth = row.Table.Columns.Contains("FiltroLabelWidth") ? (row["FiltroLabelWidth"].ToString() == "" ? 80 : Convert.ToInt32(row["FiltroLabelWidth"])) : 80;
            this.FiltroToolTipText = row["FiltroToolTipText"].ToString();
            this.FiltroTIPO = row["FiltroTIPO"].ToString();
            this.FiltroDominio = row["FiltroDominio"].ToString();
        }
    }

    public class PipelineVisual
    {
        public int Ordem { get; set; }
        public string Criterio { get; set; }
        public string Cor { get; set; }
        public string Tipo { get; set; }
        public string Colunas { get; set; }
        public int IdServico { get; set; }

        public PipelineVisual()
        { }

        public PipelineVisual(DataRow row)
        {
            this.Ordem = Convert.ToInt32(row["Ordem"]);
            this.Criterio = row["CriterioCor"].ToString();
            this.Cor = row["Cor"].ToString();
            this.Tipo = row["Tipo"].ToString();
            this.Colunas = row["Colunas"].ToString();
        }
    }
    #endregion

    #region [ Campos ]
    public class Campos
    {
        public int ID_Servico { get; set; }
        public int ID_Objeto { get; set; }
        public int ID_Etapa { get; set; }
        public int ID_Campo { get; set; }
        public string CampoNome { get; set; }
        public string CampoTipo { get; set; }
        public int CampoOrdem { get; set; }
        public string CampoLabel { get; set; }
        public string ToolTip { get; set; }
        public int LabelWidth { get; set; }
        public int CampoLinha { get; set; }
        public int CampoColuna { get; set; }
        public int CampoWidth { get; set; }
        public int CampoHeight { get; set; }
        public string CampoTab { get; set; }
        public string ValorCampo { get; set; }                  // Valor digitado
        public string CampoDominio { get; set; }
        public string CampoBatimento { get; set; }
        public string ValorCampoAntigo { get; set; }            // valor cadastrado 
        public Boolean CampoHabilitado { get; set; }
        public Boolean CampoObrigatorio { get; set; }
        public Boolean CampoHistorico { get; set; }
        public Boolean CampoDependencia { get; set; }

        public Boolean CampoIndicador { get; set; }
        public string CampoTipoIndicador { get; set; }
        public string CampoItemIndicador { get; set; }
        public string CampoRegraCalculo { get; set; }
        public string CampoEvento { get; set; }
        public string CampoAcaoRetorno { get; set; }
        public string CamposAtualizar { get; set; }
        public string CampoTipoValor { get; set; }
        public Boolean CampoGeraFUP { get; set; }
        public string CampoFUPAssociados { get; set; }

        public Campos()
        { }

        public Campos(Campos c)
        {
            this.ID_Servico = c.ID_Servico;
            this.ID_Objeto = c.ID_Objeto;
            this.ID_Etapa = c.ID_Etapa;
            this.ID_Campo = c.ID_Campo;
            this.CampoNome = c.CampoNome;
            this.CampoTipo = c.CampoTipo;
            this.CampoOrdem = c.CampoOrdem;
            this.CampoLabel = c.CampoLabel;
            this.ToolTip = c.ToolTip;
            this.LabelWidth = c.LabelWidth;
            this.CampoLinha = c.CampoLinha;
            this.CampoColuna = c.CampoColuna;
            this.CampoWidth = c.CampoWidth;
            this.CampoHeight = c.CampoHeight;
            this.CampoTab = c.CampoTab;
            this.ValorCampo = c.ValorCampo;
            this.CampoDominio = c.CampoDominio;
            this.CampoBatimento = c.CampoBatimento;
            this.ValorCampoAntigo = c.ValorCampoAntigo;
            this.CampoHabilitado = c.CampoHabilitado;
            this.CampoObrigatorio = c.CampoObrigatorio;
            this.CampoHistorico = c.CampoHistorico;
            this.CampoDependencia = c.CampoDependencia;
            this.CampoIndicador = c.CampoIndicador;
            this.CampoTipoIndicador = c.CampoTipoIndicador;
            this.CampoItemIndicador = c.CampoItemIndicador;
            this.CampoRegraCalculo = c.CampoRegraCalculo;
            this.CampoEvento = c.CampoEvento;
            this.CampoAcaoRetorno = c.CampoAcaoRetorno;
            this.CamposAtualizar = c.CamposAtualizar;
            this.CampoTipoValor = c.CampoTipoValor;
            this.CampoGeraFUP = c.CampoGeraFUP;
            this.CampoFUPAssociados = c.CampoFUPAssociados;
        }

        public Campos(DataRow row)
        {
            this.ID_Servico = row.Table.Columns.Contains("ID_Servico") ? (row["ID_Servico"].ToString() == "" ? 0 : Convert.ToInt32(row["ID_Servico"])) : 0;
            this.ID_Objeto = row.Table.Columns.Contains("ID_Objeto") ? (row["ID_Objeto"].ToString() == "" ? 0 : Convert.ToInt32(row["ID_Objeto"])) : 0;
            this.ID_Etapa = row.Table.Columns.Contains("ID_Etapa") ? (row["ID_Etapa"].ToString() == "" ? 0 : Convert.ToInt32(row["ID_Etapa"])) : 0;
            this.ID_Campo = Convert.ToInt32(row["ID_Campo"]);
            this.CampoNome = row["CampoNome"].ToString();
            this.CampoTipo = row["CampoTipo"].ToString();
            this.CampoOrdem = Convert.ToInt32(row["CampoOrdem"]);
            this.CampoLabel = row["CampoLabel"].ToString();
            this.ToolTip = row["ToolTipText"].ToString();
            this.LabelWidth = row.Table.Columns.Contains("LabelWidth") ? (row["LabelWidth"].ToString() == "" ? 100 : Convert.ToInt32(row["LabelWidth"])) : 100;
            this.CampoWidth = row.Table.Columns.Contains("CampoWidth") ? (row["CampoWidth"].ToString() == "" ? 10 : Convert.ToInt32(row["CampoWidth"])) : 10;
            this.CampoHeight = row.Table.Columns.Contains("CampoHeight") ? (row["CampoHeight"].ToString() == "" ? 10 : Convert.ToInt32(row["CampoHeight"])) : 10;
            
            this.CampoLinha = Convert.ToInt32(row["CampoLinha"]);
            this.CampoColuna = Convert.ToInt32(row["CampoColuna"]);
            this.CampoTab = row["CampoTab"].ToString();
            this.CampoDominio = row["CampoDominio"].ToString();
            this.CampoBatimento = row["CampoBatimento"].ToString();
            this.CampoObrigatorio = Convert.ToBoolean(row["CampoObrigatorio"]);
            this.CampoHabilitado = Convert.ToBoolean(row["CampoHabilitado"]);
            this.CampoHistorico = Convert.ToBoolean(row["CampoHistorico"]);         // teste
            this.CampoDependencia = Convert.ToBoolean(row["CampoDependencia"]);     // teste

            // Geração de indicadores
            this.CampoIndicador = Convert.ToBoolean(row["CampoIndicador"]);         // teste
            this.CampoTipoIndicador = row["CampoTipoIndicador"].ToString();
            this.CampoItemIndicador = row["CampoItemIndicador"].ToString();
            this.CampoRegraCalculo = row["CampoRegraCalculo"].ToString();
            this.CampoEvento = row["CampoEvento"].ToString();
            this.CampoAcaoRetorno = row["CampoAcaoRetorno"].ToString();
            this.CamposAtualizar = row["CamposAtualizar"].ToString();
            this.CampoTipoValor = row["CampoTipoValor"].ToString();
            this.CampoGeraFUP = Convert.ToBoolean(row["CampoGeraFUP"]);
            this.CampoFUPAssociados = row["CampoFUPAssociados"].ToString();

            this.ValorCampo = row.Table.Columns.Contains("ValorCampo") ? row["ValorCampo"].ToString() : "";
            this.ValorCampoAntigo = row.Table.Columns.Contains("ValorCampoAntigo") ? row["ValorCampoAntigo"].ToString() : "";

        }
    }

    public class CamposTabela
    {
        public int ID_Campo { get; set; }
        public string CampoNome { get; set; }
        public string CampoTipo { get; set; }
        public string CampoDominio { get; set; }
        public bool CampoObrigatorio { get; set; }
        public string CampoBatimento { get; set; }
        public bool Chave { get; set; }
        public bool ValoresUnicos { get; set; }
        public bool CampoHabilitado { get; set; }
        public int CampoWidth { get; set; }
        public string ToolTip { get; set; }
        
        public string NomeTabela { get; set; }
        public int IdServico { get; set; }
        public int Linha { get; set; }
        public string ValorCampo { get; set; }
        public string ValorCampoAntigo { get; set; }

        public CamposTabela()
        { }

        public CamposTabela(CamposTabela c)
        {
            this.ID_Campo = c.ID_Campo;
            this.CampoNome = c.CampoNome;
            this.CampoTipo = c.CampoTipo;
            this.CampoDominio = c.CampoDominio;
            this.CampoObrigatorio = c.CampoObrigatorio;
            this.CampoBatimento = c.CampoBatimento;
            this.Chave = c.Chave;
            this.ValoresUnicos = c.ValoresUnicos;
            this.CampoHabilitado = c.CampoHabilitado;
            this.CampoWidth = c.CampoWidth;
            this.ToolTip = c.ToolTip;

            this.NomeTabela = c.NomeTabela;
            this.IdServico = c.IdServico;
            this.Linha = c.Linha;
            this.ValorCampo = c.ValorCampo;
            this.ValorCampoAntigo = c.ValorCampoAntigo;
        }

        public CamposTabela(DataRow row)
        {
            this.ID_Campo = Convert.ToInt32(row["ID_Campo"]);
            this.CampoNome = row["CampoNome"].ToString();
            this.CampoTipo = row["CampoTipo"].ToString();
            this.CampoDominio = row["CampoDominio"].ToString();
            this.CampoObrigatorio = Convert.ToBoolean(row["CampoObrigatorio"]);
            this.CampoBatimento = row["CampoBatimento"].ToString();
            this.Chave = Convert.ToBoolean(row["Chave"]);
            this.ValoresUnicos = Convert.ToBoolean(row["ValoresUnicos"]);
            this.CampoHabilitado = Convert.ToBoolean(row["CampoHabilitado"]);
            this.CampoWidth = row.Table.Columns.Contains("CampoWidth") ? (row["CampoWidth"].ToString() == "" ? 10 : Convert.ToInt32(row["CampoWidth"])) : 10;
            this.ToolTip = row["ToolTipText"].ToString();

            this.NomeTabela = row.Table.Columns.Contains("NomeTabela") ? row["NomeTabela"].ToString() : "";
            this.IdServico = row.Table.Columns.Contains("IdServico") ? (row["IdServico"].ToString() == "" ? 0 : Convert.ToInt32(row["ID_Servico"])) : 0;
            this.ValorCampo = row.Table.Columns.Contains("ValorCampo") ? row["ValorCampo"].ToString() : "";
            this.ValorCampoAntigo = row.Table.Columns.Contains("ValorCampo") ? row["ValorCampo"].ToString() : "";
            this.Linha = row.Table.Columns.Contains("Linha") ? (row["Linha"].ToString() == "" ? 0 : Convert.ToInt32(row["Linha"])) : 0;
        }
    }

    public class CamposInfo
    {
        public int ID_Campo { get; set; }
        public string CampoNome { get; set; }
        public string CampoTipo { get; set; }
        public string CampoDominio { get; set; }
        // Geração de indicadores
        // Geração de indicadores
        public Boolean CampoIndicador { get; set; }
        public string CampoTipoIndicador { get; set; }
        public string CampoItemIndicador { get; set; }
        public string CampoRegraCalculo { get; set; }
        public string CampoEvento { get; set; }
        public string CampoAcaoRetorno { get; set; }
        public string CamposAtualizar { get; set; }
        public string CampoTipoValor { get; set; }
        public Boolean CampoGeraFUP { get; set; }
        public string CampoFUPAssociados { get; set; }

        //public Boolean CampoIndicador { get; set; }
        //public string section { get; set; }
        //public string key { get; set; }
        //public string evento { get; set; }
        //public string QdeEventosEsperados { get; set; }
        //public string AcaoRetorno { get; set; }
        //public string sectionRetorno { get; set; }

        public CamposInfo()
        { }

        public CamposInfo(DataRow row)
        {
            this.ID_Campo = Convert.ToInt32(row["ID_Campo"]);
            this.CampoNome = row["CampoNome"].ToString();
            this.CampoTipo = row["CampoTipo"].ToString();
            this.CampoDominio = row["CampoDominio"].ToString();
            // Geração de indicadores
            //this.CampoIndicador = Convert.ToBoolean(row["CampoIndicador"]);         // teste
            //this.section = row["section"].ToString();
            //this.key = row["key"].ToString();
            //this.evento = row["evento"].ToString();
            //this.QdeEventosEsperados = row["QdeEventosEsperados"].ToString();
            //this.AcaoRetorno = row["AcaoRetorno"].ToString();
            //this.sectionRetorno = row["sectionRetorno"].ToString();

            // Geração de indicadores
            this.CampoIndicador = Convert.ToBoolean(row["CampoIndicador"]);
            this.CampoTipoIndicador = row["CampoTipoIndicador"].ToString();
            this.CampoItemIndicador = row["CampoItemIndicador"].ToString();
            this.CampoRegraCalculo = row["CampoRegraCalculo"].ToString();
            this.CampoEvento = row["CampoEvento"].ToString();
            this.CampoAcaoRetorno = row["CampoAcaoRetorno"].ToString();
            this.CamposAtualizar = row["CamposAtualizar"].ToString();
            this.CampoTipoValor = row["CampoTipoValor"].ToString();
            this.CampoGeraFUP = Convert.ToBoolean(row["CampoGeraFUP"]);
            this.CampoFUPAssociados = row["CampoFUPAssociados"].ToString();


        }
    }

    public class CamposIndicadores
    {
        public int ID_Campo { get; set; }
        public string CampoNome { get; set; }
        public string CampoTipo { get; set; }
        public string ValorCampo { get; set; }                  // Valor digitado
        public string CampoDominio { get; set; }
        public Boolean CampoObrigatorio { get; set; }
        // Geração de indicadores
        public Boolean CampoIndicador { get; set; }
        public string CampoTipoIndicador { get; set; }
        public string CampoItemIndicador { get; set; }
        public string CampoRegraCalculo { get; set; }
        public string CampoEvento { get; set; }
        public string CampoAcaoRetorno { get; set; }
        public string CamposAtualizar { get; set; }
        public string CampoTipoValor { get; set; }
        public Boolean CampoGeraFUP { get; set; }
        public string CampoFUPAssociados { get; set; }

        public CamposIndicadores()
        { }

        public CamposIndicadores(DataRow row)
        {
            this.ID_Campo = Convert.ToInt32(row["ID_Campo"]);
            this.CampoNome = row["CampoNome"].ToString();
            this.CampoTipo = row["CampoTipo"].ToString();
            // Geração de indicadores
            this.CampoIndicador = Convert.ToBoolean(row["CampoIndicador"]);         // teste
            this.CampoTipoIndicador = row["CampoTipoIndicador"].ToString();
            this.CampoItemIndicador = row["CampoItemIndicador"].ToString();
            this.CampoRegraCalculo = row["CampoRegraCalculo"].ToString();
            this.CampoEvento = row["CampoEvento"].ToString();
            this.CampoAcaoRetorno = row["CampoAcaoRetorno"].ToString();
            this.CamposAtualizar = row["CamposAtualizar"].ToString();
            this.CampoTipoValor = row["CampoTipoValor"].ToString();
            this.CampoGeraFUP = Convert.ToBoolean(row["CampoGeraFUP"]);
            this.CampoFUPAssociados = row["CampoFUPAssociados"].ToString();

            this.ValorCampo = row.Table.Columns.Contains("ValorCampo") ? row["ValorCampo"].ToString() : "";
        }
    }

    public class DadosCampos
    {
        public string NomeCampo;
        public string ValorCampo;
        public int Id_Campo;

        public DadosCampos()
        { }

        public DadosCampos(DataRow row)
        {
            this.NomeCampo = row["NomeCampo"].ToString();
            this.ValorCampo = row["ValorCampo"].ToString();
            this.Id_Campo = Convert.ToInt32(row["Id_Campo"]);
        }
    }

    public class DadosCamposTabela
    {
        public int IdServico;
        public int Linha;
        public int IdCampo;
        public string NomeCampo;
        public string ValorCampo;

        public DadosCamposTabela()
        { }

        public DadosCamposTabela(DataRow row)
        {
            this.IdServico = Convert.ToInt32(row["IdServico"]);
            this.NomeCampo = row["NomeCampo"].ToString();
            this.ValorCampo = row["ValorCampo"].ToString();
            this.IdCampo = Convert.ToInt32(row["IdCampo"]);
            this.Linha = Convert.ToInt32(row["Linha"]);
        }
    }

    public class DadosCamposServico
    {
        public string ID_Servico;
        public string ID_Fluxo;
        public string Id_Campo;
        public string NomeCampo;
        public string ValorCampo;

        public DadosCamposServico() { }

        public DadosCamposServico(DataRow row)
        {
            this.ID_Servico = row["ID_Servico"].ToString();
            this.ID_Fluxo = row["ID_Fluxo"].ToString();
            this.Id_Campo = row["Id_Campo"].ToString();
            this.NomeCampo = row["NomeCampo"].ToString();
            this.ValorCampo = row["ValorCampo"].ToString();
        }
    }
    #endregion

    #region [LEGO]
    public class LEGO
    {
        public int ID_LEGO { get; set; }
        public int ID_PLANILHA { get; set; } //Id da planilha da tabela tb_0015_ParametrosArquivosPlanilha
        public int ID_Metodo_Minuta { get; set; } //Id do metodo da tabela tb_0006_CamposObjetosMinuta
        public int ID_CAMPO_MATRIZ { get; set; } //Id do campo onde foi gravado o nome da matriz
        public string PathLEGO { get; set; }
        public string NomeLEGO { get; set; }
        public string PathArquivosTXT { get; set; }
        public string ArquivosTxt_NOMES { get; set; }
        public string ArquivosTxt_NOMES_ToMobios { get; set; }

        //public string PathSaida { get; set; }
        //public string PathMatrizes { get; set; } //Local onde se encontram as matrizes que o arquivo LEGO pode utilizar

        public LEGO()
        { }

        public LEGO(DataRow row)
        {
            this.ID_LEGO = Convert.ToInt32(row["ID_LEGO"]);
            this.ID_PLANILHA = row.Table.Columns.Contains("ID_PLANILHA") ? (row["ID_PLANILHA"].ToString() == "" ? 0 : Convert.ToInt32(row["ID_PLANILHA"])) : 0;
            this.ID_Metodo_Minuta = row.Table.Columns.Contains("ID_Metodo_Minuta") ? (row["ID_Metodo_Minuta"].ToString() == "" ? 0 : Convert.ToInt32(row["ID_Metodo_Minuta"])) : 0;
            this.ID_CAMPO_MATRIZ = row.Table.Columns.Contains("ID_CAMPO_MATRIZ") ? (row["ID_CAMPO_MATRIZ"].ToString() == "" ? 0 : Convert.ToInt32(row["ID_CAMPO_MATRIZ"])) : 0;
            this.PathLEGO = row["PathLEGO"].ToString();
            this.NomeLEGO = row["NomeLEGO"].ToString();
            this.PathArquivosTXT = row["PathArquivosTXT"].ToString();
            this.ArquivosTxt_NOMES = row["ArquivosTxt_NOMES"].ToString();
            this.ArquivosTxt_NOMES_ToMobios = row["ArquivosTxt_NOMES_ToMobios"].ToString();
            //this.PathSaida = row["PathSaida"].ToString();
            //this.PathMatrizes = row["PathMatrizes"].ToString();
        }
    }
    public class CampoAux
    {
        public string ServicoName { get; set; }
        public string IDServicoMobios { get; set; }
    }
    public class CamposEscreverExcel
    {
        public int Ordem { get; set; }
        public int IDcampoMobios { get; set; }
        public string NomeCampoExcel { get; set; }
        public string RefExcelLinCol { get; set; }
        public string NomePlanilha { get; set; }


        public CamposEscreverExcel()
        { }

        public CamposEscreverExcel(DataRow row)
        {
            this.Ordem = Convert.ToInt32(row["Ordem"]);
            this.IDcampoMobios = row.Table.Columns.Contains("IDcampoMobios") ? (row["IDcampoMobios"].ToString() == "" ? 0 : Convert.ToInt32(row["IDcampoMobios"])) : 0;
            this.NomeCampoExcel = row["NomeCampoExcel"].ToString();
            this.RefExcelLinCol = row["RefExcelLinCol"].ToString();
            this.NomePlanilha = row["NomePlanilha"].ToString();

        }
    }
    public class LinhaColuna
    {
        public int rowIndex { get; set; }
        public int colIndex { get; set; }
    }
    #endregion

}
