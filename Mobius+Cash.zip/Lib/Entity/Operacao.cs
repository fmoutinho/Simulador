﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Mobios
{
    public class Operacao
    {
        public string CodContrato { get; set; }
        public int CodBoleto { get; set; }
        public string Produto { get; set; }
        public string Modalidade { get; set; }
        public string Evento { get; set; }
        public DateTime DataNegociacao { get; set; }
        public DateTime DataOperacao { get; set; }
        public DateTime DataVencimento { get; set; }
        public Double Valor { get; set; }
        public string Status { get; set; }
        public string Segmento { get; set; }
        public DateTime DataStatus { get; set; }
        public string Contraparte { get; set; }

        public int SLA
        {
            get { return this.DataOperacao.Subtract(DateTime.Now).Days; }
        }

        public Operacao()
        { }

        public Operacao(DataRow row)
        {
            this.CodContrato = row[0].ToString();
            this.CodBoleto = Convert.ToInt32(row[1]);
            this.Produto = row[2].ToString();
            this.Modalidade = row[3].ToString();
            this.Evento = row[4].ToString();
            this.DataNegociacao = Convert.ToDateTime(row[5]);
            this.DataOperacao = Convert.ToDateTime(row[6]);
            this.DataVencimento = Convert.ToDateTime(row[7]);
            this.Valor = Convert.ToDouble(row[8]);
            this.Status = row[9].ToString();
            this.Segmento = row[10].ToString();

            if(row[11] != System.DBNull.Value)
                this.DataStatus = Convert.ToDateTime(row[11]);

            this.Contraparte = row[12].ToString();
        }
    }
}
