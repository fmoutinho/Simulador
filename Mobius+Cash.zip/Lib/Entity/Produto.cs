﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Mobios
{
    public class Produto
    {

        public int IdProduto { get; set; }
        public string Nome { get; set; }

        public Produto()
        { }

        public Produto(DataRow row)
        {
            this.IdProduto = Convert.ToInt32(row[0]);
            this.Nome = row[1].ToString();
        }
    }
}
