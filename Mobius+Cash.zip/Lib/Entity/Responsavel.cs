﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Mobios
{
    public class Area
    {
        public int ID_AREA { get; set; }
        public string NomeArea { get; set; }
        public bool AtivoArea { get; set; }

        public Area()
        {

        }

        public Area(DataRow row)
        {
            this.ID_AREA = Convert.ToInt32(row["ID_AREA"]);
            this.NomeArea = row["NomeArea"].ToString();
            this.AtivoArea = Convert.ToBoolean(row["AtivoArea"]);
        }

    }

    public class Responsavel
    {
        public int ID_Responsavel { get; set; }
        public string NomeResponsavel { get; set; }
        public string LoginResponsavel { get; set; }
        public string FuncionalResponsavel { get; set; }
        public bool FLG_Gestor { get; set; }
        public bool FLG_AutoProc { get; set; }
        public int ID_Area { get; set; }
        public string NomeArea { get; set; }
        public bool AreaAtiva { get; set; }
        public int ID_Celula { get; set; }
        public string NomeCelula { get; set; }
        public bool CelulaAtiva { get; set; }
        public bool VISAO_AREA { get; set; }
        public string Integradores { get; set; }
        public bool Integra { get; set; }
        public bool UsuarioAtivo { get; set; }
        public int IdCelulaAcesso { get; set; }

        public Responsavel()
        { }

        public Responsavel(DataRow row)
        {
            this.ID_Responsavel = row.Table.Columns.Contains("ID_Responsavel") ? (row["ID_Responsavel"].ToString() == "" ? 0 : Convert.ToInt32(row["ID_Responsavel"])) : 0;
            this.NomeResponsavel = row["NomeResponsavel"].ToString();
            this.LoginResponsavel = row["LoginResponsavel"].ToString();
            this.FuncionalResponsavel = row["FuncionalResponsavel"].ToString();
            this.FLG_Gestor = Convert.ToBoolean(row["FLG_Gestor"]);
            this.FLG_AutoProc = row.Table.Columns.Contains("FLG_AutoProc") ? Convert.ToBoolean(row["FLG_AutoProc"]) : false;
            this.VISAO_AREA = Convert.ToBoolean(row["VISAO_AREA"]);
            this.ID_Area = row.Table.Columns.Contains("ID_Area") ? (row["ID_Area"].ToString() == "" ? 0 : Convert.ToInt32(row["ID_Area"])) : 0;
            this.NomeArea = row.Table.Columns.Contains("NomeArea") ? row["NomeArea"].ToString() : "";
            this.AreaAtiva = row.Table.Columns.Contains("AtivoArea") ? Convert.ToBoolean(row["AtivoArea"]) : false;
            this.ID_Celula = row.Table.Columns.Contains("ID_Celula") ? (row["ID_Celula"].ToString() == "" ? 0 : Convert.ToInt32(row["ID_Celula"])) : 0;
            this.NomeCelula = row.Table.Columns.Contains("NomeCelula") ? row["NomeCelula"].ToString() : "";
            this.CelulaAtiva = row.Table.Columns.Contains("CelulaAtiva") ? Convert.ToBoolean(row["CelulaAtiva"]) : false;
            this.Integradores = row.Table.Columns.Contains("Integradores") ? row["Integradores"].ToString() : "";
            this.Integra = row.Table.Columns.Contains("Integra") ? Convert.ToBoolean(row["Integra"]) : false;
            this.UsuarioAtivo = row.Table.Columns.Contains("ATIVO") ? Convert.ToBoolean(row["ATIVO"]) : false;
            this.IdCelulaAcesso = row.Table.Columns.Contains("CelulaAcessada") ? (row["CelulaAcessada"].ToString() == "" ? 0 : Convert.ToInt32(row["CelulaAcessada"])) : 0;
        }
    }

    public class ResponsavelServico
    {
        public int ID_Servico { get; set; }
        public int ID_Responsavel { get; set; }
        public DateTime DataCriacao { get; set; }
        public string ServicoName { get; set; }
        public string NomeObjeto { get; set; }
        public int ID_Objeto { get; set; }
        public bool Prioridade { get; set; }
        public string Segmento { get; set; }
        public int IdSegmento { get; set; }
        public bool Concluido { get; set; }
                
        public ResponsavelServico()
        { }

        public ResponsavelServico(DataRow row)
        {
            this.ID_Servico = Convert.ToInt32(row["ID_Servico"]);
            this.ID_Responsavel = row.Table.Columns.Contains("ID_Responsavel") ? Convert.ToInt32(row["ID_Responsavel"]) : 0;
            this.DataCriacao = row.Table.Columns.Contains("DataCriacao") ? Convert.ToDateTime(row["DataCriacao"]) : DateTime.Now;
            this.ServicoName = row.Table.Columns.Contains("ServicoName") ? row["ServicoName"].ToString() : "";
            this.NomeObjeto = row.Table.Columns.Contains("NomeObjeto") ? row["NomeObjeto"].ToString() : "";
            this.ID_Objeto = row.Table.Columns.Contains("ID_Objeto") ? Convert.ToInt32(row["ID_Objeto"]) : 0;
            this.Prioridade = row.Table.Columns.Contains("Prioridade") ? Convert.ToBoolean(row["Prioridade"]) : false;
            this.Segmento = row.Table.Columns.Contains("COD_SEGMENTO") ? row["COD_SEGMENTO"].ToString() : "";
            this.Concluido = row.Table.Columns.Contains("Concluido") ? Convert.ToBoolean(row["Concluido"]) : false;
            
        }
    }

    public class ResponsavelCelula
    {
        public string LoginResponsavel { get; set; }
        public int IdResponsavel { get; set; }
        public string NomeResponsavel { get; set; }
        public int IdCelula { get; set; }
        public string NomeCelula { get; set; }
        public string EmailAccount { get; set; }
        public string EmailBox { get; set; }
        public bool FLG_AutoProc { get; set; }

        public ResponsavelCelula()
        { }

        public ResponsavelCelula(DataRow row)
        {
            this.LoginResponsavel = row["LoginResponsavel"].ToString();
            this.IdResponsavel = Convert.ToInt32(row["Id_Responsavel"]);
            this.NomeResponsavel = row["NomeResponsavel"].ToString();
            this.IdCelula = Convert.ToInt32(row["Id_Celula"]);
            this.NomeCelula = row["NomeCelula"].ToString();
            this.EmailAccount = row["EmailAccount"].ToString();
            this.EmailBox = row["EmailBox"].ToString();
            this.FLG_AutoProc = row.Table.Columns.Contains("FLG_AutoProc") ? Convert.ToBoolean(row["FLG_AutoProc"]) : false;
        }
    }

    public class Produto
    {

        public int IdProduto { get; set; }
        public string Nome { get; set; }

        public Produto()
        { }

        public Produto(DataRow row)
        {
            this.IdProduto = Convert.ToInt32(row[0]);
            this.Nome = row[1].ToString();
        }
    }
}
