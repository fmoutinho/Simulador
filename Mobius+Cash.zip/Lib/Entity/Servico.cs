﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Mobios
{
    // Dados do serviço
    public class Servico
    {
        public int ID_Objeto { get; set; }
        public int ID_Servico { get; set; }
        public string Cod_Segmento { get; set; }

        //public int SLA
       // {
        //    get { return this.DataOperacao.Subtract(DateTime.Now).Days; }
       // }

        public Servico()
        { }

        public Servico(DataRow row)
        {
            this.ID_Objeto = Convert.ToInt32(row[0]);
            this.ID_Servico = Convert.ToInt32(row[1]);
            this.Cod_Segmento = row[2].ToString();
        }
    }
}
