﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mobios
{
    public class SuperGrid : DataGridView
    {
        public int PageSize
        {
            get
            {
                return _pageSize;
            }
            set
            {
                _pageSize = value;
            }
        }
        public int _pageSize = 10;
        BindingSource bs;
        BindingList<DataTable> tables;

        public void SetPagedDataSource(DataTable dataTable, BindingNavigator bnav)
        {
            ResetDataGridView();

            bs = new BindingSource();
            tables = new BindingList<DataTable>();
            DataTable dt = null;
            int counter = 1;
            foreach (DataRow dr in dataTable.Rows)
            {
                if (counter == 1)
                {
                    dt = dataTable.Clone();
                    tables.Add(dt);
                }
                dt.Rows.Add((Object[])dr.ItemArray.Clone());
                if (PageSize < ++counter)
                {
                    counter = 1;
                }
            }

            bnav.BindingSource = bs;

            bs.DataSource = tables;
            bs.PositionChanged += bs_PositionChanged;
            bs_PositionChanged(bs, EventArgs.Empty);
            bs.Disposed += bs_Disposed;
        }
        void bs_PositionChanged(object sender, EventArgs e)
        {
            if (bs.Position >= 0)
            {
                var oldTable = this.DataSource as IDisposable;
                if (oldTable != null)
                    oldTable.Dispose();

                this.DataSource = tables[bs.Position].Copy();
            }
            else
            {
                var oldTable = this.DataSource as IDisposable;
                if (oldTable != null)
                    oldTable.Dispose();

                this.DataSource = null;
            }
        }
        void bs_Disposed(object sender, EventArgs e)
        {
            var oldTable = this.DataSource as IDisposable;
            if (oldTable != null)
                oldTable.Dispose();
            this.DataSource = null;

            if (tables != null)
            {
                tables.Clear();
                tables = null;
            }
        }
        public void ResetDataGridView()
        {
            if (bs != null)
            {
                var oldTable = bs.DataSource as IDisposable;
                if (oldTable != null)
                {
                    oldTable.Dispose();
                    oldTable = null;
                }
                bs.DataSource = null;
                bs.Clear();
                bs.Dispose();
                bs = null;
            }
            if (tables != null)
            {
                tables.Clear();
                tables = null;
            }

            var oldTable1 = this.DataSource as IDisposable;
            if (oldTable1 != null)
                oldTable1.Dispose();

            this.DataSource = null;

            GC.Collect();
        }


    }
        
}
