﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Mobios
{
    public class Trinca
    {
        public string Produto { get; set; }
        public string Modalidade { get; set; }
        public string Evento { get; set; }

        public Trinca()
        {

        }

        public Trinca(DataRow row)
        {
            this.Produto = row[0].ToString();
            this.Modalidade = row[1].ToString();
            this.Evento = row[2].ToString();
        }

        public override string ToString()
        {
            return this.Produto + ";" + this.Modalidade + ";" + this.Evento;
        }
    }
}
