﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data;
using System.Configuration;
//using MSXML2;  // Need to add a reference to C:\Windows\System32\msxml3.dll
using System.Xml;
using System.Net;
using System.Globalization;

namespace Mobios
{
    class AbreServico
    {
        public static string AbreNovoServico(string[] NovoServico, string[] CamposNovoServico, string[] CamposMobios = null, string[] ValoresOperacao = null, string SistemaLog = "")
        {

            string msgLog = "Verificando se deve abrir novo serviço";
            Log.GravaLog(msgLog, SistemaLog);

            int IndexSegmento = Array.IndexOf(CamposNovoServico, "[ID_SEGMENTO]");
            int IndexObjeto = Array.IndexOf(CamposNovoServico, "[ID_OBJETO]");
            int IndexName = Array.IndexOf(CamposNovoServico, "[ServicoName]");
            int IndexPrioridade = Array.IndexOf(CamposNovoServico, "[PRIORIDADE]");
            int IndexData = Array.IndexOf(CamposNovoServico, "[DataCriacao]");

            if (IndexSegmento == -1 || IndexObjeto == -1 || IndexName == -1)
            {
                msgLog = "Parâmetros de Campos do Serviço mal cadastrados";
                Log.GravaLog(msgLog, SistemaLog);
                return "";
            }

            int IdSegmento = 0;
            int IdObjeto = 0;
            string ServicoName = NovoServico[IndexName].ToString();
            bool Prioridade = false;
            DateTime DataCriacao = DateTime.Now;

            int IdServico = 0;
            bool gravar = true;
            #region [ valida valores gerais do serviço ]
            try
            {
                #region [ Segmento ]
                Int32 outInt0 = new Int32();
                if (!Int32.TryParse(NovoServico[IndexSegmento], out outInt0))
                {
                    msgLog = "Erro na conversão para inteiro. Campo Segmento está com o valor '" + NovoServico[IndexSegmento].ToString() + "'";
                    Log.GravaLog(msgLog, SistemaLog);
                    gravar = false;
                }
                else
                {
                    IdSegmento = outInt0;
                }
                #endregion

                #region [ Objeto ]
                Int32 outInt1 = new Int32();
                if (!Int32.TryParse(NovoServico[IndexObjeto], out outInt1))
                {
                    msgLog = "Erro na conversão para inteiro. Campo Objeto está com o valor '" + NovoServico[IndexObjeto].ToString() + "' - Provavel erro de configuração na tabela tb_0406_ServicosSharePointValores ou Produto está desativado";
                    Log.GravaLog(msgLog, SistemaLog);
                    gravar = false;
                }
                else
                {
                    IdObjeto = outInt1;
                }
                #endregion

                #region [ Prioridade ]
                if (IndexPrioridade != -1)
                {
                    Boolean outBool = new Boolean();
                    NovoServico[IndexPrioridade] = (NovoServico[IndexPrioridade] == "" ? "false" : NovoServico[IndexPrioridade]);
                    if (!Boolean.TryParse(NovoServico[IndexPrioridade], out outBool))
                    {
                        msgLog = "Erro na conversão para Boolean. Campo Prioridade está com o valor '" + NovoServico[IndexPrioridade].ToString() + "'";
                        Log.GravaLog(msgLog, SistemaLog);
                        gravar = false;
                    }
                    else
                    {
                        Prioridade = outBool;
                    }
                }
                #endregion

                #region [ Data Criação ]
                if (IndexData != -1)
                {
                    DateTime outDate = new DateTime();
                    CultureInfo c = TratamentoLinguagem.BuscarLinguagem("pt-BR");
                    if (!DateTime.TryParse(NovoServico[IndexData], c, DateTimeStyles.None, out outDate))
                    {
                        msgLog = "Erro na conversão para DateTime. Campo NovoServico[4] está com o valor '" + NovoServico[4].ToString() + "'";
                        Log.GravaLog(msgLog, SistemaLog);
                        gravar = false;
                    }
                    else
                    {
                        DataCriacao = outDate;
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                msgLog = "Erro ao salvar serviço: " + ex.Message;
                return "";
            }
            #endregion

            #region [ Cria Serviço ]
            if (gravar)
            {
                if (DataAccess.VerificaServicoExistente(ServicoName) == false)
                {
                    msgLog = "Criando Serviço a partir de SharePoint. Identificação: " + NovoServico[2].ToString() + ".";
                    Log.GravaLog(msgLog, SistemaLog);
                    IdServico = DataAccess.SalvarServico(IdSegmento, IdObjeto, ServicoName, Prioridade, DataCriacao, SistemaLog);
                    if (IdServico != 0)
                    {
                        msgLog = "Serviço " + IdServico;
                        Log.GravaLog(msgLog, SistemaLog);
                    }
                    else
                    {
                        msgLog = "Falha ao salvar serviço";
                        Log.GravaLog(msgLog, SistemaLog);
                        return "";
                    }
                }
                else
                {
                    return "";
                }
            }
            else
            {
                return "";
            }
            #endregion


            #region [ Cria Etapas ]
            TelaDinamica.CriarEtapaFluxo(IdServico, IdObjeto, 0, SistemaLog);
            msgLog = "CriarEtapaFluxo | NovoServico[1](ID do Objeto) = " + IdObjeto + " | IdServico: " + IdServico.ToString();
            Log.GravaLog(msgLog, SistemaLog);
            #endregion

            if (ValoresOperacao != null)
            {
                #region [ Busca Valores de Campos ]
                List<Campos> ListCampos = new List<Campos>();
                ListCampos = DataAccess.buscarCamposDinamicos(IdObjeto);

                if (CamposMobios.Count() == ValoresOperacao.Count())
                {
                    List<Campos> CamposAcrescentar = new List<Campos>();
                    foreach (Campos campo in ListCampos)
                    {
                        #region [ busca valor ]
                        try
                        {
                            for (int i = 0; i < CamposMobios.Count(); i++)
                            {
                                if (campo.ID_Campo.ToString() == CamposMobios[i].ToString())
                                {
                                    campo.ValorCampo = ValoresOperacao[i].ToString();
                                    break;
                                }
                            }
                        }
                        catch { }

                        string nmvalor = "";
                        string rowCampoValor = campo.ValorCampo;
                        if (rowCampoValor != null)
                        {
                            nmvalor = rowCampoValor.ToString().Replace("'", "''").Replace("\"", "\"\"").Trim();
                        }
                        #endregion

                        if (nmvalor != "")
                        {
                            #region [ acrescenta campo ]
                            nmvalor = TelaDinamica.FormatarValorCampo(campo.CampoDominio, nmvalor);

                            campo.ID_Servico = IdServico;
                            campo.ValorCampo = nmvalor;

                            CamposAcrescentar.Add(campo);
                            #endregion

                            #region [Grava dados do indicador]
                            if (campo.CampoIndicador && campo.ValorCampo != campo.ValorCampoAntigo)
                            {
                                TratarEventos.GravaLinhaEvento(IdServico, campo.CampoTipoIndicador, campo.CampoRegraCalculo, campo.CampoItemIndicador, campo.ValorCampo, campo.CampoTipoValor, Environment.UserName.ToUpper(), campo.CampoEvento, "Captura do boleto");
                            }
                            #endregion

                        }
                    }
                    #region [ acrescenta em lote ]
                    if (CamposAcrescentar.Count > 0)
                    {
                        DataAccess.SalvarDadosServicoLote(CamposAcrescentar, SistemaLog);
                    }
                    #endregion
                }
                #endregion
            }

            msgLog = "Novo serviço criado com sucesso.";
            Log.GravaLog(msgLog, SistemaLog);
            return IdServico.ToString();

        }

        public static List<string> AbreServicos(DataTable dt, string CamposServico, string CamposServicoMobios, string Identificador, string CamposOperacao = "", string CamposOperacaoMobios = "", string SistemaLog = "")
        {
            #region [ Parametros ]
            List<TraducaoValoresImportados> TraducaoValores = new List<TraducaoValoresImportados>();
            TraducaoValores = DataAccess.BuscaTraducaoValoresImportados(Identificador);
            string[] CamposServicoArray = CamposServico.Split(';');
            string[] CamposServicoMobiosArray = CamposServicoMobios.Split(';');
            string[] CamposOperacaoArray = CamposOperacao.Split(';');
            string[] CamposOperacaoMobiosArray = CamposOperacaoMobios.Split(';');
            #endregion

            List<string> result = new List<string>();

            foreach (DataRow dtrow in dt.Rows)
            {
                string[] DadosRegistroServico = new string[CamposServicoArray.Count()];

                #region [ Campos do Serviço ]
                int CampoRetorno = 0;
                foreach (string CampoRetornar in CamposServicoArray)
                {
                    #region [ Retorna Valor do Campo ]
                    string[] CampoRetornarSplit = CampoRetornar.Split('|');

                    string ValorRetorno = "";
                    foreach (string campoSplitted in CampoRetornarSplit)
                    {
                        if (campoSplitted != "")
                        {
                            if (campoSplitted.ToUpper() == "MODIFIED" || campoSplitted.ToUpper() == "CREATED")
                            {
                                string valorAtual = dtrow[campoSplitted].ToString();
                                valorAtual = valorAtual.Replace("T", "").Replace("Z", "");
                                ValorRetorno += " " + Convert.ToDateTime(valorAtual).ToString("dd/MM/yyyy HH:mm:ss");
                            }
                            else if (campoSplitted.StartsWith(@"'") && campoSplitted.EndsWith(@"'"))
                            {
                                ValorRetorno += " " + campoSplitted.Replace("'", "");
                            }
                            else
                            {
                                ValorRetorno += " " + dtrow[campoSplitted].ToString();
                            }
                            ValorRetorno = ValorRetorno.Trim().ToUpper();
                        }
                    }
                    #endregion

                    #region [ Retorna Valor Traduzido ]

                    TraducaoValoresImportados ValorEncontrado = TraducaoValores.Find(n => n.Identificação.ToUpper() == Identificador.ToUpper() && n.NomeCampoExterno.ToUpper() == CampoRetornar.ToUpper() && n.ValorCampoExterno.ToUpper() == ValorRetorno && n.NomeCampoMobios.ToUpper() == CamposServicoMobiosArray[CampoRetorno].ToUpper());
                    if (ValorEncontrado != null)
                    {
                        ValorRetorno = ValorEncontrado.ValorCampoMobios.ToString();
                    }
                    else
                    {
                        ValorEncontrado = TraducaoValores.Find(n => n.Identificação.ToUpper() == Identificador.ToUpper() && n.NomeCampoExterno.ToUpper() == CampoRetornar.ToUpper() && n.ValorCampoExterno == "[null]" && n.NomeCampoMobios.ToUpper() == CamposServicoMobiosArray[CampoRetorno].ToUpper());
                        if (ValorEncontrado != null)
                        {
                            ValorRetorno = ValorEncontrado.ValorCampoMobios.ToString();
                        }
                    }

                    #endregion

                    DadosRegistroServico[CampoRetorno] = ValorRetorno;

                    CampoRetorno++;
                }
                #endregion

                #region [ Campos da Operação ]
                CampoRetorno = 0;
                string[] ValoresOperacao = null;
                if (CamposOperacao != "" && CamposOperacaoMobios != "" && CamposOperacaoArray.Count() == CamposOperacaoMobiosArray.Count())
                {
                    ValoresOperacao = new string[CamposOperacaoMobiosArray.Count()];

                    foreach (string CampoRetornar in CamposOperacaoArray)
                    {
                        #region [ Retorna Valor do Campo ]
                        string[] CampoRetornarSplit = CampoRetornar.Split('|');

                        string ValorRetorno = "";
                        foreach (string campoSplitted in CampoRetornarSplit)
                        {
                            if (campoSplitted != "")
                            {
                                if (campoSplitted.ToUpper() == "MODIFIED" || campoSplitted.ToUpper() == "CREATED")
                                {
                                    string valorAtual = dtrow[campoSplitted].ToString();
                                    valorAtual = valorAtual.Replace("T", "").Replace("Z", "");
                                    ValorRetorno = Convert.ToDateTime(valorAtual).ToString("dd/MM/yyyy HH:mm:ss");
                                }
                                else
                                {
                                    ValorRetorno += " " + dtrow[campoSplitted].ToString();
                                }
                                ValorRetorno = ValorRetorno.Trim();
                            }
                        }
                        #endregion

                        #region [ Retorna Valor Traduzido ]
                        TraducaoValoresImportados ValorEncontrado = TraducaoValores.Find(n => n.Identificação.ToUpper() == Identificador.ToUpper() && n.NomeCampoExterno.ToUpper() == CampoRetornar.ToUpper() && n.ValorCampoExterno.ToUpper() == ValorRetorno && n.NomeCampoMobios.ToUpper() == CamposOperacaoMobiosArray[CampoRetorno].ToUpper());
                        if (ValorEncontrado != null)
                        {
                            ValorRetorno = ValorEncontrado.ValorCampoMobios.ToString();
                        }
                        else
                        {
                            ValorEncontrado = TraducaoValores.Find(n => n.Identificação.ToUpper() == Identificador.ToUpper() && n.NomeCampoExterno.ToUpper() == CampoRetornar.ToUpper() && n.ValorCampoExterno == "[null]" && n.NomeCampoMobios.ToUpper() == CamposOperacaoMobiosArray[CampoRetorno].ToUpper());
                            if (ValorEncontrado != null)
                            {
                                ValorRetorno = ValorEncontrado.ValorCampoMobios.ToString();
                            }
                        }

                        #endregion

                        ValoresOperacao[CampoRetorno] = ValorRetorno;

                        CampoRetorno++;
                    }
                }
                #endregion

                string msgLog = "Serviço: " + string.Join(";", CamposServicoMobiosArray) + " - Valores: " + string.Join(";", DadosRegistroServico);
                Log.GravaLog(msgLog, SistemaLog);

                string UltimoIDServicoAberto = AbreNovoServico(DadosRegistroServico, CamposServicoMobiosArray, CamposOperacaoMobiosArray, ValoresOperacao, SistemaLog);
                if (UltimoIDServicoAberto != "")
                {
                    msgLog = "Id Aberto: " + UltimoIDServicoAberto;
                    Log.GravaLog(msgLog, SistemaLog);

                    result.Add(UltimoIDServicoAberto);
                }
            }
            return result;
        }

        public static List<string> AbreServicos(XmlNode Node, SharePointServicoRetorno Parametros, SPwebService.Lists ListService = null, string SistemaLog = "")
        {
            #region [ Parametros ]
            List<TraducaoValoresImportados> TraducaoValores = new List<TraducaoValoresImportados>();
            TraducaoValores = DataAccess.BuscaTraducaoValoresImportados(Parametros.SharePoint);
            string[] CamposServicoArray = Parametros.CampoRetornarSP.Split(';');
            string[] CamposServicoMobiosArray = Parametros.CampoRetornarMobios.Split(';');
            string[] CamposOperacaoArray = Parametros.NomeCampoOperacaoSP.Split(';');
            string[] CamposOperacaoMobiosArray = Parametros.CampoOperacaoMobios.Split(';');

            #endregion

            List<string> result = new List<string>();

            foreach (System.Xml.XmlNode listItem in Node)
            {
                if (listItem.Name == "rs:data")
                {
                    for (int f = 0; f < listItem.ChildNodes.Count; f++)
                    {
                        if (listItem.ChildNodes[f].Name == "z:row")
                        {
                            string[] DadosRegistroServico = new string[CamposServicoArray.Count()];

                            string IDShare = listItem.ChildNodes[f].Attributes["ows_ID"].Value.ToString();

                            #region [ Campos do Serviço ]
                            int CampoRetorno = 0;
                            foreach (string CampoRetornar in CamposServicoArray)
                            {
                                #region [ Retorna Valor do Campo ]
                                string[] CampoRetornarSplit = CampoRetornar.Split('|');

                                string ValorRetorno = "";
                                foreach (string campoSplitted in CampoRetornarSplit)
                                {
                                    if (campoSplitted != "")
                                    {
                                        if (campoSplitted.ToUpper() == "MODIFIED" || campoSplitted.ToUpper() == "CREATED")
                                        {
                                            string campoShare = TratamentoCampo.PrimeiraMaiuscula(campoSplitted);
                                            string valorAtual = listItem.ChildNodes[f].Attributes["ows_" + campoShare].Value.ToString();
                                            valorAtual = valorAtual.Replace("T", "").Replace("Z", "");
                                            ValorRetorno += " " + Convert.ToDateTime(valorAtual).ToString("dd/MM/yyyy HH:mm:ss");
                                        }
                                        else if (campoSplitted.StartsWith(@"'") && campoSplitted.EndsWith(@"'"))
                                        {
                                            ValorRetorno += " " + campoSplitted.Replace("'", "");
                                        }
                                        else
                                        {
                                            if (listItem.ChildNodes[f].Attributes.GetNamedItem("ows_" + campoSplitted) != null)
                                                ValorRetorno += " " + listItem.ChildNodes[f].Attributes["ows_" + campoSplitted].Value.ToString();
                                        }
                                        ValorRetorno = ValorRetorno.Trim().ToUpper();

                                    }
                                }
                                #endregion

                                #region [ Retorna Valor Traduzido ]
                                TraducaoValoresImportados ValorEncontrado = TraducaoValores.Find(n => n.Identificação.ToUpper() == Parametros.SharePoint.ToUpper() && n.NomeCampoExterno.ToUpper() == CampoRetornar.ToUpper() && n.ValorCampoExterno.ToUpper() == ValorRetorno && n.NomeCampoMobios.ToUpper() == CamposServicoMobiosArray[CampoRetorno].ToUpper());
                                if (ValorEncontrado != null)
                                {
                                    ValorRetorno = ValorEncontrado.ValorCampoMobios.ToString();
                                }
                                else
                                {
                                    ValorEncontrado = TraducaoValores.Find(n => n.Identificação.ToUpper() == Parametros.SharePoint.ToUpper() && n.NomeCampoExterno.ToUpper() == CampoRetornar.ToUpper() && n.ValorCampoExterno == "[null]" && n.NomeCampoMobios.ToUpper() == CamposServicoMobiosArray[CampoRetorno].ToUpper());
                                    if (ValorEncontrado != null)
                                    {
                                        ValorRetorno = ValorEncontrado.ValorCampoMobios.ToString();
                                    }
                                }
                                #endregion

                                DadosRegistroServico[CampoRetorno] = ValorRetorno;

                                CampoRetorno++;
                            }
                            #endregion

                            #region [ Campos da Operação ]
                            CampoRetorno = 0;
                            string[] ValoresOperacao = null;
                            if (Parametros.NomeCampoOperacaoSP != "" && Parametros.CampoOperacaoMobios != "" && CamposOperacaoArray.Count() == CamposOperacaoMobiosArray.Count())
                            {
                                ValoresOperacao = new string[CamposOperacaoMobiosArray.Count()];

                                foreach (string CampoRetornar in CamposOperacaoArray)
                                {
                                    #region [ Retorna Valor do Campo ]
                                    string[] CampoRetornarSplit = CampoRetornar.Split('|');

                                    string ValorRetorno = "";

                                    foreach (string campoSplitted in CampoRetornarSplit)
                                    {
                                        if (campoSplitted != "")
                                        {
                                            if (listItem.ChildNodes[f].Attributes.GetNamedItem("ows_" + campoSplitted) != null)
                                            {
                                                if (campoSplitted.ToUpper() == "MODIFIED" || campoSplitted.ToUpper() == "CREATED")
                                                {
                                                    string campoShare = TratamentoCampo.PrimeiraMaiuscula(campoSplitted);
                                                    string valorAtual = listItem.ChildNodes[f].Attributes["ows_" + campoShare].Value.ToString();
                                                    valorAtual = valorAtual.Replace("T", "").Replace("Z", "");
                                                    ValorRetorno += " " + Convert.ToDateTime(valorAtual).ToString("dd/MM/yyyy HH:mm:ss");
                                                }
                                                else
                                                {
                                                    ValorRetorno = listItem.ChildNodes[f].Attributes["ows_" + campoSplitted].Value.ToString();
                                                }
                                                ValorRetorno = ValorRetorno.Trim();
                                            }
                                        }
                                    }
                                    #endregion

                                    #region [ Retorna Valor Traduzido ]
                                    TraducaoValoresImportados ValorEncontrado = TraducaoValores.Find(n => n.Identificação.ToUpper() == Parametros.SharePoint.ToUpper() && n.NomeCampoExterno.ToUpper() == CampoRetornar.ToUpper() && n.ValorCampoExterno.ToUpper() == ValorRetorno && n.NomeCampoMobios.ToUpper() == CamposOperacaoMobiosArray[CampoRetorno].ToUpper());
                                    if (ValorEncontrado != null)
                                    {
                                        ValorRetorno = ValorEncontrado.ValorCampoMobios.ToString();
                                    }
                                    else
                                    {
                                        ValorEncontrado = TraducaoValores.Find(n => n.Identificação.ToUpper() == Parametros.SharePoint.ToUpper() && n.NomeCampoExterno.ToUpper() == CampoRetornar.ToUpper() && n.ValorCampoExterno == "[null]" && n.NomeCampoMobios.ToUpper() == CamposOperacaoMobiosArray[CampoRetorno].ToUpper());
                                        if (ValorEncontrado != null)
                                        {
                                            ValorRetorno = ValorEncontrado.ValorCampoMobios.ToString();
                                        }
                                    }
                                    #endregion

                                    ValoresOperacao[CampoRetorno] = ValorRetorno;

                                    CampoRetorno++;
                                }
                            }
                            #endregion

                            string UltimoIDServicoAberto = AbreNovoServico(DadosRegistroServico, CamposServicoMobiosArray, CamposOperacaoMobiosArray, ValoresOperacao, SistemaLog);
                            if (UltimoIDServicoAberto != "")
                            {
                                result.Add(UltimoIDServicoAberto);
                                string msgLog = "Serviço ID:" + UltimoIDServicoAberto + " aberto...";
                                Log.GravaLog(msgLog, SistemaLog);
                            }

                            #region [ Atualiza SharePoint ]
                            if (UltimoIDServicoAberto != "")
                            {
                                if (Parametros.CampoAtualizarSP.ToString() != "" && Parametros.ValorAtualizarSP.ToString() != "")
                                {
                                    bool atualizaValor = true;

                                    if (SharedData.gHomologação)
                                    {
                                        if (MessageBox.Show("Uma nova operação {" + DadosRegistroServico[2].ToString() + "} foi importada do SharePoint: " + Parametros.SharePoint + "\n\nComo está em HOMOLOGAÇÃO, atualizar os campos {" + Parametros.CampoAtualizarSP + "} no SharePoint para {" + Parametros.ValorAtualizarSP + "}?\n\nProssiga apenas se for um registro de teste.", "Atualiza campos SharePoint", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
                                        {
                                            atualizaValor = false;
                                        }
                                    }
                                    if (atualizaValor)
                                    {
                                        string[] CampoAtualizarSPArray = (Parametros.CampoAtualizarSP + ";ID").Split(';');
                                        string[] ValorAtualizarSPArray = (Parametros.ValorAtualizarSP + ";" + IDShare).Split(';');
                                        if (CampoAtualizarSPArray.Count() == ValorAtualizarSPArray.Count())
                                        {
                                            SharePoint.GravarRegistro(Parametros.SharePointIntegracaoURL, Parametros.SharePointListNameGUID, CampoAtualizarSPArray, ValorAtualizarSPArray, "UPDATE", SistemaLog);
                                        }
                                        if (SharedData.gHomologação)
                                        {
                                            MessageBox.Show("Campos atualizados.", "Atualiza campos SharePoint", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        }
                                    }
                                }
                            }
                            #endregion

                            #region [ Move Anexos do Sharepoint ]
                            if (UltimoIDServicoAberto != "")
                            {
                                if (Parametros.PathMoverAnexo.ToString() != "")
                                {
                                    if (SharedData.gHomologação)
                                    {
                                        string pathCopia = SharedData.BDPath + "Documentos\\" + UltimoIDServicoAberto + "\\";
                                        SharePoint.CopiarAnexos(Parametros.SharePointListNameGUID, Parametros.SharePointIntegracaoURL, Convert.ToInt32(IDShare), pathCopia, true, ListService);
                                    }
                                    else
                                    {
                                        string PathMover = TratamentoCampo.AdicionaBarraPath(Parametros.PathMoverAnexo) + UltimoIDServicoAberto + "\\";
                                        SharePoint.MoverAnexos(Parametros.SharePointListNameGUID, Parametros.SharePointIntegracaoURL, Convert.ToInt32(IDShare), PathMover, true, ListService);
                                    }
                                }
                            }
                            #endregion
                        }
                    }
                }
            }
            return result;
        }
    }
}
