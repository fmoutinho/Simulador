﻿//using Microsoft.Office.InfoPath;
//using System;
//using System.Xml;
//using System.Xml.XPath;

//namespace Mobios
//{
//    public partial class FormCode
//    {
//        private object _strUri
//        {
//            get
//            {
//                return FormState["_strUri"];
//            }
//            set
//            {
//                FormState["_strUri"] = value;
//            }
//        }


//        // NOTE: The following procedure is required by Microsoft Office InfoPath.
//        // It can be modified using Microsoft Office InfoPath.
//        public void InternalStartup()
//        {
//            EventManager.FormEvents.Submit += new SubmitEventHandler(FormEvents_Submit);
//            EventManager.FormEvents.Loading += new LoadingEventHandler(FormEvents_Loading);
//        }

//        public void FormEvents_Submit(object sender, SubmitEventArgs e)
//        {
//            //Create a Navigator object for the main DOM
//            XPathNavigator xnDoc = this.MainDataSource.CreateNavigator();

//            //Create Navigator objects for each field we will use to modify the FolderUrl
//            XPathNavigator xnLocation = xnDoc.SelectSingleNode("my:myFields/my:strLocation", this.NamespaceManager);
//            XPathNavigator xnFolderName = xnDoc.SelectSingleNode("my:myFields/my:strFolderName", this.NamespaceManager);

//            //Get a reference to the submit data connection
//            FileSubmitConnection fc = (FileSubmitConnection)this.DataConnections["Main submit"];

//            //Modify the URL we want to submit to by concatenating the 
//            //xnLocation and xnFolderName values
//            fc.FolderUrl = xnLocation.Value + "/" + xnFolderName.Value;

//            //Execute the submit connection
//            try
//            {
//                fc.Execute();
//                e.CancelableArgs.Cancel = false;
//            }
//            catch (Exception ex)
//            {
//                e.CancelableArgs.Cancel = true;
//            }
//        }

//        public void FormEvents_Loading(object sender, LoadingEventArgs e)
//        {
//            //Get the Uri (or SaveLocation in a browser form) of where 
//            //the form was opened 
//            //See if the form was opened in the browser
//            Boolean OpenedInBrowser = Application.Environment.IsBrowser;

//            //If so, we will get the "SaveLocation" from the InputParameters
//            if (OpenedInBrowser)
//                _strUri = e.InputParameters["SaveLocation"].ToString();
//            else
//                //If it was opened in the client, we will get the Uri
//                _strUri = this.Template.Uri.ToString();

//            //Populate the fields on the form - keep in mind, this is not necessary - 
//            //this is simply to see the process in action
//            PopulateLibInfo(OpenedInBrowser);

//        }

//        private void PopulateLibInfo(Boolean OpenedInBrowser)
//        {
//            //Create a Navigator object for the main DOM
//            XPathNavigator xnDoc = this.MainDataSource.CreateNavigator();

//            //Create Navigator objects for each field
//            XPathNavigator xnFormURL = xnDoc.SelectSingleNode("my:myFields/my:strFormURL", this.NamespaceManager);
//            XPathNavigator xnLocation = xnDoc.SelectSingleNode("my:myFields/my:strLocation", this.NamespaceManager);
//            XPathNavigator xnFolderName = xnDoc.SelectSingleNode("my:myFields/my:strFolderName", this.NamespaceManager);

//            //Get the Uri stored in the FormState Dictionary variable
//            string strUri = _strUri.ToString();

//            //Create a variable to store the path (URL) to the document library
//            string strPath = "";
//            if (OpenedInBrowser == true)
//            {
//                //If we are open in the browser, the strUri value is just
//                //the server name and library - so we just need to get the URL
//                //without the last "/"
//                strPath = strUri.Substring(0, strUri.LastIndexOf("/"));
//            }
//            else
//            {
//                //Parse just the path to the document library - 
//                //this would return something like this: http://server/library                				
//                strPath = strUri.Substring(0, strUri.IndexOf("Forms") - 1);
//            }

//            //Now, parse the URL to where the document library resides - 
//            //this would return something like: http://server or http://server/site
//            string strLoc = strPath.Substring(0, strPath.LastIndexOf("/"));

//            //Lastly, parse the URL to return just the document library name - 
//            //in this case,we are looking for the last "/" character 
//            // knowing that what comes after this is the document library name
//            string strFolder = strPath.Substring(strPath.LastIndexOf("/") + 1);

//            //Populate the fields on the form – we will use these values
//            //in the Submit process
//            xnFormURL.SetValue(strUri);
//            xnLocation.SetValue(strLoc);
//            xnFolderName.SetValue(strFolder);
//        }
//    }
//}
