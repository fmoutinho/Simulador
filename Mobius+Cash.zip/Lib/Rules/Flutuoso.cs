﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Mobios
{
    public class Flutuoso
    {

        private bool Visivel = false;
        private Form Pai;
        private Control PaiControl;
        private int Tamanho = 250;
        private bool ArrastarPaineis = true;
        private bool _ControlParent = false;
        public Button Alca = new Button();

        private Control Layout;

        private Posicao p;
        private bool Fazendo = false;

        public void Criar(Posicao Pos, int TamanhoPainel, Control Painel, bool Arrastar = true, bool ControlParent = false)
        {

            string Tipo = Painel.GetType().ToString();

            if (Tipo.ToLower().Contains("groupbox"))
                Layout = (GroupBox)Painel;


            if (Tipo.ToLower().Contains("panel"))
                Layout = (Panel)Painel;

            if (Tipo.ToLower().Contains("tabcontrol"))
                Layout = (Panel)Painel;

            Layout = Painel;
            Tamanho = TamanhoPainel;
            ArrastarPaineis = Arrastar;
            _ControlParent = ControlParent;

            if (_ControlParent)
                PaiControl = Layout.Parent;
            else
                Pai = Layout.FindForm();

            p = Pos;

            Panel pn = new Panel();
            Panel Margem = new Panel();

            pn.Name = "FlutuosoPanel";
            Margem.Name = "FlutuosoMargem";

            if (_ControlParent)
            {
                PaiControl.Controls.Add(pn);
                PaiControl.Controls.Add(Margem);
            }
            else
            {
                Pai.Controls.Add(pn);
                Pai.Controls.Add(Margem);
            }
            

            pn.BackColor = System.Drawing.Color.White;

            pn.BorderStyle = BorderStyle.FixedSingle;

            if (_ControlParent)
            {
                PaiControl.Controls["FlutuosoPanel"].BringToFront();

                PaiControl.Controls["FlutuosoPanel"].Controls.Add(Layout);
                PaiControl.Controls["FlutuosoPanel"].Controls[Layout.Name].Dock = DockStyle.Fill;
                PaiControl.Controls["FlutuosoPanel"].Controls[Layout.Name].BringToFront();
                PaiControl.Controls["FlutuosoPanel"].Controls[Layout.Name].Visible = true;
            }
            else
            {
                Pai.Controls["FlutuosoPanel"].BringToFront();

                Pai.Controls["FlutuosoPanel"].Controls.Add(Layout);
                Pai.Controls["FlutuosoPanel"].Controls[Layout.Name].Dock = DockStyle.Fill;
                Pai.Controls["FlutuosoPanel"].Controls[Layout.Name].BringToFront();
                Pai.Controls["FlutuosoPanel"].Controls[Layout.Name].Visible = true;
            }

            Alca.Name = "FlutuosoAlca";

            Alca.Click += bt_Click;
            //Alca.MouseLeave += bt_MouseLeave;
            //Alca.MouseEnter += Alca_MouseEnter;

            Alca.Cursor = System.Windows.Forms.Cursors.Hand;

            if (_ControlParent)
            {
                PaiControl.Controls.Add(Alca);

                PaiControl.Controls["FlutuosoAlca"].BringToFront();
            }
            else
            {
                Pai.Controls.Add(Alca);

                Pai.Controls["FlutuosoAlca"].BringToFront();
            }
            defPosicaoInicial();


        }

        //static void Alca_MouseEnter(object sender, EventArgs e)
        //{
        //    if (Fazendo == false && Visivel == false)
        //        ExibeOculta();
        //}

        //static void bt_MouseLeave(object sender, EventArgs e)
        //{
        //    if(Fazendo==false && Visivel==true)
        //      ExibeOculta();
        //}

        private void defPosicaoInicial()
        {

            if (p == Posicao.Direita)
            {
                if (_ControlParent)
                {
                    PaiControl.Width = 30;
                }
                if (ArrastarPaineis == true)
                {
                    if (_ControlParent)
                    {
                        PaiControl.Controls["FlutuosoMargem"].Dock = DockStyle.Right;
                        PaiControl.Controls["FlutuosoMargem"].SendToBack();
                        PaiControl.Controls["FlutuosoMargem"].Width = 30;
                    }
                    else
                    {
                        Pai.Controls["FlutuosoMargem"].Dock = DockStyle.Right;
                        Pai.Controls["FlutuosoMargem"].SendToBack();
                        Pai.Controls["FlutuosoMargem"].Width = 30;
                    }
                }

                if (_ControlParent)
                {
                    PaiControl.Controls["FlutuosoPanel"].Left = PaiControl.Width - 20;
                    PaiControl.Controls["FlutuosoPanel"].Top = 0;
                    PaiControl.Controls["FlutuosoPanel"].Height = PaiControl.Height;
                    PaiControl.Controls["FlutuosoPanel"].Width = Tamanho;
                    PaiControl.Controls["FlutuosoPanel"].Anchor = AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom;


                    PaiControl.Controls["FlutuosoAlca"].Height = PaiControl.Height;
                    PaiControl.Controls["FlutuosoAlca"].Width = 30;
                    PaiControl.Controls["FlutuosoAlca"].Left = PaiControl.Width - 38;
                    PaiControl.Controls["FlutuosoAlca"].Top = 0;
                    PaiControl.Controls["FlutuosoAlca"].Anchor = AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom;
                }
                else
                {
                    Pai.Controls["FlutuosoPanel"].Left = Pai.Width - 20;
                    Pai.Controls["FlutuosoPanel"].Top = 0;
                    Pai.Controls["FlutuosoPanel"].Height = Pai.Height;
                    Pai.Controls["FlutuosoPanel"].Width = Tamanho;
                    Pai.Controls["FlutuosoPanel"].Anchor = AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom;


                    Pai.Controls["FlutuosoAlca"].Height = Pai.Height;
                    Pai.Controls["FlutuosoAlca"].Width = 30;
                    Pai.Controls["FlutuosoAlca"].Left = Pai.Width - 38;
                    Pai.Controls["FlutuosoAlca"].Top = 0;
                    Pai.Controls["FlutuosoAlca"].Anchor = AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom;
                }
            }

            if (p == Posicao.Esquerda)
            {
                if (_ControlParent)
                {
                    PaiControl.Width = 30;
                }
                if (ArrastarPaineis == true)
                {
                    if (_ControlParent)
                    {
                        PaiControl.Controls["FlutuosoMargem"].Dock = DockStyle.Left;
                        PaiControl.Controls["FlutuosoMargem"].SendToBack();
                        PaiControl.Controls["FlutuosoMargem"].Width = 30;
                    }
                    else
                    {
                        Pai.Controls["FlutuosoMargem"].Dock = DockStyle.Left;
                        Pai.Controls["FlutuosoMargem"].SendToBack();
                        Pai.Controls["FlutuosoMargem"].Width = 30;
                    }
                }

                if (_ControlParent)
                {
                    PaiControl.Controls["FlutuosoPanel"].Left = 0 - (Tamanho - 5);
                    PaiControl.Controls["FlutuosoPanel"].Top = 0;
                    PaiControl.Controls["FlutuosoPanel"].Height = PaiControl.Height;
                    PaiControl.Controls["FlutuosoPanel"].Width = Tamanho;
                    PaiControl.Controls["FlutuosoPanel"].Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Bottom;

                    PaiControl.Controls["FlutuosoAlca"].Height = PaiControl.Height;
                    PaiControl.Controls["FlutuosoAlca"].Width = 30;
                    PaiControl.Controls["FlutuosoAlca"].Left = 0;
                    PaiControl.Controls["FlutuosoAlca"].Top = 0;
                    PaiControl.Controls["FlutuosoAlca"].Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Bottom;
                }
                else
                {
                    Pai.Controls["FlutuosoPanel"].Left = 0 - (Tamanho - 5);
                    Pai.Controls["FlutuosoPanel"].Top = 0;
                    Pai.Controls["FlutuosoPanel"].Height = Pai.Height;
                    Pai.Controls["FlutuosoPanel"].Width = Tamanho;
                    Pai.Controls["FlutuosoPanel"].Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Bottom;

                    Pai.Controls["FlutuosoAlca"].Height = Pai.Height;
                    Pai.Controls["FlutuosoAlca"].Width = 30;
                    Pai.Controls["FlutuosoAlca"].Left = 0;
                    Pai.Controls["FlutuosoAlca"].Top = 0;
                    Pai.Controls["FlutuosoAlca"].Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Bottom;
                }
            }

            if (p == Posicao.Base)
            {
                if (_ControlParent)
                {
                    PaiControl.Height = 30;
                }
                if (ArrastarPaineis == true)
                {
                    if (_ControlParent)
                    {
                        PaiControl.Controls["FlutuosoMargem"].Dock = DockStyle.Bottom;
                        PaiControl.Controls["FlutuosoMargem"].SendToBack();
                        PaiControl.Controls["FlutuosoMargem"].Height = 30;
                    }
                    else
                    {
                        Pai.Controls["FlutuosoMargem"].Dock = DockStyle.Bottom;
                        Pai.Controls["FlutuosoMargem"].SendToBack();
                        Pai.Controls["FlutuosoMargem"].Height = 30;
                    }
                }

                if (_ControlParent)
                {
                    PaiControl.Controls["FlutuosoPanel"].Left = 0;
                    PaiControl.Controls["FlutuosoPanel"].Top = PaiControl.Height - 30;
                    PaiControl.Controls["FlutuosoPanel"].Height = Tamanho;
                    PaiControl.Controls["FlutuosoPanel"].Width = PaiControl.Width - 10;
                    PaiControl.Controls["FlutuosoPanel"].Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;

                    PaiControl.Controls["FlutuosoAlca"].Height = 30;
                    PaiControl.Controls["FlutuosoAlca"].Top = PaiControl.Height - PaiControl.Controls["FlutuosoAlca"].Height - 30;
                    PaiControl.Controls["FlutuosoAlca"].Width = PaiControl.Width - 10;
                    PaiControl.Controls["FlutuosoAlca"].Left = 0;
                    PaiControl.Controls["FlutuosoAlca"].Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
                }
                else
                {
                    Pai.Controls["FlutuosoPanel"].Left = 0;
                    Pai.Controls["FlutuosoPanel"].Top = Pai.Height - 30;
                    Pai.Controls["FlutuosoPanel"].Height = Tamanho;
                    Pai.Controls["FlutuosoPanel"].Width = Pai.Width - 10;
                    Pai.Controls["FlutuosoPanel"].Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;

                    Pai.Controls["FlutuosoAlca"].Height = 30;
                    Pai.Controls["FlutuosoAlca"].Top = Pai.Height - Pai.Controls["FlutuosoAlca"].Height - 30;
                    Pai.Controls["FlutuosoAlca"].Width = Pai.Width - 10;
                    Pai.Controls["FlutuosoAlca"].Left = 0;
                    Pai.Controls["FlutuosoAlca"].Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
                }
            }


            if (p == Posicao.Topo)
            {
                if (_ControlParent)
                {
                    PaiControl.Height = 30;
                }
                if (ArrastarPaineis == true)
                {
                    if (_ControlParent)
                    {
                        PaiControl.Controls["FlutuosoMargem"].Dock = DockStyle.Top;
                        PaiControl.Controls["FlutuosoMargem"].SendToBack();
                        PaiControl.Controls["FlutuosoMargem"].Height = 30;
                    }
                    else
                    {
                        Pai.Controls["FlutuosoMargem"].Dock = DockStyle.Top;
                        Pai.Controls["FlutuosoMargem"].SendToBack();
                        Pai.Controls["FlutuosoMargem"].Height = 30;
                    }
                }

                if (_ControlParent)
                {
                    PaiControl.Controls["FlutuosoPanel"].Left = 0;
                    PaiControl.Controls["FlutuosoPanel"].Top = 0 - Tamanho;
                    PaiControl.Controls["FlutuosoPanel"].Height = Tamanho;
                    PaiControl.Controls["FlutuosoPanel"].Width = PaiControl.Width;
                    PaiControl.Controls["FlutuosoPanel"].Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;

                    PaiControl.Controls["FlutuosoAlca"].Height = 30;
                    PaiControl.Controls["FlutuosoAlca"].Width = PaiControl.Width;
                    PaiControl.Controls["FlutuosoAlca"].Left = 0;
                    PaiControl.Controls["FlutuosoAlca"].Top = 0;
                    PaiControl.Controls["FlutuosoAlca"].Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
                }
                else
                {
                    Pai.Controls["FlutuosoPanel"].Left = 0;
                    Pai.Controls["FlutuosoPanel"].Top = 0 - Tamanho;
                    Pai.Controls["FlutuosoPanel"].Height = Tamanho;
                    Pai.Controls["FlutuosoPanel"].Width = Pai.Width;
                    Pai.Controls["FlutuosoPanel"].Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;

                    Pai.Controls["FlutuosoAlca"].Height = 30;
                    Pai.Controls["FlutuosoAlca"].Width = Pai.Width;
                    Pai.Controls["FlutuosoAlca"].Left = 0;
                    Pai.Controls["FlutuosoAlca"].Top = 0;
                    Pai.Controls["FlutuosoAlca"].Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
                }
            }

        }

        public enum Posicao
        {

            Topo = 1,
            Direita = 2,
            Esquerda = 3,
            Base = 4,

        }

        void bt_Click(object sender, EventArgs e)
        {
            Alca.Enabled = false;
            ExibeOculta();
            Alca.Enabled = true;
        }

        delegate void execFlutuoso();

        private void ProcessarDireita()
        {

            Fazendo = true;

            if (Visivel == false)
            {
                for (int i = 0; i < (Tamanho - 20); i+=5)
                {
                    if (_ControlParent)
                    {
                        PaiControl.Controls["FlutuosoPanel"].Left -= 5;
                        PaiControl.Controls["FlutuosoAlca"].Left -= 5;
                    }
                    else
                    {
                        Pai.Controls["FlutuosoPanel"].Left -= 5;
                        Pai.Controls["FlutuosoAlca"].Left -= 5;
                    }
                    if (ArrastarPaineis)
                    {
                        if (_ControlParent)
                        {
                            PaiControl.Controls["FlutuosoMargem"].Width += 5;
                            PaiControl.Width += 5;
                        }
                        else
                        {
                            Pai.Controls["FlutuosoMargem"].Width += 5;
                        }
                    }
                    //Pai.Controls["FlutuosoAlca"].Text = ">";
                    Application.DoEvents();
                }
                Visivel = true;
            }
            else
            {
                for (int i = 0; i < (Tamanho - 20); i+=5)
                {
                    if (_ControlParent)
                    {
                        PaiControl.Controls["FlutuosoPanel"].Left += 5;
                        PaiControl.Controls["FlutuosoAlca"].Left += 5;
                    }
                    else
                    {
                        Pai.Controls["FlutuosoPanel"].Left += 5;
                        Pai.Controls["FlutuosoAlca"].Left += 5;
                    }
                    if (ArrastarPaineis)
                    {
                        if (_ControlParent)
                        {
                            PaiControl.Controls["FlutuosoMargem"].Width -= 5;
                            PaiControl.Width -= 5;
                        }
                        else
                        {
                            Pai.Controls["FlutuosoMargem"].Width -= 5;
                        }
                    }
                    //Pai.Controls["FlutuosoAlca"].Text = "<";
                    Application.DoEvents();
                }
                Visivel = false;

            }

            Fazendo = false;

        }
        private void ProcessarEsquerda()
        {

            Fazendo = true;

            if (Visivel == false)
            {
                for (int i = 0; i < (Tamanho - 5); i+=5)
                {
                    if (_ControlParent)
                    {
                        PaiControl.Controls["FlutuosoPanel"].Left += 5;
                        PaiControl.Controls["FlutuosoAlca"].Left += 5;
                    }
                    else
                    {
                        Pai.Controls["FlutuosoPanel"].Left += 5;
                        Pai.Controls["FlutuosoAlca"].Left += 5;
                    }
                    if (ArrastarPaineis)
                    {
                        if (_ControlParent)
                        {
                            PaiControl.Controls["FlutuosoMargem"].Width += 5;
                            PaiControl.Width += 5;
                        }
                        else
                        {
                            Pai.Controls["FlutuosoMargem"].Width += 5;
                        }
                    }
                    Application.DoEvents();
                }
                Visivel = true;
            }
            else
            {
                for (int i = 0; i < (Tamanho - 5); i+=5)
                {
                    if (_ControlParent)
                    {
                        PaiControl.Controls["FlutuosoPanel"].Left -= 5;
                        PaiControl.Controls["FlutuosoAlca"].Left -= 5;
                    }
                    else
                    {
                        Pai.Controls["FlutuosoPanel"].Left -= 5;
                        Pai.Controls["FlutuosoAlca"].Left -= 5;
                    }
                    if (ArrastarPaineis)
                    {
                        if (_ControlParent)
                        {
                            PaiControl.Controls["FlutuosoMargem"].Width -= 5;
                            PaiControl.Width -= 5;
                        }
                        else
                        {
                            Pai.Controls["FlutuosoMargem"].Width -= 5;
                        }
                    }
                    Application.DoEvents();
                }
                Visivel = false;

            }

            Fazendo = false;

        }
        private void ProcessarBase()
        {
            Fazendo = true;

            if (Visivel == false)
            {
                for (int i = 0; i < (Tamanho - 15); i+=5)
                {
                    if (_ControlParent)
                    {
                        PaiControl.Controls["FlutuosoPanel"].Top -= 5;
                        PaiControl.Controls["FlutuosoAlca"].Top -= 5;
                    }
                    else
                    {
                        Pai.Controls["FlutuosoPanel"].Top -= 5;
                        Pai.Controls["FlutuosoAlca"].Top -= 5;
                    }
                    if (ArrastarPaineis)
                    {
                        if (_ControlParent)
                        {
                            PaiControl.Controls["FlutuosoMargem"].Height += 5;
                            PaiControl.Height += 5;
                        }
                        else
                        {
                            Pai.Controls["FlutuosoMargem"].Height += 5;
                        }
                    }
                    Application.DoEvents();
                }
                Visivel = true;
            }
            else
            {
                for (int i = 0; i < (Tamanho - 15); i += 5)
                {
                    if (_ControlParent)
                    {
                        PaiControl.Controls["FlutuosoPanel"].Top += 5;
                        PaiControl.Controls["FlutuosoAlca"].Top += 5;
                    }
                    else
                    {
                        Pai.Controls["FlutuosoPanel"].Top += 5;
                        Pai.Controls["FlutuosoAlca"].Top += 5;
                    }
                    if (ArrastarPaineis)
                    {
                        if (_ControlParent)
                        {
                            PaiControl.Controls["FlutuosoMargem"].Height -= 5;
                            PaiControl.Height -= 5;
                        }
                        else
                        {
                            Pai.Controls["FlutuosoMargem"].Height -= 5;
                        }
                    }
                    Application.DoEvents();
                }
                Visivel = false;

            }

            Fazendo = false;

        }
        private void ProcessarTopo()
        {
            Fazendo = true;

            if (Visivel == false)
            {
                for (int i = 0; i < (Tamanho + (_ControlParent ? PaiControl.Controls["FlutuosoAlca"].Height : Pai.Controls["FlutuosoAlca"].Height)); i += 5)
                {
                    if (_ControlParent)
                    {
                        PaiControl.Controls["FlutuosoPanel"].Top += 5;
                        //PaiControl.Controls["FlutuosoAlca"].Top += 5;
                    }
                    else
                    {
                        Pai.Controls["FlutuosoPanel"].Top += 5;
                        //Pai.Controls["FlutuosoAlca"].Top += 5;
                    }
                    if (ArrastarPaineis)
                    {
                        if (i >= (_ControlParent ? PaiControl.Controls["FlutuosoAlca"].Height : Pai.Controls["FlutuosoAlca"].Height))
                        {
                            if (_ControlParent)
                            {
                                PaiControl.Controls["FlutuosoMargem"].Height += 5;
                                PaiControl.Height += 5;
                            }
                            else
                            {
                                Pai.Controls["FlutuosoMargem"].Height += 5;
                            }
                        }
                    }
                    Application.DoEvents();
                }
                Visivel = true;
            }
            else
            {
                for (int i = 0; i < (Tamanho + (_ControlParent ? PaiControl.Controls["FlutuosoAlca"].Height : Pai.Controls["FlutuosoAlca"].Height)); i += 5)
                {
                    if (_ControlParent)
                    {
                        PaiControl.Controls["FlutuosoPanel"].Top -= 5;
                        //PaiControl.Controls["FlutuosoAlca"].Top -= 5;
                    }
                    else
                    {
                        Pai.Controls["FlutuosoPanel"].Top -= 5;
                        //Pai.Controls["FlutuosoAlca"].Top -= 5;
                    }
                    if (ArrastarPaineis)
                    {
                        if (i < Tamanho)
                        {
                            if (_ControlParent)
                            {
                                PaiControl.Controls["FlutuosoMargem"].Height -= 5;
                                PaiControl.Height -= 5;
                            }
                            else
                            {
                                Pai.Controls["FlutuosoMargem"].Height -= 5;
                            }
                        }
                    }
                    Application.DoEvents();
                }
                Visivel = false;

            }

            Fazendo = false;

        }

        private void ExibeOculta()
        {

            if (_ControlParent)
            {
                if (PaiControl.Controls["FlutuosoPanel"].InvokeRequired)
                {

                    execFlutuoso d = new execFlutuoso(ExibeOculta);
                    PaiControl.Controls["FlutuosoPanel"].Invoke(d);

                }
                else
                {

                    if (p == Posicao.Esquerda)
                        ProcessarEsquerda();
                    if (p == Posicao.Direita)
                        ProcessarDireita();
                    if (p == Posicao.Base)
                        ProcessarBase();
                    if (p == Posicao.Topo)
                        ProcessarTopo();

                }
            }
            else
            {
                if (Pai.Controls["FlutuosoPanel"].InvokeRequired)
                {

                    execFlutuoso d = new execFlutuoso(ExibeOculta);
                    Pai.Controls["FlutuosoPanel"].Invoke(d);

                }
                else
                {

                    if (p == Posicao.Esquerda)
                        ProcessarEsquerda();
                    if (p == Posicao.Direita)
                        ProcessarDireita();
                    if (p == Posicao.Base)
                        ProcessarBase();
                    if (p == Posicao.Topo)
                        ProcessarTopo();

                }
            }

        }

        public void Show()
        {

            Thread trd = new Thread(new ThreadStart(ExibeOculta));

            trd.IsBackground = true;

            trd.Start();

        }



    }
}
