﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Configuration;
using System.IO;
using System.Diagnostics;
using System.Collections;
using System.Reflection;
using System.Data;
using System.Text.RegularExpressions;

namespace Mobios
{
    public class ArquivosTratar
    {
        #region [ Variáveis ]
        Excel.Application xlApp = null;
        Excel.Workbook xlWorkBook = null;
        Excel.Worksheet xlWorkSheet = null;
        Excel.Worksheet xlWorkSheetList = null;
        public string msgLog = "";
        DataTable tabela;
        List<Dados> _TodosDados;
        #endregion

        public bool LerArquivo(string tipoArquivo, string path, string nomeArquivo, string boleto, int Mapeamento, int CampoBoleto = 0)
        {
            bool result = false;
            Loading.EnableStaticTextBox("Lendo Arquivo");
            switch (tipoArquivo)
            {
                case "Excel":
                    result = ExcelLeitura(path, nomeArquivo, boleto, Mapeamento, CampoBoleto);
                    result = true;
                    break;
                case "Base Excel":
                    result = BaseExcelLeitura(path, nomeArquivo, boleto, Mapeamento, CampoBoleto);
                    result = true;
                    break;
                case "PDF":
                    result = PDFLeitura(path, nomeArquivo, boleto, Mapeamento, CampoBoleto);
                    result = true;
                    break;
            }
            return result;
        }

        #region [ Leitores de arquivo excel ]
        public bool ExcelLeitura(string pathXLS, string nomeXLS, string boleto, int Mapeamento, int CampoBoleto)
        {
            bool result = false;
            Log.GravaLog("Lendo planilha " + pathXLS + " referente ao boleto " + boleto + ".");
            try
            {
                List<BoletaParametrosArquivosPlanilha> BoletoParametros;
                String PathFull = pathXLS;

                xlApp = new Excel.Application();
                xlWorkBook = xlApp.Workbooks.Open(PathFull);

                _TodosDados = new List<Dados>();
                Dados dado = new Dados();
                dado.IdBoleto = Convert.ToInt32(boleto);
                dado.Id_Campo = CampoBoleto;
                dado.Valor = boleto;
                _TodosDados.Add(dado);

                BoletoParametros = DataAccess.retornaParametrosArquivosPlanilha(Mapeamento);

                tabela = new DataTable();
                tabela.Columns.Add("NomeTabela");
                tabela.Columns.Add("Linha");
                tabela.Columns.Add("NomeCampo");
                tabela.Columns.Add("ValorCampo");
                tabela.Columns.Add("IdCampo");

                int ParmAtual = 1;
                int BoletoParametrosTotal = BoletoParametros.Count;

                foreach (BoletaParametrosArquivosPlanilha Parm in BoletoParametros)
                {
                    Loading.EnableStaticTextBox("Lendo Campos " + ParmAtual + "/" + BoletoParametrosTotal);
                    try
                    {
                        string Separador = Parm.Separador;

                        xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(Parm.ReferenciaPlanilha);
                        string CampoInfo = "";

                        if (Parm.TipoCampo == "tabela")
                        {
                            #region [ Trata Tabela ]
                            if (Parm.ReferenciaExcel.Contains(@"?"))
                            {
                                Excel.Range last = xlWorkSheet.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell, Type.Missing);
                                int lastUsedRow = last.Row;
                                while ((double)xlApp.WorksheetFunction.CountA(xlWorkSheet.Rows[lastUsedRow]) == 0)
                                {
                                    lastUsedRow--;
                                }
                                Parm.ReferenciaExcel = Parm.ReferenciaExcel.Replace("?", lastUsedRow.ToString());
                            }

                            for (int k = 2; k <= xlWorkSheet.Range[Parm.ReferenciaExcel].Rows.Count; k++)
                            {
                                for (int c = 1; c <= xlWorkSheet.Range[Parm.ReferenciaExcel].Columns.Count; c++)
                                {
                                    if (xlWorkSheet.Range[Parm.ReferenciaExcel].Cells[c][1].Value != null && xlWorkSheet.Range[Parm.ReferenciaExcel].Cells[c][1].Value.ToString() != "")
                                    {
                                        if (xlWorkSheet.Range[Parm.ReferenciaExcel].Cells[c][k].Value != null && xlWorkSheet.Range[Parm.ReferenciaExcel].Cells[c][k].Value.ToString() != "")
                                        {
                                            tabela.Rows.Add(Parm.NomeCampo, k - 1, xlWorkSheet.Range[Parm.ReferenciaExcel].Cells[c][1].Value, xlWorkSheet.Range[Parm.ReferenciaExcel].Cells[c][k].Value, Parm.IdCampo);
                                        }
                                    }
                                }
                            }
                            #endregion
                        }
                        else
                        {

                            CampoInfo = Convert.ToString(xlWorkSheet.Range[Parm.ReferenciaExcel].Value);

                            if (Separador != "")
                            {
                                #region [ Separador ]
                                string[] arraySeparador = Separador.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
                                string[] arrayPosicao = Parm.Posicao.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);

                                int sep = 0;
                                foreach (string txtSeparador in arraySeparador)
                                {
                                    Separador = txtSeparador.Replace("\"", "").Replace("\\n", "\n").Replace("\\r", "\r");
                                    CampoInfo = CampoInfo.Replace(Separador, "|");
                                    string[] CampoInfoArray = CampoInfo.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);

                                    if (arrayPosicao[sep].ToString().Contains('@'))
                                    {
                                        string[] posicao = arrayPosicao[sep].ToString().Split('@');
                                        int posicaoInicial = 0;
                                        int posicaoFinal = 0;

                                        if (posicao[0].ToString() == "-0")
                                        {
                                            posicaoInicial = CampoInfoArray.Count() - 1;
                                        }
                                        else
                                        {
                                            posicaoInicial = Convert.ToInt32(posicao[0]);
                                        }

                                        if (posicao[1].ToString() == "-0")
                                        {
                                            posicaoFinal = CampoInfoArray.Count() - 1;
                                        }
                                        else
                                        {
                                            posicaoFinal = Convert.ToInt32(posicao[1]);
                                        }

                                        if (posicaoInicial < 0)
                                        {
                                            posicaoInicial = CampoInfoArray.Count() - 1 + posicaoInicial;
                                        }

                                        if (posicaoFinal < 0)
                                        {
                                            posicaoFinal = CampoInfoArray.Count() - 1 + posicaoFinal;
                                        }

                                        CampoInfo = "";
                                        for (int posicaoLinha = posicaoInicial; posicaoLinha <= posicaoFinal; posicaoLinha++)
                                        {
                                            if (CampoInfo == "")
                                            {
                                                CampoInfo = CampoInfoArray[posicaoLinha];
                                            }
                                            else
                                            {
                                                CampoInfo += " " + CampoInfoArray[posicaoLinha];
                                            }
                                        }

                                    }
                                    else
                                    {
                                        CampoInfo = CampoInfoArray[Convert.ToInt32(arrayPosicao[sep].ToString())].Trim();
                                    }

                                    sep++;
                                }
                                #endregion
                            }


                            if ((CampoInfo != "") && (CampoInfo != null))
                            {
                                CampoInfo = CampoInfo.Replace("'", "''").Replace("\"", "\"\"").Trim();
                                dado = new Dados();
                                dado.IdBoleto = Convert.ToInt32(boleto);
                                dado.Id_Campo = Convert.ToInt32(Parm.IdCampo);
                                dado.Valor = CampoInfo;
                                _TodosDados.Add(dado);
                            }
                            else
                            {
                                msgLog = "Iniciando leitura da Planilha " + boleto + ". Valor encontrato: [branco].";
                                Log.GravaLog(msgLog);
                            }
                        }
                    }
                    catch
                    {
                        msgLog = "Iniciando leitura da Planilha " + boleto + ". Valor encontrato: [branco].";
                        Log.GravaLog(msgLog);
                    }
                    ParmAtual++;
                }
                Loading.EnableStaticTextBox("Dados capturados");
                result = true;
            }
            catch (Exception ex)
            {
                msgLog = "Tentativa de importação dos dados da planilha falhou. Verifique se os produtos foram importados. Erro: " + ex.Message;
                Log.GravaLog(msgLog);
            }
            finally
            {
                #region [ fecha arquivo ]
                msgLog = "Fechando planilha Excel.";
                Log.GravaLog(msgLog);
                
                if (xlWorkSheet != null) { Marshal.FinalReleaseComObject(xlWorkSheet); } 
                if (xlWorkSheetList != null) { Marshal.FinalReleaseComObject(xlWorkSheetList); } 
                if (xlWorkBook != null) { xlWorkBook.Close(false, false); Marshal.FinalReleaseComObject(xlWorkBook); } 
                // Fechar
                if (xlApp != null) { xlApp.Quit(); Marshal.FinalReleaseComObject(xlApp); } 
                xlWorkBook = null; 
                xlWorkSheet = null;
                xlApp = null;

                GC.Collect();
                GC.WaitForPendingFinalizers();
                #endregion
            }
            return result;
        }

        public bool BaseExcelLeitura(string pathXLS, string nomeXLS, string boleto, int Mapeamento, int CampoBoleto)
        {
            bool result = false;
            Log.GravaLog("Lendo base " + pathXLS + " para registro de serviços em lote");
            try
            {

                List<BoletaParametrosArquivosPlanilha> BoletoParametros;
                String PathFull = pathXLS;

                xlApp = new Excel.Application();
                xlWorkBook = xlApp.Workbooks.Open(PathFull);

                BoletoParametros = DataAccess.retornaParametrosArquivosPlanilha(Mapeamento);
                try
                {
                    tabela = new DataTable();
                    tabela.Columns.Add("NomeTabela"); //NUMERO BOLETO E SERVIÇO
                    tabela.Columns.Add("Linha"); //NUMERO LINHA
                    tabela.Columns.Add("NomeCampo"); //NOME CAMPO
                    tabela.Columns.Add("ValorCampo"); //VALOR CAMPO DESTINO
                    tabela.Columns.Add("IdCampo"); //ID CAMPO DESTINO

                    xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(BoletoParametros[0].ReferenciaPlanilha);
                    Excel.Range last = xlWorkSheet.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell, Type.Missing);
                        
                    int lastUsedRow = last.Row;
                    
                    while ((double)xlApp.WorksheetFunction.CountA(xlWorkSheet.Rows[lastUsedRow])==0)
                    {
                        lastUsedRow--;
                    }

                    last = xlWorkSheet.Cells[xlWorkSheet.get_Range(BoletoParametros[0].ReferenciaServico).Column][lastUsedRow];
                    Excel.Range range = xlWorkSheet.get_Range(BoletoParametros[0].ReferenciaServico, last);

                    
                    int BoletoParametrosTotal = BoletoParametros.Count;

                    int LinhaAtual = 1;
                    int LinhasTotal = range.Rows.Count-1;
                    
                    int registros = 1;
                    int linhaTabela = 1;

                    while ((int)registros <= LinhasTotal)
                    {
                        int ParmAtual = 1;
                        foreach (BoletaParametrosArquivosPlanilha Parm in BoletoParametros)
                        {
                            Loading.EnableStaticTextBox("Lendo Campos " + ParmAtual + "/" + BoletoParametrosTotal + " da linha " + LinhaAtual + "/" + LinhasTotal);
                            try
                            {
                                string Separador = Parm.Separador;

                                Excel.Range CelulaCampoInfo = xlWorkSheet.Cells[xlWorkSheet.get_Range(Parm.ReferenciaExcel).Column][xlWorkSheet.get_Range(Parm.ReferenciaExcel).Row + registros];
                                string CampoInfo = CelulaCampoInfo.Value.ToString();

                                Excel.Range CelulaCampoReferencia = xlWorkSheet.Cells[xlWorkSheet.get_Range(Parm.ReferenciaServico).Column][xlWorkSheet.get_Range(Parm.ReferenciaServico).Row + registros];
                                string CampoReferencia = CelulaCampoReferencia.Value.ToString();

                                if (Separador != "")
                                {
                                    #region [Tratamento com Separador]

                                    string[] arraySeparador = Separador.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
                                    string[] arrayPosicao = Parm.Posicao.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);

                                    int sep = 0;
                                    foreach (string txtSeparador in arraySeparador)
                                    {
                                        Separador = txtSeparador.Replace("\"", "").Replace("\\n", "\n").Replace("\\r", "\r");
                                        CampoInfo = CampoInfo.Replace(Separador, "|");
                                        string[] CampoInfoArray = CampoInfo.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
                                        //string[] CampoInfoArray = CampoInfo.Split(Convert.ToChar(Separador));
                                        if (arrayPosicao[sep].ToString().Contains('@'))
                                        {
                                            string[] posicao = arrayPosicao[sep].ToString().Split('@');
                                            int posicaoInicial = 0;
                                            int posicaoFinal = 0;

                                            if (posicao[0].ToString() == "-0")
                                            {
                                                posicaoInicial = CampoInfoArray.Count() - 1;
                                            }
                                            else
                                            {
                                                posicaoInicial = Convert.ToInt32(posicao[0]);
                                            }

                                            if (posicao[1].ToString() == "-0")
                                            {
                                                posicaoFinal = CampoInfoArray.Count() - 1;
                                            }
                                            else
                                            {
                                                posicaoFinal = Convert.ToInt32(posicao[1]);
                                            }

                                            if (posicaoInicial < 0)
                                            {
                                                posicaoInicial = CampoInfoArray.Count() - 1 + posicaoInicial;
                                            }

                                            if (posicaoFinal < 0)
                                            {
                                                posicaoFinal = CampoInfoArray.Count() - 1 + posicaoFinal;
                                            }

                                            CampoInfo = "";
                                            for (int posicaoLinha = posicaoInicial; posicaoLinha <= posicaoFinal; posicaoLinha++)
                                            {
                                                if (CampoInfo == "")
                                                {
                                                    CampoInfo = CampoInfoArray[posicaoLinha];
                                                }
                                                else
                                                {
                                                    CampoInfo += " " + CampoInfoArray[posicaoLinha];
                                                }
                                            }

                                        }
                                        else
                                        {
                                            CampoInfo = CampoInfoArray[Convert.ToInt32(arrayPosicao[sep].ToString())].Trim();
                                        }

                                        sep++;
                                    }
                                    #endregion
                                }


                                if ((CampoInfo != "") && (CampoInfo != null))
                                {
                                    CampoInfo = CampoInfo.Replace("'", "''").Replace("\"", "\"\"").Trim();
                                    CampoReferencia = CampoReferencia.Replace("'", "''").Replace("\"", "\"\"").Trim();
                                    tabela.Rows.Add(CampoReferencia, linhaTabela, Parm.NomeCampo, CampoInfo, Parm.IdCampo);
                                }
                                else
                                {
                                    msgLog = "Iniciando leitura da Planilha " + boleto + ". Valor encontrato: [branco].";
                                    Log.GravaLog(msgLog);
                                }

                            }
                            catch
                            {
                                msgLog = "Iniciando leitura da Planilha " + boleto + ". Valor encontrato: [branco].";
                                Log.GravaLog(msgLog);
                            }
                            ParmAtual++;
                        }
                        LinhaAtual++;
                        registros++;
                        linhaTabela++;
                    }

                    // Término sem erro.
                    Loading.EnableStaticTextBox("Dados capturados");
                    result = true;
                }
                catch (Exception exp)
                {
                    Loading.StaticFormVisible(false);
                    MessageBox.Show("Erro ao ler dados. Erro: " + exp.Message);
                }
            }
            catch (Exception ex)
            {
                msgLog = "Tentativa de importação dos dados da planilha falhou. Verifique se os produtos foram importados. Erro: " + ex.Message;
                Log.GravaLog(msgLog);
            }
            finally
            {
                // Se houve erros, envia mensagem aqui 
                msgLog = "Fechando planilha Excel.";
                Log.GravaLog(msgLog);

                if (xlWorkSheet != null) { Marshal.FinalReleaseComObject(xlWorkSheet); } //release each worksheet like this
                if (xlWorkSheetList != null) { Marshal.FinalReleaseComObject(xlWorkSheetList); } //release each worksheet like this
                if (xlWorkBook != null) { xlWorkBook.Close(false, false); Marshal.FinalReleaseComObject(xlWorkBook); } //release each workbook like this
                // Fechar
                if (xlApp != null) { xlApp.Quit(); Marshal.FinalReleaseComObject(xlApp); } //release the Excel application
                xlWorkBook = null; //set each memory reference to null.
                xlWorkSheet = null;
                xlApp = null;

                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            return result;
        }
        #endregion

        #region [ Leitores de Arquivo PDF ]
        public bool PDFLeitura(string pathPDF, string nomePDF, string boleto, int Mapeamento, int CampoBoleto)
        {
            bool result = false;
            Log.GravaLog("Lendo Boleto " + pathPDF + " referente ao boleto " + boleto);
            try
            {
                List<BoletaParametrosArquivosPDF> BoletoParametros;

                String PathFull = pathPDF;

                
                string textPDF = LeitorPDF.GetText(pathPDF);
                textPDF = textPDF.Replace(" ", " ");// isto é alguma coisa que parece um espaço vazio, mas não é! Pegadinha do malandro!!!! GLuGLuGLu

                _TodosDados = new List<Dados>();
                Dados dado = new Dados();
                dado.IdBoleto = Convert.ToInt32(boleto);
                dado.Id_Campo = CampoBoleto;
                dado.Valor = boleto;
                _TodosDados.Add(dado);

                BoletoParametros = DataAccess.retornaParametrosArquivosPDF(Mapeamento);

                tabela = new DataTable();
                tabela.Columns.Add("NomeTabela");
                tabela.Columns.Add("Linha");
                tabela.Columns.Add("NomeCampo");
                tabela.Columns.Add("ValorCampo");
                tabela.Columns.Add("IdCampo");

                int ParmAtual = 1;
                int BoletoParametrosTotal = BoletoParametros.Count;

                foreach (BoletaParametrosArquivosPDF Parm in BoletoParametros)
                {
                    #region [ busca referencias de corte ]
                    Parm.ReferenciaInicial = Parm.ReferenciaInicial.Replace("\\n", "\n").Replace("\\r", "\r");
                    Parm.ReferenciaFinal = Parm.ReferenciaFinal.Replace("\\n", "\n").Replace("\\r", "\r");
                    Parm.ReferenciaCorte = Parm.ReferenciaCorte.Replace("\\n", "\n").Replace("\\r", "\r");
                    Parm.ReferenciaCorteFim = Parm.ReferenciaCorteFim.Replace("\\n", "\n").Replace("\\r", "\r");
                    #endregion

                    Loading.EnableStaticTextBox("Lendo Campos " + ParmAtual + "/" + BoletoParametrosTotal);
                    try
                    {
                        msgLog = "Iniciando leitura do boleto " + boleto + " .Capturando campo " + Parm.NomeCampo + " entre valores " + Parm.ReferenciaInicial + " e " + Parm.ReferenciaFinal + ".";
                        Log.GravaLog(msgLog);


                        string Separador = Parm.Separador;
                        if (Separador != "")
                        {
                            Separador = Separador.Replace("\"", "");
                        }
                        #region [ busca campo ]
                        if (Parm.TipoCampo == "tabela")
                        {
                            #region [ tabela ]
                            string[] tabelaString = getInfoTabela(textPDF, Parm.ReferenciaInicial, Parm.ReferenciaFinal, Parm.ReferenciaCorte, Parm.ReferenciaCorteFim);
                            string[] NomeCamposTabela = Parm.NomeCamposTabela.Split(';');
                            string[] posicao = Parm.Posicao.Split(';');

                            for (int linha = 1; linha <= tabelaString.Count(); linha++)
                            {

                                string[] camposLinha = tabelaString[linha - 1].Split(new string[] { Separador }, StringSplitOptions.RemoveEmptyEntries);

                                for (int camposTabela = 0; camposTabela < NomeCamposTabela.Count(); camposTabela++)
                                {
                                    string[] posicaoCampo = posicao[camposTabela].Split('@');
                                    int posicaoInicial = Convert.ToInt32(posicaoCampo[0]);
                                    int posicaoFinal = Convert.ToInt32(posicaoCampo[1]);
                                    if (posicaoFinal < 0)
                                    {
                                        posicaoFinal = camposLinha.Count() - 1 + posicaoFinal;
                                    }
                                    else if (posicaoFinal != posicaoInicial && posicaoFinal == 0)
                                    {
                                        posicaoFinal = camposLinha.Count() - 1;
                                    }

                                    string valorCampoTabela = "";
                                    for (int posicaoLinha = posicaoInicial; posicaoLinha <= posicaoFinal; posicaoLinha++)
                                    {
                                        if (valorCampoTabela == "")
                                        {
                                            valorCampoTabela = camposLinha[posicaoLinha];
                                        }
                                        else
                                        {
                                            valorCampoTabela += " " + camposLinha[posicaoLinha];
                                        }
                                    }

                                    if (NomeCamposTabela[camposTabela].ToString().Contains("CPF"))
                                    {
                                        if (!ValidaCPF.IsCpf(valorCampoTabela))
                                        {
                                            valorCampoTabela = ValidaCPF.CalculaDigCPF(valorCampoTabela);
                                        }
                                    }

                                    string[] chrArray = Parm.ChrEliminar.Split(';');
                                    foreach (string chr in chrArray)
                                    {
                                        valorCampoTabela = valorCampoTabela.Replace(chr, "");
                                    }

                                    tabela.Rows.Add(Parm.NomeCampo, linha, NomeCamposTabela[camposTabela], valorCampoTabela, Parm.IdCampo);

                                }
                            }
                            #endregion
                        }
                        else
                        {
                            string CampoInfo = getInfo(textPDF, Parm.ReferenciaInicial, Parm.ReferenciaFinal, Parm.ReferenciaCorte, Parm.ReferenciaCorteFim);

                            #region [ Page ]
                            if (CampoInfo.IndexOf("\nPage") != -1)
                            {


                                do
                                {
                                    int numeros = 0;
                                    bool ultimoNumero = false;
                                    string paginas = "";

                                    string CampoInfoAux = CampoInfo.Substring(CampoInfo.IndexOf("\nPage"));
                                    for (int letra = 1; letra < CampoInfoAux.Length; letra++)
                                    {
                                        int numero;
                                        if (int.TryParse(CampoInfoAux.Substring(letra, 1), out numero))
                                        {
                                            if (!ultimoNumero)
                                            {
                                                ultimoNumero = true;
                                                numeros++;
                                            }
                                        }
                                        else
                                        {
                                            ultimoNumero = false;
                                            if (numeros == 2)
                                            {
                                                break;
                                            }
                                        }
                                        paginas += CampoInfoAux.Substring(letra, 1);
                                    }
                                    CampoInfo = CampoInfo.Replace(paginas, "");
                                } while (CampoInfo.IndexOf("\nPage") != -1);
                            }
                            #endregion

                            CampoInfo = TratamentoCampo.Splitter(CampoInfo, Separador, Parm.Posicao);
                            

                            #region [ Salva valor ]
                            msgLog = "Iniciando leitura do boleto " + boleto + ". Valor encontrato: " + CampoInfo + ".";
                            Log.GravaLog(msgLog);

                            if ((CampoInfo != "") && (CampoInfo != null))
                            {
                                if (Parm.TamanhoCampo > 0)
                                {
                                    CampoInfo = CampoInfo.Substring(0, Parm.TamanhoCampo);
                                }

                                if (Parm.IdCampo != null && Parm.IdCampo != "")
                                {
                                    #region [ formatação ]
                                    CampoInfo = CampoInfo.Replace("\n", "|").Replace("\r", "|").Replace(" ", " ");
                                    string[] CampoInfoArray = CampoInfo.Split('|');
                                    CampoInfo = "";
                                    foreach (string Info in CampoInfoArray)
                                    {
                                        CampoInfo += Info.Replace("'", "''").Replace("\"", "\"\"").Trim() + " ";
                                    }
                                    CampoInfo = CampoInfo.Trim();

                                    string[] chrArray = Parm.ChrEliminar.Split(';');
                                    foreach (string chr in chrArray)
                                    {
                                        if (chr != "")
                                        {
                                            CampoInfo = CampoInfo.Replace(chr, "");
                                        }
                                    }

                                    if (Parm.TipoCampo.ToUpper() == "DATE6")
                                    {
                                        #region [ ajusta data yymmdd ]
                                        if (CampoInfo.Length == 6)
                                        {
                                            string ano = CampoInfo.Substring(0, 2);
                                            string mes = CampoInfo.Substring(2, 2);
                                            string dia = CampoInfo.Substring(4, 2);
                                            CampoInfo = dia + "/" + mes + "/" + ano;
                                            DateTime Minhadate;

                                            if (!DateTime.TryParseExact(CampoInfo, "dd/MM/yy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out Minhadate))
                                            {
                                                CampoInfo = "";
                                            }
                                            else
                                            {
                                                CampoInfo = Minhadate.ToString("dd/MM/yyyy");
                                            }
                                        }
                                        #endregion
                                    }
                                    #endregion

                                    dado = new Dados();
                                    dado.IdBoleto = Convert.ToInt32(boleto);
                                    dado.Id_Campo = Convert.ToInt32(Parm.IdCampo);
                                    dado.Valor = CampoInfo;
                                    _TodosDados.Add(dado);
                                }
                            }
                            else
                            {
                                msgLog = "Iniciando leitura do arquivo " + boleto + ". Valor encontrado: [branco].";
                                Log.GravaLog(msgLog);
                            }
                            #endregion
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        #region [ erro na captura do valor ]
                        msgLog = "Iniciando leitura do boleto " + boleto + ". Erro captura valor campo:  " + ex.Message + ".";
                        Log.GravaLog(msgLog);
                        #endregion
                    }
                    ParmAtual++;
                }
                Loading.EnableStaticTextBox("Boleto capturado");
                result = true;
            }
            catch (Exception ex)
            {
                msgLog = "Tentativa de importação dos dados do boleto falhou. Verifique se os produtos foram importados. Erro: " + ex.Message;
                Log.GravaLog(msgLog);
                throw;
            }

            return result;
        }

        public string getInfo(string Txt, string Ref1, string Ref2, string RefCorte, string RefCorteFim, int Tamanho = 0)
        {
            // Set variaveis
            //string result = "";
            string tIni = Ref1;
            string tFim = Ref2;
            string tCorte = RefCorte;
            string tCorteFim = RefCorteFim;
            // Define a posição do arquivo
            int PosCorte = Txt.IndexOf(tCorte);

            int Pos = Txt.IndexOf(tIni);
            int Pos2 = Txt.IndexOf(tFim);
            // Reduz o arquivo original para garantir que a POS2 seja depois do POS            
            if (PosCorte >= 0)
            {
                string Txt2 = Txt.Substring(PosCorte);

                if (RefCorteFim != "" && RefCorteFim != null)
                {
                    int PosCorteFim = Txt2.IndexOf(RefCorteFim);
                    if (PosCorteFim > 0)
                    {
                        Txt2 = Txt2.Substring(0, PosCorteFim);
                    }
                }

                // Define as novas posições após redução do arquivo
                Pos = Txt2.IndexOf(tIni);

                Pos2 = Txt2.IndexOf(tFim);

                //if ((Pos > 0) && (Pos2 > 0))
                if (Pos2 > 0)
                {
                    if (Tamanho == 0)
                    {
                        Txt = Txt2.Substring(Pos + tIni.Length, Pos2 - Pos - tIni.Length);
                    }
                    else
                    {
                        Txt = Txt2.Substring(Pos + tIni.Length, Tamanho);
                    }
                }
                else
                {
                    if (Pos >= 0)
                    {
                        if (Tamanho == 0)
                        {
                            Txt = Txt2.Substring(Pos + tIni.Length);
                        }
                        else
                        {
                            Txt = Txt2.Substring(Pos + tIni.Length, Tamanho);
                        }
                    }
                    else
                    {
                        msgLog = "Erro ao localizar dados do boleto. Erro: Pos = " + Pos.ToString() + " / Pos2 = " + Pos2.ToString() + ".";
                        Log.GravaLog(msgLog);
                        Txt = "";
                    }
                }
            }
            else
            {
                msgLog = "Erro ao localizar dados do boleto. Erro: Pos = " + Pos.ToString() + " / Pos2 = " + Pos2.ToString() + ".";
                Log.GravaLog(msgLog);
                Txt = "";
            }
            return Txt.Trim();

        }

        private string[] getInfoTabela(string Txt, string Ref1, string Ref2, string RefCorte, string RefCorteFim, int Tamanho = 0)
        {
            // Set variaveis
            string result = "";
            string tIni = Ref1;
            string tFim = Ref2;
            string tCorte = RefCorte;
            string tCorteFim = RefCorteFim;
            // Define a posição do arquivo
            int PosCorte = Txt.IndexOf(tCorte);

            int Pos = Txt.IndexOf(tIni);
            int Pos2 = Txt.IndexOf(tFim);
            // Reduz o arquivo original para garantir que a POS2 seja depois do POS            
            if (PosCorte >= 0)
            {
                string Txt2 = Txt.Substring(PosCorte);
                
                if (RefCorteFim != "" && RefCorteFim != null)
                {
                    int PosCorteFim = Txt2.IndexOf(RefCorteFim);
                    if (PosCorteFim>0)
                    {
                        Txt2 = Txt2.Substring(0, PosCorteFim);
                    }
                }

                // Define as novas posições após redução do arquivo
                Pos = Txt2.IndexOf(tIni);

                Pos2 = Txt2.IndexOf(tFim);

                //if ((Pos > 0) && (Pos2 > 0))
                if (Pos2 > 0 && Pos >= 0 && Pos2 > Pos)
                {
                    if (Tamanho == 0)
                    {
                        Txt = Txt2.Substring(Pos + tIni.Length, Pos2 - Pos - tIni.Length);
                    }
                    else
                    {
                        Txt = Txt2.Substring(Pos + tIni.Length, Tamanho);
                    }
                    Txt = Txt.Replace("\r\n", "_");
                    string[] Linhas = Txt.Split('_');
                    bool cabecalho = false;
                    foreach (string linha in Linhas)
                    {
                        string linhaTratada = linha.Trim();
                        if (!(linhaTratada.Substring(0, 1) == "-" || linhaTratada.Substring(0, 1) == "!"))
                        {
                            if (cabecalho == false)
                            {
                                cabecalho = true;
                            }
                            else
                            {
                                if (result == "")
                                {
                                    result = linhaTratada.Substring(0, linhaTratada.IndexOf("!"));
                                }
                                else
                                {
                                    result += ";" + linhaTratada.Substring(0, linhaTratada.IndexOf("!"));
                                }
                            }
                        }
                    }
                }
                else
                {
                    msgLog = "Erro ao localizar dados do boleto. Erro: Pos = " + Pos.ToString() + " / Pos2 = " + Pos2.ToString() + ".";
                    Log.GravaLog(msgLog);
                    Txt = "";
                }
            }
            else
            {
                msgLog = "Erro ao localizar dados do boleto. Erro: Pos = " + Pos.ToString() + " / Pos2 = " + Pos2.ToString() + ".";
                Log.GravaLog(msgLog);
                Txt = "";
            }
            return result.Split(';');

        }
        #endregion

        #region [ registra serviço ]
        public void RegistraServicoBoleto(string boleto, int cbSegmento, int cbProduto, bool prioridade, int IdAnalista)
        {
            string sqlCommandInsert;
            int IdServico;

            if (_TodosDados.Count > 0)
            {
                Log.GravaLog("Verificando se existe o serviço registrado.");
                if (DataAccess.BoletoServicoRegistrado(boleto, "tb_0125_Servico", "ServicoName", "BDconsulta") != true)
                {
                    try
                    {
                        #region [ abre serviço ]
                        Loading.StaticFormVisible(true);
                        Loading.EnableStaticTextBox("Registrando serviço");
                        string msgLog = "Registrando Serviço";
                        Log.GravaLog(msgLog);

                        IdServico = DataAccess.SalvarServico(cbSegmento, cbProduto, boleto, prioridade, DateTime.Now);
                        if (IdServico != 0)
                        {
                            msgLog = "ID Buscado para criar itens do Serviço: " + IdServico;
                            Log.GravaLog(msgLog);

                            TelaDinamica.CriarEtapaFluxo(IdServico, cbProduto);
                        #endregion

                            #region [Grava dados do serviço]
                            msgLog = "Gravando dados do serviço: " + IdServico;
                            Log.GravaLog(msgLog);

                            List<Campos> listaEstrutura = DataAccess.buscarCamposDinamicos(cbProduto);

                            int campoAtual = 1;
                            int listaEstruturaTotal = listaEstrutura.Count;

                            List<Campos> CamposAcrescentar = new List<Campos>();
                            foreach (Campos campo in listaEstrutura)
                            {
                                Loading.EnableStaticTextBox("Salvando campos " + campoAtual + "/" + listaEstruturaTotal);
                                string nmvalor = "";
                                Dados rowCampoValor = _TodosDados.Find(r => r.Id_Campo == campo.ID_Campo);
                                if (rowCampoValor != null)
                                {
                                    nmvalor = rowCampoValor.Valor.ToString().Replace("'", "''").Replace("\"", "\"\"").Trim();
                                }

                                if (nmvalor != "")
                                {
                                    nmvalor = TelaDinamica.FormatarValorCampo(campo.CampoDominio, nmvalor);

                                    campo.ID_Servico = IdServico;
                                    campo.ValorCampo = nmvalor;

                                    CamposAcrescentar.Add(campo);

                                    #region [Grava dados do indicador]
                                    if (campo.CampoIndicador && campo.ValorCampo != campo.ValorCampoAntigo)
                                    {
                                        TratarEventos.GravaLinhaEvento(IdServico, campo.CampoTipoIndicador, campo.CampoRegraCalculo, campo.CampoItemIndicador, campo.ValorCampo, campo.CampoTipoValor, Environment.UserName.ToUpper(), campo.CampoEvento, "Captura do boleto");
                                    }
                                    #endregion
                                }
                                campoAtual++;
                            }

                            if (CamposAcrescentar.Count > 0)
                            {
                                DataAccess.SalvarDadosServicoLote(CamposAcrescentar);
                            }

                            if (tabela != null && tabela.Rows.Count > 0)
                            {
                                #region [ tabela ]
                                List<CamposTabela> camposTabela = DataAccess.BuscarCamposTabela();

                                Loading.EnableStaticTextBox("Salvando tabelas");

                                DataTable dt = TratamentoCampo.DataTableGroupBy("IdCampo", "IdCampo", tabela);

                                foreach (DataRow row in dt.Rows)
                                {
                                    DataAccess.DeletarDadosTabela("tb_0134_DadosTabela", "IdServico", IdServico, "BDconsulta", Convert.ToInt32(row[0]));
                                }



                                foreach (DataRow linhaTabela in tabela.Rows)
                                {
                                    string Dominio = "";
                                    string vlrCampo = "";
                                    List<CamposTabela> camposTbl = camposTabela.Where(n => n.ID_Campo == Convert.ToInt32(linhaTabela["IdCampo"]) && n.CampoNome == linhaTabela["NomeCampo"].ToString()).ToList();

                                    if (camposTbl.Count() > 0)
                                    {
                                        Dominio = camposTbl[0].CampoDominio;
                                        vlrCampo = TelaDinamica.FormatarValorCampo(Dominio, linhaTabela["ValorCampo"].ToString().Replace("'", "''").Replace("\"", "\"\"").Trim());
                                    }
                                    else
                                    {
                                        vlrCampo = linhaTabela["ValorCampo"].ToString().Replace("'", "''").Replace("\"", "\"\"").Trim();
                                    }

                                    sqlCommandInsert = "INSERT INTO tb_0134_DadosTabela (IdServico, IdCampo, NomeTabela, Linha, NomeCampo, ValorCampo) ";
                                    sqlCommandInsert += " Values (" + IdServico + ", " + linhaTabela["IdCampo"] + ", '" + linhaTabela["NomeTabela"] + "', '" + linhaTabela["Linha"] + "', '" + linhaTabela["NomeCampo"].ToString().Replace("'", "''").Replace("\"", "\"\"").Trim() + "', '" + vlrCampo + "')";
                                    DataConnector.ExecuteDataTable(sqlCommandInsert, "BDconsulta");
                                }
                                #endregion
                            }
                            #endregion
                            Loading.StaticFormVisible(false);
                            MessageBox.Show("Arquivo capturado e serviço cadastrado.");
                        }
                        else
                        {
                            msgLog = "Falha ao salvar serviço";
                            Log.GravaLog(msgLog);
                            throw new Exception(msgLog);
                        }
                    }
                    catch (Exception exp)
                    {
                        Loading.StaticFormVisible(false);
                        string msgLog = "Erro ao tentar salvar Arquivo na Base.";
                        Log.GravaLog(msgLog + "\n\nErro: " + exp.Message);
                        throw;
                    }
                }
                else
                {
                    msgLog = "Arquivo já capturado.";
                    Log.GravaLog(msgLog);
                }
            }
        }

        public void RegistraServicoLote(int cbSegmento, int cbProduto, bool prioridade, int IdAnalista)
        {

            bool validado = true;
            string camposInvalidos = "";
            DataTable dadosOperacao = null;

            DataTable tabelaAgrupada = TratamentoCampo.DataTableGroupBy("Linha", "IdCampo", tabela);
            
            List<Campos> listaEstrutura = DataAccess.buscarCamposDinamicos(cbProduto);

            int operacaoLinha = 1;
            int inconsistencias = 0;
            foreach (DataRow operacaoTabela in tabelaAgrupada.Rows)
            {
                if (tabela.Rows.Count > 0)
                {
                    DataRow[] tabelaRows = tabela.Select("CONVERT(Linha, 'System.String') = '" + operacaoTabela["Linha"] + "'");
                    if (tabelaRows.Count() > 0)
                        dadosOperacao = tabelaRows.CopyToDataTable();
                    else
                        dadosOperacao = new DataTable();
                }

                foreach (Campos campo in listaEstrutura)
                {
                    try
                    {
                        campo.ValorCampo = "";
                        campo.ValorCampo = dadosOperacao.AsEnumerable().SingleOrDefault(r => r.Field<string>("IdCampo") == campo.ID_Campo.ToString())["ValorCampo"].ToString();
                    }
                    catch { }
                }
            
                var tupla = TelaDinamica.ValidarCamposObrigatorios(listaEstrutura);
                var tupla2 = TelaDinamica.ValidarTIPOSCampos(listaEstrutura);

                if (!tupla.Item1 || !tupla2.Item1)
                {
                    validado = false;
                    
                    if (camposInvalidos != "")
                    {
                        camposInvalidos = camposInvalidos + "\n\n";
                    }

                    if (tupla.Item1 == false)
                    {
                        camposInvalidos = camposInvalidos + " Serviço " + operacaoLinha + "\n" + tupla.Item2;
                    }
                    else if (tupla2.Item1 == false)
                    {
                        camposInvalidos = camposInvalidos + " Serviço " + operacaoLinha + "\n" + tupla2.Item2;
                    }
                    inconsistencias++;
                    
                    if (inconsistencias == 10)
                        break;
                }
                operacaoLinha++;
            }


            if (validado)
            {
                operacaoLinha = 1;
                int operacaoLinhaTotal = tabelaAgrupada.Rows.Count;
                foreach (DataRow operacaoTabela in tabelaAgrupada.Rows)
                {
                    if (tabela.Rows.Count > 0)
                    {
                        DataRow[] tabelaRows = tabela.Select("CONVERT(Linha, 'System.String') = '" + operacaoTabela["Linha"] + "'");
                        if (tabelaRows.Count() > 0)
                            dadosOperacao = tabelaRows.CopyToDataTable();
                        else
                            dadosOperacao = new DataTable();
                    }

                    int IdServico;

                    Log.GravaLog("Verificando se existe o serviço registrado.");
                    if (DataAccess.BoletoServicoRegistrado(dadosOperacao.Rows[0]["NomeTabela"].ToString(), "tb_0125_Servico", "ServicoName", "BDconsulta") != true)
                    {
                        try
                        {
                            Loading.StaticFormVisible(true);
                            Loading.EnableStaticTextBox("Registrando serviço");
                            string msgLog = "Registrando Serviço";
                            Log.GravaLog(msgLog);
                            
                            IdServico = DataAccess.SalvarServico(cbSegmento, cbProduto, dadosOperacao.Rows[0]["NomeTabela"].ToString(), prioridade, DateTime.Now);
                            if (IdServico != 0)
                            {
                                msgLog = "ID Buscado para criar itens do Serviço: " + IdServico;
                                Log.GravaLog(msgLog);

                                TelaDinamica.CriarEtapaFluxo(IdServico, cbProduto);

                                msgLog = "Gravando dados do serviço: " + IdServico;
                                Log.GravaLog(msgLog);

                                #region [Grava dados do serviço]

                                int campoAtual = 1;
                                int listaEstruturaTotal = listaEstrutura.Count;

                                List<Campos> CamposAcrescentar = new List<Campos>();
                                foreach (Campos campo in listaEstrutura)
                                {
                                    try
                                    {
                                        campo.ValorCampo = "";
                                        campo.ValorCampo = dadosOperacao.AsEnumerable().SingleOrDefault(r => r.Field<string>("IdCampo") == campo.ID_Campo.ToString())["ValorCampo"].ToString();
                                    }
                                    catch { }

                                    Loading.EnableStaticTextBox("Salvando campos " + campoAtual + "/" + listaEstruturaTotal + " do serviço " + operacaoLinha + "/" + operacaoLinhaTotal);
                                    string nmvalor = "";

                                    string rowCampoValor = campo.ValorCampo;

                                    if (rowCampoValor != null)
                                    {
                                        nmvalor = rowCampoValor.ToString().Replace("'", "''").Replace("\"", "\"\"").Trim();
                                    }

                                    if (nmvalor != "")
                                    {
                                        nmvalor = TelaDinamica.FormatarValorCampo(campo.CampoDominio, nmvalor);
                                        campo.ID_Servico = IdServico;
                                        campo.ValorCampo = nmvalor;

                                        CamposAcrescentar.Add(campo);

                                        //sqlCommandInsert = "INSERT INTO tb_0126_DadosServico (ID_Servico, Id_Campo, NomeCampo, ValorCampo, [Data Criacao], [Data Atualizacao]) ";
                                        //sqlCommandInsert += " Values (" + IdServico + ", " + campo.ID_Campo + ", '" + campo.CampoNome + "', '" + nmvalor + "', '" + DateTime.Now + "', '" + DateTime.Now + "')";
                                        //DataConnector.ExecuteDataTable(sqlCommandInsert, "BDconsulta");

                                        #region [Grava dados do indicador]
                                        if (campo.CampoIndicador && campo.ValorCampo != campo.ValorCampoAntigo)
                                        {
                                            TratarEventos.GravaLinhaEvento(IdServico, campo.CampoTipoIndicador, campo.CampoRegraCalculo, campo.CampoItemIndicador, campo.ValorCampo, campo.CampoTipoValor, Environment.UserName.ToUpper(), campo.CampoEvento, "Captura do boleto");
                                        }
                                        #endregion
                                    }
                                    campoAtual++;
                                }

                                if (CamposAcrescentar.Count > 0)
                                {
                                    DataAccess.SalvarDadosServicoLote(CamposAcrescentar);
                                }

                                #endregion
                            }
                            else
                            {
                                msgLog = "Falha ao salvar serviço";
                                Log.GravaLog(msgLog);
                                throw new Exception(msgLog);
                            }
                        }
                        catch (Exception exp)
                        {
                            string msgLog = "Erro ao tentar registrar serviço " + operacaoLinha + "/" + operacaoLinhaTotal + ".\n\nVerifique se os foram importados. " + exp.Message;
                            Log.GravaLog(msgLog);
                            throw;
                        }
                    }
                    else
                    {
                        //msgLog = "Boleto já capturado.";
                        Log.GravaLog(msgLog);
                    }
                    operacaoLinha++;
                }
                Loading.StaticFormVisible(false);
                MessageBox.Show("Serviços cadastrados.");
            }
            else
            {
                Loading.StaticFormVisible(false);
                MessageBox.Show(camposInvalidos, "Valores inconsistentes",MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        public void AtualizaServicoBoleto(string boleto, int idObjeto, int IdServico, bool CamposMinutas = false, int IdMetodoCampos = 0)
        {
            string sqlCommandInsert;
            try
            {
                if (_TodosDados.Count > 0)
                {
                    #region [Grava dados do serviço]
                    List<Campos> listaEstrutura = new List<Campos>();
                    #region [ busca campos do serviço ]
                    if (SharedData.gFormOperação == "MINUTAS" || CamposMinutas)
                    {
                        listaEstrutura = DataAccess.buscarCamposDinamicosConjunto(IdServico, IdMetodoCampos);
                    }
                    else
                    {
                        listaEstrutura = DataAccess.buscarCamposDinamicosConjunto(IdServico);
                    }
                    #endregion

                    int campoAtual = 1;
                    int listaEstruturaTotal = listaEstrutura.Count;

                    List<Campos> CamposInsert = new List<Campos>();
                    List<Campos> CamposUpdate = new List<Campos>();
                    List<Campos> CamposDelete = new List<Campos>();

                    foreach (Campos campo in listaEstrutura)
                    {
                        Loading.EnableStaticTextBox("Salvando campos " + campoAtual + "/" + listaEstruturaTotal);

                        string nmvalor = "";
                        Dados rowCampoValor = _TodosDados.Find(r => r.Id_Campo == campo.ID_Campo);

                        if (rowCampoValor != null)
                        {
                            nmvalor = rowCampoValor.Valor.ToString().Replace("'", "''").Replace("\"", "\"\"").Trim();
                        }

                        if (nmvalor != "")
                        {
                            if (campo.ID_Servico == 0)
                            {
                                campo.ID_Servico = IdServico;
                            }
                            nmvalor = TelaDinamica.FormatarValorCampo(campo.CampoDominio, nmvalor);
                            campo.ValorCampo = nmvalor;
                            #region [ Update ]
                            if ((campo.ValorCampoAntigo != null) && (campo.ValorCampoAntigo != "") && campo.ValorCampoAntigo != campo.ValorCampo)
                            {
                                if (campo.ValorCampo != "")
                                {
                                    #region [ Update ]
                                    CamposUpdate.Add(campo);
                                    #endregion
                                }
                                else
                                {
                                    #region [ Delete ]
                                    CamposDelete.Add(campo);
                                    #endregion
                                }
                            }
                            #endregion

                            #region [ Insert ]
                            if (campo.ValorCampo != null && campo.ValorCampo != "" && (campo.ValorCampoAntigo == null || campo.ValorCampoAntigo == "") && campo.ValorCampoAntigo != campo.ValorCampo)
                            {
                                CamposInsert.Add(campo);
                            }
                            #endregion

                            #region [ Indicador ]
                            if (campo.CampoIndicador == true && campo.ValorCampo != campo.ValorCampoAntigo)
                            {
                                TratarEventos.GravaLinhaEvento(IdServico, campo.CampoTipoIndicador, campo.CampoRegraCalculo, campo.CampoItemIndicador, campo.ValorCampo, campo.CampoTipoValor, Environment.UserName.ToUpper(), campo.CampoEvento, "obs");
                            }
                            #endregion
                        }
                        campoAtual++;
                    }

                    #region [ Executar MultiQuery ]
                    if (CamposDelete.Count > 0)
                    {
                        DataAccess.ExcluirDadosServicoLote(IdServico, CamposDelete);
                    }

                    if (CamposUpdate.Count > 0)
                    {
                        DataAccess.AtualizarDadosServicoLote(IdServico, CamposUpdate);
                    }

                    if (CamposInsert.Count > 0)
                    {
                        DataAccess.SalvarDadosServicoLote(CamposInsert);
                    }
                    #endregion

                    if (tabela != null && tabela.Rows.Count > 0)
                    {
                        #region [ tabela ]
                        List<CamposTabela> camposTabela = DataAccess.BuscarCamposTabela();

                        Loading.EnableStaticTextBox("Salvando tabelas");

                        DataTable dt = TratamentoCampo.DataTableGroupBy("IdCampo", "IdCampo", tabela);

                        foreach (DataRow row in dt.Rows)
                        {
                            DataAccess.DeletarDadosTabela("tb_0134_DadosTabela", "IdServico", IdServico, "BDconsulta", Convert.ToInt32(row[0]));
                        }

                        foreach (DataRow linhaTabela in tabela.Rows)
                        {

                            string Dominio = "";
                            string vlrCampo = "";
                            List<CamposTabela> camposTbl = camposTabela.Where(n => n.ID_Campo == Convert.ToInt32(linhaTabela["IdCampo"]) && n.CampoNome == linhaTabela["NomeCampo"].ToString()).ToList();

                            if (camposTbl.Count() > 0)
                            {
                                Dominio = camposTbl[0].CampoDominio;
                                vlrCampo = TelaDinamica.FormatarValorCampo(Dominio, linhaTabela["ValorCampo"].ToString().Replace("'", "''").Replace("\"", "\"\"").Trim());
                            }
                            else
                            {
                                vlrCampo = linhaTabela["ValorCampo"].ToString().Replace("'", "''").Replace("\"", "\"\"").Trim();
                            }

                            sqlCommandInsert = "INSERT INTO tb_0134_DadosTabela (IdServico, IdCampo, NomeTabela, Linha, NomeCampo, ValorCampo) ";
                            sqlCommandInsert += " Values (" + IdServico + ", " + linhaTabela["IdCampo"] + ", '" + linhaTabela["NomeTabela"] + "', '" + linhaTabela["Linha"] + "', '" + linhaTabela["NomeCampo"].ToString().Replace("'", "''").Replace("\"", "\"\"").Trim() + "', '" + vlrCampo + "')";
                            DataConnector.ExecuteDataTable(sqlCommandInsert, "BDconsulta");
                        }
                        #endregion
                    }
                    Loading.StaticFormVisible(false);
                    MessageBox.Show("Arquivo capturado e serviço cadastrado.");
                    #endregion
                }
            }
            catch (Exception err)
            {
                Loading.StaticFormVisible(false);
                msgLog = "Erro ao atualizar campo. Erro: " + err.Message;
                Log.GravaLog(msgLog);
                throw;
            }
        }
        #endregion
    }
}
