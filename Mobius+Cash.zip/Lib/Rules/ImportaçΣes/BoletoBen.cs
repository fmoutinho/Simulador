﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Data;
using System.Configuration;
using System.Xml;
using System.Net;
using System.Globalization;

namespace Mobios
{
    public class BoletoBen
    {
        // Variável
        String _Uri;
        String _tagSearchKey;
        String _fileCodContrato;
        Int32 _BoletasTraduzidas;

        // rotinas
        #region [Rotinas de apoio]
        //Verifica se boleto existe
        public static bool BoletoExiste(string boleto, string tabela, string BD)
        {
            Log.GravaLog("Verificando se existe o boleto " + boleto);
            string sqlCommand = "SELECT * FROM {0} Where Boleto = '{1}' ";
            sqlCommand = String.Format(sqlCommand, tabela, boleto);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, BD);
            if (result.Rows.Count != 0)
                return true;
            else
                return false;
        }

        public static PMEReport GetReport(string produto, string modalidade, string evento)
        {
            string sql = string.Format("SELECT * FROM VW_PME WHERE NM_PRODUTO = '{0}' AND NM_MODALIDADE = '{1}' AND NM_EVENTO = '{2}'"
                , produto, modalidade, evento);

            DataTable dt = DataConnector.ExecuteDataTable(sql, "BDconsulta");
            if (dt.Rows.Count > 0)
            {
                PMEReport obj = new PMEReport(dt.Rows[0]);
                return obj;
            }
            else
                return null;
        }

        // Pega dados boleto
        public static List<BoletaBEN> GetBoletas(string boleto)
        {
            List<BoletaBEN> list = new List<BoletaBEN>();

            string sql = string.Format("SELECT * FROM VW_BOLETA_TO_PROCESS  Where Id_Boleta = {0}", boleto);

            DataTable dt = DataConnector.ExecuteDataTable(sql, "BDconsulta");

            foreach (DataRow row in dt.Rows)
            {
                BoletaBEN obj = new BoletaBEN(row);
                list.Add(obj);
            }

            return list;
        }
        public static DataTable GetBoletasDados(string boleto)
        {
            List<BoletaBEN> list = new List<BoletaBEN>();

            string sql = string.Format("SELECT * FROM vw_IntegrarBEN Where Boleto = '{0}'", boleto);

            DataTable dt = DataConnector.ExecuteDataTable(sql, "BDconsulta");
            return dt;
        }
        public static DataTable GetBoletasDadosGarantias(string boleto)
        {
            List<BoletaBEN> list = new List<BoletaBEN>();

            string sql = string.Format("SELECT * FROM vw_IntegrarBEN_Uniao Where Boleto = '{0}'", boleto);
            DataTable dt = DataConnector.ExecuteDataTable(sql, "BDconsulta");


            return dt;
        }
        public static DataTable GetBoletasDadosParcelas(string boleto)
        {
            List<BoletaBEN> list = new List<BoletaBEN>();

            string sql = string.Format("SELECT * FROM vw_IntegrarBENParcelas Where Boleto = '{0}'", boleto);
            DataTable dt = DataConnector.ExecuteDataTable(sql, "BDconsulta");


            return dt;


            //foreach (DataRow row in dt.Rows)
            //{
            //    BoletaBEN obj = new BoletaBEN(row);
            //    list.Add(obj);
            //}
            //return list;
        }

        // Pega mapeamento
        public static List<MapeamentoXML> GetMapeamento()
        {
            List<MapeamentoXML> list = new List<MapeamentoXML>();

            string sql = string.Format("SELECT * FROM vw_Parametros4131 ");

            DataTable dt = DataConnector.ExecuteDataTable(sql, "BDconsulta");

            foreach (DataRow row in dt.Rows)
            {
                MapeamentoXML obj = new MapeamentoXML(row);
                list.Add(obj);
            }

            return list;
        }

        #endregion

        #region [Captura dos boleto]

        public void ConectarBEN(string boleto, string user, string password, int Id_Produto)
        {
            Loading.EnableStaticTextBox("Conectando...");
            Log.GravaLog("Conectando ao BEN. ");
            // Recupera o cabeçalho do boleto            
            this._fileCodContrato = SharedData.gBenTagContrato;
            this._tagSearchKey = SharedData.gBenTagSearchKey;
            this._Uri = SharedData.gBenXmlResumo;

            string uriResumo = String.Format(this._Uri, boleto);    // Format Link

            MyWebClient wc = new MyWebClient();
            wc.UseDefaultCredentials = true;
            try
            {
                var xmlResumotxt = "";
                using (new Impersonation("NT", user, password))
                {
                    Loading.EnableStaticTextBox("Baixando trinca");
                    using (MemoryStream streamResumo = new MemoryStream(wc.DownloadData(uriResumo)))
                    {
                        var sr = new StreamReader(streamResumo);
                        var xmlResumo = sr.ReadToEnd();
                        // XML do boleto tem formato inválido, então precisa fazer a alteração abaixo
                        xmlResumo.Replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "");
                        xmlResumotxt = xmlResumo;
                    }
                }
                
                if (xmlResumotxt.ToUpper().Contains(this._tagSearchKey))
                {
                    XmlDocument xmlCabecalho = new XmlDocument();
                    xmlCabecalho.LoadXml(xmlResumotxt);

                    var root = xmlCabecalho.DocumentElement;
                    var codContrato = root.GetAttribute(this._fileCodContrato);

                    // Recupera a trinca Produto/Modalide/Evento do cabeçalho da boleta
                    // e utiliza para saber qual o relatório para recuperar os detalhes
                    string[] trincaPME = SharedData.gBenTrincaPME.Split(';');
                    var produto = root.GetAttribute(trincaPME[0]);
                    var modalidade = root.GetAttribute(trincaPME[1]);
                    var evento = root.GetAttribute(trincaPME[2]);

                    PMEReport report = GetReport(produto, modalidade, evento);
                    string xmlDetalhe = string.Empty;

                    // Caso não exista a trinca, não terá relatório
                    if (report != null)
                    {
                        string uriDetalhe = string.Format(SharedData.gBenDetalhe, report.NomeReport.Replace("/", ""), boleto);

                        using (new Impersonation("NT", user, password))
                        {
                            Loading.EnableStaticTextBox("Baixando boleto");
                            using (MemoryStream streamDetalhe = new MemoryStream(wc.DownloadData(uriDetalhe)))
                            {
                                var srDetalhe = new StreamReader(streamDetalhe);
                                xmlDetalhe = srDetalhe.ReadToEnd();
                                // XML do boleto tem formato inválido, então precisa fazer a alteração abaixo
                                xmlDetalhe = xmlDetalhe.Replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "").Replace("'", "");
                            }
                        }
                        
                        BoletaBEN bol = new BoletaBEN();
                        bol.Id_Boleta = Convert.ToInt32(boleto);
                        bol.Boleto = boleto.Trim();
                        bol.CodigoContrato = codContrato;
                        bol.DataCaptura = DateTime.Now;
                        bol.DataAtualizacao = DateTime.Now;
                        bol.Id_Produto = Id_Produto;
                        bol.Produto = produto;
                        bol.Modalidade = modalidade;
                        bol.Evento = evento;
                        bol.XML = xmlDetalhe;

                        Log.GravaLog("Conectando ao BEN - Salvando dados boleto " + bol.Boleto + ".");
                        DataAccess.SaveBoleta(bol);
                    }
                    else
                    {
                        Log.GravaLog("Conectando ao BEN - Report vazio. Verifique o cadastro!");
                        string MsgErro = "Conectando ao BEN - Report vazio. Verifique o cadastro de Produto [" + produto + "], Modalidade [" + modalidade + "] e Evento [" + evento + "].";
                        throw new System.ArgumentException(MsgErro);
                    }
                }
                else
                {
                    string MsgErro = "Retorno da pesquisa não se parece com um boleto. Não contêm a palavra chave DS_PRODUTO.";
                    Log.GravaLog(MsgErro);
                    throw new System.ArgumentException(MsgErro);
                }
            }
            catch (Exception ex)
            {
                throw new System.ArgumentException(ex.Message, "Mobios");
            }
        }

        public void BoletoTranslatorBEN(string boleto)
        {
            try
            {
                // Recupera as boletas e mapeamentos
                List<BoletaBEN> boletas = GetBoletas(boleto);
                Loading.EnableStaticTextBox("Mapeando dados");
                List<MapeamentoXML> mapeamento = GetMapeamento();

                this._BoletasTraduzidas = 0;
                
                List<Dados> _TodosDados = new List<Dados>();
                foreach (var bol in boletas)
                {
                    Application.DoEvents();
                    if (bol.XML != null && bol.XML != string.Empty)
                    {
                        // Recupera o Id do PME
                        PMEReport pme = GetReport(bol.Produto, bol.Modalidade, bol.Evento);

                        if (pme != null)
                        {
                            // Recupera o mapeamento apenas para a trinca PME
                            List<MapeamentoXML> mappings = mapeamento.Where(n => n.IdReport == pme.IdReport).ToList();
                            XmlDocument xDoc = new XmlDocument();
                            XmlDocument xDocParcial = new XmlDocument();
                            xDoc.LoadXml(bol.XML);

                            XmlNamespaceManager xmlnsManager = new XmlNamespaceManager(xDoc.NameTable);
                            xmlnsManager.AddNamespace("xsi", "http://www.w3.org/2001/XMLSchema-instance");
                            xmlnsManager.AddNamespace("autoproc", xDoc.DocumentElement.GetAttribute("xmlns"));

                            DataAccess.DeleteDado4131(bol.Id_Boleta);

                            Dados dado = new Dados();
                            dado.IdBoleto = bol.Id_Boleta;
                            dado.IdSeq = 1;
                            dado.Id_Campo = Convert.ToInt32(ConfigurationManager.AppSettings["IdCampoContrato"]);
                            dado.Campo = "Número do Contrato";
                            dado.Valor = bol.CodigoContrato;
                            _TodosDados.Add(dado);

                            List<string> list = new List<string>();

                            int mapAtual = 1;
                            int totalMap = mappings.Count;

                            foreach (var map in mappings)
                            {
                                Application.DoEvents();
                                Loading.EnableStaticTextBox("Capturando dados do boleto " + mapAtual + "/" + totalMap);
                                try
                                {
                                    // Aki Adriano
                                    var tempXPath = map.XPath.Replace("/@", "#").Remove(0, 1).Replace("/", "/autoproc:").Insert(0, "/").Replace("#", "/@");
                                    XmlNodeList nodes = xDoc.SelectNodes(tempXPath, xmlnsManager);

                                    //Desvio para tratar Pai no XML
                                    if (map.XPathPai != "" && map.XPathFilhos == "")
                                    {
                                        #region [ Busca Pai ]
                                        // Pega a referencia de nó do pai

                                        #region [ Monta Tag ]
                                        var tempXPathPai = map.XPathPai.Replace("/@", "#").Remove(0, 1).Replace("/", "/autoproc:").Insert(0, "/").Replace("#", "/@");
                                        string[] tagXpathPai = map.XPathPai.ToString().Split('/');
                                        string tagInitial = ""; string TagFinal = "";

                                        for (int i = 1; i < tagXpathPai.Count(); i++)
                                        {
                                            Application.DoEvents();
                                            if (tagXpathPai[i] != "")
                                                tagInitial += "<" + tagXpathPai[i] + ">";
                                        }

                                        for (int i = tagXpathPai.Count(); i > 0; i--)
                                        {
                                            Application.DoEvents();
                                            if (tagXpathPai[i - 1] != "")
                                                TagFinal += "</" + tagXpathPai[i - 1] + ">";
                                        }
                                        #endregion

                                        #region [ Encontra os nós ]
                                        xDoc.LoadXml(bol.XML);
                                        XmlNodeList nodesPai = xDoc.SelectNodes(tempXPathPai, xmlnsManager);
                                        int IdSeq = 1;
                                        foreach (XmlNode nodep in nodesPai)
                                        {
                                            Application.DoEvents();
                                            nodep.InnerXml = tagInitial + nodep.InnerXml + TagFinal;
                                            xDocParcial.LoadXml(nodep.InnerXml);

                                            // Encontra os nós do filho
                                            XmlNodeList nodesp = xDocParcial.SelectNodes(tempXPath, xmlnsManager);
                                            
                                            foreach (XmlNode node in nodesp)
                                            {
                                                dado = new Dados();
                                                Application.DoEvents();
                                                dado.Campo = map.NomeCampo;
                                                dado.Valor = node.Value;
                                                dado.IdSeq = IdSeq;
                                                dado.Id_Campo = map.IdCampo;
                                                dado.IdBoleto = bol.Id_Boleta;
                                                
                                                _TodosDados.Add(dado);
                                                IdSeq++;
                                            }

                                        }
                                        #endregion
                                        #endregion
                                    }
                                    else
                                    {
                                        int contaNode = 0;
                                        int IdSeq = 1;
                                        foreach (XmlNode node in nodes)
                                        {
                                            if (map.XPathPai != "" && map.XPathFilhos != "")
                                            {

                                                #region [ Busca Pai ]
                                                // Pega a referencia de nó do pai
                                                #region [ Monta Tag ]
                                                var tempXPathPai = map.XPathPai.Replace("/@", "#").Remove(0, 1).Replace("/", "/autoproc:").Insert(0, "/").Replace("#", "/@");
                                                string[] tagXpathPai = map.XPathPai.ToString().Split('/');
                                                string tagInitial = ""; string TagFinal = "";

                                                for (int i = 1; i < tagXpathPai.Count(); i++)
                                                {
                                                    Application.DoEvents();
                                                    if (tagXpathPai[i] != "")
                                                        tagInitial += "<" + tagXpathPai[i] + ">";
                                                }

                                                for (int i = tagXpathPai.Count(); i > 0; i--)
                                                {
                                                    Application.DoEvents();
                                                    if (tagXpathPai[i - 1] != "")
                                                        TagFinal += "</" + tagXpathPai[i - 1] + ">";
                                                }
                                                #endregion

                                                #region [ Encontra os nós ]
                                                xDoc.LoadXml(bol.XML);
                                                XmlNodeList nodesPai = xDoc.SelectNodes(tempXPathPai, xmlnsManager);
                                                
                                                Application.DoEvents();
                                                nodesPai[contaNode].InnerXml = tagInitial + nodesPai[contaNode].InnerXml + TagFinal;
                                                xDocParcial.LoadXml(nodesPai[contaNode].InnerXml);

                                                // Encontra os nós do filho
                                                var tempXPathFilhos = map.XPathFilhos.Replace("/@", "#").Remove(0, 1).Replace("/", "/autoproc:").Insert(0, "/").Replace("#", "/@");
                                                XmlNodeList nodesp = xDocParcial.SelectNodes(tempXPathFilhos, xmlnsManager);
                                                
                                                foreach (XmlNode nodepai in nodesp)
                                                {
                                                    dado = new Dados();
                                                    dado.Id_Campo = map.IdCampo;
                                                    dado.Campo = map.NomeCampo;
                                                    dado.Valor = node.Value;
                                                    dado.IdBoleto = bol.Id_Boleta;
                                                    dado.IdSeq = IdSeq;
                                                    
                                                    _TodosDados.Add(dado);
                                                    IdSeq++;
                                                }

                                                #endregion
                                                #endregion
                                            }
                                            else
                                            {
                                                dado = new Dados();
                                                dado.Id_Campo = map.IdCampo;
                                                dado.Campo = map.NomeCampo;
                                                dado.Valor = node.Value;
                                                dado.IdBoleto = bol.Id_Boleta;
                                                dado.IdSeq = IdSeq;
                                                
                                                _TodosDados.Add(dado);
                                                IdSeq++;
                                            }

                                            contaNode++;
                                        }
                                    }
                                }
                                catch (Exception err)
                                {
                                    MessageBox.Show(err.Message);
                                }
                                mapAtual++;
                            }
                            this._BoletasTraduzidas++;
                        }
                    }
                }
                if (_TodosDados.Count>0)
                {
                    DataAccess.SaveDadoLote(_TodosDados);
                }
            }
            catch (Exception ex)
            {
                Loading.StaticFormVisible(false);
                MessageBox.Show("Erro ao traduzir o boleto. Erro: " + ex.Message);
                Loading.StaticFormVisible(true);
            }
        }

        public static void CapturaBoleto(string boleto, string user, string password, int Id_Produto)
        {
            BoletoBen bolBen = new BoletoBen();
            bool BoletoJaExiste = BoletoExiste(boleto, "tb_0210_BoletoBen", "BDconsulta");
            bool Recapturar = SharedData.gValidaBoleto;
            
            if (BoletoJaExiste != true || Recapturar == true) // não capturar mesmo boleto duas vezes; o retorno sempre será novo boleto;
            {
                Loading.EnableStaticTextBox("Capturando Boleto");
                bool Capturar = true;
                if (BoletoJaExiste == true)
                {
                    Loading.StaticFormVisible(false);
                    if (MessageBox.Show("Boleto " + boleto + " já capturado anteriormente.\nDeseja recapturar os dados no sistema do boleto?\n\nReapturando ou não será criado um novo serviço com os dados já salvos.", "Boleto BEN", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        Capturar = true;
                    }
                    else
                    {
                        Capturar = false;
                    }
                }
                Loading.StaticFormVisible(true);
                if (Capturar)
                {
                    try
                    {
                        bolBen.ConectarBEN(boleto, user, password, Id_Produto);
                        bolBen.BoletoTranslatorBEN(boleto);

                        Loading.EnableStaticTextBox("Boleto capturado");
                    }
                    catch (Exception ex)
                    {
                        Loading.StaticFormVisible(false);
                        MessageBox.Show("Erro ao tentar capturar o boleto. Veja se número do boleto é válido.\nErro:\n" + ex.Message, "Mobios");
                        Loading.StaticFormVisible(true);
                        throw;
                    }
                }
            }
        }

        public static bool RegistraServicoBoleto(string boleto, int cbSegmento, int cbProduto, bool prioridade, int IdAnalista, bool CamposMinutas = false, int IdMetodoCampos = 0)
        {
            bool result = false;
            DataTable dtBol = GetBoletasDados(boleto);
            string sqlCommandInsert;
            int IdServico;

            if (dtBol.Rows.Count > 0)
            {
                string contrato = dtBol.Select("NM_CAMPO = 'Número do Contrato'").CopyToDataTable().Rows[0]["NM_VALOR"].ToString();

                Log.GravaLog("Verificando se existe o serviço registrado.");
                if (DataAccess.BoletoServicoRegistrado(contrato, "tb_0125_Servico", "ServicoName", "BDconsulta") != true)
                {
                    try
                    {
                        #region [ Cria Serviço ]
                        result = true;
                        Loading.StaticFormVisible(true);
                        Loading.EnableStaticTextBox("Registrando serviço");
                        string msgLog = "Registrando Serviço";
                        Log.GravaLog(msgLog);
                        // Registrar servico 
                        IdServico = DataAccess.SalvarServico(cbSegmento, cbProduto, contrato, prioridade, DateTime.Now);
                        if (IdServico != 0)
                        {
                            msgLog = "ID Buscado para criar itens do Serviço: " + IdServico;
                            Log.GravaLog(msgLog);

                            TelaDinamica.CriarEtapaFluxo(IdServico, cbProduto);
                        #endregion

                            #region [Grava dados do serviço]
                            msgLog = "Gravando dados do serviço: " + IdServico;
                            Log.GravaLog(msgLog);

                            List<Campos> listaEstrutura = DataAccess.buscarCamposDinamicos(cbProduto);

                            int campoAtual = 1;
                            int listaEstruturaTotal = listaEstrutura.Count;

                            List<Campos> CamposAcrescentar = new List<Campos>();
                            Campos bol = new Campos();
                            bol.ID_Servico = IdServico;
                            bol.ID_Campo = Convert.ToInt32(ConfigurationManager.AppSettings["IdCampoBoleto"]);
                            bol.ValorCampo = boleto.ToString();
                            if (bol.ID_Campo != 0)
                            {
                                CamposAcrescentar.Add(bol);
                            }

                            foreach (Campos campo in listaEstrutura)
                            {
                                Application.DoEvents();
                                Loading.EnableStaticTextBox("Salvando dados do boleto " + campoAtual + "/" + listaEstruturaTotal);
                                string nmvalor = "";

                                if (campo.CampoTipo.ToUpper() != "TABELA" && campo.CampoTipo.ToUpper() != "TABELAGERAL")
                                {
                                    DataRow rowCampoValor = dtBol.AsEnumerable().SingleOrDefault(r => r.Field<int>("ID_CAMPO") == campo.ID_Campo);
                                    if (rowCampoValor != null)
                                    {
                                        nmvalor = rowCampoValor["NM_VALOR"].ToString();
                                    }
                                    if (nmvalor != "")
                                    {
                                        nmvalor = TelaDinamica.FormatarValorCampo(campo.CampoDominio, nmvalor);
                                        campo.ID_Servico = IdServico;
                                        campo.ValorCampo = nmvalor;
                                        CamposAcrescentar.Add(campo);

                                        #region [Grava dados do indicador]
                                        if (campo.CampoIndicador && campo.ValorCampo != campo.ValorCampoAntigo)
                                        {
                                            TratarEventos.GravaLinhaEvento(IdServico, campo.CampoTipoIndicador, campo.CampoRegraCalculo, campo.CampoItemIndicador, campo.ValorCampo, campo.CampoTipoValor, Environment.UserName.ToUpper(), campo.CampoEvento, "Captura do boleto");
                                        }
                                        #endregion
                                    }
                                }
                                else
                                {
                                    #region [ tabelas ]
                                    DataTable tabela = null;
                                    if (dtBol.Rows.Count > 0)
                                    {
                                        DataRow[] tabelaRows = dtBol.Select("ID_CAMPO = " + campo.ID_Campo.ToString());
                                        if (tabelaRows.Count() > 0)
                                            tabela = tabelaRows.CopyToDataTable();
                                        else
                                            tabela = new DataTable();
                                    }

                                    if (tabela != null && tabela.Rows.Count > 0)
                                    {
                                        List<CamposTabela> camposTabela = DataAccess.BuscarCamposTabela();

                                        DataTable dt = TratamentoCampo.DataTableGroupBy("Id_Campo", "Id_Campo", tabela);

                                        foreach (DataRow row in dt.Rows)
                                        {
                                            DataAccess.DeletarDadosTabela("tb_0134_DadosTabela", "IdServico", IdServico, "BDconsulta", Convert.ToInt32(row[0]));
                                        }



                                        foreach (DataRow linhaTabela in tabela.Rows)
                                        {

                                            string Dominio = "";
                                            string vlrCampo = "";
                                            List<CamposTabela> camposTbl = camposTabela.Where(n => n.ID_Campo == Convert.ToInt32(linhaTabela["Id_Campo"]) && n.CampoNome == linhaTabela["NM_Campo"].ToString()).ToList();

                                            if (camposTbl.Count() > 0)
                                            {
                                                Dominio = camposTbl[0].CampoDominio;
                                                vlrCampo = TelaDinamica.FormatarValorCampo(Dominio, linhaTabela["NM_VALOR"].ToString());
                                            }
                                            else
                                            {
                                                vlrCampo = linhaTabela["NM_VALOR"].ToString();
                                            }

                                            sqlCommandInsert = "INSERT INTO tb_0134_DadosTabela (IdServico, IdCampo, NomeTabela, Linha, NomeCampo, ValorCampo) ";
                                            sqlCommandInsert += " Values (" + IdServico + ", " + linhaTabela["Id_Campo"] + ", '" + campo.CampoNome + "', '" + linhaTabela["ID_SEQ"] + "', '" + linhaTabela["NM_Campo"] + "', '" + vlrCampo + "')";
                                            DataConnector.ExecuteDataTable(sqlCommandInsert, "BDconsulta");
                                        }
                                    }
                                    #endregion
                                }

                                campoAtual++;
                            }

                            if (CamposAcrescentar.Count > 0)
                            {
                                DataAccess.SalvarDadosServicoLote(CamposAcrescentar);
                            }
                            #endregion
                        }
                        else
                        {
                            msgLog = "Falha ao salvar serviço";
                            Log.GravaLog(msgLog);
                            throw new Exception(msgLog);
                        }

                    }
                    catch (Exception exp)
                    {
                        MessageBox.Show("Erro ao tentar salvar Boleto na Base. Erro: " + exp.Message);
                        string msgLog = "Erro ao tentar salvar Boleto na Base";
                        result = false;
                        Log.GravaLog(msgLog);
                    }
                }
                else
                {
                    Loading.StaticFormVisible(false);
                    MessageBox.Show("Boleto já capturado.");
                    result = false;
                    Loading.StaticFormVisible(true);
                }
            }
            Loading.EnableStaticTextBox("Processo concluído");
            MessageBox.Show("Importação concluída.");
            return result;
        }
        public static bool AtualizaServicoBoleto(string boleto, int idObjeto, int IdServico, bool CamposMinutas = false, int IdMetodoCampos = 0)
        {
            bool result = false;
            DataTable dtBol = GetBoletasDados(boleto);
            string sqlCommandInsert;
            try
            {
                if (dtBol.Rows.Count > 0)
                {
                    result = true;
                    Loading.EnableStaticTextBox("Atualizando serviço");

                    #region [Grava dados do serviço]
                    List<Campos> listaEstrutura = new List<Campos>();
                    #region [ busca campos do serviço ]
                    if (SharedData.gFormOperação == "MINUTAS" || CamposMinutas)
                    {
                        listaEstrutura = DataAccess.buscarCamposDinamicosConjunto(IdServico, IdMetodoCampos);
                    }
                    else
                    {
                        listaEstrutura = DataAccess.buscarCamposDinamicosConjunto(IdServico);
                    }
                    #endregion
                    int campoAtual = 1;
                    int listaEstruturaTotal = listaEstrutura.Count;

                    List<Campos> CamposInsert = new List<Campos>();
                    List<Campos> CamposUpdate = new List<Campos>();
                    List<Campos> CamposDelete = new List<Campos>();

                    foreach (Campos campo in listaEstrutura)
                    {
                        Loading.EnableStaticTextBox("Salvando campos " + campoAtual + "/" + listaEstruturaTotal);

                        string nmvalor = "";

                        if (campo.CampoTipo.ToUpper() != "TABELA" && campo.CampoTipo.ToUpper() != "TABELAGERAL")
                        {
                            DataRow rowCampoValor = dtBol.AsEnumerable().SingleOrDefault(r => r.Field<int>("ID_CAMPO") == campo.ID_Campo);

                            if (rowCampoValor != null)
                            {
                                nmvalor = rowCampoValor["NM_VALOR"].ToString();
                            }

                            if (nmvalor != "")
                            {
                                if (campo.ID_Servico == 0)
                                {
                                    campo.ID_Servico = IdServico;
                                }
                                nmvalor = TelaDinamica.FormatarValorCampo(campo.CampoDominio, nmvalor);
                                campo.ValorCampo = nmvalor;
                                #region [ Update ]
                                if ((campo.ValorCampoAntigo != null) && (campo.ValorCampoAntigo != "") && campo.ValorCampoAntigo != campo.ValorCampo)
                                {
                                    if (campo.ValorCampo != "")
                                    {
                                        #region [ Update ]
                                        CamposUpdate.Add(campo);
                                        #endregion
                                    }
                                    else
                                    {
                                        #region [ Delete ]
                                        CamposDelete.Add(campo);
                                        #endregion
                                    }
                                }
                                #endregion

                                #region [ Insert ]
                                if (campo.ValorCampo != null && campo.ValorCampo != "" && (campo.ValorCampoAntigo == null || campo.ValorCampoAntigo == "") && campo.ValorCampoAntigo != campo.ValorCampo)
                                {
                                    CamposInsert.Add(campo);
                                }
                                #endregion

                                #region [ Indicador ]
                                if (campo.CampoIndicador == true && campo.ValorCampo != campo.ValorCampoAntigo)
                                {
                                    TratarEventos.GravaLinhaEvento(IdServico, campo.CampoTipoIndicador, campo.CampoRegraCalculo, campo.CampoItemIndicador, campo.ValorCampo, campo.CampoTipoValor, Environment.UserName.ToUpper(), campo.CampoEvento, "obs");
                                }
                                #endregion
                            }
                            campoAtual++;
                        }
                        else
                        {
                            #region [ Tabela ]
                            DataTable tabela = null;
                            if (dtBol.Rows.Count > 0)
                            {
                                DataRow[] tabelaRows = dtBol.Select("ID_CAMPO = " + campo.ID_Campo.ToString());
                                if (tabelaRows.Count() > 0)
                                    tabela = tabelaRows.CopyToDataTable();
                                else
                                    tabela = new DataTable();
                            }

                            if (tabela != null && tabela.Rows.Count > 0)
                            {
                                //Loading.EnableStaticTextBox("Salvando tabelas");
                                List<CamposTabela> camposTabela = DataAccess.BuscarCamposTabela();

                                DataTable dt = TratamentoCampo.DataTableGroupBy("Id_Campo", "Id_Campo", tabela);
                            
                                foreach (DataRow row in dt.Rows)
                                {
                                    DataAccess.DeletarDadosTabela("tb_0134_DadosTabela", "IdServico", IdServico, "BDconsulta", Convert.ToInt32(row[0]));
                                }



                                foreach (DataRow linhaTabela in tabela.Rows)
                                {
                                    string Dominio = "";
                                    string vlrCampo = "";
                                    List<CamposTabela> camposTbl = camposTabela.Where(n => n.ID_Campo == Convert.ToInt32(linhaTabela["Id_Campo"]) && n.CampoNome == linhaTabela["NM_Campo"].ToString()).ToList();

                                    if (camposTbl.Count() > 0)
                                    {
                                        Dominio = camposTbl[0].CampoDominio;
                                        vlrCampo = TelaDinamica.FormatarValorCampo(Dominio, linhaTabela["NM_VALOR"].ToString());
                                    }
                                    else
                                    {
                                        vlrCampo = linhaTabela["NM_VALOR"].ToString();
                                    }

                                    sqlCommandInsert = "INSERT INTO tb_0134_DadosTabela (IdServico, IdCampo, NomeTabela, Linha, NomeCampo, ValorCampo) ";
                                    sqlCommandInsert += " Values (" + IdServico + ", " + linhaTabela["Id_Campo"] + ", '" + campo.CampoNome + "', '" + linhaTabela["ID_SEQ"] + "', '" + linhaTabela["NM_Campo"] + "', '" + vlrCampo + "')";
                                    DataConnector.ExecuteDataTable(sqlCommandInsert, "BDconsulta");
                                }
                            }
                            #endregion
                        }
                        campoAtual++;
                    }

                    #region [ Executar MultiQuery ]
                    if (CamposDelete.Count > 0)
                    {
                        DataAccess.ExcluirDadosServicoLote(IdServico, CamposDelete);
                    }

                    if (CamposUpdate.Count > 0)
                    {
                        DataAccess.AtualizarDadosServicoLote(IdServico, CamposUpdate);
                    }

                    if (CamposInsert.Count > 0)
                    {
                        DataAccess.SalvarDadosServicoLote(CamposInsert);
                    }
                    #endregion
                    #endregion
                }
            }
            catch (Exception err)
            {
                Loading.StaticFormVisible(false);
                MessageBox.Show("Erro ao atualizar campo. Erro: " + err.Message);
                result = false;
            }
            Loading.EnableStaticTextBox("Processo concluído");
            return result;
        }

        #endregion

        #region [ MyWebClient ]
        public class MyWebClient : WebClient
        {
            protected override WebRequest GetWebRequest(Uri uri)
            {
                WebRequest w = base.GetWebRequest(uri);
                w.Timeout = 200 * 60 * 1000;
                return w;
            }
        }
        #endregion
    }



}
