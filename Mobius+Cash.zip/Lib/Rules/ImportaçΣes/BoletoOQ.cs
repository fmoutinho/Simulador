﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data;
using System.Configuration;

namespace Mobios
{
    public class BoletoOQ
    {
        #region [ Variáveis ]
        private WebBrowser localWB;
        private List<BoletaOQParametros> BoletoParametros;
        string msgLog;
        List<Dados> _TodosDados = new List<Dados>();
        #endregion

        public void LoginOQ(WebBrowser wbOQ, string url, string user, string senha)
        {
            localWB = wbOQ;

            localWB.ScriptErrorsSuppressed = true;

            localWB.Navigate(url, false);

            while (localWB.ReadyState != WebBrowserReadyState.Complete)
            {
                Application.DoEvents();
            }

            localWB.Document.GetElementById("formLoginNormal_username").InnerText = user.ToString();
            localWB.Document.GetElementById("formLoginNormal_password").InnerText = senha.ToString();
            Application.DoEvents();
            localWB.Document.GetElementById("button1").InvokeMember("click");
            Application.DoEvents();

            int validadorLogin = 0;
            while (validadorLogin < 100000)
            {
                Application.DoEvents();
                validadorLogin++;
            }

            while (wbOQ.ReadyState != WebBrowserReadyState.Complete)
            {
                Application.DoEvents();
            }

            Application.DoEvents();

            validadorLogin = 0;
            if (LogadoOk(localWB, "Em caso de problemas com seu usuário") == false | localWB.Document.Body==null)
            {
                while (validadorLogin < 100000)
                {
                    Application.DoEvents();
                    validadorLogin++;
                }
            }

            while (validadorLogin < 100000)
            {
                Application.DoEvents();
                validadorLogin++;
            }
            
        }

        public void ProcessaOQ(string Boleto, string Versao, WebBrowser wbOQ)
        {
            localWB = wbOQ;

            Cursor.Current = Cursors.WaitCursor;

            if ((Boleto != null) && (Boleto != ""))
            {
                msgLog = "Ler boleto OQ " + Boleto;
                Log.GravaLog(msgLog);

                ConectarOQ(Boleto, Versao, localWB);
            }
            else
            {
                MessageBox.Show("Digite o número do boleto!", "Acesso");
            }

            Cursor.Current = Cursors.Default;
        }

        public void ConectarOQ(string boleto, string versao, WebBrowser wbOQ)
        {
            localWB = wbOQ;

            if (LogadoOk(localWB, "Tela de Autenticação de Usuários") != false)
            {
                msgLog = "Boleto OQ " + boleto + " inexistente. Conectando ao OQ.";
                Log.GravaLog(msgLog);

                while (localWB.ReadyState != WebBrowserReadyState.Complete)
                {
                    Application.DoEvents();
                }

                string linkOQ = SharedData.gLinkOQ;
                linkOQ = String.Format(linkOQ, boleto, versao);

                localWB.Navigate(linkOQ, false);

                while (localWB.ReadyState != WebBrowserReadyState.Complete)
                {
                    Application.DoEvents();
                }

                int validadorLogin = 0;
                while (validadorLogin < 100000)
                {
                    Application.DoEvents();
                    validadorLogin++;
                }

                while (localWB.ReadyState != WebBrowserReadyState.Complete)
                {
                    Application.DoEvents();
                }
            }
        }

        public void LerOQ(WebBrowser wbOQ, string Boleto, string IdObjeto)
        {
            localWB = wbOQ;

            if (LogadoOk(localWB, "Tela de Autenticação de Usuários") != false)
            {
                if ((Boleto != null) && (Boleto != ""))
                {
                    msgLog="Iniciando leitura do boleto OQ " + Boleto + " .";
                    Log.GravaLog(msgLog);

                    LerBoletoOQ(Boleto, IdObjeto);
                }
                else
                {
                    MessageBox.Show("Digite o número do boleto!", "Acesso");
                }
            }
            else
            {
                MessageBox.Show("Usuário não logado ao sistema OQ. Verifique seus acessos.", "Acesso");
            }
        }

        // Ler dados do boleto: podemos ter diversos tipos de boleto OQ!!!!
        public void LerBoletoOQ(string boleto, string IdObjeto)
        {
            try
            {
                if (localWB.Document.Window.Frames[0].Document.Window.Frames[1].Document.Body.InnerText != null)
                {
                    if (localWB.Document.Window.Frames[0].Document.Window.Frames[1].Document.Body.InnerText.Contains("INFORMAÇÕES GERENCIAS OQ"))
                    {
                        msgLog="Iniciando leitura do boleto OQ " + boleto + " . Recuperando parâmetros.";
                        Log.GravaLog(msgLog);

                        _TodosDados = new List<Dados>();
                        Dados dado = new Dados();
                        BoletoParametros = DataAccess.retornaParametrosOQ();
                        try
                        {
                            foreach (BoletaOQParametros Parm in BoletoParametros)
                            {
                                try
                                {
                                    msgLog = "Iniciando leitura do boleto OQ " + boleto + " .Capturando campo " + Parm.NomeCampo + " entre valores " + Parm.ReferenciaInicial + " e " + Parm.ReferenciaFinal + ".";
                                    Log.GravaLog(msgLog);
                                    string CampoInfo = getInfo(Parm.ReferenciaInicial, Parm.ReferenciaFinal, Parm.ReferenciaCorte);
                                    string Separador = Parm.Separador;
                                    if (Separador != "")
                                    {
                                        Separador = Separador.Replace("\"", "");
                                    }
                                    if (Separador != "")
                                    {
                                        string[] CampoInfoArray = CampoInfo.Split(Convert.ToChar(Separador));
                                        CampoInfo = CampoInfoArray[Convert.ToInt32(Parm.Posicao)].Trim();
                                    }
                                    msgLog="Iniciando leitura do boleto OQ " + boleto + ". Valor encontrato: " + CampoInfo + ".";
                                    Log.GravaLog(msgLog);

                                    if ((CampoInfo != "") && (CampoInfo != null))
                                    {
                                        if (Parm.TamanhoCampo > 0)
                                        {
                                            CampoInfo = CampoInfo.Substring(0, Parm.TamanhoCampo);
                                        }

                                        if (Parm.IdCampo != null && Parm.IdCampo != "")
                                        {
                                            dado = new Dados();
                                            dado.IdBoleto = Convert.ToInt32(boleto);
                                            dado.Id_Campo = Convert.ToInt32(Parm.IdCampo);
                                            dado.Valor = CampoInfo;
                                            _TodosDados.Add(dado);
                                        }
                                    }
                                    else
                                    {
                                        msgLog = "Iniciando leitura do boleto OQ " + boleto + ". Valor encontrato: [branco].";
                                        Log.GravaLog(msgLog);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    msgLog="Iniciando leitura do boleto OQ " + boleto + ". Erro captura valor campo:  " + ex.Message + ".";
                                    Log.GravaLog(msgLog);
                                }
                            }
                        }
                        catch (Exception exp)
                        {
                            msgLog = "Erro ao ler dados boleto. Erro: " + exp.Message;
                            Log.GravaLog(msgLog);
                            throw;
                        }
                    }
                    else
                    {
                        msgLog="Página não representa um item do boleto.";
                        Log.GravaLog(msgLog);
                    }
                }
            }
            catch (Exception exErr)
            {
                msgLog="Erro ao tentar ler boleto. Err: " + exErr.Message + ".\nVerifique se o boleto já foi pesquisado.";
                Log.GravaLog(msgLog);
                throw;
            }
        }

        public void RegistraServicoBoleto(string boleto, int cbSegmento, int cbProduto, bool prioridade, int IdAnalista)
        {
            int IdServico;

            if (_TodosDados.Count > 0)
            {
                #region [ Valida Serviço ]
                Log.GravaLog("Verificando se existe o serviço registrado.");
                if (DataAccess.BoletoServicoRegistrado(boleto, "tb_0125_Servico", "ServicoName", "BDconsulta") != true)
                {
                    try
                    {
                        #region [ abre serviço ]
                        Loading.StaticFormVisible(true);
                        Loading.EnableStaticTextBox("Registrando serviço");
                        string msgLog = "Registrando Serviço";
                        Log.GravaLog(msgLog);

                        IdServico = DataAccess.SalvarServico(cbSegmento, cbProduto, boleto, prioridade, DateTime.Now);
                        if (IdServico != 0)
                        {
                            msgLog = "ID Buscado para criar itens do Serviço: " + IdServico;
                            Log.GravaLog(msgLog);

                            TelaDinamica.CriarEtapaFluxo(IdServico, cbProduto);
                        #endregion

                            #region [Grava dados do serviço]
                            msgLog = "Gravando dados do serviço: " + IdServico;
                            Log.GravaLog(msgLog);

                            List<Campos> listaEstrutura = DataAccess.buscarCamposDinamicos(cbProduto);
                            int campoAtual = 1;
                            int listaEstruturaTotal = listaEstrutura.Count;

                            List<Campos> CamposAcrescentar = new List<Campos>();
                            foreach (Campos campo in listaEstrutura)
                            {
                                Loading.EnableStaticTextBox("Salvando campos " + campoAtual + "/" + listaEstruturaTotal);
                                string nmvalor = "";
                                Dados rowCampoValor = _TodosDados.Find(r => r.Id_Campo == campo.ID_Campo);
                                if (rowCampoValor != null)
                                {
                                    nmvalor = rowCampoValor.Valor.ToString().Replace("'", "''").Replace("\"", "\"\"").Trim();
                                }

                                if (nmvalor != "")
                                {
                                    nmvalor = TelaDinamica.FormatarValorCampo(campo.CampoDominio, nmvalor);

                                    campo.ID_Servico = IdServico;
                                    campo.ValorCampo = nmvalor;

                                    CamposAcrescentar.Add(campo);

                                    #region [Grava dados do indicador]
                                    if (campo.CampoIndicador && campo.ValorCampo != campo.ValorCampoAntigo)
                                    {
                                        TratarEventos.GravaLinhaEvento(IdServico, campo.CampoTipoIndicador, campo.CampoRegraCalculo, campo.CampoItemIndicador, campo.ValorCampo, campo.CampoTipoValor, Environment.UserName.ToUpper(), campo.CampoEvento, "Captura do boleto");
                                    }
                                    #endregion
                                }
                                campoAtual++;
                            }

                            if (CamposAcrescentar.Count > 0)
                            {
                                DataAccess.SalvarDadosServicoLote(CamposAcrescentar);
                            }
                            #endregion
                        }
                        else
                        {
                            msgLog = "Falha ao salvar serviço";
                            Log.GravaLog(msgLog);
                            throw new Exception(msgLog);
                        }
                    }
                    catch (Exception exp)
                    {
                        string msgLog = "Erro ao tentar salvar Boleto na Base: " + exp.Message;
                        Log.GravaLog(msgLog);
                        throw;
                    }
                    finally
                    {
                        Loading.StaticFormVisible(false);
                    }
                }
                else
                {
                    msgLog = "Boleto já capturado.";
                    Log.GravaLog(msgLog);
                }
                #endregion
            }
        }

        public void AtualizaServicoBoleto(string boleto, int idObjeto, int IdServico, bool CamposMinutas = false, int IdMetodoCampos = 0)
        {
            try
            {
                if (_TodosDados.Count > 0)
                {
                    #region [Grava dados do serviço]
                    List<Campos> listaEstrutura = new List<Campos>();
                    #region [ busca campos do serviço ]
                    if (SharedData.gFormOperação == "MINUTAS" || CamposMinutas)
                    {
                        listaEstrutura = DataAccess.buscarCamposDinamicosConjunto(IdServico, IdMetodoCampos);
                    }
                    else
                    {
                        listaEstrutura = DataAccess.buscarCamposDinamicosConjunto(IdServico);
                    }
                    #endregion

                    int campoAtual = 1;
                    int listaEstruturaTotal = listaEstrutura.Count;

                    List<Campos> CamposInsert = new List<Campos>();
                    List<Campos> CamposUpdate = new List<Campos>();
                    List<Campos> CamposDelete = new List<Campos>();

                    foreach (Campos campo in listaEstrutura)
                    {
                        Loading.EnableStaticTextBox("Salvando campos " + campoAtual + "/" + listaEstruturaTotal);

                        string nmvalor = "";
                        Dados rowCampoValor = _TodosDados.Find(r => r.Id_Campo == campo.ID_Campo);

                        if (rowCampoValor != null)
                        {
                            nmvalor = rowCampoValor.Valor.ToString().Replace("'", "''").Replace("\"", "\"\"").Trim();
                        }

                        if (nmvalor != "")
                        {
                            if (campo.ID_Servico == 0)
                            {
                                campo.ID_Servico = IdServico;
                            }
                            nmvalor = TelaDinamica.FormatarValorCampo(campo.CampoDominio, nmvalor);
                            campo.ValorCampo = nmvalor;
                            #region [ Update ]
                            if ((campo.ValorCampoAntigo != null) && (campo.ValorCampoAntigo != "") && campo.ValorCampoAntigo != campo.ValorCampo)
                            {
                                if (campo.ValorCampo != "")
                                {
                                    #region [ Update ]
                                    CamposUpdate.Add(campo);
                                    #endregion
                                }
                                else
                                {
                                    #region [ Delete ]
                                    CamposDelete.Add(campo);
                                    #endregion
                                }
                            }
                            #endregion

                            #region [ Insert ]
                            if (campo.ValorCampo != null && campo.ValorCampo != "" && (campo.ValorCampoAntigo == null || campo.ValorCampoAntigo == "") && campo.ValorCampoAntigo != campo.ValorCampo)
                            {
                                CamposInsert.Add(campo);
                            }
                            #endregion

                            #region [ Indicador ]
                            if (campo.CampoIndicador == true && campo.ValorCampo != campo.ValorCampoAntigo)
                            {
                                TratarEventos.GravaLinhaEvento(IdServico, campo.CampoTipoIndicador, campo.CampoRegraCalculo, campo.CampoItemIndicador, campo.ValorCampo, campo.CampoTipoValor, Environment.UserName.ToUpper(), campo.CampoEvento, "obs");
                            }
                            #endregion
                        }
                        campoAtual++;
                    }

                    #region [ Executar MultiQuery ]
                    if (CamposDelete.Count > 0)
                    {
                        DataAccess.ExcluirDadosServicoLote(IdServico, CamposDelete);
                    }

                    if (CamposUpdate.Count > 0)
                    {
                        DataAccess.AtualizarDadosServicoLote(IdServico, CamposUpdate);
                    }

                    if (CamposInsert.Count > 0)
                    {
                        DataAccess.SalvarDadosServicoLote(CamposInsert);
                    }
                    #endregion

                    Loading.StaticFormVisible(false);
                    MessageBox.Show("Boleto capturado e serviço cadastrado.");
                    #endregion
                }
            }
            catch (Exception err)
            {
                Loading.StaticFormVisible(false);
                msgLog = "Erro ao atualizar campo. Erro: " + err.Message;
                Log.GravaLog(msgLog);
                throw;
            }
        }

        private string getInfo(string Ref1, string Ref2, string RefCorte, int Tamanho = 0)
        {
            
            string Txt = localWB.Document.Window.Frames[0].Document.Window.Frames[1].Document.Body.InnerText;
            string tIni = Ref1;
            string tFim = Ref2;
            string tCorte = RefCorte;
            
            int PosCorte = Txt.IndexOf(tCorte);
            int Pos = Txt.IndexOf(tIni);
            int Pos2 = Txt.IndexOf(tFim);
            
            string Txt2 = Txt.Substring(PosCorte);
            
            Pos = Txt2.IndexOf(tIni);
            Pos2 = Txt2.IndexOf(tFim);

            if (Pos2 > 0)
            {
                if (Tamanho == 0)
                {
                    Txt = Txt2.Substring(Pos + tIni.Length, Pos2 - Pos - tIni.Length);
                }
                else
                {
                    Txt = Txt2.Substring(Pos + tIni.Length, Tamanho);
                }
            }
            else
            {
                msgLog= "Erro ao localizar dados do boleto. Erro: Pos = " + Pos.ToString() + " / Pos2 = " + Pos2.ToString() + ".";
                Log.GravaLog(msgLog);
                Txt = "";
            }
            return Txt.Trim();

        }

        public bool LogadoOk(WebBrowser webOQ, string textoValidacao)
        {
            bool result = true;
            HtmlElementCollection Head = webOQ.Document.GetElementsByTagName("HEAD");
            foreach (HtmlElement item in Head)
            {
                if (item.InnerText.Contains(textoValidacao))
                {
                    result = false;
                }
            }
            return result;
        }

    }
}
