﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Mobios
{
    class CSVReader
    {
        public static DataTable ConvertCSVtoDataTable(string strFilePath, char separador = ';')
        {

            DataTable dt = new DataTable();

            using (StreamReader sr = new StreamReader(strFilePath, Encoding.Default))
            {
                string[] headers = sr.ReadLine().Split(separador);

                foreach (string header in headers)
                {
                    dt.Columns.Add(header);
                }
                while (!sr.EndOfStream)
                {
                    string[] rows = Regex.Split(sr.ReadLine(), separador + "(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
                    DataRow dr = dt.NewRow();
                    if (rows.Count() == headers.Length)
                    {
                        for (int i = 0; i < headers.Length; i++)
                        {
                            dr[i] = rows[i];
                        }
                        dt.Rows.Add(dr);
                    }
                }
            }

            return dt;
        }
    }
}
