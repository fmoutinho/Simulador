﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data;
using System.Configuration;

namespace Mobios
{
    public class ImportaWeb
    {
        public string msgLog;

        private WebBrowser wb;

        public List<string> BuscaServicosWeb(List<Responsavel>UserCelulas, WebBrowser webbrowser, string user = "", string password = "")
        {
            List<string> result = new List<string>();
            List<string> resultParcial = new List<string>();

            wb = webbrowser;

            List<SharePointServicoRetorno> Parametros = new List<SharePointServicoRetorno>();
            Parametros = DataAccess.BuscaParametrosServicoImportados("WEB");
            
            foreach (SharePointServicoRetorno Parametro in Parametros)
            {
                try
                {
                    DateTime DataRotina = DateTime.Now;
                    if (UserCelulas.Where(n => n.Integradores.ToUpper().Contains(Parametro.SharePoint.ToUpper() + "=TRUE")).Count() > 0)
                    {
                        if (Parametro.SharePoint.ToUpper() == "Y9")
                        {
                            msgLog = "Importando: " + Parametro.SharePoint;
                            Log.GravaLog(msgLog, "_MobiosBackground");

                            #region [ Y9 ]
                            //string url = @"http://intracorp9hom.itau/y9portal/pages/MasterPage.aspx";
                            string urlPrincipal = Parametro.SharePointIntegracaoURL;
                            string url = "";
                            string[] portalProdutos = Parametro.ValoresCriterioSP.Split(';');
                            DataTable resultDt = new DataTable();

                            bool click = false;
                            bool pendencias = true;
                            foreach (string selecionarProduto in portalProdutos)
                            {
                                if (wb.Url != null)
                                {
                                    if (wb.Url.ToString().Contains("https"))
                                    {
                                        urlPrincipal = urlPrincipal.Replace("http:", "https:");
                                    }
                                }

                                msgLog = "Importando: " + Parametro.SharePoint + " " + selecionarProduto;
                                Log.GravaLog(msgLog, "_MobiosBackground");

                                if (WebFunctions.LoginMar2(urlPrincipal, user, password, wb, "iframeLoginMar2", true, "_MobiosBackground"))
                                {
                                    if (wb.Url.ToString().Contains("https"))
                                    {
                                        urlPrincipal = urlPrincipal.Replace("http:", "https:");
                                    }

                                    HtmlElement selector;

                                    selector = wb.Document.GetElementById("lstProdutoSessao");

                                    foreach (HtmlElement e in selector.Children)
                                    {
                                        if (e.InnerText == selecionarProduto)
                                        {
                                            e.InvokeMember("click");
                                            Application.DoEvents();
                                            click = true;
                                            break;
                                        }
                                    }
                                    if (click == false)
                                    {
                                        msgLog = "Não foi localizado o produto: " + Parametro.SharePoint + " " + selecionarProduto;
                                        Log.GravaLog(msgLog, "_MobiosBackground");
                                        continue;
                                    }

                                    wb.Document.GetElementById("btnTrocaProdutoSessao").InvokeMember("click");
                                    Application.DoEvents();

                                    string valor = "";
                                    do
                                    {
                                        selector = wb.Document.GetElementById("txtDropDownProduto");
                                        if (selector != null)
                                        {
                                            valor = selector.GetAttribute("value");
                                        }
                                        Application.DoEvents();
                                    } while (valor != selecionarProduto);

                                    while (wb.ReadyState != WebBrowserReadyState.Complete)
                                    {
                                        Application.DoEvents();
                                    }

                                    //url = @"http://intracorp9hom.itau/y9portal/pages/minhas_pendencias.aspx";

                                    msgLog = "Acessando pendências";
                                    Log.GravaLog(msgLog, "_MobiosBackground");
                                    url = @"http://intracorp9.itau/y9portal/pages/minhas_pendencias.aspx";
                                    if (wb.Url.ToString().Contains("https"))
                                    {
                                        url = url.Replace("http:", "https:");
                                    }

                                    wb.Navigate(url);

                                    while (wb.ReadyState != WebBrowserReadyState.Complete)
                                    {
                                        Application.DoEvents();
                                    }

                                    do
                                    {
                                        Application.DoEvents();
                                    } while (wb.Document.GetElementById("lnkPesquisar") == null);

                                    selector = wb.Document.GetElementById("lnkPesquisar");
                                    selector.InvokeMember("click");
                                    Application.DoEvents();

                                    msgLog = "Importando Pendências";
                                    Log.GravaLog(msgLog, "_MobiosBackground");

                                    do
                                    {
                                        if (wb.Document.Body != null)
                                        {
                                            if (wb.Document.Body.InnerText != null)
                                            {
                                                if (wb.Document.Body.InnerText.ToUpper().Contains("SEM ATIVIDADES PENDENTES PARA O PRODUTO"))
                                                {
                                                    pendencias = false;
                                                    break;
                                                }
                                            }
                                        }
                                        Application.DoEvents();
                                    } while ((wb.Document.GetElementById("tbPendencias") == null && wb.Document.GetElementById("carregando2004") != null));

                                    if (pendencias)
                                    {
                                        selector = wb.Document.GetElementById("tbPendencias");
                                        if (selector != null)
                                        {
                                            DataTable DtTarget = new DataTable();
                                            DtTarget = TratamentoCampo.MontarTabela(selector, "OBJETO;PRIORIDADE", selecionarProduto + ";false");

                                            msgLog = "Filtrando operações de PREENCHIMENTO";
                                            Log.GravaLog(msgLog, "_MobiosBackground");

                                            string valorPreenchimento = "";
                                            foreach (DataColumn dc in DtTarget.Columns)
                                            {
                                                valorPreenchimento = DtTarget.Rows[0][dc].ToString().ToUpper();
                                                if (valorPreenchimento.Contains("PREENCHIMENTO"))
                                                {
                                                    msgLog = "Operações: " + valorPreenchimento;
                                                    Log.GravaLog(msgLog, "_MobiosBackground");
                                                    if (valorPreenchimento.IndexOf('(') != -1 && valorPreenchimento.IndexOf(')') != -1)
                                                    {
                                                        valorPreenchimento = valorPreenchimento.Substring(valorPreenchimento.IndexOf('(') + 1, valorPreenchimento.IndexOf(')') - valorPreenchimento.IndexOf('(') - 1);
                                                    }
                                                    else
                                                    {
                                                        msgLog = "Não foi localizado o padrão de preenchimento: 'PREENCHIMENTO(0)'";
                                                        Log.GravaLog(msgLog, "_MobiosBackground");
                                                    }
                                                    break;
                                                }
                                            }

                                            int quantidadeOp = 0;

                                            if (Int32.TryParse(valorPreenchimento, out quantidadeOp))
                                            {
                                                DataTable dtClone = DtTarget.Clone();

                                                for (int i = 1; i <= quantidadeOp; i++)
                                                {
                                                    dtClone.ImportRow(DtTarget.Rows[i]);
                                                }
                                                DtTarget = new DataTable();
                                                DtTarget = dtClone.Copy();
                                            }
                                            else
                                            {
                                                DtTarget.Rows.Clear();
                                                msgLog = "Não foi identificado número de registros para importar (conversão para inteiro no campo PREENCHIMENTO): " + valorPreenchimento;
                                                Log.GravaLog(msgLog, "_MobiosBackground");
                                            }

                                            if (DtTarget.Rows.Count > 0)
                                            {
                                                if (resultDt.Rows.Count == 0)
                                                    resultDt = DtTarget.Copy();
                                                else
                                                    resultDt.Merge(DtTarget);
                                            }
                                        }

                                        msgLog = "Importando Fast Track";
                                        Log.GravaLog(msgLog, "_MobiosBackground");

                                        selector = wb.Document.GetElementById("divFastTrack");

                                        if (selector != null)
                                        {
                                            HtmlElementCollection selectorTable = selector.GetElementsByTagName("TABLE");
                                            foreach (HtmlElement tbl in selectorTable)
                                            {
                                                if (resultDt.Rows.Count == 0)
                                                    resultDt = TratamentoCampo.MontarTabela(tbl, "OBJETO;PRIORIDADE", selecionarProduto + ";true").Copy();
                                                else
                                                    resultDt.Merge(TratamentoCampo.MontarTabela(tbl, "OBJETO;PRIORIDADE", selecionarProduto + ";true"));
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    msgLog = "Falha no login: " + Parametro.SharePoint;
                                    Log.GravaLog(msgLog, "_MobiosBackground");

                                    throw new Exception(msgLog);
                                }

                                if (pendencias)
                                {
                                    msgLog = "Tabelas geradas";
                                    Log.GravaLog(msgLog, "_MobiosBackground");
                                }
                                wb.Navigate(urlPrincipal);

                                while (wb.ReadyState != WebBrowserReadyState.Complete)
                                {
                                    Application.DoEvents();
                                }
                            }
                            #endregion

                            #region [ Abre Serviço ]
                            DataRow[] resultRows = null;
                            if (resultDt.Rows.Count > 0)
                            {
                                msgLog = "Filtrando operações recentes";
                                Log.GravaLog(msgLog, "_MobiosBackground");
                            
                                if (Parametro.DataUltimaRotina.ToString("dd/MM/yyyy HH:mm:ss") != "01/01/0001 00:00:00")
                                {
                                    resultRows = resultDt.Select(@"CONVERT([RECEBIDO EM], 'System.DateTime') >= #" + Parametro.DataUltimaRotina.ToString("yyyy/MM/dd HH:mm:ss") + "#");
                                }

                                msgLog = "Operações Filtradas: " + resultRows.Count();
                                Log.GravaLog(msgLog, "_MobiosBackground");

                                if (resultRows.Count() > 0)
                                {
                                    resultDt = resultRows.CopyToDataTable();
                                    string camposGerais = Parametro.CampoRetornarSP;
                                    string camposGeraisMobios = Parametro.CampoRetornarMobios;
                                    string camposOperacao = Parametro.NomeCampoOperacaoSP;
                                    string camposMobios = Parametro.CampoOperacaoMobios;

                                    msgLog = "Abrindo serviços";
                                    Log.GravaLog(msgLog, "_MobiosBackground");
                                    resultParcial = AbreServico.AbreServicos(resultDt, camposGerais, camposGeraisMobios, Parametro.SharePoint.ToUpper(), camposOperacao, camposMobios, "_MobiosBackground");
                                    for (int i = 0; i < resultParcial.Count; i++)
                                    {
                                        result.Add(resultParcial[i].ToString());
                                    }
                                }
                            }
                            #endregion

                            if (click == true)
                            {
                                msgLog = "Atualiza data do procedimento de importação";
                                Log.GravaLog(msgLog, "_MobiosBackground");

                                DataAccess.AtualizaDataImportacao(Parametro.Id, DataRotina);
                            }
                        }
                    }
                }
                catch (Exception exp)
                {
                    msgLog = "Falha na importação: " + exp.Message + " Quantidade de Serviços Abertos: " + result.Count;
                    Log.GravaLog(msgLog, "_MobiosBackground");

                    throw new Exception(msgLog);
                }
            }

            return result;
        }
    }
}
