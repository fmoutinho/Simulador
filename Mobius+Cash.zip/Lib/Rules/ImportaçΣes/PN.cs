﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data;
using System.Configuration;

namespace Mobios
{
    public class PN
    {
        #region [ Variáveis ]
        private WebBrowser localWB;
        private List<BoletaPNParametros> BoletoParametros;
        string msgLog;
        string _resultText;
        DataTable tabela;
        List<Dados> _TodosDados;
        #endregion

        public void LoginPN(WebBrowser wb, string url, string user, string senha)
        {
            localWB = wb;
            localWB.ScriptErrorsSuppressed = true;
            localWB.Navigate(url, false);

            while (wb.ReadyState != WebBrowserReadyState.Complete)
            {
                Application.DoEvents();
            }

            localWB.Document.GetElementById("formLoginNormal_username").InnerText = user.ToString();
            localWB.Document.GetElementById("formLoginNormal_password").InnerText = senha.ToString();
            Application.DoEvents();
            localWB.Document.GetElementById("button1").InvokeMember("click");
            Application.DoEvents();

            int validadorLogin = 0;
            while (validadorLogin < 100000)
            {
                Application.DoEvents();
                validadorLogin++;
            }

            while (localWB.ReadyState != WebBrowserReadyState.Complete | localWB.Document.Url.ToString() != @"https://intracorp13.itau/gcweb/")
            {
                Application.DoEvents();
            }
        }

        public string BuscarDadosPN(WebBrowser wb, string PN)
        {
            localWB = wb;

            while (this.localWB.ReadyState != WebBrowserReadyState.Complete)
            {
                Application.DoEvents();
            }

            string linkPN = SharedData.gLinkPN;

            this.localWB.Navigate(linkPN, false);
            Application.DoEvents();
            while (this.localWB.ReadyState != WebBrowserReadyState.Complete | this.localWB.Document.Url.ToString() != linkPN)
            {
                Application.DoEvents();
            }

            msgLog = "Processa PN " + PN;
            Log.GravaLog(msgLog);
            HtmlElement selector = this.localWB.Document.GetElementById("txtN2920");
            selector.SetAttribute("value", PN); //"80352821"
            this.localWB.Document.InvokeScript("JS_Processar");
            Application.DoEvents();

            while (this.localWB.ReadyState != WebBrowserReadyState.Complete)
            {
                Application.DoEvents();
            }
            Application.DoEvents();
            DateTime dataInicio = DateTime.Now;
            while (this.localWB.Document.Body == null || this.localWB.Document.Body.InnerHtml.IndexOf("NUMERO DA PROPOSTA NAO EXISTE") == -1 && this.localWB.Document.Body.InnerHtml.IndexOf("GF-SISTEMA APOIO A CREDITO - POSICAO DO 2920") == -1)
            {
                Application.DoEvents();
                if (Math.Round(Convert.ToDecimal((DateTime.Now - dataInicio).TotalSeconds), 0) > 10)
                {
                    throw new Exception("TIMEOUT: Não foi possível baixar a PN.");
                }
            }
            Application.DoEvents();
            _resultText = this.localWB.Document.Body.InnerHtml.ToString();

            return _resultText;
        }

        public void LerPN(WebBrowser wbOQ, string Boleto)
        {
            localWB = wbOQ;

            if (LogadoOk(localWB, "Tela de Autenticação de Usuários") != false)
            {
                if ((Boleto != null) && (Boleto != ""))
                {
                    msgLog = "Iniciando leitura da PN " + Boleto + " .";
                    Log.GravaLog(msgLog);

                    Log.GravaLog("Verificando de boleto " + Boleto + " Já foi capturado.");
                    if (DataAccess.BoletoExiste(Boleto, "tb_0014_PN") != true)
                    {
                        LerTextoPN(Boleto);
                    }
                    else
                    {
                        try
                        {
                            DataAccess.DeletaBoleto(Boleto, "tb_0014_PN");
                            LerTextoPN(Boleto);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Erro ao tentar capturar a PN novamente. Erro: " + ex.Message, "PN");
                            throw;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Digite o número da PN!", "PN");
                }
            }
            else
            {
                MessageBox.Show("Usuário não logado ao sistema GCWEB. Efetue login.", "PN");
            }
        }

        public void LerTextoPN(string boleto)
        {
            try
            {
                if (localWB.Document.Body.InnerHtml.ToString().Contains("NUMERO DA PROPOSTA NAO EXISTE") == true)
                {
                    throw new Exception("Número da proposta não existe");
                }
                else
                {
                    _TodosDados = new List<Dados>();
                    Dados dado = new Dados();

                    BoletoParametros = DataAccess.retornaParametrosPN();

                    tabela = new DataTable();
                    tabela.Columns.Add("NomeTabela");
                    tabela.Columns.Add("Linha");
                    tabela.Columns.Add("NomeCampo");
                    tabela.Columns.Add("ValorCampo");
                    tabela.Columns.Add("IdCampo");

                    int ParmAtual = 1;
                    int BoletoParametrosTotal = BoletoParametros.Count();

                    foreach (BoletaPNParametros Parm in BoletoParametros)
                    {
                        try
                        {
                            #region [ busca referencias de corte ]
                            Parm.ReferenciaInicial = Parm.ReferenciaInicial.Replace("\\n", "\n").Replace("\\r", "\r");
                            Parm.ReferenciaFinal = Parm.ReferenciaFinal.Replace("\\n", "\n").Replace("\\r", "\r");
                            Parm.ReferenciaCorte = Parm.ReferenciaCorte.Replace("\\n", "\n").Replace("\\r", "\r");
                            #endregion

                            Loading.EnableStaticTextBox("Lendo Campos " + ParmAtual + "/" + BoletoParametrosTotal);

                            string Separador = Parm.Separador;
                            if (Separador != "")
                            {
                                Separador = Separador.Replace("\"", "");
                            }

                            if (Parm.TipoCampo == "tabela")
                            {
                                #region [ tabela ]
                                string[] tabelaString = getInfoTabela(Parm.ReferenciaInicial, Parm.ReferenciaFinal, Parm.ReferenciaCorte);
                                string[] NomeCamposTabela = Parm.NomeCamposTabela.Split(';');
                                string[] posicao = Parm.Posicao.Split(';');

                                for (int linha = 1; linha <= tabelaString.Count(); linha++)
                                {

                                    string[] camposLinha = tabelaString[linha - 1].Split(new string[] { Separador }, StringSplitOptions.RemoveEmptyEntries);

                                    for (int camposTabela = 0; camposTabela < NomeCamposTabela.Count(); camposTabela++)
                                    {
                                        string[] posicaoCampo = posicao[camposTabela].Split('@');
                                        int posicaoInicial = Convert.ToInt32(posicaoCampo[0]);
                                        int posicaoFinal = Convert.ToInt32(posicaoCampo[1]);
                                        if (posicaoFinal < 0)
                                        {
                                            posicaoFinal = camposLinha.Count() - 1 + posicaoFinal;
                                        }
                                        else if (posicaoFinal < posicaoInicial && posicaoFinal == 0)
                                        {
                                            posicaoFinal = camposLinha.Count() - 1;
                                        }

                                        string valorCampoTabela = "";
                                        for (int posicaoLinha = posicaoInicial; posicaoLinha <= posicaoFinal; posicaoLinha++)
                                        {
                                            if (valorCampoTabela == "")
                                            {
                                                valorCampoTabela = camposLinha[posicaoLinha];
                                            }
                                            else
                                            {
                                                valorCampoTabela += " " + camposLinha[posicaoLinha];
                                            }
                                        }

                                        if (NomeCamposTabela[camposTabela].ToString().Contains("CPF"))
                                        {
                                            if (!ValidaCPF.IsCpf(valorCampoTabela))
                                            {
                                                valorCampoTabela = ValidaCPF.CalculaDigCPF(valorCampoTabela);
                                            }
                                        }

                                        tabela.Rows.Add(Parm.NomeCampo, linha, NomeCamposTabela[camposTabela], valorCampoTabela, Parm.IdCampo);

                                    }
                                }
                                #endregion
                            }
                            else
                            {
                                msgLog = "Iniciando leitura da PN " + boleto + " .Capturando campo " + Parm.NomeCampo + " entre valores " + Parm.ReferenciaInicial + " e " + Parm.ReferenciaFinal + ".";
                                Log.GravaLog(msgLog);
                                string CampoInfo = getInfo(Parm.ReferenciaInicial, Parm.ReferenciaFinal, Parm.ReferenciaCorte);
                                
                                #region [ Separador ]
                                if (Separador != "")
                                {
                                    string[] arraySeparador = Separador.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
                                    string[] arrayPosicao = Parm.Posicao.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);

                                    int sep = 0;
                                    foreach (string txtSeparador in arraySeparador)
                                    {
                                        Separador = txtSeparador.Replace("\"", "").Replace("\\n", "\n").Replace("\\r", "\r");
                                        CampoInfo = CampoInfo.Replace(Separador, "|");
                                        string[] CampoInfoArray = CampoInfo.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
                                        //string[] CampoInfoArray = CampoInfo.Split(Convert.ToChar(Separador));
                                        if (arrayPosicao[sep].ToString().Contains('@'))
                                        {
                                            string[] posicao = arrayPosicao[sep].ToString().Split('@');
                                            int posicaoInicial = Convert.ToInt32(posicao[0]);
                                            int posicaoFinal = Convert.ToInt32(posicao[1]);
                                            if (posicaoFinal < 0)
                                            {
                                                posicaoFinal = CampoInfoArray.Count() - 1 + posicaoFinal;
                                            }
                                            else if (posicaoFinal < posicaoInicial && posicaoFinal == 0)
                                            {
                                                posicaoFinal = CampoInfoArray.Count() - 1;
                                            }

                                            CampoInfo = "";
                                            for (int posicaoLinha = posicaoInicial; posicaoLinha <= posicaoFinal; posicaoLinha++)
                                            {
                                                if (CampoInfo == "")
                                                {
                                                    CampoInfo = CampoInfoArray[posicaoLinha];
                                                }
                                                else
                                                {
                                                    CampoInfo += " " + CampoInfoArray[posicaoLinha];
                                                }
                                            }

                                        }
                                        else
                                        {
                                            CampoInfo = CampoInfoArray[Convert.ToInt32(arrayPosicao[sep].ToString())].Trim();
                                        }

                                        sep++;
                                    }
                                }
                                #endregion

                                #region [ Salva valor ]
                                msgLog = "Iniciando leitura PN " + boleto + ". Valor encontrato: " + CampoInfo + ".";
                                Log.GravaLog(msgLog);

                                if ((CampoInfo != "") && (CampoInfo != null))
                                {
                                    if (Parm.TamanhoCampo > 0)
                                    {
                                        CampoInfo = CampoInfo.Substring(0, Parm.TamanhoCampo);
                                    }

                                    if (Parm.IdCampo != null && Parm.IdCampo != "")
                                    {
                                        #region [ formatação ]
                                        CampoInfo = CampoInfo.Replace("\n", "|").Replace("\r", "|").Replace(" ", " ");
                                        string[] CampoInfoArray = CampoInfo.Split('|');
                                        CampoInfo = "";
                                        foreach (string Info in CampoInfoArray)
                                        {
                                            CampoInfo += Info.Replace("'", "''").Replace("\"", "\"\"").Trim() + " ";
                                        }
                                        CampoInfo = CampoInfo.Trim();
                                        #endregion

                                        dado = new Dados();
                                        dado.IdBoleto = Convert.ToInt32(boleto);
                                        dado.Id_Campo = Convert.ToInt32(Parm.IdCampo);
                                        dado.Valor = CampoInfo;
                                        _TodosDados.Add(dado);
                                    }
                                }
                                else
                                {
                                    msgLog = "Iniciando leitura da PN " + boleto + ". Valor encontrato: [branco].";
                                    Log.GravaLog(msgLog);
                                }
                                #endregion

                            }
                        }
                        catch (Exception ex)
                        {
                            msgLog = "Iniciando leitura da PN " + boleto + ". Erro captura valor campo:  " + ex.Message + ".";
                            Log.GravaLog(msgLog);
                        }
                        Application.DoEvents();

                        ParmAtual++;
                    }
                    Loading.EnableStaticTextBox("Boleto capturado");
                }

            }
            catch (Exception exp)
            {
                msgLog = "Erro ao ler dados boleto. Erro: " + exp.Message;
                Log.GravaLog(msgLog);
                throw;
            }
        }

        public void RegistraServicoBoleto(string boleto, int cbSegmento, int cbProduto, bool prioridade, int IdAnalista)
        {
            string sqlCommandInsert;
            int IdServico;

            if (_TodosDados.Count > 0)
            {
                Log.GravaLog("Verificando se existe o serviço registrado.");
                if (DataAccess.BoletoServicoRegistrado(boleto, "tb_0125_Servico", "ServicoName", "BDconsulta") != true)
                {
                    try
                    {
                        #region [ abre serviço ]
                        Loading.StaticFormVisible(true);
                        Loading.EnableStaticTextBox("Registrando serviço");
                        string msgLog = "Registrando Serviço";
                        Log.GravaLog(msgLog);

                        IdServico = DataAccess.SalvarServico(cbSegmento, cbProduto, "PN " + boleto, prioridade, DateTime.Now);
                        if (IdServico != 0)
                        {
                            msgLog = "ID Buscado para criar itens do Serviço: " + IdServico;
                            Log.GravaLog(msgLog);

                            TelaDinamica.CriarEtapaFluxo(IdServico, cbProduto);
                        #endregion

                            #region [Grava dados do serviço]
                            msgLog = "Gravando dados do serviço: " + IdServico;
                            Log.GravaLog(msgLog);

                            List<Campos> listaEstrutura = DataAccess.buscarCamposDinamicos(cbProduto);
                            int campoAtual = 1;
                            int listaEstruturaTotal = listaEstrutura.Count;

                            List<Campos> CamposAcrescentar = new List<Campos>();
                            foreach (Campos campo in listaEstrutura)
                            {
                                Loading.EnableStaticTextBox("Salvando campos " + campoAtual + "/" + listaEstruturaTotal);
                                string nmvalor = "";
                                Dados rowCampoValor = _TodosDados.Find(r => r.Id_Campo == campo.ID_Campo);
                                if (rowCampoValor != null)
                                {
                                    nmvalor = rowCampoValor.Valor.ToString().Replace("'", "''").Replace("\"", "\"\"").Trim();
                                }

                                if (nmvalor != "")
                                {
                                    nmvalor = TelaDinamica.FormatarValorCampo(campo.CampoDominio, nmvalor);

                                    campo.ID_Servico = IdServico;
                                    campo.ValorCampo = nmvalor;

                                    CamposAcrescentar.Add(campo);

                                    #region [Grava dados do indicador]
                                    if (campo.CampoIndicador && campo.ValorCampo != campo.ValorCampoAntigo)
                                    {
                                        TratarEventos.GravaLinhaEvento(IdServico, campo.CampoTipoIndicador, campo.CampoRegraCalculo, campo.CampoItemIndicador, campo.ValorCampo, campo.CampoTipoValor, Environment.UserName.ToUpper(), campo.CampoEvento, "Captura do boleto");
                                    }
                                    #endregion
                                }
                                campoAtual++;
                            }

                            if (CamposAcrescentar.Count > 0)
                            {
                                DataAccess.SalvarDadosServicoLote(CamposAcrescentar);
                            }

                            if (tabela != null && tabela.Rows.Count > 0)
                            {
                                #region [ tabela ]
                                List<CamposTabela> camposTabela = DataAccess.BuscarCamposTabela();

                                Loading.EnableStaticTextBox("Salvando tabelas");

                                DataTable dt = TratamentoCampo.DataTableGroupBy("IdCampo", "IdCampo", tabela);

                                foreach (DataRow row in dt.Rows)
                                {
                                    DataAccess.DeletarDadosTabela("tb_0134_DadosTabela", "IdServico", IdServico, "BDconsulta", Convert.ToInt32(row[0]));
                                }



                                foreach (DataRow linhaTabela in tabela.Rows)
                                {
                                    string Dominio = "";
                                    string vlrCampo = "";
                                    List<CamposTabela> camposTbl = camposTabela.Where(n => n.ID_Campo == Convert.ToInt32(linhaTabela["IdCampo"]) && n.CampoNome == linhaTabela["NomeCampo"].ToString()).ToList();

                                    if (camposTbl.Count() > 0)
                                    {
                                        Dominio = camposTbl[0].CampoDominio;
                                        vlrCampo = TelaDinamica.FormatarValorCampo(Dominio, linhaTabela["ValorCampo"].ToString().Replace("'", "''").Replace("\"", "\"\"").Trim());
                                    }
                                    else
                                    {
                                        vlrCampo = linhaTabela["ValorCampo"].ToString().Replace("'", "''").Replace("\"", "\"\"").Trim();
                                    }

                                    sqlCommandInsert = "INSERT INTO tb_0134_DadosTabela (IdServico, IdCampo, NomeTabela, Linha, NomeCampo, ValorCampo) ";
                                    sqlCommandInsert += " Values (" + IdServico + ", " + linhaTabela["IdCampo"] + ", '" + linhaTabela["NomeTabela"] + "', '" + linhaTabela["Linha"] + "', '" + linhaTabela["NomeCampo"].ToString().Replace("'", "''").Replace("\"", "\"\"").Trim() + "', '" + vlrCampo + "')";
                                    DataConnector.ExecuteDataTable(sqlCommandInsert, "BDconsulta");
                                }
                                #endregion
                            }
                            #endregion
                            Loading.StaticFormVisible(false);
                            MessageBox.Show("PN capturada e serviço cadastrado.");
                        }
                        else
                        {
                            msgLog = "Falha ao salvar serviço";
                            Log.GravaLog(msgLog);
                            throw new Exception(msgLog);
                        }
                    }
                    catch (Exception exp)
                    {
                        Loading.StaticFormVisible(false);
                        string msgLog = "Erro ao tentar salvar PN na Base.";
                        Log.GravaLog(msgLog + "\n\nErro: " + exp.Message);
                        throw;
                    }
                }
                else
                {
                    msgLog = "Boleto já capturado.";
                    Log.GravaLog(msgLog);
                }
            }
        }

        public void AtualizaServicoBoleto(string boleto, int idObjeto, int IdServico, bool CamposMinutas = false, int IdMetodoCampos = 0)
        {
            string sqlCommandInsert;
            try
            {
                if (_TodosDados.Count > 0)
                {
                    #region [Grava dados do serviço]
                    List<Campos> listaEstrutura = new List<Campos>();
                    #region [ busca campos do serviço ]
                    if (SharedData.gFormOperação == "MINUTAS" || CamposMinutas)
                    {
                        listaEstrutura = DataAccess.buscarCamposDinamicosConjunto(IdServico, IdMetodoCampos);
                    }
                    else
                    {
                        listaEstrutura = DataAccess.buscarCamposDinamicosConjunto(IdServico);
                    }
                    #endregion

                    int campoAtual = 1;
                    int listaEstruturaTotal = listaEstrutura.Count;

                    List<Campos> CamposInsert = new List<Campos>();
                    List<Campos> CamposUpdate = new List<Campos>();
                    List<Campos> CamposDelete = new List<Campos>();

                    foreach (Campos campo in listaEstrutura)
                    {
                        Loading.EnableStaticTextBox("Salvando campos " + campoAtual + "/" + listaEstruturaTotal);

                        

                        string nmvalor = "";
                        Dados rowCampoValor = _TodosDados.Find(r => r.Id_Campo == campo.ID_Campo);

                        if (rowCampoValor != null)
                        {
                            nmvalor = rowCampoValor.Valor.ToString().Replace("'", "''").Replace("\"", "\"\"").Trim();
                        }

                        if (nmvalor != "")
                        {
                            if (campo.ID_Servico == 0)
                            {
                                campo.ID_Servico = IdServico;
                            }
                            nmvalor = TelaDinamica.FormatarValorCampo(campo.CampoDominio, nmvalor);
                            campo.ValorCampo = nmvalor;
                            #region [ Update ]
                            if ((campo.ValorCampoAntigo != null) && (campo.ValorCampoAntigo != "") && campo.ValorCampoAntigo != campo.ValorCampo)
                            {
                                if (campo.ValorCampo != "")
                                {
                                    #region [ Update ]
                                    CamposUpdate.Add(campo);
                                    #endregion
                                }
                                else
                                {
                                    #region [ Delete ]
                                    CamposDelete.Add(campo);
                                    #endregion
                                }
                            }
                            #endregion

                            #region [ Insert ]
                            if (campo.ValorCampo != null && campo.ValorCampo != "" && (campo.ValorCampoAntigo == null || campo.ValorCampoAntigo == "") && campo.ValorCampoAntigo != campo.ValorCampo)
                            {
                                CamposInsert.Add(campo);
                            }
                            #endregion

                            #region [ Indicador ]
                            if (campo.CampoIndicador == true && campo.ValorCampo != campo.ValorCampoAntigo)
                            {
                                TratarEventos.GravaLinhaEvento(IdServico, campo.CampoTipoIndicador, campo.CampoRegraCalculo, campo.CampoItemIndicador, campo.ValorCampo, campo.CampoTipoValor, Environment.UserName.ToUpper(), campo.CampoEvento, "obs");
                            }
                            #endregion
                        }
                        campoAtual++;
                    }

                    #region [ Executar MultiQuery ]
                    if (CamposDelete.Count > 0)
                    {
                        DataAccess.ExcluirDadosServicoLote(IdServico, CamposDelete);
                    }

                    if (CamposUpdate.Count > 0)
                    {
                        DataAccess.AtualizarDadosServicoLote(IdServico, CamposUpdate);
                    }

                    if (CamposInsert.Count > 0)
                    {
                        DataAccess.SalvarDadosServicoLote(CamposInsert);
                    }
                    #endregion

                    if (tabela != null && tabela.Rows.Count > 0)
                    {
                        #region [ tabela ]
                        List<CamposTabela> camposTabela = DataAccess.BuscarCamposTabela();

                        Loading.EnableStaticTextBox("Salvando tabelas");

                        DataTable dt = TratamentoCampo.DataTableGroupBy("IdCampo", "IdCampo", tabela);

                        foreach (DataRow row in dt.Rows)
                        {
                            DataAccess.DeletarDadosTabela("tb_0134_DadosTabela", "IdServico", IdServico, "BDconsulta", Convert.ToInt32(row[0]));
                        }

                        foreach (DataRow linhaTabela in tabela.Rows)
                        {

                            string Dominio = "";
                            string vlrCampo = "";
                            List<CamposTabela> camposTbl = camposTabela.Where(n => n.ID_Campo == Convert.ToInt32(linhaTabela["IdCampo"]) && n.CampoNome == linhaTabela["NomeCampo"].ToString()).ToList();

                            if (camposTbl.Count() > 0)
                            {
                                Dominio = camposTbl[0].CampoDominio;
                                vlrCampo = TelaDinamica.FormatarValorCampo(Dominio, linhaTabela["ValorCampo"].ToString().Replace("'", "''").Replace("\"", "\"\"").Trim());
                            }
                            else
                            {
                                vlrCampo = linhaTabela["ValorCampo"].ToString().Replace("'", "''").Replace("\"", "\"\"").Trim();
                            }

                            sqlCommandInsert = "INSERT INTO tb_0134_DadosTabela (IdServico, IdCampo, NomeTabela, Linha, NomeCampo, ValorCampo) ";
                            sqlCommandInsert += " Values (" + IdServico + ", " + linhaTabela["IdCampo"] + ", '" + linhaTabela["NomeTabela"] + "', '" + linhaTabela["Linha"] + "', '" + linhaTabela["NomeCampo"].ToString().Replace("'", "''").Replace("\"", "\"\"").Trim() + "', '" + vlrCampo + "')";
                            DataConnector.ExecuteDataTable(sqlCommandInsert, "BDconsulta");
                        }
                        #endregion
                    }
                    Loading.StaticFormVisible(false);
                    MessageBox.Show("Boleto capturado e serviço cadastrado.");
                    #endregion
                }
            }
            catch (Exception err)
            {
                Loading.StaticFormVisible(false);
                msgLog = "Erro ao atualizar campo. Erro: " + err.Message;
                Log.GravaLog(msgLog);
                throw;
            }
        }

        private string getInfo(string Ref1, string Ref2, string RefCorte, int Tamanho = 0)
        {
            // Set variaveis
            string Txt = localWB.Document.Body.InnerHtml.ToString();
            string tIni = Ref1;
            string tFim = Ref2;
            string tCorte = RefCorte;
            // Define a posição do arquivo
            int PosCorte = Txt.IndexOf(tCorte);
            int Pos = Txt.IndexOf(tIni);
            int Pos2 = Txt.IndexOf(tFim);
            // Reduz o arquivo original para garantir que a POS2 seja depois do POS            
            if (PosCorte >= 0)
            {
                string Txt2 = Txt.Substring(PosCorte);
                // Define as novas posições após redução do arquivo
                Pos = Txt2.IndexOf(tIni);

                Pos2 = Txt2.IndexOf(tFim);

                //if ((Pos > 0) && (Pos2 > 0))
                if (Pos2 > 0 && Pos >= 0 && Pos2 > Pos)
                {
                        if (Txt2.Substring(Pos).IndexOf(tFim) < Txt2.Substring(Pos).IndexOf("!") || tFim =="!")
                        {
                            if (Tamanho == 0)
                            {
                                Txt = Txt2.Substring(Pos + tIni.Length, Pos2 - Pos - tIni.Length);
                            }
                            else
                            {
                                Txt = Txt2.Substring(Pos + tIni.Length, Tamanho);
                            }
                        }
                        else
                        {
                            Pos2 = Pos + Txt2.Substring(Pos).IndexOf("!");
                            if (Tamanho == 0)
                            {
                                Txt = Txt2.Substring(Pos + tIni.Length, Pos2 - Pos - tIni.Length);
                            }
                            else
                            {
                                Txt = Txt2.Substring(Pos + tIni.Length, Tamanho);
                            }
                        }
                }
                else
                {
                    msgLog = "Erro ao localizar dados do boleto. Erro: Pos = " + Pos.ToString() + " / Pos2 = " + Pos2.ToString() + ".";
                    Log.GravaLog(msgLog);
                    Txt = "";
                }
            }
            else
            {
                msgLog = "Erro ao localizar dados do boleto. Erro: Pos = " + Pos.ToString() + " / Pos2 = " + Pos2.ToString() + ".";
                Log.GravaLog(msgLog);
                Txt = "";
            }
            return Txt.Trim();

        }

        private string[] getInfoTabela(string Ref1, string Ref2, string RefCorte, int Tamanho = 0)
        {
            // Set variaveis
            string result = "";
            string Txt = localWB.Document.Body.InnerHtml.ToString();
            string tIni = Ref1;
            string tFim = Ref2;
            string tCorte = RefCorte;
            // Define a posição do arquivo
            int PosCorte = Txt.IndexOf(tCorte);
            int Pos = Txt.IndexOf(tIni);
            int Pos2 = Txt.IndexOf(tFim);
            // Reduz o arquivo original para garantir que a POS2 seja depois do POS            
            if (PosCorte >= 0)
            {
                string Txt2 = Txt.Substring(PosCorte);
                // Define as novas posições após redução do arquivo
                Pos = Txt2.IndexOf(tIni);

                Pos2 = Txt2.IndexOf(tFim);

                //if ((Pos > 0) && (Pos2 > 0))
                if (Pos2 > 0 && Pos >= 0 && Pos2 > Pos)
                {
                    if (Tamanho == 0)
                    {
                        Txt = Txt2.Substring(Pos + tIni.Length, Pos2 - Pos - tIni.Length);
                    }
                    else
                    {
                        Txt = Txt2.Substring(Pos + tIni.Length, Tamanho);
                    }
                    Txt = Txt.Replace("\r\n", "_");
                    string[] Linhas = Txt.Split('_');
                    bool cabecalho = false;
                    foreach (string linha in Linhas)
                    {
                        string linhaTratada = linha.Trim();
                        if (!(linhaTratada.Substring(0,1)=="-" || linhaTratada.Substring(0,1)=="!"))
                        {
                            if (cabecalho == false)
                            {
                                cabecalho = true;
                            }
                            else
                            {
                                if (result == "")
                                {
                                    result = linhaTratada.Substring(0, linhaTratada.IndexOf("!"));
                                }
                                else
                                {
                                    result += ";" + linhaTratada.Substring(0, linhaTratada.IndexOf("!"));
                                }
                            }
                        }
                    }
                }
                else
                {
                    msgLog = "Erro ao localizar dados do boleto. Erro: Pos = " + Pos.ToString() + " / Pos2 = " + Pos2.ToString() + ".";
                    Log.GravaLog(msgLog);
                    Txt = "";
                }
            }
            else
            {
                msgLog = "Erro ao localizar dados do boleto. Erro: Pos = " + Pos.ToString() + " / Pos2 = " + Pos2.ToString() + ".";
                Log.GravaLog(msgLog);
                Txt = "";
            }
            return result.Split(';');

        }

        public bool LogadoOk(WebBrowser webOQ, string textoValidacao)
        {
            bool result = true;
            HtmlElementCollection Head = webOQ.Document.GetElementsByTagName("HEAD");
            foreach (HtmlElement item in Head)
            {
                if (item.InnerText.Contains(textoValidacao))
                {
                    result = false;
                }
            }
            return result;
        }

        public static DataTable GetBoletasDadosPN(string boleto)
        {

            string sql = string.Format("SELECT * FROM vw_IntegrarPN Where Boleto = '{0}'", boleto);

            DataTable dt = DataConnector.ExecuteDataTable(sql, "BDconsulta");
            return dt;

        }

    }
}
