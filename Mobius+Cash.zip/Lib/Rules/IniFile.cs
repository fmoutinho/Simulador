﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;
using System.Configuration;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Mobios
{
    public static class IniFile
    {
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool WritePrivateProfileString(string lpAppName,
           string lpKeyName, string lpString, string lpFileName);

        // Leitura
        public static string LerINI(string fileNameAndPath, string section, string key)
        {

            if (System.IO.File.Exists(@fileNameAndPath) == false)
                return "";
            section = "[" + section + "]";
            string[] texto = File.ReadAllLines(@fileNameAndPath);

            for (int linhas = 0; linhas < texto.Length; linhas++)
            {   
                if (texto[linhas].Trim() == section && texto.Length - 1 > linhas)  // procura a seção
                {
                    for (int i = 1; i < texto.Length; i++)                         // procura chave
                    {
                        if (texto[linhas + i].Trim().IndexOf("[") > -1)             // achou outra seção, sai fora;
                        {
                            break;                            
                        }
                        int pos = texto[linhas + i].Trim().IndexOf("=");
                        if (pos > -1)
                        {
                            if (texto[linhas + i].Trim().Substring(0, texto[linhas + i].Trim().IndexOf("=")).ToUpper() == key.ToUpper())
                                return texto[linhas + i].Trim().Substring(pos + 1, texto[linhas + i].Length - pos - 1);
                        }
                    }
                }
            }

            return string.Empty;

        }

        // Escrita
        public static bool WriteINI(string fileNameAndPath, string section, string key, string text, string userName, string evento, string QdeEventosEsperados)
        {
            bool returnValue = false;    
            text = text + "|" + userName + "|" + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + "|" + evento + "|" + QdeEventosEsperados;

            string[] retornoINI = LerINI(fileNameAndPath, section, key).Split('|');
            // Se já tem, não grava novamente.
            if (retornoINI.Count() < 2)
            {            
                WritePrivateProfileString(section, key, text, fileNameAndPath);
                returnValue = true;
            }
            else if (retornoINI[4].ToUpper() == "N")
            {
                WritePrivateProfileString(section, key, text, fileNameAndPath);
                returnValue = true;
            }

            return returnValue;
        }

        }

    }
}
