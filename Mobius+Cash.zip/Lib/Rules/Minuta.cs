﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.Interop.Excel;
using System.Data;
using System.Data.OleDb;
using System.ComponentModel;
using System.Windows.Forms;
using System.Configuration;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Office;
using System.Threading;
using System.Drawing;
using System.Xml;
using System.Globalization;

namespace Mobios
{
    public class ProcessaMinutas
    {
        #region [ Variáveis ]

        public static Microsoft.Office.Interop.Word.Application Word;
        public static string msgLog;
        public static int totalCampos;
        static double _Indice = 0;
        static int _DOC;
        public static string _NomeServico;
        public static int _IdServico;
        //public static Control _lbl;
        public static string _Arquivo;
        public static WebBrowser wAux;
        public static string _CaminhoApp;
        public static List<Campos> _CamposServico;
        public static string _QRdados;
        public static int _IdObjeto;
        public static int _IdMinuta;
        public static string _erro;
        public static NumberStyles _styleNumber;
        public static CultureInfo _culture;
        public static bool _BoolAbrirArquivo;
        
        //public static DateTimeStyles _styleDate;
        #endregion

        public static void ListaMinutas(ResponsavelServico sv, List<Campos> CamposServico, int IdMinuta, int IdDoc, string QRdados = "", bool BoolAbrirArquivo = true)
        {
            try
            {
                _BoolAbrirArquivo = BoolAbrirArquivo;
                _erro = "";
                _DOC = IdDoc;
                _NomeServico = sv.ServicoName;
                //_lbl = lbl;
                _IdServico = sv.ID_Servico;
                _CaminhoApp = SharedData.ApplicationPath;
                _CamposServico = CamposServico;
                _QRdados = QRdados;
                _IdObjeto = sv.ID_Objeto;
                _IdMinuta = IdMinuta;

                _styleNumber = NumberStyles.AllowDecimalPoint | NumberStyles.AllowThousands;
                //_culture = CultureInfo.CreateSpecificCulture("pt-BR");

                _culture = TratamentoLinguagem.BuscarLinguagem("PT-BR");

                /*_culture = new CultureInfo("pt-BR"); //pt-BR usada como base
                _culture.DateTimeFormat.ShortDatePattern = "dd/MM/yyyy";
                _culture.DateTimeFormat.ShortTimePattern = "HH:mm";
                _culture.NumberFormat.NumberDecimalDigits = 2;
                _culture.NumberFormat.NumberGroupSeparator = ".";
                _culture.NumberFormat.NumberDecimalSeparator = ",";
                 * */

                Thread t = new Thread(ExportarMinutas);
                t.SetApartmentState(ApartmentState.STA);
                t.Start();
                t.Join();
                if (_erro != "")
                {
                    throw new Exception(_erro);
                }
            }
            catch (Exception erro)
            {
                Log.GravaLog("Erro: " + erro.Message);
                //this.Close();
                throw;
            }

        }

        public static void ExportarMinutas()
        {
            try
            {
                wAux = new WebBrowser();
                List<DadosMinuta> ListaDadosMinutas = new List<DadosMinuta>();
                ListaDadosMinutas = DataAccess.BuscaDadosMinutas(_IdObjeto, _IdMinuta);

                foreach (DadosMinuta DadosMinutas in ListaDadosMinutas)
                {
                    DadosMinutas.CampoValor = "";
                    if (DadosMinutas.CampoNome != "0" && DadosMinutas.CampoNome != "" && DadosMinutas.CampoNome != null)
                    {
                        Campos camposservico = _CamposServico.Find(n => n.ID_Campo.ToString() == DadosMinutas.CampoNome);
                        if (camposservico != null)
                        {
                            DadosMinutas.CampoValor = camposservico.ValorCampo;
                        }
                    }
                    if (DadosMinutas.CampoAuxiliarNome != "0" && DadosMinutas.CampoAuxiliarNome != "" && DadosMinutas.CampoAuxiliarNome != null)
                    {
                        Campos camposservico = _CamposServico.Find(n => n.ID_Campo.ToString() == DadosMinutas.CampoAuxiliarNome);
                        if (camposservico != null)
                        {
                            DadosMinutas.CampoAuxiliarValor = camposservico.ValorCampo;
                        }
                        else
                        {
                            DadosMinutas.CampoAuxiliarValor = "";
                        }
                    }
                }
                SharedData.g_sb_processo.Clear();

                ProcessarMinuta(ListaDadosMinutas);
                Loading.StaticFormVisible(false);
                if (_erro == "")
                {
                    if (SharedData.g_sb_processo.Length == 0)
                    {
                        if (_BoolAbrirArquivo)
                            MessageBox.Show("Minuta processada com sucesso."); //\nÍndice Preenchimento: " + Math.Round(_Indice*100,2) + @"%"
                    }
                    else
                    {
                        MessageBox.Show("Minuta processada com erro.\n" + SharedData.g_sb_processo.ToString()); //\nÍndice Preenchimento: " + Math.Round(_Indice*100,2) + @"%"
                    }
                    SharedData._ArquivoSalvo_Minuta = _Arquivo;
                    if (_BoolAbrirArquivo)
                        System.Diagnostics.Process.Start(_Arquivo);
                }
                SharedData.g_sb_processo.Clear();
            }
            catch (Exception erroMinuta)
            {
                Loading.StaticFormVisible(false);
                MessageBox.Show("Erro ao processar minuta: " + erroMinuta.Message);
            }
        }

        public static void ProcessarMinuta(List<DadosMinuta> Minuta)
        {
            
            if (File.Exists(Minuta[0].Path.ToString()))
            {
                #region [ Copia Arquivo ]
                string pathDestino = _CaminhoApp + DateTime.Now.ToString("ddMMyyyyHHmmss") + Path.GetFileName(Minuta[0].Path.ToString());
                if (pathDestino.Length > 250)
                {
                    string Extension = Path.GetExtension(Minuta[0].Path.ToString());
                    int lenghtExtension = Extension.Length + 1;

                    pathDestino = pathDestino.Substring(0, 250 - lenghtExtension) + Extension;
                }

                File.Copy(Minuta[0].Path.ToString(), pathDestino, true);
                Minuta[0].Path = pathDestino;
                #endregion

                if (File.Exists(Minuta[0].Path.ToString()))
                {
                    msgLog = "Abrindo minuta";
                    Log.GravaLog(msgLog);
                    Word = new Microsoft.Office.Interop.Word.Application();
                    Word.Visible = SharedData.gHomologação;
                    abreMinuta(Minuta);

                    System.Windows.Forms.Application.DoEvents();

                    msgLog = "Finalizando Word";
                    Log.GravaLog(msgLog);
                    Word.Quit();
                    Marshal.FinalReleaseComObject(Word);
                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                }

                #region [ Deleta Arquivo Copiado ]
                if (File.Exists(Minuta[0].Path.ToString()))
                {
                    if (Path.GetDirectoryName(Minuta[0].Path.ToString()) == _CaminhoApp)
                    {
                        try
                        {
                            File.Delete(Minuta[0].Path.ToString());
                        }
                        catch { }
                    }
                }
                #endregion
            }
        }

        private static void abreMinuta(List<DadosMinuta> Minuta)
        {
            SharedData.g_sb_processo.Clear();

            #region [Try]
            try
            {
                //Tentativa de ficar mais rápido e não gravar os logs
                Boolean GravarLog = SharedData.gGravarLogAoGerarMinuta;

                #region [abreMinuta]
                //if (Minuta == "") { return; }
                msgLog = "Minuta: " + Minuta[0].Path.ToString();
                Log.GravaLog(msgLog);

                Word.Documents.Open(Minuta[0].Path.ToString());
                //Word.Documents.Open(Minuta[0].Path.ToString(), null, true);
                Word.Visible = SharedData.gHomologação;
                int TotalArrobas = ContarArrobas();

                msgLog = "Total Arrobas: " + TotalArrobas;
                if (GravarLog)
                    Log.GravaLog(msgLog);

                try
                {
                    Word.ActiveDocument.Unprotect();
                }
                catch { }
                #endregion

                #region [InsereDados]
                // ============== INSERE DADOS DO FORMULÁRIO NA MINUTA
                totalCampos = Minuta.Count();
                //SharedData.g_sb_processo.AppendLine("Total de campos encontrados: " + totalCampos);
                msgLog = "Total Campos: " + totalCampos;
                if (GravarLog)
                    Log.GravaLog(msgLog);
                Loading.EnableStaticTextBox("Processando campos " + "0/" + totalCampos);
                //_lbl.Text = "0/" + totalCampos + " Campos";


                for (int i = 0; i < totalCampos; i++)
                {

                    Loading.EnableStaticTextBox("Processando campos " + (i + 1) + "/" + totalCampos);
                    System.Data.DataTable campoTabela = new System.Data.DataTable();
                    try
                    {
                        if (Minuta[i].Funcao != "" && Minuta[i].Funcao != null)
                        {
                            #region [ Trata Valor ]
                            if (Minuta[i].CampoAuxiliarNome.Contains('['))
                            {
                                Minuta[i].CampoAuxiliarValor = Minuta[i].CampoAuxiliarNome.Replace("[", "").Replace("]", "");
                            }
                            Minuta[i].Funcao = Minuta[i].Funcao.ToString().ToLower();
                            switch (Minuta[i].Funcao)
                            {
                                case "fixo":
                                    #region [ Fixo ]
                                    Minuta[i].CampoValor = Minuta[i].ValorFuncao.ToString();
                                    break;
                                    #endregion
                                case "data":
                                    #region [ Data ]
                                    if (Minuta[i].CampoNome == "0")
                                        Minuta[i].CampoValor = ValorMinutaData(Minuta[i].ValorFuncao.ToString(), Minuta[i].Formato.ToString(), DateTime.Today);
                                    else
                                        Minuta[i].CampoValor = ValorMinutaData(Minuta[i].ValorFuncao.ToString(), Minuta[i].Formato.ToString(), Convert.ToDateTime(Minuta[i].CampoValor));
                                    break;
                                    #endregion
                                case "formatar":
                                    #region [ Formatar ]
                                    string Mask = "";
                                    if (Minuta[i].Formato.ToString().ToUpper() == "CPF/CNPJ")
                                    {
                                        if (Minuta[i].CampoValor.ToString().Length == 11)
                                        {
                                            Mask = @"000\.000\.000\-00";
                                        }
                                        else if (Minuta[i].CampoValor.ToString().Length == 14)
                                        {
                                            Mask = @"00\.000\.000\/0000\-00";
                                        }
                                        Minuta[i].CampoValor = ValorFormatado(Minuta[i].CampoValor.ToString(), Minuta[i].ValorFuncao.ToString(), Mask, Minuta[i].cdRel.ToString());
                                    }
                                    else
                                        Minuta[i].CampoValor = ValorFormatado(Minuta[i].CampoValor.ToString(), Minuta[i].ValorFuncao.ToString(), Minuta[i].Formato.ToString(), Minuta[i].cdRel.ToString());
                                    break;
                                    #endregion
                                case "soma":
                                    #region [ Soma ]
                                    int testeInt;
                                    int testeInt2;
                                    Decimal testeDec;
                                    Decimal testeDec2;

                                    switch (Minuta[i].Formato)
                                    {
                                        case "Inteiro":
                                            if (Minuta[i].ValorFuncao == "[CampoAuxiliar]")
                                            {
                                                if (int.TryParse(Minuta[i].CampoValor, out testeInt) && int.TryParse(Minuta[i].CampoAuxiliarValor, out testeInt2))
                                                {
                                                    Minuta[i].CampoValor = (Convert.ToInt32(Minuta[i].CampoValor) + Convert.ToInt32(Minuta[i].CampoAuxiliarValor)).ToString();
                                                }
                                                else
                                                {
                                                    Minuta[i].CampoValor = "";
                                                }
                                            }
                                            else
                                            {
                                                if (int.TryParse(Minuta[i].CampoValor, out testeInt) && int.TryParse(Minuta[i].ValorFuncao, out testeInt2))
                                                {
                                                    Minuta[i].CampoValor = (Convert.ToInt32(Minuta[i].CampoValor) + Convert.ToInt32(Minuta[i].ValorFuncao)).ToString();
                                                }
                                                else
                                                {
                                                    Minuta[i].CampoValor = "";
                                                }
                                            }
                                            break;
                                        case "Decimal":
                                            if (Minuta[i].ValorFuncao == "[CampoAuxiliar]")
                                            {
                                                if (decimal.TryParse(Minuta[i].CampoValor, out testeDec) && decimal.TryParse(Minuta[i].CampoAuxiliarValor, out testeDec2))
                                                {
                                                    Minuta[i].CampoValor = (Convert.ToDecimal(Minuta[i].CampoValor, _culture) + Convert.ToDecimal(Minuta[i].CampoAuxiliarValor, _culture)).ToString();
                                                }
                                                else
                                                {
                                                    Minuta[i].CampoValor = "";
                                                }
                                            }
                                            else
                                            {
                                                if (decimal.TryParse(Minuta[i].CampoValor, out testeDec) && decimal.TryParse(Minuta[i].ValorFuncao, out testeDec2))
                                                {
                                                    Minuta[i].CampoValor = (Convert.ToDecimal(Minuta[i].CampoValor, _culture) + Convert.ToDecimal(Minuta[i].ValorFuncao, _culture)).ToString();
                                                }
                                                else
                                                {
                                                    Minuta[i].CampoValor = "";
                                                }
                                            }
                                            break;
                                        case "Data":
                                            DateTime DateValue;
                                            if (Minuta[i].ValorFuncao == "[CampoAuxiliar]")
                                            {
                                                if (DateTime.TryParse(Minuta[i].CampoAuxiliarValor, out DateValue))
                                                {
                                                    Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                                }
                                                else
                                                {
                                                    TimeSpan numeroDias = new TimeSpan(Convert.ToInt32(Minuta[i].CampoAuxiliarValor), 0, 0, 0);
                                                    Minuta[i].CampoValor = (Convert.ToDateTime(Minuta[i].CampoValor) + numeroDias).ToString("dd/MM/yyyy");
                                                }
                                            }
                                            else
                                            {
                                                TimeSpan numeroDias = new TimeSpan(Convert.ToInt32(Minuta[i].ValorFuncao), 0, 0, 0);
                                                Minuta[i].CampoValor = (Convert.ToDateTime(Minuta[i].CampoValor) + numeroDias).ToString("dd/MM/yyyy");
                                            }
                                            break;
                                    }
                                    break;
                                    #endregion
                                case "extenso":
                                    #region [ Extenso ]
                                    if (Minuta[i].CampoNome == "0")
                                    {
                                        Minuta[i].CampoValor = Minuta[i].ValorFuncao;
                                    }
                                    if (Minuta[i].ValorFuncao.ToUpper() == "MOEDA")
                                    {
                                        Minuta[i].CampoValor = DataAccess.BuscarMoeda(Minuta[i].CampoValor, "TextoMoeda", Minuta[i].Formato, "Singular");
                                    }
                                    else if (Minuta[i].CampoValor.Contains(@"%"))
                                    {
                                        decimal valorDecimal = Convert.ToDecimal(Minuta[i].CampoValor.Substring(0, Minuta[i].CampoValor.IndexOf(@"%")).Trim(), _culture);
                                        string valorExtenso = Extenso.toExtenso(valorDecimal, Extenso.TipoValorExtenso.Porcentagem).ToLower();
                                        string tempoTaxa = Minuta[i].CampoValor.Substring(Minuta[i].CampoValor.IndexOf(@"%") + 1).Trim().ToLower();
                                        switch (tempoTaxa)
                                        {
                                            case "a.a.":
                                                tempoTaxa = " ao ano";
                                                break;
                                            case "aa":
                                                tempoTaxa = " ao ano";
                                                break;
                                            case "a.m.":
                                                tempoTaxa = " ao mês";
                                                break;
                                            case "am":
                                                tempoTaxa = " ao mês";
                                                break;
                                            case "a.d.":
                                                tempoTaxa = " ao dia";
                                                break;
                                            case "ad":
                                                tempoTaxa = " ao dia";
                                                break;
                                        }
                                        Minuta[i].CampoValor = valorExtenso + " " + tempoTaxa;
                                    }
                                    else
                                    {
                                        string moeda = "";

                                        if (Minuta[i].CampoAuxiliarValor != "" && Minuta[i].CampoAuxiliarValor != null)
                                        {
                                            moeda = Minuta[i].CampoAuxiliarValor;
                                        }

                                        if (moeda != "")
                                        {
                                            Minuta[i].CampoValor = ValorExtenso(Minuta[i].CampoValor.ToString(), Minuta[i].Formato.ToString(), moeda);
                                        }
                                        else
                                        {
                                            if (Minuta[i].CampoValor != "")
                                            {
                                                decimal valorDecimalInt = Convert.ToDecimal(Minuta[i].CampoValor.Trim(), _culture);
                                                string valorExtensoInt = Extenso.toExtenso(valorDecimalInt, Extenso.TipoValorExtenso.Decimal);
                                                Minuta[i].CampoValor = valorExtensoInt;
                                            }
                                            else
                                            {
                                                Minuta[i].CampoValor = "";
                                            }
                                        }
                                    }
                                    break;
                                    #endregion
                                case "édata":
                                    #region [ Édata ]
                                    DateTime testeData;

                                    string[] ValorResultadoEhData = Minuta[i].ValorFuncao.Split(';');

                                    if (DateTime.TryParse(Minuta[i].CampoValor, out testeData))
                                    {
                                        if (ValorResultadoEhData[0] == "[ValorCampo]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoValor;
                                        }
                                        else if (ValorResultadoEhData[0] == "[CampoAuxiliar]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                        }
                                        else
                                        {
                                            Minuta[i].CampoValor = ValorResultadoEhData[0];
                                        }
                                    }
                                    else
                                    {
                                        if (ValorResultadoEhData[1] == "[ValorCampo]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoValor;
                                        }
                                        else if (ValorResultadoEhData[1] == "[CampoAuxiliar]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                        }
                                        else
                                        {
                                            Minuta[i].CampoValor = ValorResultadoEhData[1];
                                        }
                                    }

                                    break;
                                    #endregion
                                case "énumero":
                                    #region [ É Numero ]
                                    int testeNumero;

                                    string[] ValorResultadoEhNumero = Minuta[i].ValorFuncao.Split(';');

                                    if (int.TryParse(Minuta[i].CampoValor, out testeNumero))
                                    {
                                        if (ValorResultadoEhNumero[0] == "[ValorCampo]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoValor;
                                        }
                                        else if (ValorResultadoEhNumero[0] == "[CampoAuxiliar]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                        }
                                        else
                                        {
                                            Minuta[i].CampoValor = ValorResultadoEhNumero[0];
                                        }
                                    }
                                    else
                                    {
                                        if (ValorResultadoEhNumero[1] == "[ValorCampo]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoValor;
                                        }
                                        else if (ValorResultadoEhNumero[1] == "[CampoAuxiliar]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                        }
                                        else
                                        {
                                            Minuta[i].CampoValor = ValorResultadoEhNumero[1];
                                        }
                                    }

                                    break;
                                    #endregion
                                case "igual":
                                    #region [ Igual ]
                                    if (Minuta[i].CampoValor.ToString() == "" || Minuta[i].CampoValor.ToString() == null)
                                        Minuta[i].CampoValor = "";

                                    if (Minuta[i].Formato.ToString() == "" || Minuta[i].Formato.ToString() == null)
                                        Minuta[i].Formato = "";
                                    else if (Minuta[i].Formato.ToString() == "[ValorCampo]")
                                        Minuta[i].Formato = Minuta[i].CampoValor;
                                    else if (Minuta[i].Formato.ToString() == "[CampoAuxiliar]")
                                        Minuta[i].Formato = Minuta[i].CampoAuxiliarValor;

                                    string[] ValorResultado = Minuta[i].ValorFuncao.Split(';');

                                    if (Minuta[i].CampoValor.ToString() == Minuta[i].Formato.ToString())
                                    {
                                        if (ValorResultado[0] == "[ValorCampo]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoValor;
                                        }
                                        else if (ValorResultado[0] == "[CampoAuxiliar]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                        }
                                        else
                                        {
                                            Minuta[i].CampoValor = ValorResultado[0];
                                        }
                                    }
                                    else
                                    {
                                        if (ValorResultado[1] == "[ValorCampo]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoValor;
                                        }
                                        else if (ValorResultado[1] == "[CampoAuxiliar]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                        }
                                        else
                                        {
                                            Minuta[i].CampoValor = ValorResultado[1];
                                        }
                                    }
                                    break;
                                    #endregion
                                case "contem":
                                    #region [ Contem ]
                                    string[] ValorResultadoContem = Minuta[i].ValorFuncao.Split(';');

                                    if (Minuta[i].CampoValor.ToString().Contains(Minuta[i].Formato.ToString()))
                                    {
                                        if (ValorResultadoContem[0] == "[ValorCampo]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoValor;
                                        }
                                        else if (ValorResultadoContem[0] == "[CampoAuxiliar]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                        }
                                        else
                                        {
                                            Minuta[i].CampoValor = ValorResultadoContem[0];
                                        }
                                    }
                                    else
                                    {
                                        if (ValorResultadoContem[1] == "[ValorCampo]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoValor;
                                        }
                                        else if (ValorResultadoContem[1] == "[CampoAuxiliar]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                        }
                                        else
                                        {
                                            Minuta[i].CampoValor = ValorResultadoContem[1];
                                        }
                                    }
                                    break;
                                    #endregion
                                case "multiplicar":
                                    #region [ Multiplicar ]
                                    if (Minuta[i].CampoValor.ToString() == "" || Minuta[i].CampoValor.ToString() == null)
                                        Minuta[i].CampoValor = "0";

                                    if (Minuta[i].CampoAuxiliarValor.ToString() == "" || Minuta[i].CampoAuxiliarValor.ToString() == null)
                                        Minuta[i].CampoAuxiliarValor = "0";

                                    if (Minuta[i].CampoAuxiliarValor.Contains(@"%"))
                                    {
                                        Minuta[i].CampoAuxiliarValor = Convert.ToDecimal(TratarNumero.ConverterDecimal(Minuta[i].CampoAuxiliarValor.Substring(0, Minuta[i].CampoAuxiliarValor.IndexOf(@"%")).Trim()), _culture).ToString();
                                    }

                                    if (Minuta[i].Formato.ToString() == "" || Minuta[i].Formato.ToString() == null)
                                    {
                                        Minuta[i].CampoValor = Convert.ToDecimal(Math.Round(Convert.ToDecimal(Minuta[i].CampoValor, _culture) * Convert.ToDecimal(Minuta[i].CampoAuxiliarValor, _culture), 2), _culture).ToString();
                                    }
                                    else
                                    {
                                        Minuta[i].CampoValor = Convert.ToDecimal(Math.Round(Convert.ToDecimal(Minuta[i].CampoValor, _culture) * Convert.ToDecimal(Minuta[i].CampoAuxiliarValor, _culture), 2), _culture).ToString();

                                        string[] ValorResultadoMultiplicar = Minuta[i].ValorFuncao.Split(';');

                                        if (Minuta[i].CampoValor.ToString() == Minuta[i].Formato.ToString())
                                        {
                                            if (ValorResultadoMultiplicar[0] == "[ValorCampo]")
                                            {
                                                Minuta[i].CampoValor = Minuta[i].CampoValor;
                                            }
                                            else if (ValorResultadoMultiplicar[0] == "[CampoAuxiliar]")
                                            {
                                                Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                            }
                                            else
                                            {
                                                Minuta[i].CampoValor = ValorResultadoMultiplicar[0];
                                            }
                                        }
                                        else
                                        {
                                            if (ValorResultadoMultiplicar[1] == "[ValorCampo]")
                                            {
                                                Minuta[i].CampoValor = Minuta[i].CampoValor;
                                            }
                                            else if (ValorResultadoMultiplicar[1] == "[CampoAuxiliar]")
                                            {
                                                Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                            }
                                            else
                                            {
                                                Minuta[i].CampoValor = ValorResultadoMultiplicar[1];
                                            }
                                        }
                                    }
                                    break;
                                    #endregion
                                case "multiplicarextenso":
                                    #region [ Multiplicar Extenso ]
                                    if (Minuta[i].CampoValor.ToString() == "" || Minuta[i].CampoValor.ToString() == null)
                                        Minuta[i].CampoValor = "0";
                                    if (Minuta[i].CampoAuxiliarValor.ToString() == "" || Minuta[i].CampoAuxiliarValor.ToString() == null)
                                        Minuta[i].CampoAuxiliarValor = "0";

                                    if (Minuta[i].CampoAuxiliarValor.Contains(@"%"))
                                    {
                                        Minuta[i].CampoAuxiliarValor = Convert.ToDecimal(TratarNumero.ConverterDecimal(Minuta[i].CampoAuxiliarValor.Substring(0, Minuta[i].CampoAuxiliarValor.IndexOf(@"%")).Trim()), _culture).ToString();
                                    }

                                    if (Minuta[i].Formato.ToString() == "" || Minuta[i].Formato.ToString() == null)
                                    {
                                        Minuta[i].CampoValor = Convert.ToDecimal(Math.Round(Convert.ToDecimal(Minuta[i].CampoValor, _culture) * Convert.ToDecimal(Minuta[i].CampoAuxiliarValor, _culture), 2), _culture).ToString();
                                    }
                                    else
                                    {
                                        Minuta[i].CampoValor = Convert.ToDecimal(Math.Round(Convert.ToDecimal(Minuta[i].CampoValor, _culture) * Convert.ToDecimal(Minuta[i].CampoAuxiliarValor, _culture), 2), _culture).ToString();

                                        string[] ValorResultadoMultiplicar = Minuta[i].ValorFuncao.Split(';');

                                        if (Convert.ToDecimal(Minuta[i].CampoValor.ToString(), _culture) == 0)
                                        {
                                            if (ValorResultadoMultiplicar[0] == "[ValorCampo]")
                                            {
                                                Minuta[i].CampoValor = Minuta[i].CampoValor;
                                            }
                                            else if (ValorResultadoMultiplicar[0] == "[CampoAuxiliar]")
                                            {
                                                Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                            }
                                            else
                                            {
                                                Minuta[i].CampoValor = ValorResultadoMultiplicar[0];
                                            }
                                        }
                                        else
                                        {
                                            if (ValorResultadoMultiplicar[1] == "[ValorCampo]")
                                            {
                                                Minuta[i].CampoValor = Minuta[i].CampoValor;
                                            }
                                            else if (ValorResultadoMultiplicar[1] == "[CampoAuxiliar]")
                                            {
                                                Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                            }
                                            else
                                            {
                                                Minuta[i].CampoValor = ValorResultadoMultiplicar[1];
                                            }
                                        }
                                    }

                                    decimal valorDecimalMultiplicarExtenso;
                                    if (decimal.TryParse(Minuta[i].CampoValor, _styleNumber, _culture, out valorDecimalMultiplicarExtenso))
                                    {
                                        int idcampobusca;
                                        string moeda;
                                        if (int.TryParse(Minuta[i].cdRel, out idcampobusca))
                                        {
                                            moeda = DataAccess.BuscarCampoObjetoValor(_IdServico, idcampobusca);
                                        }
                                        else
                                        {
                                            moeda = Minuta[i].cdRel.ToString();
                                        }


                                        Minuta[i].CampoValor = ValorExtenso(Minuta[i].CampoValor.ToString(), Minuta[i].Formato.ToString(), moeda);
                                    }

                                    break;
                                    #endregion
                                case "multiplicarporcentagem":
                                    #region [ Multiplicar Porcentagem ]
                                    if (Minuta[i].CampoValor.ToString() == "" || Minuta[i].CampoValor.ToString() == null)
                                        Minuta[i].CampoValor = "0";

                                    if (Minuta[i].CampoAuxiliarValor.ToString() == "" || Minuta[i].CampoAuxiliarValor.ToString() == null)
                                        Minuta[i].CampoAuxiliarValor = "0";

                                    if (Minuta[i].CampoAuxiliarValor.Contains(@"%"))
                                    {
                                        Minuta[i].CampoAuxiliarValor = Convert.ToDecimal(TratarNumero.ConverterDecimal(Minuta[i].CampoAuxiliarValor.Substring(0, Minuta[i].CampoAuxiliarValor.IndexOf(@"%")).Trim()), _culture).ToString();
                                    }

                                    if (Minuta[i].Formato.ToString() == "" || Minuta[i].Formato.ToString() == null)
                                    {
                                        Minuta[i].CampoValor = Convert.ToDecimal(Math.Round(Convert.ToDecimal(Minuta[i].CampoValor, _culture) * (Convert.ToDecimal(Minuta[i].CampoAuxiliarValor, _culture) / 100), 2), _culture).ToString();
                                    }
                                    else
                                    {
                                        Minuta[i].CampoValor = Convert.ToDecimal(Math.Round(Convert.ToDecimal(Minuta[i].CampoValor, _culture) * (Convert.ToDecimal(Minuta[i].CampoAuxiliarValor, _culture) / 100), 2), _culture).ToString();

                                        string[] ValorResultadoMultiplicar = Minuta[i].ValorFuncao.Split(';');

                                        if (Minuta[i].CampoValor.ToString() == Minuta[i].Formato.ToString())
                                        {
                                            if (ValorResultadoMultiplicar[0] == "[ValorCampo]")
                                            {
                                                Minuta[i].CampoValor = Minuta[i].CampoValor;
                                            }
                                            else if (ValorResultadoMultiplicar[0] == "[CampoAuxiliar]")
                                            {
                                                Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                            }
                                            else
                                            {
                                                Minuta[i].CampoValor = ValorResultadoMultiplicar[0];
                                            }
                                        }
                                        else
                                        {
                                            if (ValorResultadoMultiplicar[1] == "[ValorCampo]")
                                            {
                                                Minuta[i].CampoValor = Minuta[i].CampoValor;
                                            }
                                            else if (ValorResultadoMultiplicar[1] == "[CampoAuxiliar]")
                                            {
                                                Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                            }
                                            else
                                            {
                                                Minuta[i].CampoValor = ValorResultadoMultiplicar[1];
                                            }
                                        }
                                    }
                                    break;
                                    #endregion
                                case "multiplicarporcentagemextenso":
                                    #region [ Multiplicar Porcentagem ]
                                    if (Minuta[i].CampoValor.ToString() == "" || Minuta[i].CampoValor.ToString() == null)
                                        Minuta[i].CampoValor = "0";

                                    if (Minuta[i].CampoAuxiliarValor.ToString() == "" || Minuta[i].CampoAuxiliarValor.ToString() == null)
                                        Minuta[i].CampoAuxiliarValor = "0";

                                    if (Minuta[i].CampoAuxiliarValor.Contains(@"%"))
                                    {
                                        Minuta[i].CampoAuxiliarValor = Convert.ToDecimal(TratarNumero.ConverterDecimal(Minuta[i].CampoAuxiliarValor.Substring(0, Minuta[i].CampoAuxiliarValor.IndexOf(@"%")).Trim()), _culture).ToString();
                                    }

                                    if (Minuta[i].Formato.ToString() == "" || Minuta[i].Formato.ToString() == null)
                                    {
                                        Minuta[i].CampoValor = Convert.ToDecimal(Math.Round(Convert.ToDecimal(Minuta[i].CampoValor, _culture) * (Convert.ToDecimal(Minuta[i].CampoAuxiliarValor, _culture) / 100), 2), _culture).ToString();
                                    }
                                    else
                                    {
                                        Minuta[i].CampoValor = Convert.ToDecimal(Math.Round(Convert.ToDecimal(Minuta[i].CampoValor, _culture) * (Convert.ToDecimal(Minuta[i].CampoAuxiliarValor, _culture) / 100), 2), _culture).ToString();

                                        string[] ValorResultadoMultiplicar = Minuta[i].ValorFuncao.Split(';');

                                        if (Minuta[i].CampoValor.ToString() == Minuta[i].Formato.ToString())
                                        {
                                            if (ValorResultadoMultiplicar[0] == "[ValorCampo]")
                                            {
                                                Minuta[i].CampoValor = Minuta[i].CampoValor;
                                            }
                                            else if (ValorResultadoMultiplicar[0] == "[CampoAuxiliar]")
                                            {
                                                Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                            }
                                            else
                                            {
                                                Minuta[i].CampoValor = ValorResultadoMultiplicar[0];
                                            }
                                        }
                                        else
                                        {
                                            if (ValorResultadoMultiplicar[1] == "[ValorCampo]")
                                            {
                                                Minuta[i].CampoValor = Minuta[i].CampoValor;
                                            }
                                            else if (ValorResultadoMultiplicar[1] == "[CampoAuxiliar]")
                                            {
                                                Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                            }
                                            else
                                            {
                                                Minuta[i].CampoValor = ValorResultadoMultiplicar[1];
                                            }
                                        }
                                    }

                                    decimal valorDecimalMultiplicarPorcentagemExtenso;
                                    if (decimal.TryParse(Minuta[i].CampoValor, _styleNumber, _culture, out valorDecimalMultiplicarPorcentagemExtenso))
                                    {
                                        int idcampobusca;
                                        string moeda;
                                        if (int.TryParse(Minuta[i].cdRel, out idcampobusca))
                                        {
                                            moeda = DataAccess.BuscarCampoObjetoValor(_IdServico, idcampobusca);
                                        }
                                        else
                                        {
                                            moeda = Minuta[i].cdRel.ToString();
                                        }


                                        Minuta[i].CampoValor = ValorExtenso(Minuta[i].CampoValor.ToString(), Minuta[i].Formato.ToString(), moeda);
                                    }
                                    break;
                                    #endregion

                                case "tabela":
                                    #region [ Tabela ]

                                    if (Minuta[i].CampoAuxiliarValor == null || Minuta[i].CampoAuxiliarValor.ToString() == "")
                                        Minuta[i].CampoAuxiliarValor = "";


                                    if (Minuta[i].cdRel == null || Minuta[i].cdRel.ToString() == "")
                                        Minuta[i].cdRel = "";

                                    campoTabela = DataAccess.BuscarTabela(_IdServico, Convert.ToInt32(Minuta[i].CampoNome));
                                    break;
                                    #endregion
                                case "tabelalista":
                                    #region [ Tabela Lista ]

                                    if (Minuta[i].cdRel == null || Minuta[i].cdRel.ToString() == "")
                                        Minuta[i].cdRel = "";

                                    Minuta[i].CampoValor = DataAccess.BuscaTabelaMinuta(_IdServico, Convert.ToInt32(Minuta[i].CampoNome), Minuta[i].Formato.ToString(), "", Minuta[i].cdRel.ToString());

                                    if (Minuta[i].ValorFuncao != null && Minuta[i].ValorFuncao.ToString() != "")
                                    {
                                        //tratando a função
                                        switch (Minuta[i].ValorFuncao.ToString().ToLower())
                                        {
                                            case "moeda":
                                                Minuta[i].CampoValor = TratarNumero.ConverterMoeda2(Minuta[i].CampoValor.ToString());
                                                break;
                                            default:
                                                break;
                                        }
                                    }

                                    break;
                                    #endregion
                                case "tabelalistaextenso":
                                    #region [ Tabela Lista Extenso ]

                                    if (Minuta[i].cdRel == null || Minuta[i].cdRel.ToString() == "")
                                        Minuta[i].cdRel = "";

                                    Minuta[i].CampoValor = DataAccess.BuscaTabelaMinuta(_IdServico, Convert.ToInt32(Minuta[i].CampoNome), Minuta[i].Formato.ToString(), "", Minuta[i].cdRel.ToString());
                                    decimal vlrTabelaListaExtenso;

                                    if (decimal.TryParse(Minuta[i].CampoValor, _styleNumber, _culture, out vlrTabelaListaExtenso))
                                    {
                                        Minuta[i].CampoValor = ValorExtenso(Minuta[i].CampoValor.ToString(), Minuta[i].ValorFuncao.ToString(), "R$");
                                    }
                                    break;
                                    #endregion

                                case "tabelaqtd":
                                    #region [ Tabela Quantidade Registros ]

                                    if (Minuta[i].cdRel == null || Minuta[i].cdRel.ToString() == "")
                                        Minuta[i].cdRel = "";

                                    int qtdTabela = DataAccess.BuscaTabelaQTD(_IdServico, Convert.ToInt32(Minuta[i].CampoNome), Minuta[i].Formato.ToString(), Minuta[i].ValorFuncao.ToString(), Minuta[i].cdRel.ToString());
                                    string[] ValoresTabela = Minuta[i].ValorFuncao.ToString().Split(';');
                                    if (Minuta[i].Formato.ToString() == "0")
                                    {
                                        if (qtdTabela == 0)
                                        {
                                            if (ValoresTabela.Count() > 0)
                                            {
                                                if (ValoresTabela[0] == "[ValorCampo]")
                                                {
                                                    Minuta[i].CampoValor = qtdTabela.ToString();
                                                }
                                                else if (ValoresTabela[0] == "[CampoAuxiliar]")
                                                {
                                                    Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                                }
                                                else
                                                {
                                                    Minuta[i].CampoValor = ValoresTabela[0];
                                                }

                                            }
                                            else
                                            {
                                                Minuta[i].CampoValor = "";
                                            }
                                        }
                                        else
                                        {
                                            if (ValoresTabela.Count() > 0)
                                            {
                                                if (ValoresTabela[1] == "[ValorCampo]")
                                                {
                                                    Minuta[i].CampoValor = qtdTabela.ToString();
                                                }
                                                else if (ValoresTabela[1] == "[CampoAuxiliar]")
                                                {
                                                    Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                                }
                                                else
                                                {
                                                    Minuta[i].CampoValor = ValoresTabela[1];
                                                }
                                            }
                                            else
                                            {
                                                Minuta[i].CampoValor = "";
                                            }
                                        }
                                    }
                                    if (Minuta[i].Formato.ToString() == ">0")
                                    {
                                        if (qtdTabela > 0)
                                        {
                                            if (ValoresTabela.Count() > 0)
                                            {
                                                if (ValoresTabela[0] == "[ValorCampo]")
                                                {
                                                    Minuta[i].CampoValor = qtdTabela.ToString();
                                                }
                                                else if (ValoresTabela[0] == "[CampoAuxiliar]")
                                                {
                                                    Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                                }
                                                else
                                                {
                                                    Minuta[i].CampoValor = ValoresTabela[0];
                                                }
                                            }
                                            else
                                            {
                                                Minuta[i].CampoValor = "";
                                            }
                                        }
                                        else
                                        {
                                            if (ValoresTabela.Count() > 0)
                                            {
                                                if (ValoresTabela[1] == "[ValorCampo]")
                                                {
                                                    Minuta[i].CampoValor = qtdTabela.ToString();
                                                }
                                                else if (ValoresTabela[1] == "[CampoAuxiliar]")
                                                {
                                                    Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                                }
                                                else
                                                {
                                                    Minuta[i].CampoValor = ValoresTabela[1];
                                                }
                                            }
                                            else
                                            {
                                                Minuta[i].CampoValor = "";
                                            }
                                        }
                                    }


                                    break;
                                    #endregion
                                case "tabelaqtdExtenso":
                                    #region [ Tabela Quantidade Registros por Extenso]

                                    if (Minuta[i].cdRel == null || Minuta[i].cdRel.ToString() == "")
                                        Minuta[i].cdRel = "";

                                    int qtdTabelaExtenso = DataAccess.BuscaTabelaQTD(_IdServico, Convert.ToInt32(Minuta[i].CampoNome), Minuta[i].Formato.ToString(), Minuta[i].ValorFuncao.ToString(), Minuta[i].cdRel.ToString());

                                    if (qtdTabelaExtenso == 0)
                                    {
                                        Minuta[i].CampoValor = Minuta[i].ValorFuncao;
                                    }
                                    else
                                    {
                                        decimal valorDecimal = Convert.ToDecimal(qtdTabelaExtenso, _culture);
                                        string valorExtenso = Extenso.toExtenso(valorDecimal, Extenso.TipoValorExtenso.Decimal);
                                        Minuta[i].CampoValor = valorExtenso;
                                    }

                                    break;
                                    #endregion
                                case "boletoben":
                                    #region [ Campo BEN ]
                                    Minuta[i].CampoValor = DataAccess.BuscaValorCampoBoletoBEN(Minuta[i].CampoValor, Minuta[i].Formato.ToString(), Minuta[i].ValorFuncao.ToString());
                                    break;
                                    #endregion
                                case "maior":
                                    #region [ Maior ]
                                    if (Minuta[i].Formato == "[CampoAuxiliar]")
                                    {
                                        Minuta[i].Formato = Minuta[i].CampoAuxiliarValor;
                                    }
                                    if (Minuta[i].Formato == "" || Minuta[i].Formato == null)
                                    {
                                        Minuta[i].Formato = "0";
                                    }
                                    if (Minuta[i].CampoValor == "" || Minuta[i].CampoValor == null)
                                    {
                                        Minuta[i].Formato = "0";
                                    }

                                    string[] ValorResultadoMaior = Minuta[i].ValorFuncao.Split(';');

                                    if (Convert.ToInt32(Minuta[i].CampoValor.ToString()) > Convert.ToInt32(Minuta[i].Formato.ToString()))
                                    {
                                        if (ValorResultadoMaior[0] == "[ValorCampo]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoValor;
                                        }
                                        else if (ValorResultadoMaior[0] == "[CampoAuxiliar]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                        }
                                        else
                                        {
                                            Minuta[i].CampoValor = ValorResultadoMaior[0];
                                        }
                                    }
                                    else
                                    {
                                        if (ValorResultadoMaior[1] == "[ValorCampo]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoValor;
                                        }
                                        else if (ValorResultadoMaior[1] == "[CampoAuxiliar]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                        }
                                        else
                                        {
                                            Minuta[i].CampoValor = ValorResultadoMaior[1];
                                        }
                                    }


                                    break;
                                    #endregion
                                case "éporcentagem":
                                    #region [ É Porcentagem ]
                                    string[] ValorResultadoPorcentagem = Minuta[i].ValorFuncao.Split(';');

                                    if (Minuta[i].CampoValor.Contains(@"%"))
                                    {
                                        if (ValorResultadoPorcentagem[0] == "[ValorCampo]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoValor;
                                        }
                                        else if (ValorResultadoPorcentagem[0] == "[CampoAuxiliar]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                        }
                                        else
                                        {
                                            Minuta[i].CampoValor = ValorResultadoPorcentagem[0];
                                        }
                                    }
                                    else
                                    {
                                        if (ValorResultadoPorcentagem[1] == "[ValorCampo]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoValor;
                                        }
                                        else if (ValorResultadoPorcentagem[1] == "[CampoAuxiliar]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                        }
                                        else
                                        {
                                            Minuta[i].CampoValor = ValorResultadoPorcentagem[1];
                                        }

                                        if (Minuta[i].cdRel != "" && Minuta[i].CampoValor != null && Minuta[i].CampoValor != "")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].cdRel + " " + Minuta[i].CampoValor;
                                        }
                                    }



                                    break;
                                    #endregion
                                case "éporcentagemextenso":
                                    #region [ É Porcentagem Extenso ]
                                    string[] ValorResultadoPorcentagemExtenso = Minuta[i].ValorFuncao.Split(';');

                                    decimal valorDecimalExtenso;
                                    if (Minuta[i].CampoValor.Contains(@"%"))
                                    {
                                        if (ValorResultadoPorcentagemExtenso[0] == "[ValorCampo]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoValor;
                                        }
                                        else if (ValorResultadoPorcentagemExtenso[0] == "[CampoAuxiliar]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                        }
                                        else
                                        {
                                            Minuta[i].CampoValor = ValorResultadoPorcentagemExtenso[0];
                                        }
                                    }
                                    else
                                    {
                                        if (ValorResultadoPorcentagemExtenso[1] == "[ValorCampo]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoValor;

                                            //int numberInt;
                                            //if (int.TryParse(Minuta[i].CampoAuxiliarNome, out numberInt))
                                            //{
                                            //if (Minuta[i].CampoAuxiliarValor != "" && Minuta[i].CampoAuxiliarValor != null && Minuta[i].CampoValor != null && Minuta[i].CampoValor != "")
                                            //{
                                            //Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor + " " + Minuta[i].CampoValor;
                                            //}
                                            //}
                                            //else
                                            //{
                                            //if (Minuta[i].CampoAuxiliarNome != "" && Minuta[i].CampoAuxiliarNome != null && Minuta[i].CampoValor != null && Minuta[i].CampoValor != "")
                                            //{
                                            //Minuta[i].CampoValor = Minuta[i].CampoValor;
                                            //}
                                            //}
                                        }
                                        else if (ValorResultadoPorcentagemExtenso[1] == "[CampoAuxiliar]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                        }
                                        else
                                        {
                                            Minuta[i].CampoValor = ValorResultadoPorcentagemExtenso[1];
                                        }
                                    }

                                    if (Minuta[i].CampoValor.Contains(@"%"))
                                    {
                                        valorDecimalExtenso = Convert.ToDecimal(Minuta[i].CampoValor.Substring(0, Minuta[i].CampoValor.IndexOf(@"%")).Trim(), _culture);
                                        string valorExtenso = Extenso.toExtenso(valorDecimalExtenso, Extenso.TipoValorExtenso.Porcentagem).ToLower();
                                        string tempoTaxa = Minuta[i].CampoValor.Substring(Minuta[i].CampoValor.IndexOf(@"%") + 1).Trim();
                                        string complementoTaxa = "";

                                        if (tempoTaxa.IndexOf(" ") != -1)
                                        {
                                            complementoTaxa = " " + tempoTaxa.Substring(tempoTaxa.IndexOf(" "));
                                            tempoTaxa = tempoTaxa.Substring(0, tempoTaxa.IndexOf(" ")).Trim().ToLower();
                                        }
                                        else
                                        {
                                            tempoTaxa = tempoTaxa.ToLower();
                                        }

                                        switch (tempoTaxa)
                                        {
                                            case "a.a.":
                                                tempoTaxa = " ao ano";
                                                break;
                                            case "aa":
                                                tempoTaxa = " ao ano";
                                                break;
                                            case "a.m.":
                                                tempoTaxa = " ao mês";
                                                break;
                                            case "am":
                                                tempoTaxa = " ao mês";
                                                break;
                                            case "a.d.":
                                                tempoTaxa = " ao dia";
                                                break;
                                            case "ad":
                                                tempoTaxa = " ao dia";
                                                break;
                                        }
                                        Minuta[i].CampoValor = valorExtenso + tempoTaxa + complementoTaxa;
                                    }
                                    else
                                    {
                                        string moeda = "";

                                        if (Minuta[i].cdRel.ToString() != "")
                                        {
                                            moeda = Minuta[i].cdRel;
                                        }

                                        if (decimal.TryParse(Minuta[i].CampoValor, _styleNumber, _culture, out valorDecimalExtenso))
                                        {
                                            Minuta[i].CampoValor = ValorExtenso(Minuta[i].CampoValor.ToString(), Minuta[i].Formato.ToString(), moeda);
                                        }
                                    }

                                    break;
                                    #endregion
                                case "diferente":
                                    #region Diferente
                                    if (Minuta[i].CampoValor.ToString() == "" || Minuta[i].CampoValor.ToString() == null)
                                        Minuta[i].CampoValor = "";

                                    if (Minuta[i].Formato.ToString() == "" || Minuta[i].Formato.ToString() == null)
                                        Minuta[i].Formato = "";

                                    bool Igualou = false;
                                    string[] valoresValidar = Minuta[i].Formato.ToString().Split(';');
                                    foreach (string valorValidar in valoresValidar)
                                    {
                                        if (Minuta[i].CampoValor.ToString() == valorValidar)
                                        {
                                            Igualou = true;
                                            Minuta[i].CampoValor = "";
                                            break;
                                        }
                                    }

                                    string[] ValorResultadoDif = Minuta[i].ValorFuncao.Split(';');

                                    if (Igualou == false)
                                    {
                                        if (ValorResultadoDif[0] == "[ValorCampo]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoValor;
                                        }
                                        else if (ValorResultadoDif[0] == "[CampoAuxiliar]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                        }
                                        else
                                        {
                                            Minuta[i].CampoValor = ValorResultadoDif[0];
                                        }
                                    }
                                    else
                                    {
                                        if (ValorResultadoDif[1] == "[ValorCampo]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoValor;
                                        }
                                        else if (ValorResultadoDif[1] == "[CampoAuxiliar]")
                                        {
                                            Minuta[i].CampoValor = Minuta[i].CampoAuxiliarValor;
                                        }
                                        else
                                        {
                                            Minuta[i].CampoValor = ValorResultadoDif[1];
                                        }
                                    }

                                    break;
                                    #endregion
                                case "ptax":
                                    #region [ PTAX ]
                                    System.Data.DataTable PTAX = DataAccess.BuscarTabelaGeral(Convert.ToInt32(Minuta[i].cdRel), Minuta[i].ValorFuncao.Replace("[ValorCampo]", Minuta[i].CampoValor).Replace("[CampoAuxiliar]", Minuta[i].CampoAuxiliarValor), "PTAX");
                                    if (PTAX.Rows.Count > 0)
                                    {
                                        Decimal Valor = Convert.ToDecimal(Math.Round(Convert.ToDecimal(Minuta[i].CampoValor, _culture) * Convert.ToDecimal(PTAX.Rows[0][0], _culture), 2), _culture);
                                        Minuta[i].CampoValor = "R$ " + string.Format(_culture, "{0:N}", Valor);
                                    }
                                    else
                                    {
                                        Minuta[i].CampoValor = "";
                                    }
                                    break;
                                    #endregion
                                case "ptaxextenso":
                                    #region [ PTAX Extenso ]
                                    System.Data.DataTable PTAXextenso = DataAccess.BuscarTabelaGeral(Convert.ToInt32(Minuta[i].cdRel), Minuta[i].ValorFuncao.Replace("[ValorCampo]", Minuta[i].CampoValor).Replace("[CampoAuxiliar]", Minuta[i].CampoAuxiliarValor), "PTAX");
                                    if (PTAXextenso.Rows.Count > 0)
                                    {
                                        Minuta[i].CampoValor = Convert.ToDecimal(Math.Round(Convert.ToDecimal(Minuta[i].CampoValor, _culture) * Convert.ToDecimal(PTAXextenso.Rows[0][0], _culture), 2), _culture).ToString();
                                    }
                                    else
                                    {
                                        Minuta[i].CampoValor = "";
                                    }

                                    decimal valorDecimalMultiplicarTabelaExtensoReais;

                                    if (decimal.TryParse(Minuta[i].CampoValor, _styleNumber, _culture, out valorDecimalMultiplicarTabelaExtensoReais))
                                    {
                                        Minuta[i].CampoValor = ValorExtenso(Minuta[i].CampoValor.ToString(), Minuta[i].CampoAuxiliarValor.ToString(), "R$");
                                    }

                                    break;
                                    #endregion
                                case "ptaxoperacao":
                                    #region [ PTAX OPERACAO ]
                                    System.Data.DataTable PTAXoperacao = DataAccess.BuscarTabela(_IdServico, Convert.ToInt32(Minuta[i].cdRel), Minuta[i].ValorFuncao.Replace("[ValorCampo]", Minuta[i].CampoValor).Replace("[CampoAuxiliar]", Minuta[i].CampoAuxiliarValor), "PTAX");
                                    if (PTAXoperacao.Rows.Count > 0)
                                    {
                                        Decimal Valor = Convert.ToDecimal(Math.Round(Convert.ToDecimal(Minuta[i].CampoValor, _culture) * Convert.ToDecimal(PTAXoperacao.Rows[0][0], _culture), 2), _culture);
                                        Minuta[i].CampoValor = "R$ " + string.Format(_culture, "{0:N}", Valor);
                                    }
                                    else
                                    {
                                        Minuta[i].CampoValor = "";
                                    }
                                    break;
                                    #endregion
                                case "ptaxextensoOperacao":
                                    #region [ PTAX Extenso OPERACAO ]
                                    System.Data.DataTable PTAXextensoOperacao = DataAccess.BuscarTabela(_IdServico, Convert.ToInt32(Minuta[i].cdRel), Minuta[i].ValorFuncao.Replace("[ValorCampo]", Minuta[i].CampoValor).Replace("[CampoAuxiliar]", Minuta[i].CampoAuxiliarValor), "PTAX");
                                    if (PTAXextensoOperacao.Rows.Count > 0)
                                    {

                                        decimal valor = Convert.ToDecimal(Minuta[i].CampoValor, _culture);
                                        decimal ptax = Convert.ToDecimal(PTAXextensoOperacao.Rows[0][0], _culture);
                                        decimal ValorVezesPtax = Convert.ToDecimal(Math.Round(valor * ptax, 2), _culture);
                                        Minuta[i].CampoValor = TratarNumero.ConverterMoeda(ValorVezesPtax.ToString());
                                        //Minuta[i].CampoValor = Convert.ToDecimal(Math.Round(Convert.ToDecimal(Minuta[i].CampoValor, _culture) * Convert.ToDecimal(PTAXextensoOperacao.Rows[0][0], _culture), 2), _culture).ToString();
                                    }
                                    else
                                    {
                                        Minuta[i].CampoValor = "";
                                    }

                                    decimal valorDecimalMultiplicarTabelaExtensoReaisOperacao;

                                    if (decimal.TryParse(Minuta[i].CampoValor, _styleNumber, _culture, out valorDecimalMultiplicarTabelaExtensoReaisOperacao))
                                    {
                                        Minuta[i].CampoValor = ValorExtenso(Minuta[i].CampoValor.ToString(), Minuta[i].Formato.ToString(), "R$");
                                    }

                                    break;
                                    #endregion
                            }
                            #endregion
                        }


                        if (Minuta[i].CampoValor.ToString() != "" && Minuta[i].CampoValor.ToString() != null)
                        {

                            if (Minuta[i].TipoCampo.ToString().ToLower() == "chk")
                            {
                                msgLog = "Bookmark: " + Minuta[i].Bookmark.ToString() + " - Valor: " + Minuta[i].CampoValor.ToString();
                                if (GravarLog)
                                    Log.GravaLog(msgLog);
                                Word.ActiveDocument.FormFields[Minuta[i].Bookmark.ToString()].CheckBox.Value = getBOOL(Minuta[i].CampoValor.ToString());
                            }
                            else if (Minuta[i].TipoCampo.ToString().ToLower() == "txt")
                            {
                                string bkB = Minuta[i].Bookmark.ToString().ToUpper();

                                msgLog = "Bookmark: " + bkB + " - Valor: " + Minuta[i].CampoValor.ToString();
                                if (GravarLog)
                                    Log.GravaLog(msgLog);

                                jogaValoresCampos(Word, bkB, Minuta[i].CampoValor.ToString());
                            }
                            else if (Minuta[i].TipoCampo.ToString().ToLower() == "lista")
                            {
                                string bkB = Minuta[i].Bookmark.ToString().ToLower();
                                jogaValoresCamposLista(Word, bkB, Minuta[i].CampoValor.ToString());
                            }
                            else if (Minuta[i].TipoCampo.ToString().ToLower() == "listareplace")
                            {
                                Console.WriteLine(Minuta[i].Bookmark.ToString().ToLower());
                                Microsoft.Office.Interop.Word.Range MyRange = GetRangeWordByText(Word, Minuta[i].Bookmark.ToString().ToLower());
                                if (MyRange != null)
                                {
                                    string bkB = Minuta[i].Bookmark.ToString().ToLower();
                                    Microsoft.Office.Interop.Word.WdFieldType MyType = Microsoft.Office.Interop.Word.WdFieldType.wdFieldFormTextInput;
                                    Microsoft.Office.Interop.Word.FormField oFormfield;
                                    oFormfield = Word.ActiveDocument.FormFields.Add(MyRange, MyType);
                                    oFormfield.Name = "NameFormField" + i;
                                    oFormfield.Result = @"@NameFormField" + i + @"@";
                                    jogaValoresCamposLista(Word, "NameFormField" + i, Minuta[i].CampoValor.ToString(), true);
                                }

                            }
                            else if (Minuta[i].TipoCampo.ToString().ToLower() == "listatxt")
                            {
                                string bkB = Minuta[i].Bookmark.ToString().ToLower();
                                jogaValoresCamposLista(Word, bkB, Minuta[i].CampoValor.ToString(), true, null, Minuta[i].cdRel.ToString());
                            }
                        }
                        else
                        {

                            if (Minuta[i].TipoCampo.ToString().ToLower() == "listareplace")
                            {

                                Console.WriteLine(Minuta[i].Bookmark.ToString().ToLower());
                                Microsoft.Office.Interop.Word.Range MyRange = GetRangeWordByText(Word, Minuta[i].Bookmark.ToString().ToLower());
                                if (MyRange != null)
                                {
                                    string bkB = Minuta[i].Bookmark.ToString().ToLower();
                                    Microsoft.Office.Interop.Word.WdFieldType MyType = Microsoft.Office.Interop.Word.WdFieldType.wdFieldFormTextInput;
                                    Microsoft.Office.Interop.Word.FormField oFormfield;
                                    oFormfield = Word.ActiveDocument.FormFields.Add(MyRange, MyType);
                                    oFormfield.Name = Minuta[i].Bookmark.ToString().ToLower().Replace(@"@", "");
                                    oFormfield.Result = Minuta[i].Bookmark.ToString().ToLower();
                                    //jogaValoresCamposLista(Word, "NameFormField" + i, Minuta[i].CampoValor.ToString(), true);
                                    SharedData.g_sb_processo.AppendLine("Erro Preenchimento: Campo '" + Minuta[i].Bookmark.ToString() + "' , valor '" + Minuta[i].CampoValor.ToString() + "' Erro: Campo deixado em branco.");
                                }
                            }
                        }

                        if (Minuta[i].TipoCampo.ToString().ToLower() == "replace")
                        {
                            string bkB = Minuta[i].Bookmark.ToString().ToLower();
                            FindAndReplace(Word, bkB, Minuta[i].CampoValor.ToString());
                            SearchReplace(Word, bkB, Minuta[i].CampoValor.ToString());
                        }

                        else if (Minuta[i].TipoCampo.ToString().ToLower() == "replacetabela")
                        {

                            Microsoft.Office.Interop.Word.Range MyRange = GetRangeWordByText(Word, Minuta[i].Bookmark.ToString().ToLower());
                            if (MyRange != null)
                            {
                                string bkB = Minuta[i].Bookmark.ToString().ToLower();
                                //WRD.ActiveDocument.FormFields[CampoBase].Range.Text = Valor;
                                Microsoft.Office.Interop.Word.WdFieldType MyType = Microsoft.Office.Interop.Word.WdFieldType.wdFieldFormTextInput;
                                Microsoft.Office.Interop.Word.FormField oFormfield;
                                oFormfield = Word.ActiveDocument.FormFields.Add(MyRange, MyType);
                                oFormfield.Name = "NameFormField";
                                jogaValoresTabela(Word, "NameFormField", campoTabela, Minuta[i].Formato, Minuta[i].ValorFuncao, Minuta[i].cdRel, Minuta[i].CampoAuxiliarValor);
                            }
                        }
                        else if (Minuta[i].TipoCampo.ToString().ToLower() == "tabela")
                        {
                            string bkB = Minuta[i].Bookmark.ToString().ToLower();
                            jogaValoresTabela(Word, bkB, campoTabela, Minuta[i].Formato, Minuta[i].ValorFuncao, Minuta[i].cdRel, Minuta[i].CampoAuxiliarValor);
                        }
                        //_lbl.Text = i + 1 + "/" + totalCampos + " Campos";
                        System.Windows.Forms.Application.DoEvents();
                    }
                    catch (Exception ErroPreenchimento)
                    {
                        msgLog = "Erro Preenchimento: Campo " + Minuta[i].Bookmark.ToString() + " " + Minuta[i].CampoValor.ToString() + " " + ErroPreenchimento.Message;
                        if (GravarLog)
                            Log.GravaLog(msgLog);

                        SharedData.g_sb_processo.AppendLine("Erro Preenchimento: Campo '" + Minuta[i].Bookmark.ToString() + "' , valor '" + Minuta[i].CampoValor.ToString() + "' Erro: " + ErroPreenchimento.Message);
                    }
                }
                //_lbl.Text = "Salvando Minuta...";
                Loading.EnableStaticTextBox("Salvando Minuta...");
                System.Windows.Forms.Application.DoEvents();
                #endregion

                #region [QRcode]
                // QRCODE

                if (_QRdados != "" && _QRdados != null)
                {
                    if (Convert.ToBoolean(SharedData.gQrCode) == true)
                    {
                        msgLog = "Gerando QR Code: " + _CaminhoApp;
                        if (GravarLog)
                            Log.GravaLog(msgLog);
                        Loading.EnableStaticTextBox("Gerando QR Code");
                        //_lbl.Text = "Gerando QR Code";
                        System.Windows.Forms.Application.DoEvents();
                        bool booleanQR = QRCODE(TextoQRCode(_QRdados), _CaminhoApp + @"\QR.PNG");
                        if (!booleanQR)
                        {
                            msgLog = "Erro ao tentar gerar QRCode";
                            Log.GravaLog(msgLog);
                        }
                        Loading.EnableStaticTextBox("Inserindo QR Code");
                        //_lbl.Text = "Inserindo QR Code";
                        System.Windows.Forms.Application.DoEvents();
                        string Tamanho = SharedData.gQrCodeTamanho;
                        int Inttamanho = 60;
                        int.TryParse(Tamanho, out Inttamanho);


                        Microsoft.Office.Interop.Word.Shape Sp;
                        foreach (Microsoft.Office.Interop.Word.Section section in Word.ActiveDocument.Sections)
                        {
                            //Microsoft.Office.Interop.Word.HeaderFooter header = Word.ActiveDocument.Sections.First.Headers[Microsoft.Office.Interop.Word.WdHeaderFooterIndex.wdHeaderFooterPrimary];
                            Microsoft.Office.Interop.Word.HeaderFooter header = section.Headers[Microsoft.Office.Interop.Word.WdHeaderFooterIndex.wdHeaderFooterPrimary];



                            Sp = header.Shapes.AddPicture(_CaminhoApp + @"\QR.PNG", Type.Missing, Type.Missing, Type.Missing, Type.Missing, Inttamanho, Inttamanho, Type.Missing);


                            Sp.WrapFormat.Type = Microsoft.Office.Interop.Word.WdWrapType.wdWrapFront;
                            Sp.RelativeHorizontalPosition = Microsoft.Office.Interop.Word.WdRelativeHorizontalPosition.wdRelativeHorizontalPositionPage;
                            Sp.RelativeVerticalPosition = Microsoft.Office.Interop.Word.WdRelativeVerticalPosition.wdRelativeVerticalPositionPage;
                            Sp.Left = Word.ActiveDocument.PageSetup.PageWidth - (Word.ActiveDocument.Sections[1].PageSetup.RightMargin + Sp.Width);
                            Sp.Top = 10; //- Word.ActiveDocument.PageSetup.TopMargin;
                        }
                    }
                }
                //===========
                #endregion

                #region [ContaArrobasFim]
                int TotalBrancos = ContarArrobas();

                try
                {
                    _Indice = (TotalArrobas - TotalBrancos) / Convert.ToDouble(TotalArrobas);

                    msgLog = "Índice de Preenchimento: " + (_Indice * 100).ToString() + "%";
                    Log.GravaLog(msgLog);
                }
                catch { }
                //Log.GravaLog(LogPath, "Tirando Campos não preenchidos");
                limpaArrobas();

                //try
                //{
                //    Word.ActiveDocument.Protect(Microsoft.Office.Interop.Word.WdProtectionType.wdAllowOnlyRevisions);
                //}
                //catch { }
                #endregion

                #region [Salva Arquivo Saída]
                Minuta[0].PathSaida = TratamentoCampo.AdicionaBarraPath(Minuta[0].PathSaida);
                _Arquivo = Minuta[0].PathSaida.ToString() + DateTime.Now.ToString("yyyyMMddHHmmss") + "_" + _NomeServico + "_" + Minuta[0].NomeMinuta;
                int length = (_Arquivo).Length;
                if (length > 250)
                {
                    length = 250;
                }


                if (_DOC == 1)
                {
                    _Arquivo = (_Arquivo).Substring(0, length) + ".doc";

                    msgLog = "Gerando Minuta no formato Word";
                    Log.GravaLog(msgLog);
                    msgLog = "Salvando Word: " + _Arquivo;
                    Log.GravaLog(msgLog);
                    Word.ActiveDocument.SaveAs(_Arquivo);
                }


                if (_DOC == 2)
                {

                    _Arquivo = (_Arquivo).Substring(0, length) + ".pdf";

                    msgLog = "Gerando Minuta no formato PDF";
                    Log.GravaLog(msgLog);
                    msgLog = "Salvando PDF: " + _Arquivo;
                    Log.GravaLog(msgLog);
                    Word.ActiveDocument.SaveAs(_Arquivo, 17);
                }
                #endregion

                msgLog = "Fechando Minuta [Preenchimento: " + (_Indice * 100).ToString() + "]";
                Log.GravaLog(msgLog);
                Word.ActiveDocument.Close(false);
                //_lbl.Text = "";
            }
            #endregion
            #region [Catch]
            catch (Exception Ex)
            {
                //Log.GravaLog(LogPath, "Erro Minuta: " + Minuta);
                msgLog = "ERRO NO PROCESSO";
                Log.GravaLog(msgLog);
                msgLog = Ex.Message;
                Log.GravaLog(msgLog);
                //erro = true;
                try
                {
                    Word.ActiveDocument.Close(false);
                }
                catch { }
                //throw;
                _erro = Ex.Message;
            }
            #endregion

        }

        public static string TextoQRCode(string QRdados)
        {
            string result = "";
            string[] ArrayQR = QRdados.Split(';');
            foreach (string Info in ArrayQR)
            {
                Campos campoQR = _CamposServico.Find(n => n.ID_Campo.ToString() == Info);
                if (campoQR != null)
                {
                    if (result != "")
                    {
                        result += " \n";
                    }
                    else
                    {
                        result += RemoverAcentos(campoQR.CampoNome.ToString());
                        result += RemoverAcentos(": " + campoQR.ValorCampo.ToString());
                    }
                }
            }

            return result;
        }

        public static string RemoverAcentos(string texto)
        {
            string s = texto.Normalize(NormalizationForm.FormD);

            StringBuilder sb = new StringBuilder();

            for (int k = 0; k < s.Length; k++)
            {
                UnicodeCategory uc = CharUnicodeInfo.GetUnicodeCategory(s[k]);
                if (uc != UnicodeCategory.NonSpacingMark)
                {
                    sb.Append(s[k]);
                }
            }
            return sb.ToString();
        }
        
        public static Microsoft.Office.Interop.Word.Range GetRangeWordByText(Microsoft.Office.Interop.Word.Application doc, string findText)
        {
            Microsoft.Office.Interop.Word.Document dc = doc.Application.ActiveDocument;

            Microsoft.Office.Interop.Word.Range rng = dc.Content;

            dc.Activate();

            rng.Find.ClearFormatting();

            rng.Find.Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindContinue;

            rng.Find.Format = false;

            rng.Find.MatchCase = false;

            rng.Find.MatchWholeWord = false;

            rng.Find.MatchWildcards = false;

            rng.Find.MatchSoundsLike = false;

            rng.Find.MatchAllWordForms = false;

            rng.Find.Forward = true;

            object missing = System.Reflection.Missing.Value;

            object repl = Microsoft.Office.Interop.Word.WdReplace.wdReplaceNone;

            object Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindContinue;

            if (rng.Find.Execute(findText, missing, missing, missing, missing, missing, missing, Wrap, missing, "", repl, missing, missing, missing, missing))
            {

                //MessageBox.Show("Text found.");

            }

            else
            {

                //MessageBox.Show("Text not found.");
                return null;

            }

            rng.Select();

            return rng;
        }

        public static void SearchReplace(Microsoft.Office.Interop.Word.Application doc, string findText, string replaceWithText)
        {
            Microsoft.Office.Interop.Word.Find findObject = doc.Selection.Find;
            findObject.ClearFormatting();
            findObject.Text = findText;
            findObject.Replacement.ClearFormatting();
            findObject.Replacement.Text = replaceWithText;

            object replaceAll = Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll;
            object findTxt = findText;
            object replaceTxt = replaceWithText;
            object matchCase = false;
            object matchWholeWord = true;
            object matchWildCards = false;
            object matchSoundsLike = false;
            object matchAllWordForms = false;
            object forward = true;
            object format = false;
            object matchKashida = false;
            object matchDiacritics = false;
            object matchAlefHamza = false;
            object matchControl = false;
            object read_only = false;
            object visible = true;
            object replace = 2;
            object wrap = 1;


            findObject.Execute(
                    ref findTxt,
                    ref matchCase,
                    ref matchWholeWord,
                    ref matchWildCards,
                    ref matchSoundsLike,
                    ref matchAllWordForms,
                    ref forward,
                    ref wrap,
                    ref format,
                    ref replaceTxt,
                    ref replaceAll,
                    ref matchKashida,
                    ref matchDiacritics,
                    ref matchAlefHamza,
                    ref matchControl
                    );


        }

        public static void FindAndReplace(Microsoft.Office.Interop.Word.Application doc, string findText, string replaceWithText)
        {
            //options
            object replaceAll = Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll;


            foreach (Microsoft.Office.Interop.Word.Section section in doc.ActiveDocument.Sections)
            {
                Microsoft.Office.Interop.Word.HeadersFooters footers = section.Footers;
                //foreach (Microsoft.Office.Interop.Word.HeaderFooter footer in footers)
                //{
                Microsoft.Office.Interop.Word.Range footerRange = section.Footers[Microsoft.Office.Interop.Word.WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;

                object findTxt = findText;
                object replaceTxt = replaceWithText;
                object matchCase = false;
                object matchWholeWord = true;
                object matchWildCards = false;
                object matchSoundsLike = false;
                object matchAllWordForms = false;
                object forward = true;
                object format = false;
                object matchKashida = false;
                object matchDiacritics = false;
                object matchAlefHamza = false;
                object matchControl = false;
                object read_only = false;
                object visible = true;
                object replace = 2;
                object wrap = 1;

                footerRange.Find.Execute(ref findTxt, ref matchCase, ref matchWholeWord,
    ref matchWildCards, ref matchSoundsLike, ref matchAllWordForms, ref forward, ref wrap, ref format, ref replaceTxt, ref replace,
    ref matchKashida, ref matchDiacritics, ref matchAlefHamza, ref matchControl);

                //}
            }

        }

        public static bool QRCODE(string Texto, string Saida)
        {

            string Tamanho = SharedData.gQrCodeTamanho;

            Tamanho = Tamanho + "x" + Tamanho;

            wAux.Url = new Uri(@"http://chart.apis.google.com/chart?cht=qr&chl=" + Texto + @"&chs=" + Tamanho);
            bool result = false;


            //espera
            while (wAux.IsBusy)
                System.Windows.Forms.Application.DoEvents();

            for (int i = 0; i < 500; i++)
                if (wAux.ReadyState != System.Windows.Forms.WebBrowserReadyState.Complete)
                {
                    System.Windows.Forms.Application.DoEvents();
                    System.Threading.Thread.Sleep(100);
                }
                else
                {
                    break;
                }

            if (wAux.ReadyState != System.Windows.Forms.WebBrowserReadyState.Complete)
            {
                msgLog = "Tempo Limite alcançado com o WebBrowser para gerar QRCode - Qrcode não gerado";
                Log.GravaLog(msgLog);
                return false;
            }

            System.Windows.Forms.Application.DoEvents();
            //======================


            mshtml.IHTMLDocument2 doc = (mshtml.IHTMLDocument2)wAux.Document.DomDocument;
            mshtml.IHTMLControlRange imgRange = (mshtml.IHTMLControlRange)((mshtml.HTMLBody)doc.body).createControlRange();

            try { System.IO.File.Delete(Saida); }
            catch { }

            foreach (mshtml.IHTMLImgElement img in doc.images)
            {
                imgRange.add((mshtml.IHTMLControlElement)img);

                imgRange.execCommand("Copy", false, null);

                using (Bitmap bmp = (Bitmap)Clipboard.GetDataObject().GetData(DataFormats.Bitmap))
                {
                    string caminho = Saida;
                    bmp.Save(caminho);
                    result = true;
                }
            }

            return result;


        }

        private static void jogaValoresCampos(Microsoft.Office.Interop.Word.Application WRD, string CampoBase, string Valor, bool eLista = false, string nmCampo = "", int cdRel = 0)
        {
            WRD.ActiveDocument.FormFields[CampoBase].Range.Text = Valor;
            msgLog = "Atualizado";
            Log.GravaLog(msgLog);
        }

        private static void jogaValoresTabela(Microsoft.Office.Interop.Word.Application WRD, string CampoBase, System.Data.DataTable tabelaDados, string NomeCampos, string valorNulo = "", string NomeCamposCustom = "", string valorAuxiliar = "")
        {
            Microsoft.Office.Interop.Word.Table Tbl;

            string[] titulos = NomeCampos.Split(';');
            string[] titulosCustom = NomeCamposCustom.Split(';');
            bool usarNomesCustom = false;

            if (titulos.Count() == titulosCustom.Count())
            {
                usarNomesCustom = true;
            }

            int tabelaLinhas = tabelaDados.Rows.Count;
            if (tabelaLinhas == 0)
            {
                tabelaLinhas = 1;
            }
            //insere tabela
            if (titulos.Count() == 0)
            {
                WRD.ActiveDocument.FormFields[CampoBase].Range.Text = valorNulo;
            }
            else
            {
                Tbl = WRD.ActiveDocument.FormFields[CampoBase].Range.Tables.Add(WRD.ActiveDocument.FormFields[CampoBase].Range, tabelaLinhas + 1, titulos.Count(), null, Microsoft.Office.Interop.Word.WdAutoFitBehavior.wdAutoFitContent);

                //Tbl.AllowAutoFit = false;
                Tbl.Borders[Microsoft.Office.Interop.Word.WdBorderType.wdBorderBottom].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleSingle;
                Tbl.Borders[Microsoft.Office.Interop.Word.WdBorderType.wdBorderTop].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleSingle;
                Tbl.Borders[Microsoft.Office.Interop.Word.WdBorderType.wdBorderRight].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleSingle;
                Tbl.Borders[Microsoft.Office.Interop.Word.WdBorderType.wdBorderLeft].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleSingle;
                Tbl.Borders[Microsoft.Office.Interop.Word.WdBorderType.wdBorderHorizontal].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleSingle;
                Tbl.Borders[Microsoft.Office.Interop.Word.WdBorderType.wdBorderVertical].LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleSingle;
                Tbl.Select();
                WRD.Selection.Font.Size = 12;
                //================

                int tituloTabela = 1;
                foreach (string titulo in titulos)
                {
                    bool colunaEncontrada = false;

                    if (usarNomesCustom)
                    {
                        Tbl.Rows[1].Cells[tituloTabela].Range.Text = titulosCustom[tituloTabela - 1];
                    }
                    else
                    {
                        Tbl.Rows[1].Cells[tituloTabela].Range.Text = titulo;
                    }
                    Tbl.Rows[1].Cells[tituloTabela].Range.Font.Bold = 1;

                    string[] SubTitulo = titulo.Split('|');

                    for (int linhaTabela = 1; linhaTabela <= tabelaDados.Rows.Count; linhaTabela++)
                    {
                        string valorCampo = "";
                        foreach (string subtitulo in SubTitulo)
                        {
                            if (subtitulo == "[CampoAuxiliar]")
                            {
                                valorCampo += " " + valorAuxiliar;
                                valorCampo = valorCampo.Trim();
                                colunaEncontrada = true;
                            }
                            else
                            {
                                for (int colunaTabela = 0; colunaTabela < tabelaDados.Columns.Count; colunaTabela++)
                                {
                                    string colunaTabelaNome = tabelaDados.Columns[colunaTabela].ColumnName.Trim().Replace(@"_", "").Replace(@".", "").Replace(@"\", "");

                                    if (subtitulo == colunaTabelaNome)
                                    {
                                        valorCampo += " " + tabelaDados.Rows[linhaTabela - 1][colunaTabela].ToString();
                                        valorCampo = valorCampo.Trim();
                                        colunaEncontrada = true;
                                    }
                                }
                            }
                        }

                        if (!colunaEncontrada)
                        {
                            Tbl.Rows[linhaTabela + 1].Cells[tituloTabela].Range.Text = valorNulo;
                        }
                        else
                        {
                            if (valorCampo.Trim() == "")
                            {
                                Tbl.Rows[linhaTabela + 1].Cells[tituloTabela].Range.Text = valorNulo;
                            }
                            else
                            {
                                Tbl.Rows[linhaTabela + 1].Cells[tituloTabela].Range.Text = valorCampo;
                            }
                        }
                    }
                    tituloTabela++;
                }
            }
        }

        private static void jogaValoresCamposLista(Microsoft.Office.Interop.Word.Application WRD, string CampoBase, string Valor, bool eLista = false, string nmCampo = "", string cdRel = "")
        {
            string[] ValoresArray = Valor.Split(';');
            string valorAcumulado = "";
            int i = 1;
            foreach (string valorLista in ValoresArray)
            {
                //int totCamposX = Word.ActiveDocument.FormFields.Count;

                //for (int x = totCamposX; x >= 1; x--)
                //{

                //string bkW = WRD.ActiveDocument.FormFields[x].Range.Text.ToString().ToLower();


                //if (bkW.IndexOf((CampoBase.Substring(0,CampoBase.Length-1) + i + @"@").ToLower()) >= 0)
                //{
                if (eLista)
                {
                    if (valorAcumulado =="")
                    {
                        valorAcumulado += valorLista;
                    }
                    else
                    {
                        valorAcumulado += cdRel + valorLista;
                    }
                }
                else
                {
                    WRD.ActiveDocument.FormFields[CampoBase + i.ToString()].Range.Text = valorLista;
                    msgLog = "Atualizado";
                    Log.GravaLog(msgLog);
                }
                
                //}

                //}
                i++;
            }
            if (eLista)
            {
                WRD.ActiveDocument.FormFields[CampoBase].Range.Text = valorAcumulado;
                msgLog = "Atualizado";
                Log.GravaLog(msgLog);
            }

        }

        private static int ContarArrobas()
        {
            int Total = 0;
            for (int i = 1; i <= Word.ActiveDocument.FormFields.Count; i++)
            {
                if (Word.ActiveDocument.FormFields[i].Range.Text != null)
                {
                    if (Word.ActiveDocument.FormFields[i].Range.Text.Substring(0, 1) == "@")
                    {
                        Total++;
                    }
                }
            }
            return Total;
        }

        private static void limpaArrobas()
        {
            int total = Word.ActiveDocument.FormFields.Count;
            for (int i = total; i >= 1; i--)
            {
                if (Word.ActiveDocument.FormFields[i].Range.Text != null)
                {

                    string txt = Word.ActiveDocument.FormFields[i].Range.Text;
                    if (txt.Substring(0, 1) == "@" && txt.Substring(txt.Length - 1, 1) == "@")
                    {
                        try
                        {
                            Word.ActiveDocument.FormFields[i].Range.Select();
                            Word.Selection.TypeBackspace();//remove the field
                            Word.Selection.TypeBackspace();//remove the line
                            //Word.ActiveDocument.FormFields[i].Range.Delete();
                        }
                        catch { }

                    }
                }
            }
        }

        private static bool getBOOL(string valor)
        {

            if (valor.ToLower() == "sim" || valor.ToLower() == "s" || valor.ToLower() == "1" || valor.ToLower() == "-1" || valor.ToLower() == "true")
            {
                return true;

            }
            else
            {
                return false;
            }

        }

        private static string ValorMinutaData(string Valor, string Formato, DateTime Data)
        {
            string result;
            switch (Valor)
            {
                case "Extenso":
                    //CultureInfo culture = new CultureInfo(Formato);
                    CultureInfo culture = TratamentoLinguagem.BuscarLinguagem(Formato);
        
                    DateTimeFormatInfo dtfi = culture.DateTimeFormat;

                    int dia = Data.Day;
                    int ano = Data.Year;
                    string mes = culture.TextInfo.ToTitleCase(dtfi.GetMonthName(Data.Month));
                    //string diasemana = culture.TextInfo.ToTitleCase(dtfi.GetDayName(DateTime.Now.DayOfWeek));

                    if (Formato == "pt-BR")
                        result = dia + " de " + mes + " de " + ano;
                    else
                    {
                        if (dia.ToString().Substring(dia.ToString().Length - 1) == "1")
                            result = mes + " " + dia + ", " + ano;
                        else if (dia.ToString().Substring(dia.ToString().Length - 1) == "2")
                            result = mes + " " + dia + ", " + ano;
                        else if (dia.ToString().Substring(dia.ToString().Length - 1) == "3")
                            result = mes + " " + dia + ", " + ano;
                        else
                            result = mes + " " + dia + ", " + ano;
                    }
                    break;
                default:
                    result = Data.ToString(Formato);
                    break;
            }

            return result;
        }

        private static string ValorFormatado(string Valor, string Tipo, string Formato, string cultura)
        {

            string result = "";
            if (Tipo == "Numero")
            {
                //CultureInfo culture = CultureInfo.GetCultureInfo(cultura);
                if (Valor != null && Valor != "")
                {
                    CultureInfo culture = TratamentoLinguagem.BuscarLinguagem(cultura);
                    result = Convert.ToDecimal(Valor).ToString(Formato, culture);
                }
            }
            else if (Tipo == "Data")
            {
                if (Valor != null && Valor != "")
                {
                    DateTime date = DateTime.ParseExact(Valor, Formato, CultureInfo.InvariantCulture);
                    result = date.ToString(Formato);
                }
            }
            return result;
        }

        //Passar uma string formatada em c com o String.Format o valor máximo é 999 bilhões, não esqueça o ' ,00 '
        public static string ValorExtenso(string wvalor, string Formato, string Moeda)
        {
            string wextenso = "";

            string moeda = wvalor.IndexOf(" ") != -1 ? wvalor.Substring(0, wvalor.IndexOf(" ")).Trim() : Moeda;
            string MoedaSingular = DataAccess.BuscarMoeda(moeda, "TextoMoeda", Formato, "Singular");
            string MoedaPlural = DataAccess.BuscarMoeda(moeda, "TextoMoeda", Formato, "Plural");

            if (Formato == "pt-BR")
            {
                string[] wunidade = { "", " e um", " e dois", " e três", " e quatro", " e cinco", " e seis", " e sete", " e oito", " e nove" };
                string[] wdezes = { "", " e onze", " e doze", " e treze", " e quatorze", " e quinze", " e dezesseis", " e dezessete", " e dezoito", " e dezenove" };
                string[] wdezenas = { "", " e dez", " e vinte", " e trinta", " e quarenta", " e cinquenta", " e sessenta", " e setenta", " e oitenta", " e noventa" };
                string[] wcentenas = { "", " e cento", " e duzentos", " e trezentos", " e quatrocentos", " e quinhentos", " e seiscentos", " e setecentos", " e oitocentos", " e novecentos" };
                string[] wplural = { " bilhões", " milhões", " mil", "" };
                string[] wsingular = { " bilhão", " milhão", " mil", "" };

                string wfracao;

                wvalor = wvalor.Substring(wvalor.IndexOf(" ") != -1 ? wvalor.IndexOf(" ") : 0).Trim();
                if (wvalor.IndexOf(",") == -1)
                {
                    wvalor = wvalor + ",00";
                }
                else if (wvalor.Substring(wvalor.IndexOf(",")).Length == 2)
                {
                    wvalor = wvalor + "0";
                }
                else if (wvalor.Substring(wvalor.IndexOf(",")).Length == 1)
                {
                    wvalor = wvalor + "00";
                }

                string wnumero = wvalor.Replace(",", "").Trim();
                wnumero = wnumero.Replace(".", "").PadLeft(14, '0');
                if (Int64.Parse(wnumero.Substring(0, 12)) > 0)
                {
                    for (int i = 0; i < 4; i++)
                    {
                        wfracao = wnumero.Substring(i * 3, 3);
                        if (int.Parse(wfracao) != 0)
                        {
                            if (int.Parse(wfracao.Substring(0, 3)) == 100) wextenso += " e cem";
                            else
                            {
                                wextenso += wcentenas[int.Parse(wfracao.Substring(0, 1))];
                                if (int.Parse(wfracao.Substring(1, 2)) > 10 && int.Parse(wfracao.Substring(1, 2)) < 20) wextenso += wdezes[int.Parse(wfracao.Substring(2, 1))];
                                else
                                {
                                    wextenso += wdezenas[int.Parse(wfracao.Substring(1, 1))];
                                    wextenso += wunidade[int.Parse(wfracao.Substring(2, 1))];
                                }
                            }
                            if (int.Parse(wfracao) > 1) wextenso += wplural[i];
                            else wextenso += wsingular[i];
                        }
                    }

                    if (Int64.Parse(wnumero.Substring(0, 12)) > 1) wextenso += " " + MoedaPlural;
                    else wextenso += " " + MoedaSingular;

                    //if (moeda == "BLR")
                    //{
                    //    if (Int64.Parse(wnumero.Substring(0, 12)) > 1) wextenso += " reais";
                    //    else wextenso += " real";
                    //}
                    //else if (moeda == "USD")
                    //{
                    //    if (Int64.Parse(wnumero.Substring(0, 12)) > 1) wextenso += " dólares dos Estados Unidos da América";
                    //    else wextenso += " dólar dos Estados Unidos da América";
                    //}
                    //else if (moeda == "EUR")
                    //{
                    //    if (Int64.Parse(wnumero.Substring(0, 12)) > 1) wextenso += " euros";
                    //    else wextenso += " euro";
                    //}
                    //else
                    //{
                    //    if (Int64.Parse(wnumero.Substring(0, 12)) > 1) wextenso += " " + moeda + "s";
                    //    else wextenso += " " + moeda;
                    //}
                }
                wfracao = wnumero.Substring(12, 2);
                if (int.Parse(wfracao) > 0)
                {
                    if (int.Parse(wfracao.Substring(0, 2)) > 10 && int.Parse(wfracao.Substring(0, 2)) < 20) wextenso = wextenso + wdezes[int.Parse(wfracao.Substring(1, 1))];
                    else
                    {
                        wextenso += wdezenas[int.Parse(wfracao.Substring(0, 1))];
                        wextenso += wunidade[int.Parse(wfracao.Substring(1, 1))];
                    }

                    string CentavosSingular = DataAccess.BuscarMoeda(moeda, "TextoCentavos", Formato, "Singular");
                    string CentavosPlural = DataAccess.BuscarMoeda(moeda, "TextoCentavos", Formato, "Plural");

                    //if (moeda == "BLR")
                    //{
                    //    if (int.Parse(wfracao) > 1) wextenso += " centavos";
                    //    else wextenso += " centavo";
                    //}
                    //else if (moeda == "USD")
                    //{
                    //    if (int.Parse(wfracao) > 1) wextenso += " centavos";
                    //    else wextenso += " centavo";
                    //}
                    //else if (moeda == "EUR")
                    //{
                    //    if (int.Parse(wfracao) > 1) wextenso += " centavos";
                    //    else wextenso += " centavo";
                    //}
                    //else
                    //{
                    //    if (int.Parse(wfracao) > 1) wextenso += " [#DEFINIR CENTAVOS#]s";
                    //    else wextenso += " [#DEFINIR CENTAVOS#]";
                    //}

                    if (int.Parse(wfracao) > 1) wextenso += " " + CentavosPlural;
                    else wextenso += " " + CentavosSingular;
                }
                if (wextenso != "") wextenso = wextenso.Substring(3, 1).ToUpper() + wextenso.Substring(4);
                else wextenso = "zero" + " " + MoedaPlural;

            }
            return wextenso;
        }
    }

    public class DadosMinuta
    {
        public string NomeMinuta { get; set; }
        public string Path { get; set; }
        public string TipoCampo { get; set; }
        public string Bookmark { get; set; }
        public string ArquivoSaida { get; set; }
        public string PathSaida { get; set; }
        public string CampoNome { get; set; }
        public string CampoValor { get; set; }
        public string CampoAuxiliarNome { get; set; }
        public string CampoAuxiliarValor { get; set; }
        public string cdRel { get; set; }
        public string ValorFuncao { get; set; }
        public string Funcao { get; set; }
        public string Formato { get; set; }

        public DadosMinuta(DataRow row)
        {
            this.NomeMinuta = row["NomeMinuta"].ToString();
            this.Path = row["PathMinutas"].ToString();
            this.TipoCampo = row["TipoCampo"].ToString();
            this.Bookmark = row["Arroba"].ToString();
            this.ArquivoSaida = row["PathSaida"].ToString();
            this.PathSaida = row["PathSaida"].ToString();
            this.CampoNome = row["IdCampo"].ToString();
            //this.CampoValor = row["ValorCampo"].ToString();
            this.CampoAuxiliarNome = row["IdCampoAuxiliar"].ToString();
            //this.CampoAuxiliarValor = row["IdCampo"].ToString();
            this.cdRel = row["cdRel"].ToString();
            this.Funcao = row["Funcao"].ToString();
            this.ValorFuncao = row["Valor"].ToString();
            this.Formato = row["Formato"].ToString();
        }
    }

    public class Minuta
    {
        public int IdObjeto { get; set; }
        public string NomeMinuta { get; set; }
        public int IdMinuta { get; set; }
        public string QRdados { get; set; }
        public string CamposCriterios { get; set; }
        public string ValoresCriterios { get; set; }

        public Minuta()
        { }

        public Minuta(DataRow row)
        {
            this.IdObjeto = Convert.ToInt32(row["IdObjeto"]);
            this.NomeMinuta = row["NomeMinuta"].ToString();
            this.IdMinuta = Convert.ToInt32(row["IdMinuta"]);
            this.QRdados = row["QR_Dados"].ToString();
            this.CamposCriterios = row["CamposCriterios"].ToString();
            this.ValoresCriterios = row["ValoresCriterios"].ToString();
        }
    }

    public class MinutaDOC
    {
        public int idDOC { get; set; }
        public string nomeDOC { get; set; }

        public MinutaDOC()
        { }

        public MinutaDOC(DataRow row)
        {
            this.idDOC = Convert.ToInt32(row["IdDoc"]);
            this.nomeDOC = row["NomeDoc"].ToString();
        }
    }
}
