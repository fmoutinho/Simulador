﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;
using System.ComponentModel;
using System.Windows.Forms;
using System.Configuration;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Office;
using System.Threading;
using System.Drawing;
using System.Xml;
using System.Globalization;

namespace Mobios
{
    public class ProcessaPtax
    {
        public static DataGridView Ptax(int ID_Campo, string CampoNome, int CampoOrdem, int posicaoLinha, int posicaoColuna, int CampoWidth, int CampoHeight, bool camposativos, bool CampoHabilitado, string CampoDominio)
        {
            DataGridView tbl = new DataGridView();
            tbl.Name = CampoNome;
            tbl.Tag = CampoOrdem;
            tbl.Top = posicaoLinha;
            tbl.Left = posicaoColuna;
            tbl.Width = CampoWidth;
            if (CampoHeight == 0)
            {
                tbl.Height = 0;
            }
            else
            {
                tbl.Height = CampoHeight;
            }
            tbl.Enabled = camposativos && CampoHabilitado;
            tbl.AllowUserToDeleteRows = camposativos && CampoHabilitado;
            tbl.AllowUserToAddRows = camposativos && CampoHabilitado;
            tbl.AllowUserToOrderColumns = camposativos && CampoHabilitado;
            tbl.AllowUserToResizeColumns = camposativos && CampoHabilitado;

            string view = "";
            if (CampoDominio.IndexOf(']') != -1 && CampoDominio.IndexOf('[') == 0)
            {
                view = CampoDominio.Substring(1, CampoDominio.IndexOf(']') - 1);
            }
            else
            {
                view = null;
            }

            string[] lineValues = CampoDominio.IndexOf(']') != -1 && CampoDominio.IndexOf('[') == 0 ? CampoDominio.Substring(CampoDominio.IndexOf(']') + 1).Split(';') : CampoDominio.Split(';');
            foreach (string value in lineValues)
            {
                tbl.Columns.Add(value.Trim(), value.Trim());
            }

            tbl.Columns.Add("Linha", "Linha");
            tbl.Columns["Linha"].Visible = false;

            DataTable dt = DataAccess.BuscarTabelaGeral(Convert.ToInt32(ID_Campo), view);
            //tabela dt já vem correta da view

            for (int linha = 0; linha < dt.Rows.Count; linha++)
            {
                tbl.Rows.Add();
            }
            for (int coluna = 0; coluna < tbl.Columns.Count; coluna++)
            {
                foreach (DataColumn colunaDt in dt.Columns)
                {
                    if (tbl.Columns[coluna].Name.Trim() == colunaDt.ColumnName.Trim())
                    {
                        for (int linha = 0; linha < dt.Rows.Count; linha++)
                        {
                            tbl[coluna, linha].Value = dt.Rows[linha][colunaDt.ColumnName];
                        }
                    }
                }
            }

            return tbl;

        }
    }
}
