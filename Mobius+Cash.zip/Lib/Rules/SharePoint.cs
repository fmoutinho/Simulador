﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using MSXML2;  // Need to add a reference to C:\Windows\System32\msxml3.dll
using System.Windows.Forms;
using System.IO;
//using PIC.Entidade;
//using PIC.Negocio;
using System.Xml;
using System.Net;
using System.Data;
using System.Configuration;
using System.Xml.Linq;
using System.Globalization;
using System.Security; 

namespace Mobios
{
    public class SharePoint
    {

        // Insere lista Sharepoint via Serviço
        public static void InsertListItems(string ListName, string SharepointUrl, string Insert, string SistemaLog = "")
        {
            SPwebService.Lists listService = new SPwebService.Lists();

            listService.UseDefaultCredentials = true;

            SharepointUrl = TratamentoCampo.AdicionaBarraUrl(SharepointUrl);

            listService.Url = SharepointUrl + "_vti_bin/lists.asmx";

            System.Xml.XmlNode ndListView = listService.GetListAndView(ListName, "");
            string strListID = ndListView.ChildNodes[0].Attributes["Name"].Value;
            string strViewID = ndListView.ChildNodes[1].Attributes["Name"].Value;

            /*Create an XmlDocument object and construct a Batch element and its
            attributes. Note that an empty ViewName parameter causes the
            method to use the default view. */
            System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
            System.Xml.XmlElement batchElement = doc.CreateElement("Batch");
            batchElement.SetAttribute("OnError", "Continue");
            batchElement.SetAttribute("ListVersion", "1");
            batchElement.SetAttribute("ViewName", strViewID);

            /*Specify methods for the batch post using CAML. To update or delete, 
            specify the ID of the item, and to update or add, specify 
            the value to place in the specified column.*/
            batchElement.InnerXml = Insert;

            /*Update list items. This example uses the list GUID, which is recommended, 
            but the list display name will also work.*/
            Log.GravaLog("Atualiza SharePoint: " + SharepointUrl + " - Lista: " + ListName + " " + strListID + ". Ação: " + Insert, SistemaLog);
            listService.UpdateListItems(strListID, batchElement);
            Log.GravaLog("SharePoint Atualizado", SistemaLog);
        }

        // Grava registro SHAREPOINT
        public static void GravarRegistro(string site, string lista, string[] campos, string[] DadosOperacao, string funcao, string SistemaLog = "")
        {
            string myXMLnode = "";

            #region [ INSERT SHAREPOINT]
            if (funcao.ToUpper() == "INSERT") // Chama função de INSERT
            {
                myXMLnode = "<Method ID='1' Cmd='New'>";
                myXMLnode = myXMLnode + "<Field Name='ID'>New</Field>";
                for (int i = 0; i < DadosOperacao.Count(); i++)
                {
                    if ((DadosOperacao[i] != null) && (campos[i] != null))
                    {
                        myXMLnode = myXMLnode + "<Field Name='" + campos[i] + "'>" + DadosOperacao[i] + "</Field>";

                    }
                }
                myXMLnode = myXMLnode + "</Method>";
            }
            #endregion

            #region [ UPDATE SHAREPOINT]
            if (funcao.ToUpper() == "UPDATE") // Chama função de UPDATE
            {
                int IndexOfID = -1;
                for (int i = 0; i < campos.Count(); i++)
                {
                    if (campos[i] == "ID")
                    {
                        IndexOfID = i;
                    }

                }
                if (IndexOfID >= 0)
                {
                    myXMLnode = "<Method ID='1' Cmd='Update'>";
                    myXMLnode = myXMLnode + "<Field Name='ID'>" + DadosOperacao[IndexOfID] + "</Field>";
                    for (int i = 0; i < DadosOperacao.Count(); i++)
                    {
                        if ((DadosOperacao[i] != null) && (campos[i] != null) && (i != IndexOfID))
                        {
                            myXMLnode = myXMLnode + "<Field Name='" + campos[i] + "'>" + DadosOperacao[i] + "</Field>";

                        }
                    }
                    myXMLnode = myXMLnode + "</Method>";
                }


            }
            #endregion

            if (lista != "" && site != "" && myXMLnode != "")
            {
                InsertListItems(lista, site, myXMLnode, SistemaLog);
            }

        }

        public static XmlNode GetListItem(string ListName, string SharepointUrl, string[] CamposCriterio, string[] ValoresCriterio, string[] TipoCriterio, string[] CamposRetornar)
        {
            SPwebService.Lists listService = new SPwebService.Lists();

            listService.UseDefaultCredentials = true;

            SharepointUrl = TratamentoCampo.AdicionaBarraUrl(SharepointUrl);

            listService.Url = SharepointUrl + "_vti_bin/lists.asmx";

            System.Xml.XmlNode ndListView = listService.GetListAndView(ListName, "");
            string strListID = ndListView.ChildNodes[0].Attributes["Name"].Value;
            string strViewID = ndListView.ChildNodes[1].Attributes["Name"].Value;

            System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

            XmlNode ndQuery = doc.CreateNode(XmlNodeType.Element, "Query", "");
            XmlNode ndViewFields = doc.CreateNode(XmlNodeType.Element, "ViewFields", "");
            XmlNode ndQueryOptions = doc.CreateNode(XmlNodeType.Element, "QueryOptions", "");

            ndQueryOptions.InnerXml = "<IncludeMandatoryColumns>FALSE</IncludeMandatoryColumns>"; //+"<DateInUtc>TRUE</DateInUtc>";

            string XmlCamposRetornar = "";
            foreach (string Campo in CamposRetornar)
            {
                XmlCamposRetornar = XmlCamposRetornar + "<FieldRef Name='" + Campo + "' />";
            }
            ndViewFields.InnerXml = XmlCamposRetornar;
            int i = 0;
            //string[] TipoCriterioArray = TipoCriterio.Split(';');

            string XmlCamposCriterio = "";
            foreach (string Criterio in CamposCriterio)
            {
                if (Criterio != "")
                {
                    if (i > 0)
                    {
                        XmlCamposCriterio = "<And>" + XmlCamposCriterio;
                    }

                    #region [ Criterio formato Data ]
                    CultureInfo c = TratamentoLinguagem.BuscarLinguagem("pt-BR");
                    if (TipoCriterio[i].ToUpper() == "DATETIME")
                    {
                        TipoCriterio[i] = "DATETIME' IncludeTimeValue='TRUE";
                        ValoresCriterio[i] = Convert.ToDateTime(ValoresCriterio[i], c).ToString("yyyy-MM-ddTHH:mm:ssZ");
                    }
                    else if (TipoCriterio[i].ToUpper() == "DATE")
                    {
                        TipoCriterio[i] = "DATETIME' IncludeTimeValue='FALSE";
                        ValoresCriterio[i] = Convert.ToDateTime(ValoresCriterio[i], c).ToString("yyyy-MM-dd");
                    }
                    #endregion

                    XmlCamposCriterio = XmlCamposCriterio + "<Eq><FieldRef Name='" + CamposCriterio[i] + "'/><Value Type='" + TipoCriterio[i] + "'>" + ValoresCriterio[i] + "</Value></Eq>";
                    if (i > 0)
                    {
                        XmlCamposCriterio = XmlCamposCriterio + "</And>";
                    }
                }
                i++;
            }
            ndQuery.InnerXml = "<Where>" + XmlCamposCriterio + "</Where>";
            //ndQuery.InnerXml = "<Where><Eq><FieldRef Name='" + CamposCriterio + "'/><Value Type='" + TipoCriterio + "'>" + ValoresCriterio + "</Value></Eq></Where>";
            XmlNode result = listService.GetListItems(strListID, strViewID, ndQuery, ndViewFields, null, ndQueryOptions, null);
            return result;
        }

        #region [ Descrição numeros]
        //'Number - Description
        //'100' Continue
        //'101' Switching protocols
        //'200' OK
        //'201' Created
        //'202' Accepted
        //'203' Non-Authoritative Information
        //'204' No Content
        //'205' Reset Content
        //'206' Partial Content
        //'300' Multiple Choices
        //'301' Moved Permanently
        //'302' Found
        //'303' See Other
        //'304' Not Modified
        //'305' use Proxy
        //'307' Temporary Redirect
        //'400' Bad Request
        //'401' Unauthorized
        //'402' Payment Required
        //'403' Forbidden
        //'404' Not Found
        //'405' Method Not Allowed
        //'406' Not Acceptable
        //'407' Proxy Authentication Required
        //'408' Request Timeout
        //'409' Conflict
        //'410' Gone
        //'411' length Required
        //'412' Precondition Failed
        //'413' Request Entity Too Large
        //'414' Request-URI Too Long
        //'415' Unsupported Media Type
        //'416' Requested Not Range
        //'417' Expectation Failed
        //'500' Internal Server Error
        //'501' Not Implemented
        //'502' Bad Gateway
        //'503' Service Unavailable
        //'504' Gateway Timeout
        //'505' http Not Version
        #endregion

        public static List<string> BuscaDadosSharePoint()
        {
            #region [ Parametros ]
            List<SharePointParametrosRetorno> SPparametrosRetorno = new List<SharePointParametrosRetorno>();
            string msgLog = "Buscando Parametros para busca no Sharepoint";
            Log.GravaLog(msgLog, "_MobiosBackground");
            SPparametrosRetorno = DataAccess.BuscaParametrosSharePoint();
            List<string> IDServicos = new List<string>();
            #endregion

            foreach (SharePointParametrosRetorno Parametro in SPparametrosRetorno)
            {
                if (SharedData.UserCelulas.Where(n => n.Integradores.ToUpper().Contains(Parametro.SharePoint.ToUpper() + "=TRUE")).Count() > 0)
                {
                    if (Parametro.CamposCriteriosMobios != null && Parametro.CamposCriteriosMobios != "" && Parametro.ValoresCriteriosMobios != null && Parametro.ValoresCriteriosMobios != "")
                    {
                        #region [ Retorna serviços a buscar dados no sharepoint ]
                        string sql = "Select Distinct * From " + Parametro.TabelaMobios;
                        sql = sql + " Where ";
                        string[] CamposCriteriosMobiosArray = Parametro.CamposCriteriosMobios.Split(';');
                        string[] ValoresCriteriosMobiosArray = Parametro.ValoresCriteriosMobios.Split(';');

                        int i = 0;

                        foreach (string CampoCriterio in CamposCriteriosMobiosArray)
                        {
                            if (i > 0)
                            {
                                sql = sql + " And ";
                            }

                            if (ValoresCriteriosMobiosArray[i] == "NULL" | ValoresCriteriosMobiosArray[i] == "NOT NULL")
                            {
                                sql = sql + "[" + CampoCriterio + "] is " + ValoresCriteriosMobiosArray[i];
                            }
                            else
                            {
                                sql = sql + "[" + CampoCriterio + "] = " + ValoresCriteriosMobiosArray[i];
                            }
                            i++;
                        }
                        DataTable result = DataConnector.ExecuteDataTable(sql, "BDconsulta");
                        #endregion

                        #region [ Criterios para o Sharepoint ]
                        if (Parametro.CamposChaveSP != "")
                        {
                            if (Parametro.CamposCriterioSP != "")
                            {
                                Parametro.CamposChaveSP += ";";
                            }
                        }
                        Parametro.CamposChaveSP += Parametro.CamposCriterioSP;

                        if (Parametro.TipoChaveSP != "")
                        {
                            if (Parametro.TipoCriterioSP != "")
                            {
                                Parametro.TipoChaveSP += ";";
                            }
                        }
                        Parametro.TipoChaveSP += Parametro.TipoCriterioSP;

                        string[] CamposChaveSP = Parametro.CamposChaveSP.Split(';');
                        string[] TipoChaveSPArray = Parametro.TipoChaveSP.Split(';');
                        string[] ValorCamposChaveSP = new string[CamposChaveSP.Count()];
                        string[] ValoresCriterioSPArray = Parametro.ValoresCriterioSP.Split(';');
                        string[] ValorCamposChaveMobios = Parametro.CamposChaveMobios.Split(';');

                        string[] CampoRetornarSPArray = Parametro.CampoRetornarSP.Split(';');
                        #endregion

                        foreach (DataRow Registro in result.Rows)
                        {
                            try
                            {
                                #region [ Busca dados no Sharepoint ]
                                i = 0;
                                foreach (string Chave in ValorCamposChaveMobios)
                                {
                                    ValorCamposChaveSP[i] = Registro[ValorCamposChaveMobios[i]].ToString();
                                    i++;
                                }

                                foreach (string V in ValoresCriterioSPArray)
                                {
                                    ValorCamposChaveSP[i] = V;
                                    i++;
                                }

                                msgLog = "Buscando Dados no Sharepoint: " + Parametro.SharePointIntegracaoURL;
                                Log.GravaLog(msgLog, "_MobiosBackground");
                                XmlNode RetornoSP = SharePoint.GetListItem(Parametro.SharePointListNameGUID, Parametro.SharePointIntegracaoURL, CamposChaveSP, ValorCamposChaveSP, TipoChaveSPArray, CampoRetornarSPArray);
                                #endregion

                                foreach (System.Xml.XmlNode listItem in RetornoSP)
                                {
                                    if (listItem.Name == "rs:data")
                                    {

                                        for (int f = 0; f < listItem.ChildNodes.Count; f++)
                                        {
                                            if (listItem.ChildNodes[f].Name == "z:row")
                                            {

                                                #region [ Campo Retorno ]
                                                string ValorRetorno = "";
                                                if (Parametro.CampoRetornarSP != "")
                                                {
                                                    if (Parametro.CampoRetornarSP.ToUpper() == "MODIFIED" || Parametro.CampoRetornarSP.ToUpper() == "CREATED")
                                                    {
                                                        string campoShare = Parametro.CampoRetornarSP.Substring(0, 1).ToUpper() + Parametro.CampoRetornarSP.Substring(1, Parametro.CampoRetornarSP.Length - 1).ToLower();
                                                        ValorRetorno = listItem.ChildNodes[f].Attributes["ows_" + campoShare].Value.ToString();
                                                        ValorRetorno = Convert.ToDateTime(ValorRetorno).ToString("dd/MM/yyyy HH:mm:ss");
                                                    }
                                                    else
                                                    {
                                                        ValorRetorno = listItem.ChildNodes[f].Attributes["ows_" + Parametro.CampoRetornarSP].Value.ToString();
                                                    }
                                                }
                                                #endregion

                                                #region [ atualiza campos ]
                                                string sqlUpdate = "";
                                                if (Parametro.TipoRetorno == "UPDATE")
                                                {
                                                    #region [ Atualiza Tabela ]
                                                    sqlUpdate = "UPDATE [" + Parametro.TabelaAtualizar + "] SET [" + Parametro.CampoAtualizar + "] = '" + ValorRetorno + "'";

                                                    string[] CamposCriteriosAtualizarArray = Parametro.CamposCriteriosAtualizar.Split(';');
                                                    string[] TipoCamposCriteriosAtualizarArray = Parametro.TipoCamposCriteriosAtualizar.Split(';');

                                                    if (CamposCriteriosAtualizarArray.Count() > 0)
                                                    {
                                                        sqlUpdate = sqlUpdate + " WHERE ";
                                                        string[] ValoresCriteriosAtualizarArray = new string[CamposCriteriosAtualizarArray.Count()]; ;

                                                        i = 0;
                                                        foreach (string CampoCriterio in CamposCriteriosAtualizarArray)
                                                        {
                                                            if (i > 0)
                                                            {
                                                                sqlUpdate = sqlUpdate + " AND ";
                                                            }
                                                            ValoresCriteriosAtualizarArray[i] = Registro[CamposCriteriosAtualizarArray[i]].ToString();
                                                            //Adiciona à uma lista os ID dos Serviços que foram atualizados do Sharepoint
                                                            IDServicos.Add(Registro["ID_Servico"].ToString());

                                                            if (TipoCamposCriteriosAtualizarArray[i] == "NUMERO")
                                                            {
                                                                sqlUpdate = sqlUpdate + "[" + CamposCriteriosAtualizarArray[i] + "] = " + ValoresCriteriosAtualizarArray[i];
                                                            }
                                                            else
                                                            {
                                                                sqlUpdate = sqlUpdate + "[" + CamposCriteriosAtualizarArray[i] + "] = '" + ValoresCriteriosAtualizarArray[i] + "'";
                                                            }


                                                            i++;
                                                        }
                                                    }
                                                    #endregion
                                                }
                                                else if (Parametro.TipoRetorno == "INSERT")
                                                {
                                                    #region [ Insere em tabela ]
                                                    sqlUpdate = "INSERT INTO [" + Parametro.TabelaAtualizar + "] ( [" + Parametro.CampoAtualizar + "] ";

                                                    string[] CamposCriteriosAtualizarArray = Parametro.CamposCriteriosAtualizar.Split(';');
                                                    string[] TipoCamposCriteriosAtualizarArray = Parametro.TipoCamposCriteriosAtualizar.Split(';');
                                                    string[] ValoresCriteriosAtualizarArray = new string[CamposCriteriosAtualizarArray.Count()]; ;

                                                    if (CamposCriteriosAtualizarArray.Count() > 0)
                                                    {
                                                        foreach (string CampoCriterio in CamposCriteriosAtualizarArray)
                                                        {
                                                            sqlUpdate = sqlUpdate + ", [" + CampoCriterio + "]";
                                                        }
                                                    }
                                                    sqlUpdate = sqlUpdate + ")";
                                                    sqlUpdate = sqlUpdate + " VALUES ('" + ValorRetorno + "'";

                                                    if (CamposCriteriosAtualizarArray.Count() > 0)
                                                    {
                                                        i = 0;
                                                        foreach (string CampoCriterio in CamposCriteriosAtualizarArray)
                                                        {
                                                            ValoresCriteriosAtualizarArray[i] = Registro[CamposCriteriosAtualizarArray[i]].ToString();
                                                            //Adiciona à uma lista os ID dos Serviços que foram atualizados do Sharepoint
                                                            IDServicos.Add(Registro["ID_Servico"].ToString());
                                                            if (TipoCamposCriteriosAtualizarArray[i] == "NUMERO")
                                                            {
                                                                sqlUpdate = sqlUpdate + ", " + ValoresCriteriosAtualizarArray[i];
                                                            }
                                                            else
                                                            {
                                                                sqlUpdate = sqlUpdate + ", '" + ValoresCriteriosAtualizarArray[i] + "'";
                                                            }
                                                            i++;
                                                        }
                                                    }
                                                    sqlUpdate = sqlUpdate + ")";
                                                    #endregion
                                                }
                                                if (sqlUpdate != "")
                                                {
                                                    msgLog = "Executando o query de retorno do SharePoint " + sqlUpdate;
                                                    Log.GravaLog(msgLog, "_MobiosBackground");
                                                    DataConnector.ExecuteDataTable(sqlUpdate, "BDconsulta");
                                                }
                                                #endregion

                                                #region [ Atualiza Status ]
                                                //ATUALIZA A ETAPA NA VOLTA DO SHAREPOINT
                                                if (Parametro.EtapaStatusRetorno != 0 && Parametro.StatusRetorno != 0)
                                                {
                                                    FluxoServico flx = DataAccess.BuscarStatusFluxoServico(Convert.ToInt32(Registro["ID_Servico"]), Parametro.EtapaStatusRetorno);
                                                    if (flx != null && flx.ID_Status != Parametro.StatusRetorno)
                                                    {
                                                        ValorRetorno = listItem.ChildNodes[f].Attributes["ows_Modified"].Value.ToString();
                                                        ValorRetorno = Convert.ToDateTime(ValorRetorno).ToString("dd/MM/yyyy HH:mm:ss");

                                                        DataAccess.AtualizaStatusEtapa(Convert.ToInt32(Registro["ID_Servico"]), false, Parametro.StatusRetorno, Parametro.EtapaStatusRetorno, "_MobiosBackground", ValorRetorno);

                                                        #region [ Follow-Up ]
                                                        //GRAVA FOLLOW-UP DA VOTLA
                                                        FollowUp _FollowUp = new FollowUp();
                                                        _FollowUp.ID_Servico = Convert.ToInt32(Convert.ToInt32(Registro["ID_Servico"]));
                                                        _FollowUp.ID_Fluxo = Convert.ToInt32(Parametro.EtapaStatusRetorno);
                                                        _FollowUp.ID_Campo = 0;
                                                        _FollowUp.FollowUpEtapa = "Retornou atualização de Status do Sharepoint: " + Parametro.SharePoint;
                                                        _FollowUp.DataCriacao = DateTime.Now;                   //Opção foi usar a data que recebeu a caixa e não data/hora de envio (SentOn);
                                                        DataAccess.RegistrarFollowUpEtapaServico(_FollowUp, false);
                                                        #endregion
                                                    }
                                                }
                                                #endregion
                                            }
                                        }
                                    }
                                }
                            }
                            catch (Exception exp)
                            {
                                msgLog = "Erro na integração do Sharepoint " + exp.Message;
                                Log.GravaLog(msgLog, "_MobiosBackground");
                                continue;
                            }
                        }
                    }
                }
            }
            return IDServicos;
        }
        
        //public static List<string> BuscaDadosSharePoint2()
        //{
        //    #region [ Parametros ]
        //    List<SharePointParametrosRetorno> SPparametrosRetorno = new List<SharePointParametrosRetorno>();
        //    string msgLog = "Buscando Parâmetros para buscar no Sharepoint";
        //    Log.GravaLog(msgLog, "_MobiosBackground");
        //    SPparametrosRetorno = DataAccess.BuscaParametrosSharePoint();

        //    List<string> IDServicos = new List<string>();
        //    #endregion

        //    foreach (SharePointParametrosRetorno Parametro in SPparametrosRetorno)
        //    {
        //        #region [ Busca dados no Sharepoint ]
        //        string[] CamposCriteriosSP = Parametro.CamposCriterioSP.Split(';');
        //        string[] ValoresCriteriosSP = Parametro.ValoresCriterioSP.Split(';');
        //        string[] TipoCriteriosSP = Parametro.TipoCriterioSP.Split(';');
        //        string[] CamposRetornoSP = Parametro.CampoRetornarSP.Split(';');
        //        string[] ChaveSP = Parametro.CamposChaveSP.Split(';');

        //        msgLog = "Buscando Dados no Sharepoint: " + Parametro.SharePointIntegracaoURL;
        //        Log.GravaLog(msgLog, "_MobiosBackground");
        //        XmlNode RetornoSP = SharePoint.GetListItem(Parametro.SharePointListNameGUID, Parametro.SharePointIntegracaoURL, CamposCriteriosSP, ValoresCriteriosSP, TipoCriteriosSP, CamposRetornoSP);
        //        #endregion

        //        #region [ Valida se retornou dados ]
        //        bool retornouValores = false;
        //        foreach (System.Xml.XmlNode listItem in RetornoSP)
        //        {
        //            if (listItem.Name == "rs:data")
        //            {
        //                for (int f = 0; f < listItem.ChildNodes.Count; f++)
        //                {
        //                    if (listItem.ChildNodes[f].Name == "z:row")
        //                    {
        //                        retornouValores = true;
        //                    }
        //                }
        //            }
        //        }
        //        #endregion

        //        if (retornouValores)
        //        {
                    
        //            foreach (System.Xml.XmlNode listItem in RetornoSP)
        //            {
        //                #region [ para cada linha, busca se o serviço já existe no Mobios ]
        //                if (listItem.Name == "rs:data")
        //                {
        //                    for (int f = 0; f < listItem.ChildNodes.Count; f++)
        //                    {
        //                        if (listItem.ChildNodes[f].Name == "z:row")
        //                        {
        //                            string[] DadosRegistroServico = new string[ChaveSP.Count()];

        //                            int CampoRetorno = 0;
        //                            foreach (string CampoRetornar in ChaveSP)
        //                            {
        //                                #region [ Retorna Valor do Campo ]
        //                                string[] CampoRetornarSplit = CampoRetornar.Split('|');

        //                                string ValorRetorno = "";
        //                                foreach (string campoSplitted in CampoRetornarSplit)
        //                                {
        //                                    if (campoSplitted != "")
        //                                    {
        //                                        if (campoSplitted.ToUpper() == "MODIFIED" || campoSplitted.ToUpper() == "CREATED")
        //                                        {
        //                                            string campoShare = TratamentoCampo.PrimeiraMaiuscula(campoSplitted);
        //                                            string valorAtual = listItem.ChildNodes[f].Attributes["ows_" + campoShare].Value.ToString();
        //                                            valorAtual = valorAtual.Replace("T", "").Replace("Z", "");
        //                                            ValorRetorno += " " + Convert.ToDateTime(valorAtual).ToString("dd/MM/yyyy HH:mm:ss");
        //                                        }
        //                                        else if (campoSplitted.StartsWith(@"'") && campoSplitted.EndsWith(@"'"))
        //                                        {
        //                                            ValorRetorno += " " + campoSplitted.Replace("'", "");
        //                                        }
        //                                        else
        //                                        {
        //                                            if (listItem.ChildNodes[f].Attributes.GetNamedItem("ows_" + campoSplitted) != null)
        //                                                ValorRetorno += " " + listItem.ChildNodes[f].Attributes["ows_" + campoSplitted].Value.ToString();
        //                                        }
        //                                        ValorRetorno = ValorRetorno.Trim().ToUpper();

        //                                    }
        //                                }
        //                                #endregion

        //                                DadosRegistroServico[CampoRetorno] = ValorRetorno;

        //                                CampoRetorno++;
        //                            }

        //                            //Parametrizar busca por serviço. pode utilizar as tabelas 0125, 0126 e 0127
        //                            int IdServico = DataAccess.BuscarIDServico(DadosRegistroServico[0]);

        //                            if (IdServico != 0)
        //                            {
        //                                if (Parametro.EtapasStatusAtualizar != "" && Parametro.ValoresStatusAtualizar != "")
        //                                {
        //                                    DataAccess.BuscarFluxoServico(IdServico);
        //                                }
        //                                if (Parametro.CampoRetornarSP != "" && Parametro.CampoRetornarMobios != "")
        //                                {
        //                                    DataAccess.buscarCamposDinamicosConjunto(IdServico);
        //                                }
        //                                DataAccess.Servico
        //                            }

        //                        }
        //                    }
        //                }
        //                #endregion
        //            }
                    
        //        }
        //    }
            
        //    return IDServicos;
        //}

        public static List<string> BuscaServicosSharePoint()
        {
            #region [ Busca Parametros ]
            List<SharePointServicoRetorno> SPparametrosRetorno = new List<SharePointServicoRetorno>();
            //List<TraducaoValoresImportados> SPparametrosRetornoValores = new List<TraducaoValoresImportados>();
            string msgLog = "Buscando Parametros para abrir Serviços com dados do Sharepoint";
            Log.GravaLog(msgLog, "_MobiosBackground");
            SPparametrosRetorno = DataAccess.BuscaParametrosServicoImportados("SharePoint");
            //SPparametrosRetornoValores = DataAccess.BuscaTraducaoValoresImportados();
            List<string> IDServicos = new List<string>();
            #endregion

            foreach (SharePointServicoRetorno Parametro in SPparametrosRetorno)
            {
                if (SharedData.UserCelulas.Where(n => n.Integradores.ToUpper().Contains(Parametro.SharePoint.ToUpper() + "=TRUE")).Count() > 0)
                {
                    try
                    {
                        string[] CamposCriterioSPArray = Parametro.CamposCriterioSP.Split(';');
                        string[] ValoresCriterioSPArray = Parametro.ValoresCriterioSP.Split(';');
                        string[] TipoCriterioSPArray = Parametro.TipoCriterioSP.Split(';'); ;

                        msgLog = "Buscando Dados no Sharepoint" + Parametro.SharePoint + " | Critérios dos Filtros: " + Parametro.CamposCriterioSP + "=" + Parametro.ValoresCriterioSP;
                        Log.GravaLog(msgLog, "_MobiosBackground");

                        string StrCamposRetornar = Parametro.CampoRetornarSP;
                        StrCamposRetornar = StrCamposRetornar.Substring(StrCamposRetornar.Length - 1, 1) == ";" ? StrCamposRetornar.Substring(0, StrCamposRetornar.Length - 1) : StrCamposRetornar;
                        if (Parametro.NomeCampoOperacaoSP != "")
                            StrCamposRetornar += ";" + Parametro.NomeCampoOperacaoSP;

                        string[] CamposRetornarArray = StrCamposRetornar.Replace('|', ';').Split(';');
                        CamposRetornarArray = CamposRetornarArray.Distinct().ToArray();

                        XmlNode RetornoSP = SharePoint.GetListItem(Parametro.SharePointListNameGUID, Parametro.SharePointIntegracaoURL, CamposCriterioSPArray, ValoresCriterioSPArray, TipoCriterioSPArray, CamposRetornarArray);

                        #region [ Valida se retornou dados ]
                        bool retornouValores = false;
                        foreach (System.Xml.XmlNode listItem in RetornoSP)
                        {
                            if (listItem.Name == "rs:data")
                            {

                                for (int f = 0; f < listItem.ChildNodes.Count; f++)
                                {
                                    if (listItem.ChildNodes[f].Name == "z:row")
                                    {
                                        retornouValores = true;
                                    }
                                }
                            }
                        }
                        #endregion

                        if (retornouValores)
                        {
                            #region [ Abre Serviço ]
                            List<string> IDServicosParcial = new List<string>();
                            IDServicosParcial.AddRange(AbreServico.AbreServicos(RetornoSP, Parametro, null, "_MobiosBackground"));
                            for (int i = 0; i < IDServicosParcial.Count; i++)
                            {
                                IDServicos.Add(Parametro.SharePoint + "| ID: " + IDServicosParcial[i] + " | Critérios dos Filtros: " + Parametro.CamposCriterioSP + "=" + Parametro.ValoresCriterioSP);
                            }
                            #endregion
                        }
                    }
                    catch (Exception exp)
                    {
                        msgLog = "Erro na integração do Sharepoint " + exp.Message;
                        Log.GravaLog(msgLog, "_MobiosBackground");
                        continue;
                    }
                }
            }
            return IDServicos;
        }

        public static DataTable GetListItemService(string ListName, string SharepointUrl, List<string> ListViewFields = null, string CalmQuery = "", string StrRowLimit = "3000")
        {
            DataTable Mydt = new DataTable();
            Mydt = null;
            DataTable Mydt2 = new DataTable();
            Mydt2 = null;
            SPwebService.Lists listService = new SPwebService.Lists();
            listService.UseDefaultCredentials = true;

            SharepointUrl = TratamentoCampo.AdicionaBarraUrl(SharepointUrl);

            listService.Url = SharepointUrl + "_vti_bin/lists.asmx";

            DataTable DTCollection = new DataTable();
            DTCollection = null;

            XmlDocument xmlDoc = new System.Xml.XmlDocument();

            XmlNode ndQuery = xmlDoc.CreateNode(XmlNodeType.Element, "Query", "");
            XmlNode ndViewFields = xmlDoc.CreateNode(XmlNodeType.Element, "ViewFields", "");
            XmlNode ndQueryOptions = xmlDoc.CreateNode(XmlNodeType.Element, "QueryOptions", "");
            XmlNode positionNext = null;
            int count = 0;

            string myoption = "<IncludeMandatoryColumns>FALSE</IncludeMandatoryColumns>";//<Paging ListItemCollectionPositionNext=\"Paged=TRUE&amp;p_ID=" + 100 + "&amp;PageFirstRow=" + ((j * 100) + 1) + "\" />";
            ndQueryOptions.InnerXml = myoption;
            //"<DateInUtc>TRUE</DateInUtc>";
            if (ListViewFields != null)
            {
                string ViewInnerXml = "";
                for (int i = 0; i < ListViewFields.Count; i++)
                {
                    ViewInnerXml += "<FieldRef Name='" + ListViewFields[i] + "' />";
                }
                ndViewFields.InnerXml = ViewInnerXml;
            }


            if (CalmQuery != "")
            {
                ndQuery.InnerXml = CalmQuery;
            }
            string Order = "<OrderBy><FieldRef Name='ID' Ascending='TRUE'/></OrderBy>";
            ndQuery.InnerXml = Order + CalmQuery;

            try
            {

                while (true)
                {
                    count++;

                    Mydt = null;

                    Console.WriteLine("------------ Page " + count + " ----------------");

                    //XmlNode results = listService.GetListItems("ITNews", null, query, null, null, queryOptions, null);
                    XmlNode results = listService.GetListItems(ListName, null, ndQuery, ndViewFields, StrRowLimit, ndQueryOptions, null);
                    Console.WriteLine("Query :" + ndQuery.OuterXml + "");
                    Console.WriteLine("QueryOptions :" + ndQueryOptions.OuterXml + "");
                    //Console.WriteLine(results.OuterXml.Replace("<", "\r\n<").Replace("ows", "\r\n\tows"));
                    positionNext = results.SelectSingleNode("//@ListItemCollectionPositionNext");


                    XElement element = XElement.Parse(results.OuterXml);
                    XNamespace ns = "#RowsetSchema";
                    List<XElement> elementList = element.Descendants().Where(x => x.Name == ns + "row").ToList();
                    //DataTable table = new DataTable();//use your own table here instead of this blank table I created.
                    //XElement X0 = elementList[0];
                    DataTable table = new DataTable();
                    /*foreach (XAttribute a in X0.Attributes())
                    {
                        string tagName = a.Name.LocalName;
                        if (!table.Columns.Contains(tagName))
                        {
                            table.Columns.Add(tagName);
                        }
                    }*/


                    foreach (XElement e in elementList)
                    {
                        //Para cada linha, verifica se todas as colunas estão presentes na tebela.
                        foreach (XAttribute a in e.Attributes())
                        {
                            string tagName = a.Name.LocalName;
                            if (!table.Columns.Contains(tagName))
                            {
                                table.Columns.Add(tagName);
                            }

                        }

                        DataRow row = table.NewRow();
                        foreach (XAttribute a in e.Attributes())
                        {
                            string tagName = a.Name.LocalName;
                            row[tagName] = a.Value;
                        }
                        table.Rows.Add(row);
                    }


                    /*DataSet ds = new DataSet();

                    StringReader sr = new StringReader(results.OuterXml);

                    ds.ReadXml(sr);

                    Mydt2 = ds.Tables["row"];

                    XmlDocument xmlDoc2 = new System.Xml.XmlDocument();
                    xmlDoc2.LoadXml(results.OuterXml);

                    XmlNodeReader xmlReader = new XmlNodeReader(xmlDoc2);
                    DataSet dsreader = new DataSet();

                    dsreader.ReadXml(xmlReader);
                    Mydt = dsreader.Tables["row"];
                    */

                    if (table != null)
                    {
                        if (DTCollection == null)
                            DTCollection = table.Copy();
                        else
                            DTCollection.Merge(table);
                    }

                    if (positionNext == null)
                        break; // break if it is the last page
                    else
                        // set next page info if there is more page
                        ndQueryOptions.InnerXml = "<Paging ListItemCollectionPositionNext='" + positionNext.InnerXml + "' />";
                }

                List<string> cabecalho = new List<string>();
                if (DTCollection != null)
                {
                    StringBuilder colunas = new StringBuilder();
                    foreach (DataColumn col in DTCollection.Columns)
                    {
                        if (col.ColumnName.Substring(0, 4) == "ows_")
                        {
                            col.ColumnName = col.ColumnName.Substring(4, col.ColumnName.Length - 4);
                            cabecalho.Add(col.ColumnName);

                        }
                        colunas.AppendLine(col.ColumnName);

                    }
                    Console.WriteLine(colunas.ToString());

                    if (ListViewFields != null)
                    {
                        foreach (string item in cabecalho)
                        {
                            if (ListViewFields.Contains(item) == false && item != "_Id")
                            {
                                DTCollection.Columns.Remove(item);
                            }
                        }
                    }
                }

                return DTCollection;


            }




            /*catch (Exception ex)
            {
                MessageBox.Show("Message:\n" + ex.Message + "\nDetail:\n");
                //erro na funcao
                return DTCollection;
            }
             * */
            catch (System.Web.Services.Protocols.SoapException ex)
            {
                MessageBox.Show("Message:\n" + ex.Message + "\nDetail:\n" +
                    ex.Detail.InnerText +
                     "\nStackTrace:\n" + ex.StackTrace);
                //erro na funcao
                return DTCollection;
            }

            finally
            {

            }



        }

        public static string BuscaIDPeople(string URL, string valorCampo)
        {
            SP_PeopleService.People peopleService = new SP_PeopleService.People();
            peopleService.UseDefaultCredentials = true;
            peopleService.Url = URL + "/_vti_bin/People.asmx";

            String[] users = new String[] { valorCampo };
            SP_PeopleService.PrincipalInfo[] principleInfoUser = peopleService.ResolvePrincipals(users, SP_PeopleService.SPPrincipalType.User, true);
            if (principleInfoUser[0].IsResolved == true && principleInfoUser.Count() == 1)
            {
                String displayName = principleInfoUser[0].DisplayName;
                String UserID = principleInfoUser[0].UserInfoID.ToString();
                String UserFormat = principleInfoUser[0].UserInfoID.ToString() + ";#" + principleInfoUser[0].AccountName.ToString();
                return UserFormat;
            }
            else if (principleInfoUser.Count() > 1)
            {
                throw new Exception("/nFoi localizado mais de um retorno para " + valorCampo + "/n Insira o e-mail ou o usuário!");
            }
            else
            {
                throw new Exception("/nNão foram localizados nenhum resultado para este nome " + valorCampo + "/nInsira o e-mail ou o usuário!");
            }



        }

        public static void ExcluirAnexos(string ListName, string SharepointUrl, int IdItem, SPwebService.Lists ListService = null)
        {
            if (ListService == null)
            {
                ListService = new SPwebService.Lists();

                ListService.UseDefaultCredentials = true;

                SharepointUrl = TratamentoCampo.AdicionaBarraUrl(SharepointUrl);

                ListService.Url = SharepointUrl + "_vti_bin/lists.asmx";
            }

            System.Xml.XmlNode ndListView = ListService.GetListAndView(ListName, "");
            
            string strListID = ndListView.ChildNodes[0].Attributes["Name"].Value;
            string strViewID = ndListView.ChildNodes[1].Attributes["Name"].Value;

            XmlNode ndAttach = ListService.GetAttachmentCollection(ListName, IdItem.ToString());
            XmlNodeList ndsAttach = ndAttach.ChildNodes;

            for (int i = 0; i < ndsAttach.Count; i++)
            {
                string delUrl = ndsAttach[i].InnerText;
                ListService.DeleteAttachment(ListName, IdItem.ToString(), delUrl);
            }
        }

        public static void MoverAnexos(string ListName, string SharepointUrl, int IdItem, string PathDestino, bool overwrite = false, SPwebService.Lists ListService = null)
        {
            if (ListService == null)
            {
                ListService = new SPwebService.Lists();

                ListService.UseDefaultCredentials = true;

                SharepointUrl = TratamentoCampo.AdicionaBarraUrl(SharepointUrl);

                ListService.Url = SharepointUrl + "_vti_bin/lists.asmx";
            }

            System.Xml.XmlNode ndListView = ListService.GetListAndView(ListName, "");

            string strListID = ndListView.ChildNodes[0].Attributes["Name"].Value;
            string strViewID = ndListView.ChildNodes[1].Attributes["Name"].Value;

            XmlNode ndAttach = ListService.GetAttachmentCollection(ListName, IdItem.ToString());
            XmlNodeList ndsAttach = ndAttach.ChildNodes;

            PathDestino = TratamentoCampo.AdicionaBarraPath(PathDestino);

            Log.CriaDiretorioRede(PathDestino);

            for (int i = 0; i < ndsAttach.Count; i++)
            {
                string delUrl = ndsAttach[i].InnerText;
                
                string targetFile = Path.Combine(PathDestino, Path.GetFileName(delUrl));
                if (File.Exists(targetFile))
                {
                    if (overwrite)
                    {
                        File.Delete(targetFile);
                        File.Move(delUrl, targetFile);
                    }
                    else
                    {
                        File.Delete(delUrl);
                    }
                }
                else
                {
                    File.Move(delUrl, targetFile);
                }

            }
        }

        public static void CopiarAnexos(string ListName, string SharepointUrl, int IdItem, string PathDestino, bool overwrite = false, SPwebService.Lists ListService = null)
        {
            if (ListService == null)
            {
                ListService = new SPwebService.Lists();

                ListService.UseDefaultCredentials = true;

                SharepointUrl = TratamentoCampo.AdicionaBarraUrl(SharepointUrl);

                ListService.Url = SharepointUrl + "_vti_bin/lists.asmx";
            }

            System.Xml.XmlNode ndListView = ListService.GetListAndView(ListName, "");

            string strListID = ndListView.ChildNodes[0].Attributes["Name"].Value;
            string strViewID = ndListView.ChildNodes[1].Attributes["Name"].Value;

            XmlNode ndAttach = ListService.GetAttachmentCollection(ListName, IdItem.ToString());
            XmlNodeList ndsAttach = ndAttach.ChildNodes;

            PathDestino = TratamentoCampo.AdicionaBarraPath(PathDestino);


            Log.CriaDiretorioRede(PathDestino);
            

            for (int i = 0; i < ndsAttach.Count; i++)
            {
                string delUrl = ndsAttach[i].InnerText;

                string targetFile = Path.Combine(PathDestino, Path.GetFileName(delUrl));

                File.Copy(delUrl, targetFile, overwrite);

            }
        }

        public static void LimparLixeira(string SharepointUrl)
        {

            using (var site = new Microsoft.SharePoint.Client.ClientContext(SharepointUrl))
            {
                //site.Credentials = new Microsoft.SharePoint.Client.AppPrincipalCredential();
                Microsoft.SharePoint.Client.RecycleBinItemCollection rbiColl = site.Site.RecycleBin;

                site.Load(rbiColl);
                site.ExecuteQuery();
                site.Site.RecycleBin.DeleteAll();

                rbiColl = site.Web.RecycleBin;
                site.Load(rbiColl);
                site.ExecuteQuery();
                site.Web.RecycleBin.DeleteAll();
            }

            GC.Collect();
            GC.WaitForPendingFinalizers();
        }
    }
}
