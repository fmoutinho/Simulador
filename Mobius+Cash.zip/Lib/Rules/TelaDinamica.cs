﻿using System;
using System.Collections.Generic;
using System.Data;
using System.ComponentModel;
using System.Globalization;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Mobios
{
    public class TelaDinamica
    {
        public static List<Campos> RecuperarServico(List<Campos> listaEstrutura, int idservico)
        {
            List<DadosCampos> dataCampos = new List<DadosCampos>();
            dataCampos = DataAccess.BuscarDadosCampos(idservico);

            foreach (Campos campoServico in listaEstrutura)
            {
                List<DadosCampos> dt = dataCampos.Where(n => n.Id_Campo == campoServico.ID_Campo).ToList();
                if (dt.Count > 0)
                {
                    campoServico.ValorCampo = dt[0].ValorCampo;
                    campoServico.ValorCampoAntigo = dt[0].ValorCampo;
                }
                else
                {
                    campoServico.ValorCampo = "";
                    campoServico.ValorCampoAntigo = "";
                }
            }
            return listaEstrutura;
        }

        public static List<CamposTabela> RecuperarServico(List<CamposTabela> listaEstrutura, int idservico, bool TabelaGeral)
        {
            List<DadosCamposTabela> dataCampos = new List<DadosCamposTabela>();
            dataCampos = DataAccess.BuscarDadosCamposTabela(idservico, TabelaGeral);

            List<CamposTabela> result = new List<CamposTabela>();

            listaEstrutura = listaEstrutura.GroupBy(s => new {s.ID_Campo, s.CampoNome}).Select(g => g.First()).ToList();
            
            foreach (CamposTabela campoServico in listaEstrutura)
            {
                List<DadosCamposTabela> dt = dataCampos.Where(n => n.IdCampo == campoServico.ID_Campo && n.NomeCampo == campoServico.CampoNome).ToList();

                if (dt.Count > 0)
                {
                    foreach (DadosCamposTabela d in dt)
                    {
                        CamposTabela temp = new CamposTabela(campoServico);
                        temp.IdServico = d.IdServico;
                        temp.ValorCampo = d.ValorCampo;
                        temp.ValorCampoAntigo = d.ValorCampo;
                        temp.Linha = d.Linha;
                        result.Add(temp);
                    }
                }
                else
                {
                    CamposTabela temp = new CamposTabela(campoServico);
                    temp.IdServico = 0;
                    temp.ValorCampo = "";
                    temp.ValorCampoAntigo = "";
                    temp.Linha = 0;
                    result.Add(temp);
                }
            }
            
            return result;
        }

        public static void MontarFormulario(List<Campos> lista, Form Formulario, TabControl tbcontrol, bool camposativos, List<CamposTabela> camposTabela = null, int Height = 200, int Width = 950)
        {
            #region [ Campos Tabela ]
            if (camposTabela == null)
            {
                if ((lista != null) && (lista.Exists(n => n.CampoTipo.ToUpper() == "TABELA" || n.CampoTipo.ToUpper() == "TABELAGERAL")))
                {
                    camposTabela = new List<CamposTabela>();
                    if (SharedData.gCamposTabela != null && SharedData.gCamposTabela.Count > 0)
                    {
                        foreach (CamposTabela c in SharedData.gCamposTabela)
                        {
                            camposTabela.Add(new CamposTabela(c));
                        }
                    }

                    if (camposTabela == null || camposTabela.Count == 0)
                    {
                        if (lista.Exists(n => n.CampoTipo.ToUpper() == "TABELAGERAL"))
                        {
                            camposTabela = DataAccess.BuscarCamposTabela();
                        }
                        else
                        {
                            camposTabela = DataAccess.BuscarCamposTabela();
                        }
                    }
                }
            }
            #endregion

            int tamCampoAnt = 0;
            int linhaObj = 1;
            int posicaoLinha = 0;
            int posicaoColuna = 100;
            string tabPageAnt = "";
            int colAnterior = 0;
            string tipoCampoAnterior = "";

            tbcontrol.Height = Height;
            tbcontrol.Width = Width;
            ToolTip toolTip1 = new ToolTip();

            foreach (Campos c in lista)
            {
                bool ctrlExists = false;
                bool lblExists = false;

                TabPage tabpage;

                if (tbcontrol.TabPages.ContainsKey(c.CampoTab))
                {
                    tabpage = tbcontrol.TabPages[c.CampoTab];
                    ctrlExists = tabpage.Controls.ContainsKey(c.CampoNome);
                    lblExists = ctrlExists;
                }
                else
                {
                    tabpage = new TabPage();
                    tabpage.Name = c.CampoTab;
                    tabpage.Text = c.CampoTab;
                    tabpage.AutoScroll = true;
                    //tabpage.BackColor = System.Drawing.Color.LightGray;
                    tbcontrol.TabPages.Add(tabpage);
                }

                #region [Campo Obrigatório]
                Label lbl = null;
                if (!lblExists)
                {
                    lbl = new Label();

                    if (c.CampoObrigatorio == true)
                    {
                        lbl.Text = "*" + c.CampoLabel;
                    }
                    else
                    {
                        lbl.Text = c.CampoLabel;
                    }
                    lbl.AutoSize = true;
                    lbl.Width = c.LabelWidth;
                }
                #endregion


                if (linhaObj == c.CampoLinha && tabPageAnt.Equals(c.CampoTab))
                {
                    posicaoColuna = posicaoColuna + tamCampoAnt + c.LabelWidth + (c.CampoColuna - colAnterior - 1) * 100;
                }
                else
                {
                    posicaoColuna = c.LabelWidth * c.CampoColuna;
                }

                posicaoLinha = c.CampoLinha * 25 - 15;

                #region [ Adiciona Campos ]
                if (c.CampoTipo.ToUpper().Trim() == "TEXTBOX")
                {
                    #region [ TextBox]
                    if (!lblExists)
                    {
                        lbl.Top = posicaoLinha;
                        lbl.Left = posicaoColuna - lbl.PreferredWidth;
                    }

                    MaskedTextBox txtbox;
                    if (!ctrlExists)
                    {
                        //CultureInfo culture = CultureInfo.CreateSpecificCulture("en-US");
                        CultureInfo culture = TratamentoLinguagem.BuscarLinguagem("en-US");
                        MaskedTextProvider maskProvider = new MaskedTextProvider(".", culture);


                        txtbox = new MaskedTextBox(maskProvider);
                        txtbox.Mask = "";
                        txtbox.Name = c.CampoNome;
                        txtbox.Tag = c.CampoOrdem;
                        txtbox.Text = c.ValorCampo;
                        txtbox.Top = posicaoLinha;
                        txtbox.Left = posicaoColuna;
                        txtbox.Width = c.CampoWidth;
                        txtbox.Enabled = camposativos && c.CampoHabilitado;
                        txtbox.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;
                    }
                    else
                    {
                        txtbox = null;
                        try
                        {
                            txtbox = (MaskedTextBox)tabpage.Controls[c.CampoNome];
                            txtbox.Enabled = camposativos && c.CampoHabilitado;
                            txtbox.Text = c.ValorCampo;
                        }
                        catch
                        { }
                    }
                    
                    

                    if (c.CampoDominio.ToUpper().Trim() == "NUMERICO")
                    {
                        #region [Numérico]
                        //MaskedTextBox t = new MaskedTextBox();
                        //t.Mask = "#,#00.00 %";
                        //t.RightToLeft = RightToLeft.Yes;
                        if (!ctrlExists)
                        {
                            NumericTextBox numtxtbox = new NumericTextBox();
                            numtxtbox.Name = c.CampoNome;
                            numtxtbox.Tag = c.CampoOrdem;
                            numtxtbox.Top = posicaoLinha;
                            numtxtbox.Left = posicaoColuna;
                            numtxtbox.Width = c.CampoWidth;
                            numtxtbox.Enabled = camposativos && c.CampoHabilitado;
                            numtxtbox.Text = c.ValorCampo;
                            tabpage.Controls.Add(numtxtbox);

                            if (c.ToolTip != null && c.ToolTip != "")
                                toolTip1.SetToolTip(numtxtbox, c.ToolTip);
                        }
                        else
                        {
                            NumericTextBox numtxtbox = (NumericTextBox)tabpage.Controls[c.CampoNome];
                            numtxtbox.Text = c.ValorCampo;
                            numtxtbox.Enabled = camposativos && c.CampoHabilitado;
                        }
                        #endregion
                    }
                    else if (c.CampoDominio.ToUpper().Trim() == "NUMERICO_CC")
                    {
                        #region [Numérico Conta Corrente]
                        if (!ctrlExists)
                        {
                            MaskedTextBox t_CC = new MaskedTextBox();
                            t_CC.Mask = "00000";
                            t_CC.Name = c.CampoNome;
                            t_CC.Tag = c.CampoOrdem;
                            t_CC.Top = posicaoLinha;
                            t_CC.Left = posicaoColuna;
                            t_CC.Width = c.CampoWidth;
                            t_CC.Enabled = camposativos && c.CampoHabilitado;
                            t_CC.Text = c.ValorCampo;
                            t_CC.MaxLength = 5;
                            tabpage.Controls.Add(t_CC);

                            if (c.ToolTip != null && c.ToolTip != "")
                                toolTip1.SetToolTip(t_CC, c.ToolTip);
                        }
                        else
                        {
                            txtbox.Text = c.ValorCampo;
                        }
                        #endregion
                    }
                    else if (c.CampoDominio.ToUpper().Trim() == "NUMERICO_AG")
                    {
                        #region [Numérico Agência]
                        if (!ctrlExists)
                        {
                            MaskedTextBox t_AG = new MaskedTextBox();
                            t_AG.Mask = "0000";
                            t_AG.Name = c.CampoNome;
                            t_AG.Tag = c.CampoOrdem;
                            t_AG.Top = posicaoLinha;
                            t_AG.Left = posicaoColuna;
                            t_AG.Width = c.CampoWidth;
                            t_AG.Enabled = camposativos && c.CampoHabilitado;
                            t_AG.Text = c.ValorCampo;
                            t_AG.MaxLength = 4;
                            tabpage.Controls.Add(t_AG);

                            if (c.ToolTip != null && c.ToolTip != "")
                                toolTip1.SetToolTip(t_AG, c.ToolTip);
                        }
                        else
                        {
                            txtbox.Text = c.ValorCampo;
                        }
                        #endregion
                    }
                    else if (c.CampoDominio.ToUpper().Trim() == "NUMERICO_DAC")
                    {
                        #region [Numérico DAC]
                        if (!ctrlExists)
                        {
                            MaskedTextBox t_DAC = new MaskedTextBox();
                            t_DAC.Mask = "0";
                            t_DAC.Name = c.CampoNome;
                            t_DAC.Tag = c.CampoOrdem;
                            t_DAC.Top = posicaoLinha;
                            t_DAC.Left = posicaoColuna;
                            t_DAC.Width = c.CampoWidth;
                            t_DAC.Enabled = camposativos && c.CampoHabilitado;
                            t_DAC.Text = c.ValorCampo;
                            t_DAC.MaxLength = 1;
                            tabpage.Controls.Add(t_DAC);

                            if (c.ToolTip != null && c.ToolTip != "")
                                toolTip1.SetToolTip(t_DAC, c.ToolTip);
                        }
                        else
                        {
                            txtbox.Text = c.ValorCampo;
                        }
                        #endregion
                    }
                    else if (c.CampoDominio.ToUpper().Trim() == "NUMERICO_CC_DAC")
                    {
                        #region [Numérico Conta+DAC]
                        if (!ctrlExists)
                        {
                            MaskedTextBox t_DAC = new MaskedTextBox();
                            t_DAC.Mask = "00000-0";
                            t_DAC.Name = c.CampoNome;
                            t_DAC.Tag = c.CampoOrdem;
                            t_DAC.Top = posicaoLinha;
                            t_DAC.Left = posicaoColuna;
                            t_DAC.Width = c.CampoWidth;
                            t_DAC.Enabled = camposativos && c.CampoHabilitado;
                            t_DAC.Text = c.ValorCampo;
                            t_DAC.MaxLength = 1;
                            tabpage.Controls.Add(t_DAC);

                            if (c.ToolTip != null && c.ToolTip != "")
                                toolTip1.SetToolTip(t_DAC, c.ToolTip);
                        }
                        else
                        {
                            txtbox.Text = c.ValorCampo;
                        }
                        #endregion
                    }
                    else if (c.CampoDominio.ToUpper().Trim() == "DATA")
                    {
                        #region [Data]
                        if (!ctrlExists)
                        {
                            txtbox.Mask = "00/00/0000";
                            txtbox.ValidatingType = typeof(System.DateTime);

                            tabpage.Controls.Add(txtbox);

                            if (c.ToolTip != null && c.ToolTip != "")
                                toolTip1.SetToolTip(txtbox, c.ToolTip);
                        }
                        #endregion
                    }
                    else if (c.CampoDominio.ToUpper().Trim() == "DATAHORA")
                    {
                        #region [Data + Hora]
                        if (!ctrlExists)
                        {
                            txtbox.Mask = "00/00/0000 00:00:00";
                            txtbox.ValidatingType = typeof(System.DateTime);

                            tabpage.Controls.Add(txtbox);

                            if (c.ToolTip != null && c.ToolTip != "")
                                toolTip1.SetToolTip(txtbox, c.ToolTip);
                        }
                        #endregion
                    }
                    else if (c.CampoDominio.ToUpper().Trim() == "DATAHOJE" || c.CampoDominio.ToUpper().Trim() == "DATAPASSADA" || c.CampoDominio.ToUpper().Trim() == "DATAFUTURA")
                    {
                        #region [ Data Hoje ]
                        if (!ctrlExists)
                        {
                            txtbox.Mask = "00/00/0000";
                            txtbox.ValidatingType = typeof(System.DateTime);

                            if (c.CampoDominio.ToUpper().Trim() == "DATAHOJE")
                            {
                                txtbox.Click += (s, e) => { txtbox.Text = DateTime.Today.ToString("dd/MM/yyyy"); };
                            }

                            tabpage.Controls.Add(txtbox);

                            if (c.ToolTip != null && c.ToolTip != "")
                                toolTip1.SetToolTip(txtbox, c.ToolTip);
                        }

                        #endregion
                    }

                    else if (c.CampoDominio.ToUpper().Trim() == "CNPJ")
                    {
                        #region [CNPJ]
                        if (!ctrlExists)
                        {
                        txtbox.Mask = "00.000.000/0000-00";
                            tabpage.Controls.Add(txtbox);

                            if (c.ToolTip != null && c.ToolTip != "")
                                toolTip1.SetToolTip(txtbox, c.ToolTip);
                        }
                        #endregion
                    }
                    else if (c.CampoDominio.ToUpper().Trim() == "CPF")
                    {
                        #region [CPF]
                        if (!ctrlExists)
                        {
                        txtbox.Mask = "000.000.000-00";
                            tabpage.Controls.Add(txtbox);

                            if (c.ToolTip != null && c.ToolTip != "")
                                toolTip1.SetToolTip(txtbox, c.ToolTip);
                        }
                        #endregion
                    }
                    else if (c.CampoDominio.ToUpper().Trim() == "CPF/CNPJ")
                    {
                        #region [ CPF / CNPJ ]
                        ComboBox cbbox;
                        if (!ctrlExists)
                        {
                            #region [ComboBox]
                            lbl.Top = posicaoLinha;
                            lbl.Left = posicaoColuna - lbl.PreferredWidth;
                            cbbox = new ComboBox();
                            cbbox.DropDownStyle = ComboBoxStyle.DropDownList;
                            cbbox.Name = c.CampoNome + "cboCPFCNPJ";
                            cbbox.Tag = c.CampoOrdem;
                            cbbox.Top = posicaoLinha;
                            cbbox.Left = posicaoColuna;
                            cbbox.Width = 50;
                            posicaoColuna = posicaoColuna + 70;
                            cbbox.Enabled = camposativos && c.CampoHabilitado;
                            cbbox.ValueMember = c.CampoNome + "---ComboCPFCNPJ---";
                            string[] lineValues = (";CPF;CNPJ").Split(';');
                            string[] ValoresBatimento = c.CampoBatimento.Split(';').Distinct().ToArray();
                            foreach (string value in lineValues)
                            {
                                if (c.CampoBatimento == "" || Array.IndexOf(ValoresBatimento, value) != -1)
                                    cbbox.Items.Add(value.Trim());
                            }
                            string MaskComboCPFCNPJ = "";
                            if (cbbox.Items.Count > 0)
                            {
                                string valorcombocpjcnpj = "";
                                if (c.CampoBatimento.ToUpper() == "CNPJ" || c.CampoBatimento.ToUpper() == "CPF")
                                {
                                    valorcombocpjcnpj = c.CampoBatimento.ToUpper();
                                    if (valorcombocpjcnpj == "CNPJ")
                                        MaskComboCPFCNPJ = "00.000.000/0000-00";
                                    else if (valorcombocpjcnpj == "CPF")
                                        MaskComboCPFCNPJ = "000.000.000-00";
                                }
                                else if (c.ValorCampo != null && c.ValorCampo != "")
                                {
                                    if (c.ValorCampo.Length == 11)
                                    {
                                        valorcombocpjcnpj = "CPF";
                                        MaskComboCPFCNPJ = "000.000.000-00";
                                    }
                                    else if (c.ValorCampo.Length == 14)
                                    {
                                        valorcombocpjcnpj = "CNPJ";
                                        MaskComboCPFCNPJ = "00.000.000/0000-00";
                                    }
                                }
                                cbbox.SelectedIndex = cbbox.FindStringExact(valorcombocpjcnpj);
                                #region [ Evento ]
                                cbbox.SelectedIndexChanged += (s, e) =>
                                {
                                    if (cbbox.Text != "")
                                    {
                                        if (cbbox.Text == "CPF")
                                        {
                                            if (txtbox.Mask != "000.000.000-00")
                                            {
                                                txtbox.Mask = "000.000.000-00";
                                            }
                                        }
                                        else if (cbbox.Text == "CNPJ")
                                        {
                                            if (txtbox.Mask != "00.000.000/0000-00")
                                            {
                                                txtbox.Mask = "00.000.000/0000-00";
                                            }
                                        }
                                        else
                                        {
                                            if (txtbox.Mask != "")
                                            {
                                                txtbox.Mask = "";
                                            }
                                        }
                                        txtbox.Enabled = cbbox.Enabled;
                                    }
                                    else
                                    {
                                        if (txtbox.Mask != "")
                                        {
                                            txtbox.Mask = "";
                                        }
                                        txtbox.Text = "";
                                        txtbox.Enabled = false;
                                    }
                                };
                                #endregion
                            }

                            tabpage.Controls.Add(cbbox);

                            if (c.ToolTip != null && c.ToolTip != "")
                                toolTip1.SetToolTip(cbbox, c.ToolTip);
                            #endregion

                            #region [CPF/CNPJ]
                            txtbox.Left = posicaoColuna;
                            txtbox.Mask = MaskComboCPFCNPJ;
                            if (c.CampoBatimento.ToUpper() == "CNPJ" || c.CampoBatimento.ToUpper() == "CPF")
                            {
                                txtbox.Enabled = true;
                            }
                            else if (c.ValorCampo == null || c.ValorCampo == "")
                            {
                                txtbox.Enabled = false;
                            }
                            
                            tabpage.Controls.Add(txtbox);
                            if (c.ToolTip != null && c.ToolTip != "")
                                toolTip1.SetToolTip(txtbox, c.ToolTip);
                            #endregion
                        }
                        else
                        {
                            cbbox = (ComboBox)(ComboBox)tabpage.Controls[c.CampoNome + "cboCPFCNPJ"];
                            cbbox.Enabled = camposativos && c.CampoHabilitado;
                            string MaskComboCPFCNPJ = "";
                            if (cbbox.Items.Count > 0)
                            {
                                string valorcombocpjcnpj = "";
                                if (c.ValorCampo != null && c.ValorCampo != "")
                                {
                                    if (c.ValorCampo.Length == 11)
                                    {
                                        valorcombocpjcnpj = "CPF";
                                        MaskComboCPFCNPJ = "000.000.000-00";
                                    }
                                    else if (c.ValorCampo.Length == 14)
                                    {
                                        valorcombocpjcnpj = "CNPJ";
                                        MaskComboCPFCNPJ = "00.000.000/0000-00";
                                    }
                                }
                                cbbox.SelectedIndex = cbbox.FindStringExact(valorcombocpjcnpj);
                            }
                            txtbox.Mask = MaskComboCPFCNPJ;
                            if (c.ValorCampo == null || c.ValorCampo == "")
                            {
                                txtbox.Enabled = false;
                            }
                            else
                            {
                                txtbox.Text = c.ValorCampo;
                            }
                        }

                        if (!lblExists)
                        {
                            tabpage.Controls.Add(lbl);
                        }
                        #endregion
                    }
                    else if (c.CampoDominio.ToUpper().Trim() == "HORA")
                    {
                        #region [ Hora ]
                        if (!ctrlExists)
                        {
                            txtbox.Mask = "00:00";
                            tabpage.Controls.Add(txtbox);

                            if (c.ToolTip != null && c.ToolTip != "")
                                toolTip1.SetToolTip(txtbox, c.ToolTip);
                        }
                        #endregion
                    }
                    else if (c.CampoDominio.ToUpper().Trim() == "MOEDA")
                    {
                        #region [Moeda]
                        //CultureInfo cultureMoeda = CultureInfo.CreateSpecificCulture("pt-BR");
                        CultureInfo cultureMoeda = TratamentoLinguagem.BuscarLinguagem("pt-BR");
                        var minhaCultura = TratamentoLinguagem.BuscarLinguagem("pt-BR");
                        minhaCultura.NumberFormat.NumberDecimalDigits = 2;
                        /*var minhaCultura = new CultureInfo("pt-BR"); //pt-BR usada como base
                        minhaCultura.DateTimeFormat.ShortDatePattern = "dd/MM/yyyy";
                        minhaCultura.DateTimeFormat.ShortTimePattern = "HH:mm";
                        minhaCultura.NumberFormat.NumberDecimalDigits = 2;
                        minhaCultura.NumberFormat.NumberGroupSeparator = ".";
                        minhaCultura.NumberFormat.NumberDecimalSeparator = ",";
                        */

                        string vlrMoeda = "";
                        if (c.ValorCampo != null && c.ValorCampo != "")
                        {
                            decimal valormoeda = Convert.ToDecimal(c.ValorCampo, minhaCultura);
                            //decimal valormoeda = Convert.ToDecimal(c.ValorCampo, cultureMoeda);
                            vlrMoeda = string.Format(minhaCultura, "{0:N}", valormoeda);
                            //vlrMoeda = valormoeda.ToString("N", cultureMoeda);
                            //string vlrMoeda = string.Format("{0:#.00}", Convert.ToDecimal(c.ValorCampo, cultureMoeda));
                        }
                        txtbox.Text = vlrMoeda;
                        if (!ctrlExists)
                        {
                            tabpage.Controls.Add(txtbox);

                            if (c.ToolTip != null && c.ToolTip != "")
                                toolTip1.SetToolTip(txtbox, c.ToolTip);
                        }
                        #endregion
                    }
                    else if (c.CampoDominio.ToUpper().Trim() == "DECIMAL")
                    {
                        #region [Decimal]
                        //CultureInfo cultureDecimal = CultureInfo.CreateSpecificCulture("pt-BR");
                        CultureInfo cultureDecimal = TratamentoLinguagem.BuscarLinguagem("PT-BR");
                        string vlrDecimal = "";
                        if (c.ValorCampo != null && c.ValorCampo != "")
                        {
                            decimal valordecimal = Convert.ToDecimal(c.ValorCampo, cultureDecimal);
                            string n = "0";
                            if (c.ValorCampo.IndexOf(',') != -1)
                            {
                                n = c.ValorCampo.Substring(c.ValorCampo.IndexOf(',') + 1).Length.ToString();
                            }
                            vlrDecimal = valordecimal.ToString("N" + n, cultureDecimal);
                            //string vlrMoeda = string.Format("{0:#.00}", Convert.ToDecimal(c.ValorCampo, cultureMoeda));
                        }
                        txtbox.Text = vlrDecimal;
                        if (!ctrlExists)
                        {
                            tabpage.Controls.Add(txtbox);

                            if (c.ToolTip != null && c.ToolTip != "")
                                toolTip1.SetToolTip(txtbox, c.ToolTip);
                        }
                        #endregion
                    }
                    else
                    {
                        if (!ctrlExists)
                        {
                            tabpage.Controls.Add(txtbox);

                            if (c.ToolTip != null && c.ToolTip != "")
                                toolTip1.SetToolTip(txtbox, c.ToolTip);
                        }
                    }

                    if (!lblExists)
                        tabpage.Controls.Add(lbl);
                    #endregion
                }
                else if (c.CampoTipo.ToUpper().Trim() == "MASKEDTEXTBOX")
                {
                    #region [ MaskedTextBox ]
                    if (!lblExists)
                    {
                        lbl.Top = posicaoLinha;
                        lbl.Left = posicaoColuna - lbl.PreferredWidth;
                    }
                    MaskedTextBox msktxtbox;
                    if (!ctrlExists)
                    {
                        //CultureInfo culture = CultureInfo.CreateSpecificCulture("en-US");
                        CultureInfo culture = TratamentoLinguagem.BuscarLinguagem("EN-US");
                        MaskedTextProvider maskProvider = new MaskedTextProvider(c.CampoDominio, culture);


                        msktxtbox = new MaskedTextBox(maskProvider);


                        msktxtbox.Name = c.CampoNome;
                        msktxtbox.Tag = c.CampoOrdem;
                        msktxtbox.Top = posicaoLinha;
                        msktxtbox.Left = posicaoColuna;
                        msktxtbox.Width = c.CampoWidth;
                        msktxtbox.Enabled = camposativos && c.CampoHabilitado;

                        //msktxtbox.Mask = c.CampoDominio;

                        msktxtbox.Text = c.ValorCampo;

                        tabpage.Controls.Add(msktxtbox);

                        if (c.ToolTip != null && c.ToolTip != "")
                            toolTip1.SetToolTip(msktxtbox, c.ToolTip);
                    }
                    else
                    {
                        msktxtbox = (MaskedTextBox)tabpage.Controls[c.CampoNome];
                        msktxtbox.Text = c.ValorCampo;
                        msktxtbox.Enabled = camposativos && c.CampoHabilitado;
                    }

                    if (!lblExists)
                    {
                        tabpage.Controls.Add(lbl);
                    }
                    #endregion
                }
                else if (c.CampoTipo.ToUpper() == "COMBOBOX")
                {
                    #region [ComboBox]
                    if (!lblExists)
                    {
                        lbl.Top = posicaoLinha;
                        lbl.Left = posicaoColuna - lbl.PreferredWidth;
                    }

                    ComboBox cbbox;
                    if (!ctrlExists)
                    {
                        cbbox = new ComboBox();
                        cbbox.DropDownStyle = ComboBoxStyle.DropDownList;
                        cbbox.Name = c.CampoNome;
                        cbbox.Tag = c.CampoOrdem;
                        cbbox.Top = posicaoLinha;
                        cbbox.Left = posicaoColuna;
                        cbbox.Width = c.CampoWidth;
                        cbbox.Enabled = camposativos && c.CampoHabilitado;
                        cbbox.ValueMember = c.CampoNome;
                        string[] lineValues = c.CampoDominio.Split(';').Distinct().ToArray();
                        string[] ValoresBatimento = c.CampoBatimento.Split(';').Distinct().ToArray();
                        foreach (string value in lineValues)
                        {
                            if (c.CampoBatimento == "" || Array.IndexOf(ValoresBatimento, value) != -1 || Array.IndexOf(ValoresBatimento, "*" + value) != -1)
                                cbbox.Items.Add(value.Trim());
                        }
                        if (cbbox.Items.Count > 0)
                        {
                            cbbox.SelectedIndex = cbbox.FindStringExact(c.ValorCampo);
                        }
                        //cbbox.DataSource = c.CampoDominio.Split(';').ToList();

                        tabpage.Controls.Add(cbbox);

                        if (c.ToolTip != null && c.ToolTip != "")
                            toolTip1.SetToolTip(cbbox, c.ToolTip);
                    }
                    else
                    {
                        cbbox = (ComboBox)tabpage.Controls[c.CampoNome];
                        if (cbbox.Items.Count > 0)
                        {
                            cbbox.SelectedIndex = cbbox.FindStringExact(c.ValorCampo);
                        }
                        cbbox.Enabled = camposativos && c.CampoHabilitado;
                    }

                    if (!lblExists)
                    {
                        tabpage.Controls.Add(lbl);
                    }

                    #endregion
                }
                else if (c.CampoTipo.ToUpper() == "CHECKBOX")
                {
                    #region [CheckBox]
                    CheckBox ckbox;
                    if (!ctrlExists)
                    {
                        ckbox = new CheckBox();
                        ckbox.AutoSize = true;
                        if (c.CampoObrigatorio == true)
                        {
                            ckbox.Text = c.CampoLabel + "*";
                        }
                        else
                        {
                            ckbox.Text = c.CampoLabel;
                        }
                        ckbox.Text = c.CampoLabel;
                        ckbox.Top = posicaoLinha;
                        ckbox.Left = posicaoColuna;
                        posicaoColuna = posicaoColuna + lbl.Width;
                        ckbox.Name = c.CampoNome;
                        ckbox.Enabled = camposativos && c.CampoHabilitado;
                        if (c.ValorCampo != "")
                        {
                            ckbox.Checked = Convert.ToBoolean(c.ValorCampo);
                        }
                        else
                        {
                            ckbox.Checked = false;
                        }
                        tabpage.Controls.Add(ckbox);

                        if (c.ToolTip != null && c.ToolTip != "")
                            toolTip1.SetToolTip(ckbox, c.ToolTip);
                    }
                    else
                    {
                        ckbox = (CheckBox)tabpage.Controls[c.CampoNome];
                        if (c.ValorCampo != "")
                        {
                            ckbox.Checked = Convert.ToBoolean(c.ValorCampo);
                        }
                        else
                        {
                            ckbox.Checked = false;
                        }
                        ckbox.Enabled = camposativos && c.CampoHabilitado;
                    }
                    #endregion
                }
                else if (c.CampoTipo.ToUpper() == "LABEL")
                {
                    #region [Label]
                    if (!ctrlExists)
                    {
                        Label lblText = new Label();
                        lblText.AutoSize = true;
                        lblText.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Bold);
                        lblText.Text = c.CampoLabel;
                        lblText.Left = posicaoColuna - lblText.PreferredWidth;
                        lblText.Top = posicaoLinha;

                        tabpage.Controls.Add(lblText);
                    }
                    #endregion
                }
                else if (c.CampoTipo.ToUpper() == "MEMO")
                {
                    #region [Memo]
                    if (!lblExists)
                    {
                        lbl.Top = posicaoLinha;
                        lbl.Left = posicaoColuna - lbl.PreferredWidth;
                    }

                    RichTextBox memo;
                    if (!ctrlExists)
                    {
                        memo = new RichTextBox();
                        memo.Name = c.CampoNome;
                        memo.Tag = c.CampoOrdem;
                        memo.Top = posicaoLinha;
                        memo.Left = posicaoColuna;
                        memo.Width = c.CampoWidth;
                        if (c.CampoHeight == 0)
                        {
                            memo.Height = 0;
                        }
                        else
                        {
                            memo.Height = c.CampoHeight;
                        }
                        memo.Enabled = camposativos && c.CampoHabilitado;
                        memo.Text = c.ValorCampo;

                        tabpage.Controls.Add(memo);

                        if (c.ToolTip != null && c.ToolTip != "")
                            toolTip1.SetToolTip(memo, c.ToolTip);
                    }
                    else
                    {
                        memo = (RichTextBox)tabpage.Controls[c.CampoNome];
                        memo.Text = c.ValorCampo;
                        memo.Enabled = camposativos && c.CampoHabilitado;
                    }

                    if (!lblExists)
                    {
                        tabpage.Controls.Add(lbl);
                    }
                    #endregion
                }
                else if (c.CampoTipo.ToUpper() == "TABELA")
                {
                    #region [Tabela]
                    if (!lblExists)
                    {
                        lbl.Top = posicaoLinha;
                        lbl.Left = posicaoColuna - lbl.PreferredWidth;
                    }

                    DataGridView tbl;
                    if (!ctrlExists)
                    {
                        #region [ cria grid ]
                        tbl = new DataGridView();
                        tbl.Name = c.CampoNome;
                        tbl.Tag = c.CampoOrdem;
                        tbl.Top = posicaoLinha;
                        tbl.Left = posicaoColuna;
                        tbl.Width = c.CampoWidth;

                        if (c.CampoHeight == 0)
                        {
                            tbl.Height = 0;
                        }
                        else
                        {
                            tbl.Height = c.CampoHeight;
                        }
                        tbl.Enabled = camposativos && c.CampoHabilitado;
                        tbl.AllowUserToDeleteRows = camposativos && c.CampoHabilitado;
                        tbl.AllowUserToAddRows = camposativos && c.CampoHabilitado;
                        tbl.AllowUserToOrderColumns = camposativos && c.CampoHabilitado;
                        tbl.AllowUserToResizeColumns = camposativos && c.CampoHabilitado;

                        tbl.CellValueChanged += (s, e) => { tbl.NotifyCurrentCellDirty(true); tbl.NotifyCurrentCellDirty(false); };

                        #region [ adiciona colunas no grid ]
                        string[] lineValues = c.CampoDominio.Split(';');

                        foreach (string value in lineValues)
                        {
                            DataGridViewColumn MinhaCol = null;

                            CamposTabela campoTbl = camposTabela.Find(n => n.ID_Campo == c.ID_Campo && n.CampoNome.ToUpper().Trim() == value.ToUpper().Trim());
                            
                            if (campoTbl != null)
                            {
                                #region [ define tipo de coluna ]
                                if (campoTbl.CampoTipo.ToUpper().Trim() == "TEXTBOX")
                                {
                                    #region [ TextBox]

                                    DataGridViewMaskedTextColumn MinhaColTxt = new DataGridViewMaskedTextColumn();
                                    
                                    MinhaColTxt.Mask = "";
                                    MinhaColTxt.ValueType = typeof(String);
                                    MinhaColTxt.ReadOnly = !(camposativos && campoTbl.CampoHabilitado);
                                    
                                    if (campoTbl.ToolTip != null && campoTbl.ToolTip != "")
                                        MinhaColTxt.ToolTipText = campoTbl.ToolTip;

                                    MinhaColTxt.Width = campoTbl.CampoWidth;

                                    if (campoTbl.CampoDominio.ToUpper().Trim() == "DATA")
                                    {
                                        #region [Data]
                                        MinhaColTxt.Mask = "00/00/0000";
                                        MinhaColTxt.ValueType = typeof(System.DateTime);
                                        #endregion
                                    }
                                    else if (campoTbl.CampoDominio.ToUpper().Trim() == "DATAHORA")
                                    {
                                        #region [Data + Hora]
                                        MinhaColTxt.Mask = "00/00/0000 00:00:00";
                                        MinhaColTxt.ValueType = typeof(System.DateTime);
                                        #endregion
                                    }
                                    else if (campoTbl.CampoDominio.ToUpper().Trim() == "DATAHOJE" || campoTbl.CampoDominio.ToUpper().Trim() == "DATAPASSADA" || campoTbl.CampoDominio.ToUpper().Trim() == "DATAFUTURA")
                                    {
                                        #region [ Data Hoje ]
                                        MinhaColTxt.Mask = "00/00/0000";
                                        MinhaColTxt.ValueType = typeof(System.DateTime);

                                        if (campoTbl.CampoDominio.ToUpper().Trim() == "DATAHOJE")
                                        {
                                            tbl.CellEnter += (s, e) =>
                                            {
                                                if (e.RowIndex != -1 && tbl.Columns[e.ColumnIndex].Name.ToUpper().Trim() == value.ToUpper().ToUpper().Trim())
                                                    tbl.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = DateTime.Today.ToString("dd/MM/yyyy");
                                            };
                                        }
                                        #endregion
                                    }

                                    else if (campoTbl.CampoDominio.ToUpper().Trim() == "CNPJ")
                                    {
                                        #region [CNPJ]
                                        MinhaColTxt.Mask = "00.000.000/0000-00";
                                        
                                        MinhaColTxt.ValueType = typeof(System.String);
                                        #endregion
                                    }
                                    else if (campoTbl.CampoDominio.ToUpper().Trim() == "CPF")
                                    {
                                        #region [CPF]
                                        MinhaColTxt.Mask = "000.000.000-00";
                                        #endregion
                                    }
                                    else if (campoTbl.CampoDominio.ToUpper().Trim() == "HORA")
                                    {
                                        #region [ Hora ]
                                        MinhaColTxt.Mask = "00:00";
                                        #endregion
                                    }

                                    MinhaCol = MinhaColTxt;

                                    #endregion
                                }
                                else if (campoTbl.CampoTipo.ToUpper().Trim() == "MASKEDTEXTBOX")
                                {
                                    #region [ MaskedTextBox ]

                                    DataGridViewMaskedTextColumn MinhaColMask = new DataGridViewMaskedTextColumn(campoTbl.CampoDominio);
                                    MinhaColMask.ValueType = typeof(System.String);
                                    MinhaColMask.ReadOnly = !(camposativos && campoTbl.CampoHabilitado);

                                    if (campoTbl.ToolTip != null && campoTbl.ToolTip != "")
                                        MinhaColMask.ToolTipText = campoTbl.ToolTip;

                                    MinhaColMask.Width = campoTbl.CampoWidth;

                                    MinhaCol = MinhaColMask;
                                    #endregion
                                }
                                else if (campoTbl.CampoTipo.ToUpper() == "COMBOBOX")
                                {
                                    #region [ComboBox]
                                    DataGridViewComboBoxColumn MinhaColCombo = new DataGridViewComboBoxColumn();
                                    MinhaColCombo.ValueType = typeof(System.String);
                                    MinhaColCombo.DisplayStyle = DataGridViewComboBoxDisplayStyle.DropDownButton;
                                    MinhaColCombo.DisplayStyleForCurrentCellOnly = true;
                                    MinhaColCombo.AutoComplete = true;

                                    if (campoTbl.ToolTip != null && campoTbl.ToolTip != "")
                                        MinhaColCombo.ToolTipText = campoTbl.ToolTip;

                                    MinhaColCombo.ReadOnly = !(camposativos && campoTbl.CampoHabilitado);
                                    MinhaColCombo.Width = campoTbl.CampoWidth;



                                    string[] lineValuesGrid = campoTbl.CampoDominio.Split(';');
                                    MinhaColCombo.MaxDropDownItems = lineValuesGrid.Count();
                                    foreach (string valueGrid in lineValuesGrid)
                                    {
                                        MinhaColCombo.Items.Add(valueGrid.Trim());
                                    }

                                    MinhaCol = MinhaColCombo;
                                    #endregion
                                }
                                else if (c.CampoTipo.ToUpper() == "CHECKBOX")
                                {
                                    #region [CheckBox]
                                    DataGridViewCheckBoxColumn MinhaColChk = new DataGridViewCheckBoxColumn();
                                    MinhaColChk.ThreeState = false;
                                    MinhaColChk.ValueType = typeof(System.Boolean);
                                    MinhaColChk.ReadOnly = !(camposativos && campoTbl.CampoHabilitado);

                                    if (campoTbl.ToolTip != null && campoTbl.ToolTip != "")
                                        MinhaColChk.ToolTipText = campoTbl.ToolTip;

                                    MinhaColChk.Width = campoTbl.CampoWidth;

                                    MinhaCol = MinhaColChk;
                                    #endregion
                                }
                                #endregion

                                MinhaCol.HeaderText = value.Trim();
                                MinhaCol.Name = value.Trim();
                                
                                tbl.Columns.Add(MinhaCol);
                            }
                        }
                        #endregion

                        #region [ adiciona linhas ]
                        tbl.Columns.Add("Linha", "Linha");
                        tbl.Columns["Linha"].Visible = false;


                        List<CamposTabela> campoTblValores = camposTabela.FindAll(n => n.ID_Campo == c.ID_Campo && n.Linha != 0 && n.IdServico != 0).ToList();
                        List<int> Linhas = campoTblValores.Select(n => n.Linha).Distinct().ToList();

                        for (int linha = 0; linha < Linhas.Count; linha++)
                        {
                            tbl.Rows.Add();
                            tbl.Rows[linha].Cells["Linha"].Value = Linhas[linha].ToString();

                            List<CamposTabela> CamposLinha = campoTblValores.FindAll(n => n.Linha == Linhas[linha]).ToList();
                            foreach (CamposTabela cTbl in CamposLinha)
                            {
                                tbl.Rows[linha].Cells[cTbl.CampoNome].Value = cTbl.ValorCampo;
                            }
                        }
                        #endregion

                        tabpage.Controls.Add(tbl);

                        if (c.ToolTip != null && c.ToolTip != "")
                            toolTip1.SetToolTip(tbl, c.ToolTip);
                        #endregion
                    }
                    else
                    {
                        #region [ Já existe o grid ]
                        tbl = (DataGridView)tabpage.Controls[c.CampoNome];
                        tbl.Rows.Clear();

                        #region [ adiciona linhas ]
                        List<CamposTabela> campoTblValores = camposTabela.FindAll(n => n.ID_Campo == c.ID_Campo && n.Linha != 0 && n.IdServico != 0).ToList();
                        List<int> Linhas = campoTblValores.Select(n => n.Linha).Distinct().ToList();

                        for (int linha = 0; linha < Linhas.Count; linha++)
                        {
                            tbl.Rows.Add();
                            tbl.Rows[linha].Cells["Linha"].Value = Linhas[linha].ToString();

                            List<CamposTabela> CamposLinha = campoTblValores.FindAll(n => n.Linha == Linhas[linha]).ToList();
                            foreach (CamposTabela cTbl in CamposLinha)
                            {
                                tbl.Rows[linha].Cells[cTbl.CampoNome].Value = cTbl.ValorCampo;
                            }
                        }
                        #endregion

                        tbl.Enabled = camposativos && c.CampoHabilitado;
                        tbl.AllowUserToDeleteRows = camposativos && c.CampoHabilitado;
                        tbl.AllowUserToAddRows = camposativos && c.CampoHabilitado;
                        tbl.AllowUserToOrderColumns = camposativos && c.CampoHabilitado;
                        tbl.AllowUserToResizeColumns = camposativos && c.CampoHabilitado;
                        #endregion
                    }

                    if (!lblExists)
                    {
                        tabpage.Controls.Add(lbl);
                    }
                    #endregion
                }
                else if (c.CampoTipo.ToUpper() == "TABELAGERAL")
                {
                    #region [ Tabela Geral ]
                    if (!lblExists)
                    {
                        lbl.Top = posicaoLinha;
                        lbl.Left = posicaoColuna - lbl.PreferredWidth;
                    }

                    DataGridView tbl;
                    if (!ctrlExists)
                    {
                        #region [ cria grid ]
                        tbl = new DataGridView();
                        tbl.Name = c.CampoNome;
                        tbl.Tag = c.CampoOrdem;
                        tbl.Top = posicaoLinha;
                        tbl.Left = posicaoColuna;
                        tbl.Width = c.CampoWidth;

                        if (c.CampoHeight == 0)
                        {
                            tbl.Height = 0;
                        }
                        else
                        {
                            tbl.Height = c.CampoHeight;
                        }
                        tbl.Enabled = camposativos && c.CampoHabilitado;
                        tbl.AllowUserToDeleteRows = camposativos && c.CampoHabilitado;
                        tbl.AllowUserToAddRows = camposativos && c.CampoHabilitado;
                        tbl.AllowUserToOrderColumns = camposativos && c.CampoHabilitado;
                        tbl.AllowUserToResizeColumns = camposativos && c.CampoHabilitado;

                        tbl.CellValueChanged += (s, e) => { tbl.NotifyCurrentCellDirty(true); tbl.NotifyCurrentCellDirty(false); };

                        #region [ view ]
                        string view = "";
                        if (c.CampoDominio.IndexOf(']') != -1 && c.CampoDominio.IndexOf('[') == 0)
                        {
                            view = c.CampoDominio.Substring(1, c.CampoDominio.IndexOf(']') - 1);
                        }
                        else
                        {
                            view = null;
                        }
                        #endregion

                        #region [ adiciona colunas no grid ]
                        string[] lineValues = c.CampoDominio.IndexOf(']') != -1 && c.CampoDominio.IndexOf('[') == 0 ? c.CampoDominio.Substring(c.CampoDominio.IndexOf(']') + 1).Split(';') : c.CampoDominio.Split(';');

                        foreach (string value in lineValues)
                        {
                            DataGridViewColumn MinhaCol = null;

                            CamposTabela campoTbl = camposTabela.Find(n => n.ID_Campo == c.ID_Campo && n.CampoNome.ToUpper().Trim() == value.ToUpper().Trim());

                            if (campoTbl != null)
                            {
                                #region [ define tipo de coluna ]
                                if (campoTbl.CampoTipo.ToUpper().Trim() == "TEXTBOX")
                                {
                                    #region [ TextBox]

                                    DataGridViewMaskedTextColumn MinhaColTxt = new DataGridViewMaskedTextColumn();

                                    MinhaColTxt.Mask = "";
                                    MinhaColTxt.ValueType = typeof(String);
                                    MinhaColTxt.ReadOnly = !(camposativos && campoTbl.CampoHabilitado);

                                    if (campoTbl.ToolTip != null && campoTbl.ToolTip != "")
                                        MinhaColTxt.ToolTipText = campoTbl.ToolTip;

                                    MinhaColTxt.Width = campoTbl.CampoWidth;

                                    if (campoTbl.CampoDominio.ToUpper().Trim() == "DATA")
                                    {
                                        #region [Data]
                                        MinhaColTxt.Mask = "00/00/0000";
                                        MinhaColTxt.ValueType = typeof(System.DateTime);
                                        #endregion
                                    }
                                    else if (campoTbl.CampoDominio.ToUpper().Trim() == "DATAHORA")
                                    {
                                        #region [Data + Hora]
                                        MinhaColTxt.Mask = "00/00/0000 00:00:00";
                                        MinhaColTxt.ValueType = typeof(System.DateTime);
                                        #endregion
                                    }
                                    else if (campoTbl.CampoDominio.ToUpper().Trim() == "DATAHOJE" || campoTbl.CampoDominio.ToUpper().Trim() == "DATAPASSADA" || campoTbl.CampoDominio.ToUpper().Trim() == "DATAFUTURA")
                                    {
                                        #region [ Data Hoje ]
                                        MinhaColTxt.Mask = "00/00/0000";
                                        MinhaColTxt.ValueType = typeof(System.DateTime);

                                        if (campoTbl.CampoDominio.ToUpper().Trim() == "DATAHOJE")
                                        {
                                            tbl.CellEnter += (s, e) =>
                                            {
                                                if (e.RowIndex != -1 && tbl.Columns[e.ColumnIndex].Name.ToUpper().Trim() == value.ToUpper().ToUpper().Trim())
                                                    tbl.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = DateTime.Today.ToString("dd/MM/yyyy");
                                            };
                                        }
                                        #endregion
                                    }

                                    else if (campoTbl.CampoDominio.ToUpper().Trim() == "CNPJ")
                                    {
                                        #region [CNPJ]
                                        MinhaColTxt.Mask = "00.000.000/0000-00";

                                        MinhaColTxt.ValueType = typeof(System.String);
                                        #endregion
                                    }
                                    else if (campoTbl.CampoDominio.ToUpper().Trim() == "CPF")
                                    {
                                        #region [CPF]
                                        MinhaColTxt.Mask = "000.000.000-00";
                                        #endregion
                                    }
                                    else if (campoTbl.CampoDominio.ToUpper().Trim() == "HORA")
                                    {
                                        #region [ Hora ]
                                        MinhaColTxt.Mask = "00:00";
                                        #endregion
                                    }

                                    MinhaCol = MinhaColTxt;

                                    #endregion
                                }
                                else if (campoTbl.CampoTipo.ToUpper().Trim() == "MASKEDTEXTBOX")
                                {
                                    #region [ MaskedTextBox ]

                                    DataGridViewMaskedTextColumn MinhaColMask = new DataGridViewMaskedTextColumn(campoTbl.CampoDominio);
                                    MinhaColMask.ValueType = typeof(System.String);
                                    MinhaColMask.ReadOnly = !(camposativos && campoTbl.CampoHabilitado);

                                    if (campoTbl.ToolTip != null && campoTbl.ToolTip != "")
                                        MinhaColMask.ToolTipText = campoTbl.ToolTip;

                                    MinhaColMask.Width = campoTbl.CampoWidth;

                                    MinhaCol = MinhaColMask;
                                    #endregion
                                }
                                else if (campoTbl.CampoTipo.ToUpper() == "COMBOBOX")
                                {
                                    #region [ComboBox]
                                    DataGridViewComboBoxColumn MinhaColCombo = new DataGridViewComboBoxColumn();
                                    MinhaColCombo.ValueType = typeof(System.String);
                                    MinhaColCombo.DisplayStyle = DataGridViewComboBoxDisplayStyle.DropDownButton;
                                    MinhaColCombo.DisplayStyleForCurrentCellOnly = true;
                                    MinhaColCombo.AutoComplete = true;

                                    if (campoTbl.ToolTip != null && campoTbl.ToolTip != "")
                                        MinhaColCombo.ToolTipText = campoTbl.ToolTip;

                                    MinhaColCombo.ReadOnly = !(camposativos && campoTbl.CampoHabilitado);
                                    MinhaColCombo.Width = campoTbl.CampoWidth;



                                    string[] lineValuesGrid = campoTbl.CampoDominio.Split(';');
                                    MinhaColCombo.MaxDropDownItems = lineValuesGrid.Count();
                                    foreach (string valueGrid in lineValuesGrid)
                                    {
                                        MinhaColCombo.Items.Add(valueGrid.Trim());
                                    }

                                    MinhaCol = MinhaColCombo;
                                    #endregion
                                }
                                else if (c.CampoTipo.ToUpper() == "CHECKBOX")
                                {
                                    #region [CheckBox]
                                    DataGridViewCheckBoxColumn MinhaColChk = new DataGridViewCheckBoxColumn();
                                    MinhaColChk.ThreeState = false;
                                    MinhaColChk.ValueType = typeof(System.Boolean);
                                    MinhaColChk.ReadOnly = !(camposativos && campoTbl.CampoHabilitado);

                                    if (campoTbl.ToolTip != null && campoTbl.ToolTip != "")
                                        MinhaColChk.ToolTipText = campoTbl.ToolTip;

                                    MinhaColChk.Width = campoTbl.CampoWidth;

                                    MinhaCol = MinhaColChk;
                                    #endregion
                                }
                                #endregion

                                MinhaCol.HeaderText = value.Trim();
                                MinhaCol.Name = value.Trim();

                                tbl.Columns.Add(MinhaCol);
                            }
                        }
                        #endregion

                        #region [ adiciona linhas ]
                        tbl.Columns.Add("Linha", "Linha");
                        tbl.Columns["Linha"].Visible = false;

                        List<CamposTabela> campoTblValores = camposTabela.FindAll(n => n.ID_Campo == c.ID_Campo && n.Linha != 0 && n.IdServico == 0).ToList();
                        List<int> Linhas = campoTblValores.Select(n => n.Linha).Distinct().ToList();

                        for (int linha = 0; linha < Linhas.Count; linha++)
                        {
                            tbl.Rows.Add();
                            tbl.Rows[linha].Cells["Linha"].Value = Linhas[linha].ToString();

                            List<CamposTabela> CamposLinha = campoTblValores.FindAll(n => n.Linha == Linhas[linha]).ToList();
                            foreach (CamposTabela cTbl in CamposLinha)
                            {
                                tbl.Rows[linha].Cells[cTbl.CampoNome].Value = cTbl.ValorCampo;
                            }
                        }
                        #endregion

                        tabpage.Controls.Add(tbl);

                        if (c.ToolTip != null && c.ToolTip != "")
                            toolTip1.SetToolTip(tbl, c.ToolTip);
                        #endregion
                    }
                    else
                    {
                        #region [ Já existe o grid ]
                        tbl = (DataGridView)tabpage.Controls[c.CampoNome];
                        tbl.Rows.Clear();

                        #region [ view ]
                        string view = "";
                        if (c.CampoDominio.IndexOf(']') != -1 && c.CampoDominio.IndexOf('[') == 0)
                        {
                            view = c.CampoDominio.Substring(1, c.CampoDominio.IndexOf(']') - 1);
                        }
                        else
                        {
                            view = null;
                        }
                        #endregion

                        #region [ adiciona linhas ]
                        List<CamposTabela> campoTblValores = camposTabela.FindAll(n => n.ID_Campo == c.ID_Campo && n.Linha != 0 && n.IdServico == 0).ToList();
                        List<int> Linhas = campoTblValores.Select(n => n.Linha).Distinct().ToList();

                        for (int linha = 0; linha < Linhas.Count; linha++)
                        {
                            tbl.Rows.Add();
                            tbl.Rows[linha].Cells["Linha"].Value = Linhas[linha].ToString();

                            List<CamposTabela> CamposLinha = campoTblValores.FindAll(n => n.Linha == Linhas[linha]).ToList();
                            foreach (CamposTabela cTbl in CamposLinha)
                            {
                                tbl.Rows[linha].Cells[cTbl.CampoNome].Value = cTbl.ValorCampo;
                            }
                        }
                        #endregion

                        tbl.Enabled = camposativos && c.CampoHabilitado;
                        tbl.AllowUserToDeleteRows = camposativos && c.CampoHabilitado;
                        tbl.AllowUserToAddRows = camposativos && c.CampoHabilitado;
                        tbl.AllowUserToOrderColumns = camposativos && c.CampoHabilitado;
                        tbl.AllowUserToResizeColumns = camposativos && c.CampoHabilitado;
                        #endregion
                    }

                    if (!lblExists)
                    {
                        tabpage.Controls.Add(lbl);
                    }
                    #endregion
                }
                #endregion

                linhaObj = c.CampoLinha;
                tamCampoAnt = c.CampoWidth;
                tabPageAnt = c.CampoTab;
                colAnterior = c.CampoColuna;
                tipoCampoAnterior = c.CampoTipo.ToUpper();
            }
        }


        public static List<PipelineCampos> MontarFiltro(List<PipelineCampos> lista, Form Formulario, Panel tbcontrol, Button btnfiltro) //int Height = 150, int Width = 950)
        {
            int tamCampoAnt = 0;
            int linhaObj = 1;
            int posicaoLinha = 0;
            int posicaoColuna = 20;
            //string tabPageAnt = "";
            int colAnterior = 0;
            string tipoCampoAnterior = "";

            //tbcontrol.Height = Height;
            //tbcontrol.Width = Width;
            ToolTip toolTip1 = new ToolTip();

            tbcontrol.Controls.Clear();
            List<PipelineCampos> ListaFiltrada = new List<PipelineCampos>();
            ListaFiltrada = lista.Where(x => x.MostrarFiltro == true && x.Visivel == true).ToList();
            
            if (ListaFiltrada.Count > 0)
            {
                ListaFiltrada = ListaFiltrada.OrderBy(m => m.FiltroLinha).ThenBy(m => m.FiltroColuna).ToList();

                tbcontrol.Visible = true;
                tbcontrol.AutoScroll = true;

                foreach (PipelineCampos c in ListaFiltrada)
                {

                    if (c.MostrarFiltro && c.Visivel)
                    {
                        Label lbl = new Label();

                        lbl.Text = c.NomeHeader;
                        lbl.AutoSize = true;
                        lbl.Width = c.FiltroLabelWidth;

                        if (linhaObj == c.FiltroLinha)//&& tabPageAnt.Equals(c.CampoTab)
                        {
                            posicaoColuna = posicaoColuna + tamCampoAnt + lbl.Width + (c.FiltroColuna - colAnterior - 1) * 100;
                        }
                        else
                        {
                            posicaoColuna = lbl.Width * c.FiltroColuna;
                        }

                        posicaoLinha = c.FiltroLinha * 25 - 15;

                        #region [ Adiciona Campos ]
                        if (c.FiltroTIPO.ToUpper().Trim() == "TEXTBOX")
                        {
                            #region [ TextBox]
                            lbl.Top = posicaoLinha;
                            lbl.Left = posicaoColuna - lbl.PreferredWidth;

                            TextBox txtbox = new TextBox();

                            txtbox.Name = "txt" + c.NomeDesign;
                            //txtbox.Tag = c.CampoOrdem;
                            
                            txtbox.Top = posicaoLinha;
                            txtbox.Left = posicaoColuna;
                            txtbox.Width = c.FiltroWidth;
                            txtbox.Enabled = true;
                            txtbox.KeyUp += (s, e) =>
                            {
                                if (e.KeyCode.ToString() == "Return")
                                {
                                    Button btn = new Button();
                                    btn = btnfiltro;
                                    //btn = (Button)Formulario.Controls["FlutuosoPanel"].Controls["grpfiltro"].Controls["panel2"].Controls["button_Filtro"];
                                    btn.PerformClick();
                                }
                            };
                            tbcontrol.Controls.Add(lbl);
                            tbcontrol.Controls.Add(txtbox);

                            if (c.FiltroToolTipText != null && c.FiltroToolTipText != "")
                                toolTip1.SetToolTip(txtbox, c.FiltroToolTipText);


                            #endregion
                        }
                        else if (c.FiltroTIPO.ToUpper().Trim() == "COMBOBOX" || c.FiltroTIPO.ToUpper().Trim() == "CHECKBOX")
                        {
                            #region [ ComboBox]
                            lbl.Top = posicaoLinha;
                            lbl.Left = posicaoColuna - lbl.PreferredWidth;
                            ComboBox cbbox = new ComboBox();
                            cbbox.DropDownStyle = ComboBoxStyle.DropDownList;
                            cbbox.Name = "txt" + c.NomeDesign;

                            cbbox.Top = posicaoLinha;
                            cbbox.Left = posicaoColuna;
                            cbbox.Width = c.FiltroWidth;
                            cbbox.Enabled = true;

                            cbbox.ValueMember = "txt" + c.NomeDesign;

                            if (c.FiltroTIPO.ToUpper().Trim() == "CHECKBOX")
                            {
                                c.FiltroDominio = "SIM;NÃO";
                            }

                            string[] lineValues = c.FiltroDominio.Split(';');
                            if (lineValues.Count() > 0)
                            {
                                cbbox.Items.Add("");
                            }
                            foreach (string value in lineValues)
                            {
                                cbbox.Items.Add(value);
                            }
                            
                            //if (cbbox.Items.Count > 0)
                            //{
                            //    cbbox.SelectedIndex = cbbox.FindStringExact(c.ValorCampo);
                            //}
                            cbbox.KeyUp += (s, e) =>
                            {
                                if (e.KeyCode.ToString() == "Return")
                                {
                                    Button btn = new Button();
                                    //btn = (Button)Formulario.Controls["FlutuosoPanel"].Controls["grpfiltro"].Controls["panel2"].Controls["button_Filtro"];
                                    btn = btnfiltro;
                                    btn.PerformClick();
                                }
                            };

                            tbcontrol.Controls.Add(lbl);
                            tbcontrol.Controls.Add(cbbox);

                            if (c.FiltroToolTipText != null && c.FiltroToolTipText != "")
                                toolTip1.SetToolTip(cbbox, c.FiltroToolTipText);

                            #endregion
                        }

                        linhaObj = c.FiltroLinha;
                        tamCampoAnt = c.FiltroWidth;
                        //tabPageAnt = c.CampoTab;
                        colAnterior = c.FiltroColuna;
                        tipoCampoAnterior = c.FiltroTIPO.ToUpper();
                        #endregion
                    }   
                }
            }
            else
            {
                tbcontrol.Visible = false;
            }
            return ListaFiltrada;
        }

        public static void CriarEtapaFluxo(int idServico, int idObjeto, int IdResponsavel = 0, string SistemaLog = "")
        {
            List<EtapasObjeto> listaProximaEtapa = new List<EtapasObjeto>();

            listaProximaEtapa = DataAccess.BuscarEtapasObjeto(idObjeto);

            foreach (EtapasObjeto etapaObj in listaProximaEtapa)
            {
                etapaObj.ID_Status = etapaObj.StatusInicial;
                etapaObj.ID_Servico = idServico;
                
                if (SharedData.gAtribuiResponsavelServico)
                {
                    etapaObj.IdResponsavel = IdResponsavel;
                }
            }

            if (listaProximaEtapa.Count > 0)
            {
                DataAccess.RegistrarFluxoServicoLote(listaProximaEtapa, SistemaLog);
            }
        }

        public static string FormatarValorCampo(string campoDominio, string nmvalor)
        {
            CultureInfo Cultura = TratamentoLinguagem.BuscarLinguagem("PT-BR");
            
            if (nmvalor != "")
            {
                nmvalor = nmvalor.Trim();
                if (nmvalor != null && nmvalor != "")
                {
                    if (campoDominio.ToUpper() == "CNPJ")
                    {
                        #region [ CNPJ ]
                        if (TratarNumero.ConverterMoeda(nmvalor) != "")
                        {
                            nmvalor = TratarNumero.ConverterMoeda(nmvalor);
                            nmvalor = nmvalor.Substring(0, nmvalor.IndexOf(',')).PadLeft(14, '0');
                        }
                        try
                        {
                            nmvalor = Convert.ToInt64(nmvalor.Replace(".", "").Replace("-", "").Replace("/", "").Replace(" ", "")).ToString().PadLeft(14, '0');
                        }
                        catch { nmvalor = ""; }

                        if (nmvalor != "")
                        {
                            if (nmvalor.Length <= 14)
                            {
                                string valorCNPJ = nmvalor.PadLeft(11, '0');
                                if (Mobios.ValidaCNPJ.IsCnpj(valorCNPJ))
                                {
                                    nmvalor = valorCNPJ;
                                }
                                else
                                {
                                    nmvalor = "";
                                }
                            }
                        }
                        #endregion
                    }
                    else if (campoDominio.ToUpper() == "CPF")
                    {
                        #region [ CPF ]
                        if (TratarNumero.ConverterMoeda(nmvalor) != "")
                        {
                            nmvalor = TratarNumero.ConverterMoeda(nmvalor);
                            nmvalor = nmvalor.Substring(0, nmvalor.IndexOf(',')).PadLeft(11, '0');
                        }
                        try
                        {
                            nmvalor = Convert.ToInt64(nmvalor.Replace(".", "").Replace("-", "").Replace("/", "").Replace(" ", "")).ToString().PadLeft(11, '0');
                        }
                        catch { nmvalor = ""; }

                        if (nmvalor != "")
                        {
                            if (nmvalor.Length <= 11)
                            {
                                string valorCPF = nmvalor.PadLeft(11, '0');
                                if (Mobios.ValidaCPF.IsCpf(valorCPF))
                                {
                                    nmvalor = valorCPF;
                                }
                                else
                                {
                                    nmvalor = "";
                                }
                            }
                        }
                        #endregion
                    }
                    else if (campoDominio.ToUpper() == "CPF/CNPJ")
                    {
                        #region [ CPF/CNPJ ]
                        if (TratarNumero.ConverterMoeda(nmvalor) != "")
                        {
                            nmvalor = TratarNumero.ConverterMoeda(nmvalor);
                            nmvalor = nmvalor.Substring(0, nmvalor.IndexOf(','));
                        }
                        try
                        {
                            nmvalor = Convert.ToInt64(nmvalor.Replace(".", "").Replace("-", "").Replace("/", "").Replace(" ", "")).ToString().PadLeft(11, '0');
                        }
                        catch { nmvalor = ""; }

                        if (nmvalor != "")
                        {
                            bool validado = false;
                            if (nmvalor.Length <= 11)
                            {
                                string valorCPF = nmvalor.PadLeft(11, '0');
                                if (Mobios.ValidaCPF.IsCpf(valorCPF))
                                {
                                    nmvalor = valorCPF;
                                    validado = true;
                                }
                            }
                            else if (nmvalor.Length <= 14)
                            {
                                string valorCNPJ = nmvalor.PadLeft(14, '0');
                                if (Mobios.ValidaCNPJ.IsCnpj(valorCNPJ))
                                {
                                    nmvalor = valorCNPJ;
                                    validado = true;
                                }
                            }
                            if (validado == false)
                            {
                                nmvalor = "";
                            }
                        }
                        #endregion
                    }
                    else if ((campoDominio.ToUpper() == "DATA") || (campoDominio.ToUpper() == "DATAHOJE") || (campoDominio.ToUpper() == "DATAPASSADA") || (campoDominio.ToUpper() == "DATAFUTURA"))
                    {
                        nmvalor = Convert.ToDateTime(nmvalor.Replace("T", " "), Cultura).ToString("dd/MM/yyyy");
                    }
                    else if (campoDominio.ToUpper() == "DATAHORA")
                    {

                        nmvalor = Convert.ToDateTime(nmvalor.Replace("T", " "), Cultura).ToString("dd/MM/yyyy HH:mm:ss");
                    }
                    else if (campoDominio.ToUpper() == "NUMERICO")
                    {
                        nmvalor = TratarNumero.ConverterDecimal(nmvalor);
                        nmvalor = nmvalor.Substring(0, nmvalor.IndexOf(','));
                    }
                    else if (campoDominio.ToUpper() == "MOEDA")
                    {
                        if (nmvalor != null && nmvalor != "")
                            nmvalor = TratarNumero.ConverterMoeda(nmvalor);
                    }
                    else if (campoDominio.ToUpper() == "DECIMAL")
                    {
                        nmvalor = TratarNumero.ConverterDecimal(nmvalor);
                    }
                }
            }
            return nmvalor;
        }

        public static Tuple<Boolean, string> ValidarTIPOSCampos(List<Campos> listaEstrutura, TabControl tabControl = null, List<CamposTabela> camposTabela = null)
        {
            Boolean camposValidos = true;
            string my_regular_expression = "";
            string camposInvalidos = "Preenha com os tipos corretos os campos descritos abaixo:" + System.Environment.NewLine;

            foreach (Campos validaObrigatorio in listaEstrutura)
            {
                string TIPO = validaObrigatorio.CampoTipo.ToUpper().Trim();
                string DOMINIO = validaObrigatorio.CampoDominio.ToUpper().Trim();

                string TEXTO = "";
                if (TIPO == "TEXTBOX")
                {
                    #region [ TextBox ]

                    if (tabControl != null)
                    {
                        TEXTO = tabControl.TabPages[validaObrigatorio.CampoTab].Controls[validaObrigatorio.CampoNome].Text.Trim();
                    }
                    else
                    {
                        TEXTO = validaObrigatorio.ValorCampo.Trim();
                    }

                    if (DOMINIO == "NUMERICO")
                    {
                        #region [ Numerico ]
                        if (TEXTO != null && TEXTO != "")
                        {
                            my_regular_expression = @"^[-+]?([0-9]*\,[0-9]+|[0-9]+)$";
                            Match match = Regex.Match(TEXTO, my_regular_expression);

                            if (match.Success)
                            {

                            }
                            else
                            {
                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [ #.##0,00].";
                                camposValidos = false;
                            }
                        }
                        #endregion
                    }
                    else if (DOMINIO == "MOEDA")
                    {
                        #region [ Moeda ]
                        if (TEXTO != null && TEXTO != "")
                        {
                            string teste = TEXTO;
                            teste = teste.Replace(".", "").Replace(",", ""); //deve ser um número sem virgula e sem pontos

                            my_regular_expression = @"^[-+]?([0-9]*\,[0-9]|[0-9]+)$";
                            Match match = Regex.Match(teste, my_regular_expression);

                            if (match.Success)
                            {
                                string textoValidado = TratarNumero.ConverterMoeda(TEXTO);
                                if (textoValidado == "")
                                {
                                    camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser um valor em formato Moeda.";
                                    camposValidos = false;
                                }
                                
                            }
                            else
                            {
                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [ #.##0,00].";
                                camposValidos = false;
                            }
                            
                            
                        }
                        #endregion
                    }
                    else if (DOMINIO == "DECIMAL")
                    {
                        #region [ Decimal ]
                        if (TEXTO != null && TEXTO != "")
                        {
                            string textoValidado = TratarNumero.ConverterDecimal(TEXTO);
                            if (textoValidado == "")
                            {
                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser um número.";
                                camposValidos = false;
                            }
                        }
                        #endregion
                    }
                    else if (DOMINIO == "NUMERICO_CC")
                    {
                        #region [ Conta Corrente ]
                        if (TEXTO != null && TEXTO != "")
                        {


                            my_regular_expression = @"^\d{5}$";
                            Match match = Regex.Match(TEXTO, my_regular_expression);
                            if (!match.Success)
                            {
                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "]  deve ter 5 dígitos.";
                                camposValidos = false;
                            }

                        }
                        #endregion
                    }
                    else if (DOMINIO == "NUMERICO_AG")
                    {
                        #region [ Agencia ]
                        if (TEXTO != null && TEXTO != "")
                        {
                            my_regular_expression = @"^\d{4}$";
                            Match match = Regex.Match(TEXTO, my_regular_expression);
                            if (!match.Success)
                            {
                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ter 4 dígitos.";
                                camposValidos = false;
                            }
                        }
                        #endregion
                    }
                    else if (DOMINIO == "NUMERICO_DAC")
                    {
                        #region [ DAC ]
                        if (TEXTO != null && TEXTO != "")
                        {
                            my_regular_expression = @"^\d{1}$";
                            Match match = Regex.Match(TEXTO, my_regular_expression);
                            if (!match.Success)
                            {
                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ter 1 dígito.";
                                camposValidos = false;
                            }
                        }
                        #endregion
                    }
                    else if (DOMINIO == "NUMERICO_CC_DAC")
                    {
                        #region [ Conta DAC ]
                        if (TEXTO != null && TEXTO != "" && TEXTO.Trim() != "-")
                        {
                            my_regular_expression = @"^\d{5}\-\d{1}$";
                            Match match = Regex.Match(TEXTO, my_regular_expression);
                            if (!match.Success)
                            {
                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser do tipo [00000-0].";
                                camposValidos = false;
                            }

                        }
                        #endregion
                    }

                    else if (DOMINIO == "DATA")
                    {
                        #region [ Data ]
                        if (TEXTO != null && TEXTO != "")
                        {
                            TEXTO = TEXTO.Replace("/", "").Replace("00:00:00", "").Replace(" ", "").Trim();
                            //TIPO data = DDMMAAAA
                            DateTimeStyles dateStyle = DateTimeStyles.None;
                            DateTime dateOut;
                            //CultureInfo culture = CultureInfo.CreateSpecificCulture("pt-BR");
                            CultureInfo culture = TratamentoLinguagem.BuscarLinguagem("PT-BR");
                            if (TEXTO.Length != 8)
                            {
                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa].";
                                camposValidos = false;
                            }
                            else
                            {
                                //validar data
                                string minhadata = TEXTO.Substring(0, 2);
                                minhadata += "/" + TEXTO.Substring(2, 2);
                                minhadata += "/" + TEXTO.Substring(4, 4);

                                if (DateTime.TryParse(minhadata, culture, dateStyle, out dateOut))
                                {
                                    my_regular_expression = @"^((0[1-9]|[12]\d)\/(0[1-9]|1[0-2])|30\/(0[13-9]|1[0-2])|31\/(0[13578]|1[02]))\/\d{4}$";
                                    Match match = Regex.Match(dateOut.ToString("dd/MM/yyyy"), my_regular_expression);

                                    if (match.Success)
                                    {

                                    }
                                    else
                                    {
                                        camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + minhadata + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa]";
                                        camposValidos = false;
                                    }
                                }
                                else
                                {
                                    camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + minhadata + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa].";
                                    camposValidos = false;
                                }
                            }
                        }
                        #endregion
                    }
                    else if (DOMINIO == "DATAHORA")
                    {
                        #region [ Data ]
                        if (TEXTO != null && TEXTO != "")
                        {
                            TEXTO = TEXTO.Replace("/", "").Replace(":", "").Replace(" ", "").Trim();
                            //TIPO data = DDMMAAAAHHMMSS
                            DateTimeStyles dateStyle = DateTimeStyles.None;
                            DateTime dateOut;
                            //CultureInfo culture = CultureInfo.CreateSpecificCulture("pt-BR");
                            CultureInfo culture = TratamentoLinguagem.BuscarLinguagem("PT-BR");
                            if (TEXTO.Length != 12)
                            {
                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa].";
                                camposValidos = false;
                            }
                            else
                            {
                                //validar data
                                string minhadata = TEXTO.Substring(0, 2);
                                minhadata += "/" + TEXTO.Substring(2, 2);
                                minhadata += "/" + TEXTO.Substring(4, 4);
                                minhadata += " " + TEXTO.Substring(6, 2);
                                minhadata += ":" + TEXTO.Substring(8, 2);

                                if (DateTime.TryParse(minhadata, culture, dateStyle, out dateOut))
                                {
                                    //my_regular_expression = @"^((0[1-9]|[12]\d)\/(0[1-9]|1[0-2])|30\/(0[13-9]|1[0-2])|31\/(0[13578]|1[02]))\/\d{4}$";
                                    //Match match = Regex.Match(dateOut.ToString("dd/MM/yyyy"), my_regular_expression);

                                    //if (match.Success)
                                    //{

                                    //}
                                    //else
                                    //{
                                        //camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + minhadata + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa]";
                                        //camposValidos = false;
                                    //}
                                }
                                else
                                {
                                    camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + minhadata + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa].";
                                    camposValidos = false;
                                }
                            }
                        }
                        #endregion
                    }
                    else if (DOMINIO == "DATAHOJE")
                    {
                        #region [ Data Hoje ]
                        if (TEXTO != null && TEXTO != "")
                        {
                            TEXTO = TEXTO.Replace("/", "").Replace("00:00:00", "").Replace(" ", "").Trim();
                            DateTimeStyles dateStyle = DateTimeStyles.None;
                            DateTime dateOut;
                            //CultureInfo culture = CultureInfo.CreateSpecificCulture("pt-BR");
                            CultureInfo culture = TratamentoLinguagem.BuscarLinguagem("PT-BR");
                            //TIPO data = DDMMAAAA
                            if (TEXTO.Length != 8)
                            {
                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa].";
                                camposValidos = false;
                            }
                            else
                            {
                                //validar data
                                string minhadata = TEXTO.Substring(0, 2);
                                minhadata += "/" + TEXTO.Substring(2, 2);
                                minhadata += "/" + TEXTO.Substring(4, 4);



                                //DateTime minhadata2 = Convert.ToDateTime(minhadata);

                                if (DateTime.TryParse(minhadata, culture, dateStyle, out dateOut))
                                {
                                    my_regular_expression = @"^((0[1-9]|[12]\d)\/(0[1-9]|1[0-2])|30\/(0[13-9]|1[0-2])|31\/(0[13578]|1[02]))\/\d{4}$";
                                    Match match = Regex.Match(minhadata, my_regular_expression);

                                    if (match.Success)
                                    {
                                        if (dateOut != DateTime.Today)
                                        {
                                            camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + minhadata + "] deve ser a data de hoje.";
                                            camposValidos = false;
                                        }

                                    }
                                    else
                                    {
                                        camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa]";
                                        camposValidos = false;
                                    }
                                }
                                else
                                {
                                    camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa]";
                                    camposValidos = false;
                                }

                            }


                        }
                        #endregion
                    }
                    else if (DOMINIO == "DATAPASSADA")
                    {
                        #region [ Data Passada ]
                        if (TEXTO != null && TEXTO != "")
                        {
                            TEXTO = TEXTO.Replace("/", "").Replace("00:00:00", "").Replace(" ", "").Trim();
                            DateTimeStyles dateStyle = DateTimeStyles.None;
                                DateTime dateOut;
                                //CultureInfo culture = CultureInfo.CreateSpecificCulture("pt-BR");
                                CultureInfo culture = TratamentoLinguagem.BuscarLinguagem("PT-BR");
                            //TIPO data = DDMMAAAA
                            if (TEXTO.Length != 8)
                            {
                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa].";
                                camposValidos = false;
                            }
                            else
                            {
                                //validar data
                                string minhadata = TEXTO.Substring(0, 2);
                                minhadata += "/" + TEXTO.Substring(2, 2);
                                minhadata += "/" + TEXTO.Substring(4, 4);

                                

                                //DateTime minhadata2 = Convert.ToDateTime(minhadata);

                                if (DateTime.TryParse(minhadata, culture, dateStyle, out dateOut))
                                {
                                    my_regular_expression = @"^((0[1-9]|[12]\d)\/(0[1-9]|1[0-2])|30\/(0[13-9]|1[0-2])|31\/(0[13578]|1[02]))\/\d{4}$";
                                    Match match = Regex.Match(minhadata, my_regular_expression);

                                    if (match.Success)
                                    {
                                        if (dateOut > DateTime.Today)
                                        {
                                            camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + minhadata + "] não pode ser data futura.";
                                            camposValidos = false;
                                        }

                                    }
                                    else
                                    {
                                        camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa]";
                                        camposValidos = false;
                                    }
                                }
                                else
                                {
                                    camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa]";
                                    camposValidos = false;
                                }

                            }


                        }
                        #endregion
                    }
                    else if (DOMINIO == "DATAFUTURA")
                    {
                        #region [ Data Futura ]
                        if (TEXTO != null && TEXTO != "")
                        {
                            TEXTO = TEXTO.Replace("/", "").Replace("00:00:00", "").Replace(" ", "").Trim();
                            DateTimeStyles dateStyle = DateTimeStyles.None;
                            DateTime dateOut;
                            //CultureInfo culture = CultureInfo.CreateSpecificCulture("pt-BR");
                            CultureInfo culture = TratamentoLinguagem.BuscarLinguagem("PT-BR");
                            //TIPO data = DDMMAAAA
                            TEXTO = TEXTO.Replace("00:00:00", "").Trim();
                            if (TEXTO.Length != 8)
                            {
                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa].";
                                camposValidos = false;
                            }
                            else
                            {
                                //validar data
                                string minhadata = TEXTO.Substring(0, 2);
                                minhadata += "/" + TEXTO.Substring(2, 2);
                                minhadata += "/" + TEXTO.Substring(4, 4);



                                //DateTime minhadata2 = Convert.ToDateTime(minhadata);

                                if (DateTime.TryParse(minhadata, culture, dateStyle, out dateOut))
                                {
                                    my_regular_expression = @"^((0[1-9]|[12]\d)\/(0[1-9]|1[0-2])|30\/(0[13-9]|1[0-2])|31\/(0[13578]|1[02]))\/\d{4}$";
                                    Match match = Regex.Match(minhadata, my_regular_expression);

                                    if (match.Success)
                                    {
                                        if (dateOut < DateTime.Today)
                                        {
                                            camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + minhadata + "] não pode ser data passada.";
                                            camposValidos = false;
                                        }

                                    }
                                    else
                                    {
                                        camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa]";
                                        camposValidos = false;
                                    }
                                }
                                else
                                {
                                    camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa]";
                                    camposValidos = false;
                                }

                            }


                        }
                        #endregion
                    }
                    else if (DOMINIO == "CNPJ")
                    {
                        #region [ CNPJ ]
                        if (TEXTO != null && TEXTO != "")
                        {

                            //TIPO CNPJ = 14 dígitos
                            TEXTO = TEXTO.Replace(".", "").Replace("-", "").Replace("/", "");
                            //if (TEXTO.Length != 14)
                            //{
                            //    TEXTO = TEXTO.PadLeft(14, '0');
                            //}

                            if (TEXTO.Length != 14)
                            {
                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + "[14 dígitos].";
                                camposValidos = false;
                            }
                            else if (Mobios.ValidaCNPJ.IsCnpj(TEXTO) == false)
                            {

                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] inválido. Verfique o número digitado.";
                                camposValidos = false;
                            }
                            else
                            {

                            }

                            /*my_regular_expression = @"^\d{3}.?\d{3}.?\d{3}/?\d{3}-?\d{2}$";
                            Match match = Regex.Match(TEXTO, my_regular_expression);

                            if (match.Success)
                            {
                                
                            }
                            else
                            {
                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " deve ser do tipo " + DOMINIO;
                                camposValidos=false;
                            }
                             * */
                        }
                        #endregion
                    }
                    else if (DOMINIO == "CPF")
                    {
                        #region [ CPF ]
                        TEXTO = TEXTO.Replace(".", "").Replace("-", "").Replace("/", "");
                        if (TEXTO != null && TEXTO != "")
                        {
                            if (TEXTO.Length != 11)
                            {
                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [11 dígitos].";
                                camposValidos = false;
                            }
                            else if (Mobios.ValidaCPF.IsCpf(TEXTO) == false)
                            {

                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] inválido. Verificar o número digitado.";
                                camposValidos = false;
                            }
                            else
                            {

                            }

                            /*my_regular_expression = @"^\d{3}\.?\d{3}\.?\d{3}\-?\d{2}$";
                            Match match = Regex.Match(TEXTO, my_regular_expression);

                            if (match.Success)
                            {
                                
                            }
                            else
                            {
                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " deve ser do tipo " + DOMINIO;
                                camposValidos=false;
                            }*/
                        }
                        #endregion
                    }
                    else if (DOMINIO == "CPF/CNPJ")
                    {
                        #region [ CPF ]
                        TEXTO = TEXTO.Replace(".", "").Replace("-", "").Replace("/", "");
                        if (TEXTO != null && TEXTO != "")
                        {
                            //TIPO CPF = 11 dígitos
                            if (TEXTO.Length != 11 && TEXTO.Length != 14)
                            {
                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [11 ou 14 dígitos].";
                                camposValidos = false;
                            }
                            else if (Mobios.ValidaCPF.IsCpf(TEXTO) == false && Mobios.ValidaCNPJ.IsCnpj(TEXTO) == false)
                            {
                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] inválido. Verificar o número digitado.";
                                camposValidos = false;
                            }
                            else
                            {
                            }
                        }
                        #endregion
                    }
                    else if (DOMINIO == "CEP")
                    {
                        #region [ CEP ]
                        if (TEXTO != null && TEXTO != "")
                        {
                            /* my_regular_expression = @"^\d{5}\-?\d{3}$";
                             Match match = Regex.Match(TEXTO, my_regular_expression);

                             if (match.Success)
                             {
                                
                             }
                             else
                             {
                                 camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " deve ser do tipo " + DOMINIO;
                                 camposValidos=false;
                             }*/
                        }
                        #endregion
                    }
                    else if (DOMINIO == "HORA")
                    {
                        #region [ Hora ]
                        if (TEXTO != null && TEXTO != "")
                        {
                            string minhahora = TEXTO.Substring(0, 2);
                            minhahora += ":" + TEXTO.Substring(2, 2);

                            my_regular_expression = @"^([0-1][0-9]|[2][0-3]):[0-5][0-9]$";
                            Match match = Regex.Match(minhahora, my_regular_expression);

                            if (match.Success)
                            {

                            }
                            else
                            {
                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [hh:mm].";
                                camposValidos = false;
                            }
                        }
                        #endregion
                    }
                    else if (DOMINIO == "EMAIL")
                    {
                        #region [ Email ]
                        if (TEXTO != null && TEXTO != "")
                        {
                            my_regular_expression = @"^([\w\-]+\.)*[\w\- ]+@([\w\- ]+\.)+([\w\-]{2,3})$";
                            Match match = Regex.Match(TEXTO, my_regular_expression);

                            if (match.Success)
                            {

                            }
                            else
                            {
                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [nome@dominio.com].";
                                camposValidos = false;
                            }
                        }
                        #endregion
                    }
                    else
                    {
                        // sem validação
                    }
                    #endregion
                }
                else if (TIPO == "MASKEDTEXTBOX")
                {
                    #region [ Masked Text Box ]

                    if (tabControl != null)
                    {
                        TEXTO = tabControl.TabPages[validaObrigatorio.CampoTab].Controls[validaObrigatorio.CampoNome].Text.Trim();
                    }
                    else
                    {
                        TEXTO = validaObrigatorio.ValorCampo.Trim();
                    }

                    if (TEXTO != null && TEXTO != "" && validaObrigatorio.CampoBatimento != null && validaObrigatorio.CampoBatimento != "")
                    {
                        my_regular_expression = validaObrigatorio.CampoBatimento;
                        Match match = Regex.Match(TEXTO, my_regular_expression);
                        if (!match.Success)
                        {
                            camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ter formato " + validaObrigatorio.CampoDominio;
                            camposValidos = false;
                        }
                    }
                    #endregion
                }
                else if (TIPO == "TABELA" || TIPO == "TABELAGERAL")
                {
                    #region [ Valida Campos Tabela ]
                    if (camposTabela != null && camposTabela.Count > 0)
                    {
                        if (tabControl != null)
                        {
                            DataGridView valueGrid = new DataGridView();
                            valueGrid = (DataGridView)tabControl.TabPages[validaObrigatorio.CampoTab].Controls[validaObrigatorio.CampoNome];
                            
                            #region [ Valida campos chave ]
                            List<CamposTabela> camposTblChave = camposTabela.FindAll(n => n.ID_Campo == validaObrigatorio.ID_Campo && n.Chave == true);
                            List<string> colunasChave = new List<string>();
                            if (camposTblChave.Count > 0)
                                colunasChave = camposTblChave.Select(n => n.CampoNome).Distinct().ToList();

                            bool validadoChave = true;
                            string ColunasChave = "";
                            foreach (string c in colunasChave)
                            {
                                if (ColunasChave != "")
                                    ColunasChave += "|";

                                    ColunasChave += c;

                                if (!valueGrid.Columns.Contains(c))
                                {
                                    validadoChave = false;
                                }
                            }

                            if (colunasChave.Count > 0 && validadoChave)
                            {
                                List<string> ValoresChave = new List<string>();
                                foreach (DataGridViewRow dtrow in valueGrid.Rows)
                                {
                                    if (!dtrow.IsNewRow)
                                    {
                                        bool valorBranco = false;
                                        string vlrTemp = "";

                                        foreach (string c in colunasChave)
                                        {
                                            if (vlrTemp != "")
                                                vlrTemp += "|||";

                                            if (dtrow.Cells[c].Value != null && dtrow.Cells[c].Value != "")
                                                vlrTemp += dtrow.Cells[c].Value.ToString().Trim();
                                            else
                                                valorBranco = true;
                                        }

                                        if (valorBranco)
                                        {
                                            camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + ColunasChave + " são valores chave que não podem ficar em branco";
                                            camposValidos = false;
                                            break;
                                        }

                                        if (ValoresChave.Contains(vlrTemp))
                                        {
                                            camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + ColunasChave + " são valores chave que não podem coincidir";
                                            camposValidos = false;
                                            break;
                                        }
                                        else
                                        {
                                            ValoresChave.Add(vlrTemp);
                                        }
                                    }
                                }
                            }
                            else
                            {
                                if (!validadoChave)
                                {
                                    camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + ColunasChave + " valores chave que não podem duplicar";
                                    camposValidos = false;
                                }
                            }
                            #endregion

                            foreach (DataGridViewColumn dtcolumn in valueGrid.Columns)
                            {
                                CamposTabela camposTbl = camposTabela.Find(n => n.ID_Campo == validaObrigatorio.ID_Campo && n.CampoNome == dtcolumn.Name);

                                if (camposTbl != null)
                                {
                                    #region [ Valores Únicos ]
                                    if (camposTbl.ValoresUnicos)
                                    {
                                        List<string> ValoresUnicos = new List<string>();
                                        foreach (DataGridViewRow dtrow in valueGrid.Rows)
                                        {
                                            if (!dtrow.IsNewRow)
                                            {
                                                string vlrTemp = "";
                                                if (dtrow.Cells[dtcolumn.Name].Value != null)
                                                    vlrTemp = dtrow.Cells[dtcolumn.Name].Value.ToString().Trim();


                                                if (ValoresUnicos.Contains(vlrTemp))
                                                {
                                                    camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " não aceita duplicidade";
                                                    camposValidos = false;
                                                    break;
                                                }
                                                else
                                                {
                                                    ValoresUnicos.Add(vlrTemp);
                                                }
                                            }
                                        }
                                    }
                                    #endregion

                                    #region [ Valida Formatação dos Valores ]
                                    foreach (DataGridViewRow dtrow in valueGrid.Rows)
                                    {
                                        if (!dtrow.IsNewRow)
                                        {
                                            TEXTO = "";
                                            if (valueGrid[dtcolumn.Index, dtrow.Index].Value != null)
                                                TEXTO = valueGrid[dtcolumn.Index, dtrow.Index].Value.ToString().Replace("_", " ").Trim();

                                            if (camposTbl.CampoObrigatorio && (TEXTO == null || TEXTO == ""))
                                            {
                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " é obrigatório";
                                                camposValidos = false;
                                                break;
                                            }
                                            else if (TEXTO != null || TEXTO.Trim() != "")
                                            {
                                                TIPO = camposTbl.CampoTipo.ToUpper().Trim();
                                                DOMINIO = camposTbl.CampoDominio.ToUpper().Trim();
                                                if (TIPO == "TEXTBOX")
                                                {
                                                    #region [ TextBox ]
                                                    if (DOMINIO == "NUMERICO")
                                                    {
                                                        #region [ Numerico ]
                                                        if (TEXTO != null && TEXTO != "")
                                                        {
                                                            my_regular_expression = @"^[-+]?([0-9]*\,[0-9]+|[0-9]+)$";
                                                            Match match = Regex.Match(TEXTO, my_regular_expression);

                                                            if (!match.Success)
                                                            {
                                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [ #.##0,00].";
                                                                camposValidos = false;
                                                                break;
                                                            }
                                                        }
                                                        #endregion
                                                    }
                                                    else if (DOMINIO == "MOEDA")
                                                    {
                                                        #region [ Moeda ]
                                                        if (TEXTO != null && TEXTO != "")
                                                        {
                                                            string teste = TEXTO;
                                                            teste = teste.Replace(".", "").Replace(",", ""); //deve ser um número sem virgula e sem pontos

                                                            my_regular_expression = @"^[-+]?([0-9]*\,[0-9]|[0-9]+)$";
                                                            Match match = Regex.Match(teste, my_regular_expression);

                                                            if (match.Success)
                                                            {
                                                                string textoValidado = TratarNumero.ConverterMoeda(TEXTO);
                                                                if (textoValidado == "")
                                                                {
                                                                    camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] deve ser um valor em formato Moeda.";
                                                                    camposValidos = false;
                                                                    break;
                                                                }

                                                            }
                                                            else
                                                            {
                                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [ #.##0,00].";
                                                                camposValidos = false;
                                                                break;
                                                            }


                                                        }
                                                        #endregion
                                                    }
                                                    else if (DOMINIO == "DECIMAL")
                                                    {
                                                        #region [ Decimal ]
                                                        if (TEXTO != null && TEXTO != "")
                                                        {
                                                            string textoValidado = TratarNumero.ConverterDecimal(TEXTO);
                                                            if (textoValidado == "")
                                                            {
                                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] deve ser um número.";
                                                                camposValidos = false;
                                                                break;
                                                            }
                                                        }
                                                        #endregion
                                                    }
                                                    else if (DOMINIO == "NUMERICO_CC")
                                                    {
                                                        #region [ Conta Corrente ]
                                                        if (TEXTO != null && TEXTO != "")
                                                        {


                                                            my_regular_expression = @"^\d{5}$";
                                                            Match match = Regex.Match(TEXTO, my_regular_expression);
                                                            if (!match.Success)
                                                            {
                                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "]  deve ter 5 dígitos.";
                                                                camposValidos = false;
                                                                break;
                                                            }

                                                        }
                                                        #endregion
                                                    }
                                                    else if (DOMINIO == "NUMERICO_AG")
                                                    {
                                                        #region [ Agencia ]
                                                        if (TEXTO != null && TEXTO != "")
                                                        {
                                                            my_regular_expression = @"^\d{4}$";
                                                            Match match = Regex.Match(TEXTO, my_regular_expression);
                                                            if (!match.Success)
                                                            {
                                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] deve ter 4 dígitos.";
                                                                camposValidos = false;
                                                                break;
                                                            }
                                                        }
                                                        #endregion
                                                    }
                                                    else if (DOMINIO == "NUMERICO_DAC")
                                                    {
                                                        #region [ DAC ]
                                                        if (TEXTO != null && TEXTO != "")
                                                        {
                                                            my_regular_expression = @"^\d{1}$";
                                                            Match match = Regex.Match(TEXTO, my_regular_expression);
                                                            if (!match.Success)
                                                            {
                                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] deve ter 1 dígito.";
                                                                camposValidos = false;
                                                                break;
                                                            }
                                                        }
                                                        #endregion
                                                    }
                                                    else if (DOMINIO == "NUMERICO_CC_DAC")
                                                    {
                                                        #region [ Conta DAC ]
                                                        if (TEXTO != null && TEXTO != "" && TEXTO.Trim() != "-")
                                                        {
                                                            my_regular_expression = @"^\d{5}\-\d{1}$";
                                                            Match match = Regex.Match(TEXTO, my_regular_expression);
                                                            if (!match.Success)
                                                            {
                                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] deve ser do tipo [00000-0].";
                                                                camposValidos = false;
                                                                break;
                                                            }

                                                        }
                                                        #endregion
                                                    }
                                                    else if (DOMINIO == "DATA")
                                                    {
                                                        #region [ Data ]
                                                        if (TEXTO != null && TEXTO != "")
                                                        {
                                                            TEXTO = TEXTO.Replace("/", "").Replace("00:00:00", "").Replace(" ", "").Trim();
                                                            //TIPO data = DDMMAAAA
                                                            DateTimeStyles dateStyle = DateTimeStyles.None;
                                                            DateTime dateOut;
                                                            //CultureInfo culture = CultureInfo.CreateSpecificCulture("pt-BR");
                                                            CultureInfo culture = TratamentoLinguagem.BuscarLinguagem("PT-BR");
                                                            if (TEXTO.Length != 8)
                                                            {
                                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa].";
                                                                camposValidos = false;
                                                                break;
                                                            }
                                                            else
                                                            {
                                                                //validar data
                                                                string minhadata = TEXTO.Substring(0, 2);
                                                                minhadata += "/" + TEXTO.Substring(2, 2);
                                                                minhadata += "/" + TEXTO.Substring(4, 4);

                                                                if (DateTime.TryParse(minhadata, culture, dateStyle, out dateOut))
                                                                {
                                                                    my_regular_expression = @"^((0[1-9]|[12]\d)\/(0[1-9]|1[0-2])|30\/(0[13-9]|1[0-2])|31\/(0[13578]|1[02]))\/\d{4}$";
                                                                    Match match = Regex.Match(dateOut.ToString("dd/MM/yyyy"), my_regular_expression);

                                                                    if (match.Success)
                                                                    {

                                                                    }
                                                                    else
                                                                    {
                                                                        camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + minhadata + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa]";
                                                                        camposValidos = false;
                                                                        break;
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + minhadata + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa].";
                                                                    camposValidos = false;
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                        #endregion
                                                    }
                                                    else if (DOMINIO == "DATAHORA")
                                                    {
                                                        #region [ Data ]
                                                        if (TEXTO != null && TEXTO != "")
                                                        {
                                                            TEXTO = TEXTO.Replace("/", "").Replace(":", "").Replace(" ", "").Trim();
                                                            //TIPO data = DDMMAAAAHHMMSS
                                                            DateTimeStyles dateStyle = DateTimeStyles.None;
                                                            DateTime dateOut;
                                                            //CultureInfo culture = CultureInfo.CreateSpecificCulture("pt-BR");
                                                            CultureInfo culture = TratamentoLinguagem.BuscarLinguagem("PT-BR");
                                                            if (TEXTO.Length != 12)
                                                            {
                                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa].";
                                                                camposValidos = false;
                                                                break;
                                                            }
                                                            else
                                                            {
                                                                //validar data
                                                                string minhadata = TEXTO.Substring(0, 2);
                                                                minhadata += "/" + TEXTO.Substring(2, 2);
                                                                minhadata += "/" + TEXTO.Substring(4, 4);
                                                                minhadata += " " + TEXTO.Substring(6, 2);
                                                                minhadata += ":" + TEXTO.Substring(8, 2);

                                                                if (DateTime.TryParse(minhadata, culture, dateStyle, out dateOut))
                                                                {
                                                                    //my_regular_expression = @"^((0[1-9]|[12]\d)\/(0[1-9]|1[0-2])|30\/(0[13-9]|1[0-2])|31\/(0[13578]|1[02]))\/\d{4}$";
                                                                    //Match match = Regex.Match(dateOut.ToString("dd/MM/yyyy"), my_regular_expression);

                                                                    //if (match.Success)
                                                                    //{

                                                                    //}
                                                                    //else
                                                                    //{
                                                                    //camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + minhadata + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa]";
                                                                    //camposValidos = false;
                                                                    //}
                                                                }
                                                                else
                                                                {
                                                                    camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + minhadata + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa].";
                                                                    camposValidos = false;
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                        #endregion
                                                    }
                                                    else if (DOMINIO == "DATAHOJE")
                                                    {
                                                        #region [ Data Hoje ]
                                                        if (TEXTO != null && TEXTO != "")
                                                        {
                                                            TEXTO = TEXTO.Replace("/", "").Replace("00:00:00", "").Replace(" ", "").Trim();
                                                            DateTimeStyles dateStyle = DateTimeStyles.None;
                                                            DateTime dateOut;
                                                            //CultureInfo culture = CultureInfo.CreateSpecificCulture("pt-BR");
                                                            CultureInfo culture = TratamentoLinguagem.BuscarLinguagem("PT-BR");
                                                            //TIPO data = DDMMAAAA
                                                            if (TEXTO.Length != 8)
                                                            {
                                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa].";
                                                                camposValidos = false;
                                                                break;
                                                            }
                                                            else
                                                            {
                                                                //validar data
                                                                string minhadata = TEXTO.Substring(0, 2);
                                                                minhadata += "/" + TEXTO.Substring(2, 2);
                                                                minhadata += "/" + TEXTO.Substring(4, 4);



                                                                //DateTime minhadata2 = Convert.ToDateTime(minhadata);

                                                                if (DateTime.TryParse(minhadata, culture, dateStyle, out dateOut))
                                                                {
                                                                    my_regular_expression = @"^((0[1-9]|[12]\d)\/(0[1-9]|1[0-2])|30\/(0[13-9]|1[0-2])|31\/(0[13578]|1[02]))\/\d{4}$";
                                                                    Match match = Regex.Match(minhadata, my_regular_expression);

                                                                    if (match.Success)
                                                                    {
                                                                        if (dateOut != DateTime.Today)
                                                                        {
                                                                            camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + minhadata + "] deve ser a data de hoje.";
                                                                            camposValidos = false;
                                                                            break;
                                                                        }

                                                                    }
                                                                    else
                                                                    {
                                                                        camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa]";
                                                                        camposValidos = false;
                                                                        break;
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa]";
                                                                    camposValidos = false;
                                                                }

                                                            }


                                                        }
                                                        #endregion
                                                    }
                                                    else if (DOMINIO == "DATAPASSADA")
                                                    {
                                                        #region [ Data Passada ]
                                                        if (TEXTO != null && TEXTO != "")
                                                        {
                                                            TEXTO = TEXTO.Replace("/", "").Replace("00:00:00", "").Replace(" ", "").Trim();
                                                            DateTimeStyles dateStyle = DateTimeStyles.None;
                                                            DateTime dateOut;
                                                            //CultureInfo culture = CultureInfo.CreateSpecificCulture("pt-BR");
                                                            CultureInfo culture = TratamentoLinguagem.BuscarLinguagem("PT-BR");
                                                            //TIPO data = DDMMAAAA
                                                            if (TEXTO.Length != 8)
                                                            {
                                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa].";
                                                                camposValidos = false;
                                                                break;
                                                            }
                                                            else
                                                            {
                                                                //validar data
                                                                string minhadata = TEXTO.Substring(0, 2);
                                                                minhadata += "/" + TEXTO.Substring(2, 2);
                                                                minhadata += "/" + TEXTO.Substring(4, 4);



                                                                //DateTime minhadata2 = Convert.ToDateTime(minhadata);

                                                                if (DateTime.TryParse(minhadata, culture, dateStyle, out dateOut))
                                                                {
                                                                    my_regular_expression = @"^((0[1-9]|[12]\d)\/(0[1-9]|1[0-2])|30\/(0[13-9]|1[0-2])|31\/(0[13578]|1[02]))\/\d{4}$";
                                                                    Match match = Regex.Match(minhadata, my_regular_expression);

                                                                    if (match.Success)
                                                                    {
                                                                        if (dateOut > DateTime.Today)
                                                                        {
                                                                            camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + minhadata + "] não pode ser data futura.";
                                                                            camposValidos = false;
                                                                            break;
                                                                        }

                                                                    }
                                                                    else
                                                                    {
                                                                        camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa]";
                                                                        camposValidos = false;
                                                                        break;
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa]";
                                                                    camposValidos = false;
                                                                    break;
                                                                }

                                                            }


                                                        }
                                                        #endregion
                                                    }
                                                    else if (DOMINIO == "DATAFUTURA")
                                                    {
                                                        #region [ Data Futura ]
                                                        if (TEXTO != null && TEXTO != "")
                                                        {
                                                            TEXTO = TEXTO.Replace("/", "").Replace("00:00:00", "").Replace(" ", "").Trim();
                                                            DateTimeStyles dateStyle = DateTimeStyles.None;
                                                            DateTime dateOut;
                                                            //CultureInfo culture = CultureInfo.CreateSpecificCulture("pt-BR");
                                                            CultureInfo culture = TratamentoLinguagem.BuscarLinguagem("PT-BR");
                                                            //TIPO data = DDMMAAAA
                                                            TEXTO = TEXTO.Replace("00:00:00", "").Trim();
                                                            if (TEXTO.Length != 8)
                                                            {
                                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa].";
                                                                camposValidos = false;
                                                                break;
                                                            }
                                                            else
                                                            {
                                                                //validar data
                                                                string minhadata = TEXTO.Substring(0, 2);
                                                                minhadata += "/" + TEXTO.Substring(2, 2);
                                                                minhadata += "/" + TEXTO.Substring(4, 4);



                                                                //DateTime minhadata2 = Convert.ToDateTime(minhadata);

                                                                if (DateTime.TryParse(minhadata, culture, dateStyle, out dateOut))
                                                                {
                                                                    my_regular_expression = @"^((0[1-9]|[12]\d)\/(0[1-9]|1[0-2])|30\/(0[13-9]|1[0-2])|31\/(0[13578]|1[02]))\/\d{4}$";
                                                                    Match match = Regex.Match(minhadata, my_regular_expression);

                                                                    if (match.Success)
                                                                    {
                                                                        if (dateOut < DateTime.Today)
                                                                        {
                                                                            camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + minhadata + "] não pode ser data passada.";
                                                                            camposValidos = false;
                                                                            break;
                                                                        }

                                                                    }
                                                                    else
                                                                    {
                                                                        camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa]";
                                                                        camposValidos = false;
                                                                        break;
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [dd/mm/aaaa]";
                                                                    camposValidos = false;
                                                                    break;
                                                                }

                                                            }


                                                        }
                                                        #endregion
                                                    }
                                                    else if (DOMINIO == "CNPJ")
                                                    {
                                                        #region [ CNPJ ]
                                                        if (TEXTO != null && TEXTO != "")
                                                        {

                                                            //TIPO CNPJ = 14 dígitos
                                                            TEXTO = TEXTO.Replace(".", "").Replace("-", "").Replace("/", "");
                                                            //if (TEXTO.Length != 14)
                                                            //{
                                                            //    TEXTO = TEXTO.PadLeft(14, '0');
                                                            //}

                                                            if (TEXTO.Length != 14)
                                                            {
                                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + "[14 dígitos].";
                                                                camposValidos = false;
                                                                break;
                                                            }
                                                            else if (Mobios.ValidaCNPJ.IsCnpj(TEXTO) == false)
                                                            {

                                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] inválido. Verfique o número digitado.";
                                                                camposValidos = false;
                                                                break;
                                                            }
                                                            else
                                                            {

                                                            }

                                                            /*my_regular_expression = @"^\d{3}.?\d{3}.?\d{3}/?\d{3}-?\d{2}$";
                                                            Match match = Regex.Match(TEXTO, my_regular_expression);

                                                            if (match.Success)
                                                            {
                                
                                                            }
                                                            else
                                                            {
                                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " deve ser do tipo " + DOMINIO;
                                                                camposValidos=false;
                                                            }
                                                             * */
                                                        }
                                                        #endregion
                                                    }
                                                    else if (DOMINIO == "CPF")
                                                    {
                                                        #region [ CPF ]
                                                        TEXTO = TEXTO.Replace(".", "").Replace("-", "").Replace("/", "");
                                                        if (TEXTO != null && TEXTO != "")
                                                        {
                                                            if (TEXTO.Length != 11)
                                                            {
                                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [11 dígitos].";
                                                                camposValidos = false;
                                                                break;
                                                            }
                                                            else if (Mobios.ValidaCPF.IsCpf(TEXTO) == false)
                                                            {

                                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] inválido. Verificar o número digitado.";
                                                                camposValidos = false;
                                                                break;
                                                            }
                                                            else
                                                            {

                                                            }

                                                            /*my_regular_expression = @"^\d{3}\.?\d{3}\.?\d{3}\-?\d{2}$";
                                                            Match match = Regex.Match(TEXTO, my_regular_expression);

                                                            if (match.Success)
                                                            {
                                
                                                            }
                                                            else
                                                            {
                                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " deve ser do tipo " + DOMINIO;
                                                                camposValidos=false;
                                                            }*/
                                                        }
                                                        #endregion
                                                    }
                                                    else if (DOMINIO == "CPF/CNPJ")
                                                    {
                                                        #region [ CPF ]
                                                        TEXTO = TEXTO.Replace(".", "").Replace("-", "").Replace("/", "");
                                                        if (TEXTO != null && TEXTO != "")
                                                        {
                                                            //TIPO CPF = 11 dígitos
                                                            if (TEXTO.Length != 11 && TEXTO.Length != 14)
                                                            {
                                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [11 ou 14 dígitos].";
                                                                camposValidos = false;
                                                                break;
                                                            }
                                                            else if (Mobios.ValidaCPF.IsCpf(TEXTO) == false && Mobios.ValidaCNPJ.IsCnpj(TEXTO) == false)
                                                            {
                                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] inválido. Verificar o número digitado.";
                                                                camposValidos = false;
                                                                break;
                                                            }
                                                            else
                                                            {
                                                            }
                                                        }
                                                        #endregion
                                                    }
                                                    else if (DOMINIO == "CEP")
                                                    {
                                                        #region [ CEP ]
                                                        if (TEXTO != null && TEXTO != "")
                                                        {
                                                            /* my_regular_expression = @"^\d{5}\-?\d{3}$";
                                                             Match match = Regex.Match(TEXTO, my_regular_expression);

                                                             if (match.Success)
                                                             {
                                
                                                             }
                                                             else
                                                             {
                                                                 camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + " deve ser do tipo " + DOMINIO;
                                                                 camposValidos=false;
                                                             }*/
                                                        }
                                                        #endregion
                                                    }
                                                    else if (DOMINIO == "HORA")
                                                    {
                                                        #region [ Hora ]
                                                        if (TEXTO != null && TEXTO != "")
                                                        {
                                                            string minhahora = TEXTO.Substring(0, 2);
                                                            minhahora += ":" + TEXTO.Substring(2, 2);

                                                            my_regular_expression = @"^([0-1][0-9]|[2][0-3]):[0-5][0-9]$";
                                                            Match match = Regex.Match(minhahora, my_regular_expression);

                                                            if (match.Success)
                                                            {

                                                            }
                                                            else
                                                            {
                                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [hh:mm].";
                                                                camposValidos = false;
                                                                break;
                                                            }
                                                        }
                                                        #endregion
                                                    }
                                                    else if (DOMINIO == "EMAIL")
                                                    {
                                                        #region [ Email ]
                                                        if (TEXTO != null && TEXTO != "")
                                                        {
                                                            my_regular_expression = @"^([\w\-]+\.)*[\w\- ]+@([\w\- ]+\.)+([\w\-]{2,3})$";
                                                            Match match = Regex.Match(TEXTO, my_regular_expression);

                                                            if (match.Success)
                                                            {

                                                            }
                                                            else
                                                            {
                                                                camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] deve ser do tipo " + DOMINIO + " [nome@dominio.com].";
                                                                camposValidos = false;
                                                                break;
                                                            }
                                                        }
                                                        #endregion
                                                    }
                                                    else
                                                    {
                                                        // sem validação
                                                    }
                                                    #endregion
                                                }
                                                else if (TIPO == "MASKEDTEXTBOX")
                                                {
                                                    #region [ Masked Text Box ]

                                                    if (TEXTO != null && TEXTO != "" && camposTbl.CampoBatimento != null && camposTbl.CampoBatimento != "")
                                                    {
                                                        my_regular_expression = camposTbl.CampoBatimento;
                                                        Match match = Regex.Match(TEXTO, my_regular_expression);
                                                        if (!match.Success)
                                                        {
                                                            camposInvalidos = camposInvalidos + System.Environment.NewLine + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " [" + TEXTO + "] deve ter formato " + validaObrigatorio.CampoDominio;
                                                            camposValidos = false;
                                                            break;
                                                        }
                                                    }
                                                    #endregion
                                                }
                                            }
                                        }
                                    }
                                    #endregion
                                }
                            }
                        }
                    }
                    #endregion
                }
            }
            return new Tuple<bool, string>(camposValidos, camposInvalidos);
        }

        public static Tuple<Boolean, string> ValidarCamposObrigatorios(List<Campos> listaEstrutura, TabControl tabControl = null, bool Batimento = false, List<CamposTabela> camposTabela = null)
        {
            Boolean camposValidos = true;
            string camposInvalidos = "Os campos com (*) devem ser preenchidos." + System.Environment.NewLine + " Os seguintes campos estão incompletos: ";
            Boolean batimentoValido = true;
            string camposBatimento = "Os seguintes campos devem estar validados para prosseguir." + System.Environment.NewLine;

            foreach (Campos validaObrigatorio in listaEstrutura)
            {
                if (validaObrigatorio.CampoObrigatorio)
                {
                    #region [ Busca Valor do Campo ]
                    string valor = "";
                    if (tabControl != null)
                    {
                        if (validaObrigatorio.CampoTipo.ToUpper() == "CHECKBOX")
                        {
                            CheckBox valueCkbox = new CheckBox();
                            valueCkbox = (CheckBox)tabControl.TabPages[validaObrigatorio.CampoTab].Controls[validaObrigatorio.CampoNome];
                            valor = valueCkbox.Checked.ToString().Trim();
                        }
                        else if (validaObrigatorio.CampoTipo.ToUpper() == "LABEL" || validaObrigatorio.CampoTipo.ToUpper() == "MASKEDTEXTBOX")
                        {
                            continue;
                        }
                        else if (validaObrigatorio.CampoTipo.ToUpper() == "TABELA" || validaObrigatorio.CampoTipo.ToUpper() == "TABELAGERAL")
                        {
                            #region [ Valida Campos Tabela ]
                            DataGridView valueGrid = new DataGridView();
                            valueGrid = (DataGridView)tabControl.TabPages[validaObrigatorio.CampoTab].Controls[validaObrigatorio.CampoNome];
                            
                            if (valueGrid.Rows.Count - (valueGrid.AllowUserToAddRows ? 1 : 0) == 0)
                                valor = "";
                            else
                                valor = valueGrid.Rows.Count.ToString().Trim();
                            #endregion
                        }
                        else
                        {
                            valor = tabControl.TabPages[validaObrigatorio.CampoTab].Controls[validaObrigatorio.CampoNome].Text.ToString().Trim();
                        }
                    }
                    else
                    {
                        valor = validaObrigatorio.ValorCampo.Trim();
                    }
                    #endregion

                    if (valor == null || valor == "")
                    {
                        #region [ Valida campo vazio ]
                        camposInvalidos = camposInvalidos + validaObrigatorio.CampoLabel + " ,";
                        camposValidos = false;
                        #endregion
                    }
                    else if (validaObrigatorio.CampoBatimento != null && validaObrigatorio.CampoBatimento != "" && Batimento == true)
                    {
                        #region [ Batimento do Valor do Campo ]

                        bool validadoBatimento = false;
                        string[] valoresBatimento = validaObrigatorio.CampoBatimento.Split(';');

                        #region [ Ajuste para ComboBox ]
                        if (validaObrigatorio.CampoTipo.ToUpper() == "COMBOBOX")
                        {
                            string bat = "";
                            foreach (string valorBatimento in valoresBatimento)
                            {
                                if (valorBatimento.StartsWith("*"))
                                {
                                    if (bat != "")
                                        bat += ";";

                                    bat += valorBatimento.Remove(0, 1);
                                }
                            }
                            valoresBatimento = bat.Split(';');
                            if (valoresBatimento.Count() == 0)
                                validadoBatimento = true;
                        }
                        #endregion

                        if (validaObrigatorio.CampoTipo.ToUpper() != "CPF/CNPJ")
                        {
                            foreach (string valorBatimento in valoresBatimento)
                            {
                                if (validaObrigatorio.CampoTipo.ToUpper() == "TABELA" || validaObrigatorio.CampoTipo.ToUpper() == "TABELAGERAL")
                                {
                                    #region [ Tabela ]
                                    int resultRows = 0;
                                    if (Int32.TryParse(valor, out resultRows) && Int32.TryParse(valorBatimento, out resultRows))
                                    {
                                        if (Convert.ToInt32(valor) >= Convert.ToInt32(valorBatimento))
                                        {
                                            validadoBatimento = true;
                                        }
                                        else
                                        {
                                            valor = "Ao menos " + valor + "registros";
                                        }
                                    }
                                    #endregion
                                }
                                else
                                {
                                    if (valor.ToUpper() == valorBatimento.ToUpper())
                                    {
                                        validadoBatimento = true;
                                    }
                                }
                            }

                            if (!validadoBatimento)
                            {
                                camposBatimento = camposBatimento + validaObrigatorio.CampoLabel + ": " + valor + " ,";
                                batimentoValido = false;
                            }
                        }
                        #endregion
                    }
                }

                #region [ Valida Campos Tabela ]
                if (validaObrigatorio.CampoTipo.ToUpper() == "TABELA" || validaObrigatorio.CampoTipo.ToUpper() == "TABELAGERAL")
                {
                    if (camposTabela != null && camposTabela.Count > 0)
                    {
                        if (tabControl != null)
                        {
                            DataGridView valueGrid = new DataGridView();
                            valueGrid = (DataGridView)tabControl.TabPages[validaObrigatorio.CampoTab].Controls[validaObrigatorio.CampoNome];
                            
                            foreach (DataGridViewColumn dtcolumn in valueGrid.Columns)
                            {
                                CamposTabela camposTbl = camposTabela.Find(n => n.ID_Campo == validaObrigatorio.ID_Campo && n.CampoNome == dtcolumn.Name);

                                if (camposTbl != null)
                                {
                                    foreach (DataGridViewRow dtrow in valueGrid.Rows)
                                    {
                                        string TEXTO = "";
                                        if (!dtrow.IsNewRow)
                                        {
                                            if (valueGrid[dtcolumn.Index, dtrow.Index].Value != null)
                                                TEXTO = valueGrid[dtcolumn.Index, dtrow.Index].Value.ToString().Trim();

                                            if (camposTbl.CampoObrigatorio && (TEXTO == null || TEXTO == ""))
                                            {
                                                camposInvalidos = camposInvalidos + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + " ,";
                                                camposValidos = false;
                                                break;
                                            }
                                            else if (camposTbl.CampoBatimento != null && camposTbl.CampoBatimento != "" && Batimento == true)
                                            {
                                                bool validadoBatimento = false;
                                                string[] valoresBatimento = camposTbl.CampoBatimento.Split(';');
                                                foreach (string valorBatimento in valoresBatimento)
                                                {
                                                    if (TEXTO.ToUpper() == valorBatimento.ToUpper())
                                                    {
                                                        validadoBatimento = true;
                                                    }
                                                }
                                                if (!validadoBatimento)
                                                {
                                                    camposBatimento = camposBatimento + validaObrigatorio.CampoLabel + ": " + dtcolumn.HeaderText + ": " + TEXTO + " ,";
                                                    batimentoValido = false;
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion
            }
            #region [ Monta Texto Invalido ]
            string result = "";
            if (camposValidos == false)
            {
                result = camposInvalidos;
            }
            if (batimentoValido == false)
            {
                if (result == "")
                {
                    result += camposBatimento;
                }
                else
                {
                    result += System.Environment.NewLine + System.Environment.NewLine + camposBatimento;
                }
            }
            if (result != "")
                result = result.Remove(result.Length - 2);
            #endregion
            return new Tuple<bool, string>(camposValidos && batimentoValido, result);
        }
    }
}
