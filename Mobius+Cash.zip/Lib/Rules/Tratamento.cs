﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using System.Data;
using System.Globalization;
using System.Threading;
using System.Speech.Synthesis;
using Microsoft.Speech.Synthesis;
using System.IO;
using System.Text;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using System.Runtime.InteropServices;

namespace Mobios
{
    #region [ FileDialog STA ]
    [RunInstaller(true)]

    public class FileDialogSTA
    {
        public void Installer1()
        {
            MessageBox.Show("Cannot Locate Config File");
            MessageBox.Show("Pid : " + System.Diagnostics.Process.GetCurrentProcess().Id.ToString());
            String Location = String.Empty;
            OpenFileDialog frm = new OpenFileDialog();
            frm.InitializeLifetimeService();
            frm.Filter = "Config Files (*.config)|*.config| (*.xml)|*.xml";
            frm.Title = "Browse Config file";
            DialogResult ret = STAShowDialog(frm);
            
            if (ret == DialogResult.OK)
                Location = frm.FileName;

            MessageBox.Show(Location);
            //InitializeComponent();
        }


        /* STAShowDialog takes a FileDialog and shows it on a background STA thread and returns the results.
         * Usage:
         *   OpenFileDialog d = new OpenFileDialog();
         *   DialogResult ret = STAShowDialog(d);
         *   if (ret == DialogResult.OK)
         *      MessageBox.Show(d.FileName);
         */
        public static DialogResult STAShowDialog(OpenFileDialog dialog)
        {
            DialogState state = new DialogState();
            state.dialog = dialog;
            System.Threading.Thread t = new System.Threading.Thread(state.ThreadProcShowDialog);
            t.SetApartmentState(System.Threading.ApartmentState.STA);
            t.Start();
            t.Join();
            return state.result;
        }
    }

    /* Helper class to hold state and return value in order to call FileDialog.ShowDialog on a background thread.
     * Usage:
     *   DialogState state = new DialogState();
     *   state.dialog = // <any class that derives from FileDialog>
     *   System.Threading.Thread t = new System.Threading.Thread(state.ThreadProcShowDialog);
     *   t.SetApartmentState(System.Threading.ApartmentState.STA);
     *   t.Start();
     *   t.Join();
     *   return state.result;
     */

    public class DialogState
    {
        public DialogResult result;
        public OpenFileDialog dialog;
        public void ThreadProcShowDialog()
        {
            try
            {
                result = dialog.ShowDialog();
            }
            catch { }
        }
    }
    #endregion

    public class TratamentoCampo
    {
        public static string[] ConvertToStringArray(System.Array values)
        {
            // cria uma nova string de array
            string[] array = new string[values.Length];
            // percorrer o array e vai obtendo os valores de cada celula 
            for (int i = 1; i <= values.Length; i++)
            {
                if (values.GetValue(1, i) == null)
                    array[i - 1] = "";
                else
                    array[i - 1] = (string)values.GetValue(1, i).ToString();
            }
            return array;
        }

        public static DataTable ConvertToDataTable(List<Campos> data, int IdServico, DateTime DataCriacao, DateTime DataAtualizacao)
        {
            PropertyDescriptorCollection properties =
               TypeDescriptor.GetProperties(typeof(Campos));
            DataTable table = new DataTable();
            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            table.Columns.Add("ID_Servico", typeof(int));
            table.Columns.Add("Data_Criacao", typeof(DateTime));
            table.Columns.Add("Data_Atualizacao", typeof(DateTime));
            foreach (Campos item in data)
            {
                if (item.ValorCampo != null && item.ValorCampo != "" && item.ValorCampoAntigo == null && item.ValorCampoAntigo != item.ValorCampo)
                {
                    DataRow row = table.NewRow();
                    foreach (PropertyDescriptor prop in properties)
                        row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                    row["ID_Servico"] = IdServico;
                    row["Data_Criacao"] = DataCriacao;
                    row["Data_Atualizacao"] = DataAtualizacao;
                    table.Rows.Add(row);
                }
            }
            return table;
        }

        public static DataTable ConvertListToDataTable<T>(IList<T> data)
        {
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();
            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            foreach (T item in data)
            {
                DataRow row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                table.Rows.Add(row);
            }
            return table;

        }

        public static DataTable ConvertObjectToDataTable<T>(T data)
        {
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();
            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            
                DataRow row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                    row[prop.Name] = prop.GetValue(data) ?? DBNull.Value;
                table.Rows.Add(row);
            
            return table;

        }

        public static DataTable DataTableGroupBy(string i_sGroupByColumn, string i_sAggregateColumn, DataTable i_dSourceTable)
        {

            DataView dv = new DataView(i_dSourceTable);

            //getting distinct values for group column
            DataTable dtGroup = dv.ToTable(true, new string[] { i_sGroupByColumn });

            //adding column for the row count
            dtGroup.Columns.Add("Count", typeof(int));

            //looping thru distinct values for the group, counting
            foreach (DataRow dr in dtGroup.Rows)
            {
                dr["Count"] = i_dSourceTable.Compute("Count(" + i_sAggregateColumn + ")", i_sGroupByColumn + " = '" + dr[i_sGroupByColumn] + "'");
            }

            //returning grouped/counted result
            return dtGroup;
        }

        public static DataTable DataTableGroupBy(string[] Columns, DataTable SourceTable)
        {
            DataTable temporary = SourceTable.Copy();
            string colunas = "";
            foreach (string col in Columns)
            {
                if (colunas != "")
                {
                    colunas+=" + ";
                }
                colunas += col;
            }
            temporary.Columns.Add("IdTemporaryId", System.Type.GetType("System.String"), colunas);

            DataTable result = temporary.AsEnumerable().GroupBy(s => s.Field<string>("IdTemporaryId")).Select(g => g.First()).CopyToDataTable();
            result.Columns.Remove("IdTemporaryId");
            return result;
        }

        public enum JoinType
        {
            /// <summary>
            /// Same as regular join. Inner join produces only the set of records that match in both Table A and Table B.
            /// </summary>
            Inner = 0,
            /// <summary>
            /// Same as Left Outer join. Left outer join produces a complete set of records from Table A, with the matching records (where available) in Table B. If there is no match, the right side will contain null.
            /// </summary>
            Left = 1
        }

        /// <summary>
        /// Joins the passed in DataTables on the colToJoinOn.
        /// <para>Returns an appropriate DataTable with zero rows if the colToJoinOn does not exist in both tables.</para>
        /// </summary>
        /// <param name="dtblLeft"></param>
        /// <param name="dtblRight"></param>
        /// <param name="colToJoinOn"></param>
        /// <param name="joinType"></param>
        /// <returns></returns>
        /// <remarks>
        /// <para>http://stackoverflow.com/questions/2379747/create-combined-datatable-from-two-datatables-joined-with-linq-c-sharp?rq=1</para>
        /// <para>http://msdn.microsoft.com/en-us/library/vstudio/bb397895.aspx</para>
        /// <para>http://www.codinghorror.com/blog/2007/10/a-visual-explanation-of-sql-joins.html</para>
        /// <para>http://stackoverflow.com/questions/406294/left-join-and-left-outer-join-in-sql-server</para>
        /// </remarks>
        public static DataTable JoinTwoDataTablesOnOneColumn(DataTable dtblLeft, DataTable dtblRight, string colToJoinOn, JoinType joinType)
        {
            //Change column name to a temp name so the LINQ for getting row data will work properly.
            string strTempColName = colToJoinOn + "_2";
            if (dtblRight.Columns.Contains(colToJoinOn))
                dtblRight.Columns[colToJoinOn].ColumnName = strTempColName;

            //Get columns from dtblLeft
            DataTable dtblResult = dtblLeft.Clone();

            //Get columns from dtblRight
            var dt2Columns = dtblRight.Columns.OfType<DataColumn>().Select(dc => new DataColumn(dc.ColumnName, dc.DataType, dc.Expression, dc.ColumnMapping));

            //Get columns from dtblRight that are not in dtblLeft
            var dt2FinalColumns = from dc in dt2Columns.AsEnumerable()
                                  where !dtblResult.Columns.Contains(dc.ColumnName)
                                  select dc;
            List<string> Listdt2FinalColumns = new List<string>();
            List<string> ListColumnsToRemove = new List<string>();
            foreach (var item in dt2FinalColumns)
            {
                Listdt2FinalColumns.Add(item.ColumnName);
            }

            //Add the rest of the columns to dtblResult
            dtblResult.Columns.AddRange(dt2FinalColumns.ToArray());

            for (int i = 0; i < dtblRight.Columns.Count; i++)
            {
                if (Listdt2FinalColumns.Contains(dtblRight.Columns[i].ColumnName) == false)
                {
                    ListColumnsToRemove.Add(dtblRight.Columns[i].ColumnName);
                }
            }
            for (int i = 0; i < ListColumnsToRemove.Count; i++)
            {
                dtblRight.Columns.Remove(ListColumnsToRemove[i]);
            }



            //No reason to continue if the colToJoinOn does not exist in both DataTables.
            if (!dtblLeft.Columns.Contains(colToJoinOn) || (!dtblRight.Columns.Contains(colToJoinOn) && !dtblRight.Columns.Contains(strTempColName)))
            {
                if (!dtblResult.Columns.Contains(colToJoinOn))
                    dtblResult.Columns.Add(colToJoinOn);
                return dtblResult;
            }

            switch (joinType)
            {

                default:
                case JoinType.Inner:
                    #region Inner
                    //get row data
                    //To use the DataTable.AsEnumerable() extension method you need to add a reference to the System.Data.DataSetExtension assembly in your project. 
                    var rowDataLeftInner = from rowLeft in dtblLeft.AsEnumerable()
                                           join rowRight in dtblRight.AsEnumerable() on rowLeft[colToJoinOn] equals rowRight[strTempColName]
                                           select rowLeft.ItemArray.Concat(rowRight.ItemArray).ToArray();


                    //Add row data to dtblResult
                    foreach (object[] values in rowDataLeftInner)
                        dtblResult.Rows.Add(values);

                    #endregion
                    break;
                case JoinType.Left:
                    #region Left
                    var rowDataLeftOuter = from rowLeft in dtblLeft.AsEnumerable()
                                           join rowRight in dtblRight.AsEnumerable() on rowLeft[colToJoinOn] equals rowRight[strTempColName] into gj
                                           from subRight in gj.DefaultIfEmpty()
                                           select rowLeft.ItemArray.Concat((subRight == null) ? (dtblRight.NewRow().ItemArray) : subRight.ItemArray).ToArray();


                    //Add row data to dtblResult
                    foreach (object[] values in rowDataLeftOuter)
                        dtblResult.Rows.Add(values);

                    #endregion
                    break;
            }

            //Change column name back to original
            dtblRight.Columns[strTempColName].ColumnName = colToJoinOn;

            //Remove extra column from result
            dtblResult.Columns.Remove(strTempColName);

            return dtblResult;
        }

        public static DataTable MontarTabela(HtmlElement table)
        {
            DataTable result = new DataTable();
            int i = 0;

            if (result.Columns.Count == 0)
            {
                if (table.GetElementsByTagName("TH").Count > 0)
                {
                    foreach (HtmlElement row in table.GetElementsByTagName("TH"))
                    {
                        result.Columns.Add(row.InnerText.Trim());
                    }
                }
            }

            if (result.Columns.Count > 0)
            {
                foreach (HtmlElement row in table.GetElementsByTagName("TR"))
                {
                    if (row.GetElementsByTagName("TD").Count > 0)
                    {
                        int j = 0;
                        foreach (HtmlElement column in row.GetElementsByTagName("TD"))
                        {
                            string registerData = "";
                            if (column.InnerHtml.ToString().Contains("SPAN"))
                            {
                                foreach (HtmlElement register in column.GetElementsByTagName("SPAN"))
                                {
                                    try
                                    {
                                        registerData = register.InnerText.Trim();
                                    }
                                    catch { };
                                    break;
                                }
                            }
                            else
                            {
                                registerData = column.InnerText.Trim();
                            }

                            while (result.Rows.Count <= i)
                            {
                                result.Rows.Add();
                            }
                            result.Rows[i][j] = registerData;

                            j++;
                        }
                        i++;
                    }
                }

            }
            return result;
        }

        public static DataTable MontarTabela(HtmlElement table, string ColunaExtra, string ValorExtra)
        {
            DataTable result = new DataTable();
            int i = 0;

            string[] ColunaExtraArray = ColunaExtra.Split(';');
            string[] ValorExtraArray = ValorExtra.Split(';');

            if (result.Columns.Count == 0)
            {

                if (table.GetElementsByTagName("TH").Count > 0)
                {
                    foreach (string col in ColunaExtraArray)
                    {
                        result.Columns.Add(col);
                    }
                    foreach (HtmlElement row in table.GetElementsByTagName("TH"))
                    {
                        result.Columns.Add(row.InnerText.Trim());
                    }
                }
            }

            if (result.Columns.Count > 0)
            {
                foreach (HtmlElement row in table.GetElementsByTagName("TR"))
                {
                    if (row.GetElementsByTagName("TD").Count > 0)
                    {
                        int j = ColunaExtraArray.Count();
                        foreach (HtmlElement column in row.GetElementsByTagName("TD"))
                        {
                            string registerData = "";
                            if (column.InnerHtml.ToString().Contains("SPAN"))
                            {
                                foreach (HtmlElement register in column.GetElementsByTagName("SPAN"))
                                {
                                    try
                                    {
                                        registerData = register.InnerText.Trim();
                                    }
                                    catch { };
                                    break;
                                }
                            }
                            else
                            {
                                registerData = column.InnerText.Trim();
                            }

                            while (result.Rows.Count <= i)
                            {
                                result.Rows.Add();
                            }
                            result.Rows[i][j] = registerData;
                            j++;
                        }

                        j = 0;
                        foreach (string val in ValorExtraArray)
                        {
                            result.Rows[i][j] = val;
                            j++;
                        }
                        i++;
                    }
                }

            }
            return result;
        }

        public static string AdicionaBarraPath(string Path)
        {
            if (Path.Length > 0)
            {
                if (Path.Substring(Path.Length - 1, 1) != @"\")
                {
                    Path += @"\";
                }
            }
            return Path;
        }
        public static string AdicionaBarraUrl(string url)
        {
            if (url.Length > 0)
            {
                if (url.Substring(url.Length - 1, 1) != @"/")
                {
                    url += @"/";
                }
            }
            return url;
        }

        public static string PrimeiraMaiuscula (string txt)
        {
            string result = "";
            if (txt != "")
            {
                if (txt.Length == 1)
                    result = txt.ToUpper();
                else
                    result = txt.Substring(0, 1).ToUpper() + txt.Substring(1, txt.Length - 1).ToLower();
            }
            return result;
        }
        

        public static string MyReplace(string mystring)
        {
            mystring = mystring.Replace("\r\n", "");
            mystring = mystring.Replace("\r", "");
            mystring = mystring.Replace("\n", "");
            mystring = mystring.Trim();
            return mystring;
        }
        public static string AntiInjection(string mystring)
        {
            mystring = mystring.Replace("'", "''");
            mystring = mystring.Replace("\"", "\"\"");
            mystring = mystring.Replace("*", "\\*");
            mystring = mystring.Replace("?", "\\?");
            mystring = mystring.Trim();
            return mystring;
        }

        public static string Splitter(string CampoInfo, string Separador, string Posicao = @"0@-0", string splitterSeparador = "|")
        {
            if (CampoInfo != "")
            {
                if (Separador != "")
                {
                    if (Posicao == null || Posicao == "")
                        Posicao = @"0@-0";
                    string[] arraySeparador = Separador.Split(new string[] { splitterSeparador }, StringSplitOptions.RemoveEmptyEntries);
                    string[] arrayPosicao = Posicao.Split(new string[] { splitterSeparador }, StringSplitOptions.RemoveEmptyEntries);
                    CampoInfo = Splitter(CampoInfo, arraySeparador, arrayPosicao);
                }
            }
            return CampoInfo;
        }
        public static string Splitter(string CampoInfo, string[] arraySeparador, string[] arrayPosicao)
        {
            if (CampoInfo != "")
            {
                if (arraySeparador.Count() == arrayPosicao.Count())
                {
                    int sep = 0;
                    foreach (string txtSeparador in arraySeparador)
                    {
                        string Separador = "";
                        Separador = txtSeparador.Replace("\"", "").Replace("\\n", "\n").Replace("\\r", "\r");
                        if (Separador != "")
                        {
                            CampoInfo = CampoInfo.Replace(Separador, "|||||");
                            string[] CampoInfoArray = CampoInfo.Split(new string[] { "|||||" }, StringSplitOptions.RemoveEmptyEntries);
                            //string[] CampoInfoArray = CampoInfo.Split(Convert.ToChar(Separador));
                            if (arrayPosicao[sep].ToString().Contains('@'))
                            {
                                string[] posicao = arrayPosicao[sep].ToString().Split('@');
                                int posicaoInicial = 0;
                                int posicaoFinal = 0;

                                if (posicao[0].ToString() == "-0")
                                {
                                    posicaoInicial = CampoInfoArray.Count() - 1;
                                }
                                else
                                {
                                    posicaoInicial = Convert.ToInt32(posicao[0]);
                                }

                                if (posicao[1].ToString() == "-0")
                                {
                                    posicaoFinal = CampoInfoArray.Count() - 1;
                                }
                                else
                                {
                                    posicaoFinal = Convert.ToInt32(posicao[1]);
                                }

                                if (posicaoInicial < 0)
                                {
                                    posicaoInicial = CampoInfoArray.Count() - 1 + posicaoInicial;
                                }

                                if (posicaoFinal < 0)
                                {
                                    posicaoFinal = CampoInfoArray.Count() - 1 + posicaoFinal;
                                }

                                CampoInfo = "";
                                for (int posicaoLinha = posicaoInicial; posicaoLinha <= posicaoFinal; posicaoLinha++)
                                {
                                    if (CampoInfoArray.Count() > posicaoLinha)
                                    {
                                        if (CampoInfo == "")
                                        {
                                            CampoInfo = CampoInfoArray[posicaoLinha];
                                        }
                                        else
                                        {
                                            CampoInfo += " " + CampoInfoArray[posicaoLinha];
                                        }
                                    }
                                }

                            }
                            else
                            {
                                if (CampoInfoArray.Count() > Convert.ToInt32(arrayPosicao[sep].ToString()))
                                {
                                    CampoInfo = CampoInfoArray[Convert.ToInt32(arrayPosicao[sep].ToString())].Trim();
                                }
                            }
                        }
                        sep++;
                    }
                }
            }
            return CampoInfo;
        }
    }

    public class TratamentoSQL
    {
        public static string ReturnDataLongaSQL(DateTime Data)
        {
            string ReturnData = "";
            ReturnData = Data.Year.ToString() + "/" + Data.Month.ToString() + "/" + Data.Day.ToString() + " " + Data.TimeOfDay.ToString("hh\\:mm\\:ss");
            return ReturnData;
        }
        public static string ReturnDataCurtaSQL(DateTime Data)
        {
            string ReturnData = "";
            ReturnData = Data.Year.ToString() + "/" + Data.Month.ToString() + "/" + Data.Day.ToString();
            return ReturnData;
        }
        public static string AdicionaWhere(string sql, string where)
        {
            int indexWhere = sql.ToUpper().IndexOf("WHERE");
            int indexOrderBy = sql.ToUpper().IndexOf("ORDER BY");

            if (indexWhere != -1)
            {
                string sqlInicial = sql.Substring(0, indexWhere);
                indexWhere = indexWhere + 6;
                string sqlFinal = sql.Substring(indexWhere, sql.Length - indexWhere);

                sql = sqlInicial + " WHERE (" + where + ") AND " + sqlFinal;
            }
            else if (indexOrderBy != -1)
            {
                string sqlInicial = sql.Substring(0, indexOrderBy);
                indexWhere = indexWhere + 9;
                string sqlFinal = sql.Substring(indexOrderBy, sql.Length - indexOrderBy);
                sql = sqlInicial + " WHERE (" + where + ") " + sqlFinal;
            }
            else
            {
                sql = sql + " WHERE (" + where + ") ";
            }

            return sql;
        }
        public static string ReturnNullWhoTextIsBlank(string texto)
        {
            if (texto == "")
            {
                return " null ";
            }
            else
            {
                return "'" + texto + "'";
            }
        }
    }

    public class TratarNumero
    {
        public static string ConverterMoeda2(string str_valor,bool GravarBD=false)
        {
            string valorFormatado = "";
            try
            {


                string teste = "1,000,000.01";
                decimal Resultado;
                decimal.TryParse(teste, out Resultado);
                bool apaga = false;
                int Myint;

                //Tirando dos os caracteres que não são números, exceto o último
                string R = "";
                for (int k = str_valor.Length - 1; k >= 0; k--)
                {

                    if (!int.TryParse(str_valor[k].ToString(), out Myint))
                    {
                        if (!apaga)
                        {
                            //R = str_valor[k].ToString() + R;
                            R = "@" + R;
                            apaga = true;
                        }
                        else
                        {
                            //R = R;
                        }
                    }
                    else
                    {
                        R = str_valor[k].ToString() + R;
                    }
                }
                str_valor = R; //Número com apenas o arroba no local do decimal



                if (GravarBD)
                {
                    //Sempre deixar o ponto para gravar no BD
                    str_valor = str_valor.Replace("@", ".");
                    decimal Valor = Convert.ToDecimal(str_valor);
                    valorFormatado = Valor.ToString();
                }
                else
                {
                    str_valor = str_valor.Replace("@", ",");
                    /*if (Resultado.ToString() == "1000000.01")
                    {
                        str_valor = str_valor.Replace("@", ".");
                    }
                    else
                    {
                        str_valor = str_valor.Replace("@", ",");
                    }
                     * */
                    //Define minha cultura
                    var minhaCultura = TratamentoLinguagem.BuscarLinguagem("PT-BR");
                    /*var minhaCultura = new CultureInfo("pt-BR"); //pt-BR usada como base
                    minhaCultura.DateTimeFormat.ShortDatePattern = "dd/MM/yyyy";
                    minhaCultura.DateTimeFormat.ShortTimePattern = "HH:mm";
                    minhaCultura.NumberFormat.NumberDecimalDigits = 2;
                    minhaCultura.NumberFormat.NumberGroupSeparator = ".";
                    minhaCultura.NumberFormat.NumberDecimalSeparator = ",";
                     * */
                    decimal Valor = Convert.ToDecimal(str_valor, minhaCultura);
                    valorFormatado = string.Format(minhaCultura, "{0:N}", Valor);
                }
            }
            catch (Exception ex)
            {
                StringBuilder sb = new StringBuilder();
                Log.GravaLog("Erro na função ConverterMoeda2 \n\n" + SharedData.FormatarErro(sb, ex), "_Mobios");
                valorFormatado = "";
            }

            return valorFormatado;

            // obtém a cultura local
            //var cultureInfo = Thread.CurrentThread.CurrentCulture;
            // faz uma cópia das informações de formatação de número da cultura local
            //var numberFormatInfo = (NumberFormatInfo)cultureInfo.NumberFormat.Clone();
            // fixa o símbolo da moeda estrangeira
            //numberFormatInfo.CurrencySymbol = "";
            // obtém o valor em moeda estrangeira formatado conforme a cultura local
            //var valorFormatado = string.Format(culture, "{0:C}", Valor);

            
        }
        public static string ConverterMoeda(string i)
        {
            NumberStyles style = NumberStyles.AllowDecimalPoint | NumberStyles.AllowThousands;
            //CultureInfo culture = CultureInfo.CreateSpecificCulture("en-US");
            CultureInfo culture = TratamentoLinguagem.BuscarLinguagem("en-US");
            //string i = "1000.01";
            decimal j;
            bool numeroOk = false;
            bool primeiroPonto = true;
            bool pontuacaoOK = true;
            int n;
            int qtdNumeros = 0;
            int VirgulaUltimo = i.LastIndexOf(",");
            int PontoUltimo = i.LastIndexOf(".");
            bool JaTevePonto = false;
            bool JaTeveVirgula = false;
            string ultimaPontuacaoEncontrada = "";
            int virgulas = 0;
            int pontos = 0;
            bool acima3digitos = false;

            for (int k = 0; k <= i.Length; k++)
            {
                if (qtdNumeros > 3 && ultimaPontuacaoEncontrada != "")
                {
                    pontuacaoOK = false;
                    break;
                }

                if (k == i.Length)
                {
                    if (qtdNumeros < 3)
                    {
                        if (virgulas > 1 && pontos == 0)
                        {
                            pontuacaoOK = false;
                            break;
                        }
                        else if (pontos > 1 && virgulas == 0)
                        {
                            pontuacaoOK = false;
                            break;
                        }
                    }
                    pontuacaoOK = true;
                    break;
                }

                if (Int32.TryParse(i.Substring(k, 1), out n))
                {
                    qtdNumeros++;
                    if (qtdNumeros > 3 && acima3digitos == false)
                    {
                        acima3digitos = true;
                    }
                }
                else
                {
                    if (qtdNumeros == 0)
                    {
                        pontuacaoOK = false;
                        break;
                    }

                    if ((JaTevePonto || JaTeveVirgula) && acima3digitos)
                    {
                        pontuacaoOK = false;
                        break;
                    }

                    if (i.Substring(k, 1) != "," && i.Substring(k, 1) != ".")
                    {
                        pontuacaoOK = false;
                        break;
                    }
                    else
                    {
                        if ((JaTevePonto) && (JaTeveVirgula))
                        {
                            pontuacaoOK = false;
                            break;
                        }
                        else if (i.Substring(k, 1) == ",")
                        {
                            virgulas++;
                            ultimaPontuacaoEncontrada = ",";
                            JaTeveVirgula = true;

                        }
                        else if (i.Substring(k, 1) == ".")
                        {
                            pontos++;
                            ultimaPontuacaoEncontrada = ".";
                            JaTevePonto = true;
                        }


                        if (qtdNumeros != 3 && primeiroPonto == true)
                        {
                            qtdNumeros = 0;
                            primeiroPonto = false;
                        }
                        else if (qtdNumeros != 3)
                        {
                            pontuacaoOK = false;
                            break;
                        }
                        else
                        {
                            qtdNumeros = 0;
                        }
                    }
                }
            }

            if (pontuacaoOK)
            {
                if ((pontos > 1 || pontos == 0) && virgulas == 0)
                {
                    i = i + ",00";
                }
                else if (virgulas > 1 && pontos == 0)
                {
                    i = i + ".00";
                }
                else if (pontos == 1 && virgulas == 0)
                {
                    if (i.IndexOf(".") <= 4)
                    {
                        int casasDecimaisPonto = i.Substring(i.IndexOf(".")).Length;
                        if (casasDecimaisPonto == 1)
                        {
                            i = i + "00";
                        }
                        else if (casasDecimaisPonto == 2)
                        {
                            i = i + "0";
                        }
                        else if (casasDecimaisPonto == 4)
                        {
                            i = i + ",00";
                        }
                    }
                }
                else if (virgulas == 1 && pontos == 0)
                {
                    if (i.IndexOf(",") <= 4)
                    {
                        int casasDecimaisVirgula = i.Substring(i.IndexOf(",")).Length;
                        if (casasDecimaisVirgula == 1)
                        {
                            i = i + "00";
                        }
                        else if (casasDecimaisVirgula == 2)
                        {
                            i = i + "0";
                        }
                        else if (casasDecimaisVirgula == 4)
                        {
                            i = i + ".00";
                        }
                    }
                }

                if (Decimal.TryParse(i, style, culture, out j))
                {
                    numeroOk = true;
                }

                //culture = CultureInfo.CreateSpecificCulture("pt-BR");
                culture = TratamentoLinguagem.BuscarLinguagem("pt-BR");
                if (Decimal.TryParse(i, style, culture, out j))
                {
                    numeroOk = true;
                }
            }

            string result = "";
            if (numeroOk)
            {
                VirgulaUltimo = i.LastIndexOf(",");
                PontoUltimo = i.LastIndexOf(".");

                if (VirgulaUltimo > PontoUltimo)
                {
                    int casasDecimaisVirgula = i.Substring(i.IndexOf(",")).Length;
                    if (casasDecimaisVirgula == 1)
                    {
                        i = i + "00";
                    }
                    else if (casasDecimaisVirgula == 2)
                    {
                        i = i + "0";
                    }

                    result = i.Replace(".", "");
                }
                else if (PontoUltimo > VirgulaUltimo)
                {
                    int casasDecimaisPonto = i.Substring(i.IndexOf(".")).Length;
                    if (casasDecimaisPonto == 1)
                    {
                        i = i + "00";
                    }
                    else if (casasDecimaisPonto == 2)
                    {
                        i = i + "0";
                    }

                    result = i.Replace(".", "@").Replace(",", "").Replace("@", ",");
                }
                else
                {
                    result = i;
                }
            }
            return result;
        }

        public static string ConverterDecimal(string i)
        {
            NumberStyles style = NumberStyles.AllowDecimalPoint | NumberStyles.AllowThousands;
            //CultureInfo culture = CultureInfo.CreateSpecificCulture("en-US");
            CultureInfo culture = TratamentoLinguagem.BuscarLinguagem("en-US");

            //string i = "1000.01";
            decimal j;
            bool numeroOk = false;
            bool primeiroPonto = true;
            bool pontuacaoOK = true;
            int n;
            int qtdNumeros = 0;
            int VirgulaUltimo = i.LastIndexOf(",");
            int PontoUltimo = i.LastIndexOf(".");
            bool JaTevePonto = false;
            bool JaTeveVirgula = false;
            string ultimaPontuacaoEncontrada = "";
            int virgulas = 0;
            int pontos = 0;
            bool acima3digitos = false;

            for (int k = 0; k <= i.Length; k++)
            {
                if (qtdNumeros > 3 && ultimaPontuacaoEncontrada != "")
                {
                    if (VirgulaUltimo + 1 > k || PontoUltimo + 1 > k)
                    {
                        pontuacaoOK = false;
                        break;
                    }
                }

                if (k == i.Length)
                {
                    if (qtdNumeros < 3)
                    {
                        if (virgulas > 1 && pontos == 0)
                        {
                            pontuacaoOK = false;
                            break;
                        }
                        else if (pontos > 1 && virgulas == 0)
                        {
                            pontuacaoOK = false;
                            break;
                        }
                    }
                    pontuacaoOK = true;
                    break;
                }

                if (Int32.TryParse(i.Substring(k, 1), out n))
                {
                    qtdNumeros++;
                    if (qtdNumeros > 3 && acima3digitos == false)
                    {
                        acima3digitos = true;
                    }
                }
                else
                {
                    if (qtdNumeros == 0)
                    {
                        pontuacaoOK = false;
                        break;
                    }

                    if ((JaTevePonto || JaTeveVirgula) && acima3digitos)
                    {
                        pontuacaoOK = false;
                        break;
                    }

                    if (i.Substring(k, 1) != "," && i.Substring(k, 1) != ".")
                    {
                        pontuacaoOK = false;
                        break;
                    }
                    else
                    {
                        if ((JaTevePonto) && (JaTeveVirgula))
                        {
                            pontuacaoOK = false;
                            break;
                        }
                        else if (i.Substring(k, 1) == ",")
                        {
                            virgulas++;
                            ultimaPontuacaoEncontrada = ",";
                            JaTeveVirgula = true;

                        }
                        else if (i.Substring(k, 1) == ".")
                        {
                            pontos++;
                            ultimaPontuacaoEncontrada = ".";
                            JaTevePonto = true;
                        }


                        if (qtdNumeros != 3 && primeiroPonto == true)
                        {
                            qtdNumeros = 0;
                            primeiroPonto = false;
                        }
                        else if (qtdNumeros != 3)
                        {
                            pontuacaoOK = false;
                            break;
                        }
                        else
                        {
                            qtdNumeros = 0;
                        }
                    }
                }
            }

            if (pontuacaoOK)
            {
                if ((pontos > 1 || pontos == 0) && virgulas == 0)
                {
                    i = i + ",00";
                }
                else if (virgulas > 1 && pontos == 0)
                {
                    i = i + ".00";
                }

                if (Decimal.TryParse(i, style, culture, out j))
                {
                    numeroOk = true;
                }

                //culture = CultureInfo.CreateSpecificCulture("pt-BR");
                culture = TratamentoLinguagem.BuscarLinguagem("pt-BR");
                if (Decimal.TryParse(i, style, culture, out j))
                {
                    numeroOk = true;
                }
            }

            string result = "";
            if (numeroOk)
            {
                VirgulaUltimo = i.LastIndexOf(",");
                PontoUltimo = i.LastIndexOf(".");

                if (VirgulaUltimo > PontoUltimo)
                {
                    result = i.Replace(".", "");
                }
                else if (PontoUltimo > VirgulaUltimo)
                {
                    result = i.Replace(".", "@").Replace(",", "").Replace("@", ",");
                }
                else
                {
                    result = i;
                }
            }
            return result;
        }
    }

    public static class Extenso
    {
        public enum TipoValorExtenso
        {
            Monetario,
            Porcentagem,
            Decimal
        }

        public static string toExtenso(double Valor, TipoValorExtenso tipoValorExtenso)
        {
            decimal valorEscrever = new decimal(Valor);

            return toExtenso(valorEscrever, tipoValorExtenso);
        }

        // O método toExtenso recebe um valor do tipo decimal
        public static string toExtenso(decimal valor, TipoValorExtenso tipoValorExtenso)
        {
            if (valor <= 0 | valor >= 1000000000000000)
                throw new ArgumentOutOfRangeException("Valor não suportado pelo sistema. Valor: " + valor);

            int PadLenght = valor.ToString().Substring(valor.ToString().IndexOf(',') + 1, valor.ToString().Length - (valor.ToString().IndexOf(',') + 1)).Length;
            string formato = ("000000000000000.").PadRight(16 + PadLenght - 1, '0') + "#";

            string strValor = String.Empty;
            strValor = valor.ToString(formato);
            //strValor = valor.ToString("{0:0.00#}");
            string valor_por_extenso = string.Empty;
            
            int qtdCasasDecimais = 0;
            bool existemValoresAposDecimal = false;
            if (strValor.IndexOf(',') != -1)
            {
                qtdCasasDecimais = strValor.Substring(strValor.IndexOf(',') + 1, strValor.Length - (strValor.IndexOf(',') + 1)).Length;
                existemValoresAposDecimal = Convert.ToInt32(strValor.Substring(16, qtdCasasDecimais)) > 0;
            }
            
            
            var parte = "";
            for (int i = 0; i <= 15; i += 3)
            {
                if (i == 15)
                {
                    if (qtdCasasDecimais > 0)
                    {
                        parte = strValor.Substring(i, qtdCasasDecimais + 1);
                    }
                    else
                    {
                        parte = "";
                    }
                }
                else
                {
                    parte = strValor.Substring(i, 3);
                }

                // se parte contém vírgula, pega a substring com base na quantidade de casas decimais.
                if (parte.Contains(','))
                {
                    parte = strValor.Substring(i + 1, qtdCasasDecimais);


                    for (int Decimais = 0; Decimais < parte.Length; Decimais++)
                    {
                        if (parte.Substring(Decimais, 1) == "0")
                        {
                            if (existemValoresAposDecimal)
                                valor_por_extenso += "ZERO ";
                            else break;
                        }
                        else break;
                    }

                    valor_por_extenso += escreva_parte(Convert.ToDecimal(parte), true);
                }
                else
                {
                    if (parte != "")
                    {
                        valor_por_extenso += escreva_parte(Convert.ToDecimal(parte));
                    }
                }

                if (i == 0 & valor_por_extenso != string.Empty)
                {
                    if (Convert.ToInt32(strValor.Substring(0, 3)) == 1)
                        valor_por_extenso += " TRILHÃO" +
                                             ((Convert.ToDecimal(strValor.Substring(3, 12)) > 0)
                                                  ? " E "
                                                  : string.Empty);
                    else if (Convert.ToInt32(strValor.Substring(0, 3)) > 1)
                        valor_por_extenso += " TRILHÕES" +
                                             ((Convert.ToDecimal(strValor.Substring(3, 12)) > 0)
                                                  ? " E "
                                                  : string.Empty);
                }
                else if (i == 3 & valor_por_extenso != string.Empty)
                {
                    if (Convert.ToInt32(strValor.Substring(3, 3)) == 1)
                        valor_por_extenso += " BILHÃO" +
                                             ((Convert.ToDecimal(strValor.Substring(6, 9)) > 0)
                                                  ? " E "
                                                  : string.Empty);
                    else if (Convert.ToInt32(strValor.Substring(3, 3)) > 1)
                        valor_por_extenso += " BILHÕES" +
                                             ((Convert.ToDecimal(strValor.Substring(6, 9)) > 0)
                                                  ? " E "
                                                  : string.Empty);
                }
                else if (i == 6 & valor_por_extenso != string.Empty)
                {
                    if (Convert.ToInt32(strValor.Substring(6, 3)) == 1)
                        valor_por_extenso += " MILHÃO" +
                                             ((Convert.ToDecimal(strValor.Substring(9, 6)) > 0)
                                                  ? " E "
                                                  : string.Empty);
                    else if (Convert.ToInt32(strValor.Substring(6, 3)) > 1)
                        valor_por_extenso += " MILHÕES" +
                                             ((Convert.ToDecimal(strValor.Substring(9, 6)) > 0)
                                                  ? " E "
                                                  : string.Empty);
                }
                else if (i == 9 & valor_por_extenso != string.Empty)
                    if (Convert.ToInt32(strValor.Substring(9, 3)) > 0)
                        valor_por_extenso += " MIL" +
                                             ((Convert.ToDecimal(strValor.Substring(12, 3)) > 0)
                                                  ? " E "
                                                  : string.Empty);

                if (i == 12)
                {
                    if (valor_por_extenso.Length > 8)
                        if (valor_por_extenso.Substring(valor_por_extenso.Length - 6, 6) == "BILHÃO" |
                            valor_por_extenso.Substring(valor_por_extenso.Length - 6, 6) == "MILHÃO")
                            valor_por_extenso += " DE";
                        else if (valor_por_extenso.Substring(valor_por_extenso.Length - 7, 7) == "BILHÕES" |
                                 valor_por_extenso.Substring(valor_por_extenso.Length - 7, 7) == "MILHÕES" |
                                 valor_por_extenso.Substring(valor_por_extenso.Length - 8, 7) == "TRILHÕES")
                            valor_por_extenso += " DE";
                        else if (valor_por_extenso.Substring(valor_por_extenso.Length - 8, 8) == "TRILHÕES")
                            valor_por_extenso += " DE";

                    if (Convert.ToInt64(strValor.Substring(0, 15)) == 1)
                    {
                        switch (tipoValorExtenso)
                        {
                            case TipoValorExtenso.Monetario:
                                valor_por_extenso += " REAL";
                                break;
                            case TipoValorExtenso.Porcentagem:
                                if (existemValoresAposDecimal == false)
                                    valor_por_extenso += " VÍRGULA ZERO POR CENTO";
                                break;
                            case TipoValorExtenso.Decimal:
                                break;
                            default:
                                throw new ArgumentOutOfRangeException("tipoValorExtenso");
                        }
                    }

                    else if (Convert.ToInt64(strValor.Substring(0, 15)) > 1)
                    {
                        switch (tipoValorExtenso)
                        {
                            case TipoValorExtenso.Monetario:
                                valor_por_extenso += " REAIS";
                                break;
                            case TipoValorExtenso.Porcentagem:
                                if (existemValoresAposDecimal == false)
                                    valor_por_extenso += " VÍRGULA ZERO POR CENTO";
                                break;
                            case TipoValorExtenso.Decimal:
                                break;
                            default:
                                throw new ArgumentOutOfRangeException("tipoValorExtenso");
                        }
                    }

                    if (qtdCasasDecimais > 0)
                    {
                        if (Convert.ToInt32(strValor.Substring(16, qtdCasasDecimais)) > 0 && valor_por_extenso != string.Empty)
                        {
                            switch (tipoValorExtenso)
                            {
                                case TipoValorExtenso.Monetario:
                                    valor_por_extenso += " E ";
                                    break;
                                case TipoValorExtenso.Porcentagem:
                                    valor_por_extenso += " VÍRGULA ";
                                    break;
                                case TipoValorExtenso.Decimal:
                                    break;
                                default:
                                    throw new ArgumentOutOfRangeException("tipoValorExtenso");
                            }
                        }
                    }
                }

                if (i == 15 && qtdCasasDecimais > 0)
                    if (Convert.ToInt32(strValor.Substring(16, qtdCasasDecimais)) == 1)
                    {
                        switch (tipoValorExtenso)
                        {
                            case TipoValorExtenso.Monetario:
                                valor_por_extenso += " CENTAVO";
                                break;
                            case TipoValorExtenso.Porcentagem:
                                valor_por_extenso += "POR CENTO";
                                break;
                            case TipoValorExtenso.Decimal:
                                break;
                            default:
                                throw new ArgumentOutOfRangeException("tipoValorExtenso");
                        }
                    }

                    else if (Convert.ToInt32(strValor.Substring(16, qtdCasasDecimais)) > 1)
                    {
                        switch (tipoValorExtenso)
                        {
                            case TipoValorExtenso.Monetario:
                                valor_por_extenso += " CENTAVOS";
                                break;
                            case TipoValorExtenso.Porcentagem:
                                valor_por_extenso += "POR CENTO";
                                break;
                            case TipoValorExtenso.Decimal:
                                break;
                            default:
                                throw new ArgumentOutOfRangeException("tipoValorExtenso");
                        }
                    }
            }
            return valor_por_extenso;
        }

        private static string escreva_parte(decimal valor, bool Decimal = false)
        {
            if (valor <= 0)
                return string.Empty;
            else
            {
                if (Decimal)
                {
                    string montagemDecimal = "";
                    int tamanho = valor.ToString().Length;

                    for (int i = 0; i < tamanho; i++)
                    {
                        int Numero = Convert.ToInt32(valor.ToString().Substring(i, 1));

                        if (Numero == 1) montagemDecimal += "UM ";
                        else if (Numero == 2) montagemDecimal += "DOIS ";
                        else if (Numero == 3) montagemDecimal += "TRÊS ";
                        else if (Numero == 4) montagemDecimal += "QUATRO ";
                        else if (Numero == 5) montagemDecimal += "CINCO ";
                        else if (Numero == 6) montagemDecimal += "SEIS ";
                        else if (Numero == 7) montagemDecimal += "SETE ";
                        else if (Numero == 8) montagemDecimal += "OITO ";
                        else if (Numero == 9) montagemDecimal += "NOVE ";
                        else if (Numero == 0) montagemDecimal += "ZERO ";
                    }
                    return montagemDecimal;
                }
                else
                {
                    string montagem = string.Empty;
                    if (valor > 0 & valor < 1)
                    {
                        valor *= 100;
                    }
                    string strValor = valor.ToString("000");
                    int a = Convert.ToInt32(strValor.Substring(0, 1));
                    int b = Convert.ToInt32(strValor.Substring(1, 1));
                    int c = Convert.ToInt32(strValor.Substring(2, 1));

                    if (a == 1) montagem += (b + c == 0) ? "CEM" : "CENTO";
                    else if (a == 2) montagem += "DUZENTOS";
                    else if (a == 3) montagem += "TREZENTOS";
                    else if (a == 4) montagem += "QUATROCENTOS";
                    else if (a == 5) montagem += "QUINHENTOS";
                    else if (a == 6) montagem += "SEISCENTOS";
                    else if (a == 7) montagem += "SETECENTOS";
                    else if (a == 8) montagem += "OITOCENTOS";
                    else if (a == 9) montagem += "NOVECENTOS";

                    if (b == 1)
                    {
                        if (c == 0) montagem += ((a > 0) ? " E " : string.Empty) + "DEZ";
                        else if (c == 1) montagem += ((a > 0) ? " E " : string.Empty) + "ONZE";
                        else if (c == 2) montagem += ((a > 0) ? " E " : string.Empty) + "DOZE";
                        else if (c == 3) montagem += ((a > 0) ? " E " : string.Empty) + "TREZE";
                        else if (c == 4) montagem += ((a > 0) ? " E " : string.Empty) + "QUATORZE";
                        else if (c == 5) montagem += ((a > 0) ? " E " : string.Empty) + "QUINZE";
                        else if (c == 6) montagem += ((a > 0) ? " E " : string.Empty) + "DEZESSEIS";
                        else if (c == 7) montagem += ((a > 0) ? " E " : string.Empty) + "DEZESSETE";
                        else if (c == 8) montagem += ((a > 0) ? " E " : string.Empty) + "DEZOITO";
                        else if (c == 9) montagem += ((a > 0) ? " E " : string.Empty) + "DEZENOVE";
                    }
                    else if (b == 2) montagem += ((a > 0) ? " E " : string.Empty) + "VINTE";
                    else if (b == 3) montagem += ((a > 0) ? " E " : string.Empty) + "TRINTA";
                    else if (b == 4) montagem += ((a > 0) ? " E " : string.Empty) + "QUARENTA";
                    else if (b == 5) montagem += ((a > 0) ? " E " : string.Empty) + "CINQUENTA";
                    else if (b == 6) montagem += ((a > 0) ? " E " : string.Empty) + "SESSENTA";
                    else if (b == 7) montagem += ((a > 0) ? " E " : string.Empty) + "SETENTA";
                    else if (b == 8) montagem += ((a > 0) ? " E " : string.Empty) + "OITENTA";
                    else if (b == 9) montagem += ((a > 0) ? " E " : string.Empty) + "NOVENTA";

                    if (strValor.Substring(1, 1) != "1" & c != 0 & montagem != string.Empty) montagem += " E ";

                    if (strValor.Substring(1, 1) != "1")
                        if (c == 1) montagem += "UM";
                        else if (c == 2) montagem += "DOIS";
                        else if (c == 3) montagem += "TRÊS";
                        else if (c == 4) montagem += "QUATRO";
                        else if (c == 5) montagem += "CINCO";
                        else if (c == 6) montagem += "SEIS";
                        else if (c == 7) montagem += "SETE";
                        else if (c == 8) montagem += "OITO";
                        else if (c == 9) montagem += "NOVE";

                    return montagem;
                }
            }
        }
    }

    public static class ValidaCNPJ
    {
        public static bool IsCnpj(string cnpj)
        {
            int[] multiplicador1 = new int[12] { 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };
            int[] multiplicador2 = new int[13] { 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };
            int soma;
            int resto;
            string digito;
            string tempCnpj;
            cnpj = cnpj.Trim();
            cnpj = cnpj.Replace(".", "").Replace("-", "").Replace("/", "");
            if (cnpj.Length != 14)
                return false;
            tempCnpj = cnpj.Substring(0, 12);
            soma = 0;
            for (int i = 0; i < 12; i++)
                soma += int.Parse(tempCnpj[i].ToString()) * multiplicador1[i];
            resto = (soma % 11);
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;
            digito = resto.ToString();
            tempCnpj = tempCnpj + digito;
            soma = 0;
            for (int i = 0; i < 13; i++)
                soma += int.Parse(tempCnpj[i].ToString()) * multiplicador2[i];
            resto = (soma % 11);
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;
            digito = digito + resto.ToString();
            return cnpj.EndsWith(digito);
        }
    }

    public static class ValidaCPF
    {
        public static bool IsCpf(string cpf)
        {
            int[] multiplicador1 = new int[9] { 10, 9, 8, 7, 6, 5, 4, 3, 2 };
            int[] multiplicador2 = new int[10] { 11, 10, 9, 8, 7, 6, 5, 4, 3, 2 };
            string tempCpf;
            string digito;
            int soma;
            int resto;
            cpf = cpf.Trim();
            cpf = cpf.Replace(".", "").Replace("-", "");
            if (cpf.Length != 11)
                return false;
            tempCpf = cpf.Substring(0, 9);
            soma = 0;

            for (int i = 0; i < 9; i++)
                soma += int.Parse(tempCpf[i].ToString()) * multiplicador1[i];
            resto = soma % 11;
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;
            digito = resto.ToString();
            tempCpf = tempCpf + digito;
            soma = 0;
            for (int i = 0; i < 10; i++)
                soma += int.Parse(tempCpf[i].ToString()) * multiplicador2[i];
            resto = soma % 11;
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;
            digito = digito + resto.ToString();
            return cpf.EndsWith(digito);
        }

        /// <summary>     
        /// Calcula o Digito verificador de um CPF informado       
        /// </summary>     
        /// <param name="cpf">int64 com o CPF contendo 9 digitos e sem o digito verificador</param>     
        /// <returns>string com o digito calculado do CPF ou null caso o cpf informado for maior que 9 digitos</returns>     
        public static string CalculaDigCPF(Int64 cpf)
        {
            return CalculaDigCPF(cpf.ToString("D9"));
        }
        /// <summary>     
        /// Calcula o Digito verificador de um CPF informado       
        /// </summary>     
        /// <param name="cpf">string com o CPF contendo 9 digitos e sem o digito verificador</param>     
        /// <returns>string com o digito calculado do CPF ou null caso o cpf informado for maior que 9 digitos</returns>     
        public static string CalculaDigCPF(string cpf)
        {
            // Declara variaveis para uso         
            string new_cpf = "";
            string digito = "";
            Int32 Aux1 = 0;
            Int32 Aux2 = 0;
            // Retira carcteres invalidos não numericos da string         
            for (int i = 0; i < cpf.Length; i++)
            {
                if (isDigito(cpf.Substring(i, 1)))
                {
                    new_cpf += cpf.Substring(i, 1);
                }
            }
            // Ajusta o Tamanho do CPF para 9 digitos completando com zeros a esquerda         
            new_cpf = Convert.ToInt64(new_cpf).ToString("D9");
            // Caso o tamanho do CPF informado for maior que 9 digitos retorna nulo         
            if (new_cpf.Length > 9)
            {
                return cpf;
            }
            // Calcula o primeiro digito do CPF         
            Aux1 = 0;
            for (int i = 0; i < new_cpf.Length; i++)
            {
                Aux1 += Convert.ToInt32(new_cpf.Substring(i, 1)) * (10 - i);
            }
            Aux2 = 11 - (Aux1 % 11);
            // Carrega o primeiro digito na variavel digito         
            if (Aux2 > 9)
            {
                digito += "0";
            }
            else
            {
                digito += Aux2.ToString();
            }
            // Adiciona o primeiro digito ao final do CPF para calculo do segundo digito         
            new_cpf += digito;
            // Calcula o segundo digito do CPF         
            Aux1 = 0;
            for (int i = 0; i < new_cpf.Length; i++)
            {
                Aux1 += Convert.ToInt32(new_cpf.Substring(i, 1)) * (11 - i);
            }
            Aux2 = 11 - (Aux1 % 11);
            // Carrega o segundo digito na variavel digito         
            if (Aux2 > 9)
            {
                digito += "0";
            }
            else
            {
                digito += Aux2.ToString();
            }
            return cpf + "-" + digito;
        }
        /// <summary>     
        /// Verifica se um digito informado é um numero     
        /// </summary>     
        /// <param name="digito">string com um caracter para verificar se é um numero</param>     
        /// <returns>Boolean True/False</returns>     
        public static Boolean isDigito(string digito)
        {
            int n;
            return Int32.TryParse(digito, out n);
        }
    }

    public static class TratamentoLinguagem
    {
        public static CultureInfo BuscarLinguagem(string idioma)
        {
            CultureInfo _culture;
            _culture = new CultureInfo("pt-BR"); //pt-BR usada como base

            if (idioma.ToUpper() == "PT-BR")
            {
                _culture.DateTimeFormat.ShortDatePattern = "dd/MM/yyyy";
                _culture.DateTimeFormat.ShortTimePattern = "HH:mm";
                //_culture.NumberFormat.NumberDecimalDigits = 2;
                _culture.NumberFormat.NumberGroupSeparator = ".";
                _culture.NumberFormat.NumberDecimalSeparator = ",";
            }
            else if (idioma.ToUpper() == "EN-US")
            {
                _culture.DateTimeFormat.ShortDatePattern = "MM/dd/yyyy";
                _culture.DateTimeFormat.ShortTimePattern = "HH:mm";
                //_culture.NumberFormat.NumberDecimalDigits = 2;
                _culture.NumberFormat.NumberGroupSeparator = ",";
                _culture.NumberFormat.NumberDecimalSeparator = ".";
            }
            return _culture;
        }
    }

    public static class Falar
    {
        public static Microsoft.Speech.Synthesis.SpeechSynthesizer speech;
        public static System.Speech.Synthesis.SpeechSynthesizer speech2;

        public static void Speak(string txt)
        {
            if (SharedData.gFalar)
            {
                try
                {
                    if (speech != null)
                        speech.Dispose();

                    if (speech2 != null)
                        speech2.Dispose();
                    if (txt != "")
                    {
                        CultureInfo c = new CultureInfo("pt-BR"); //pt-BR usada como base
                        try
                        {
                            speech = new Microsoft.Speech.Synthesis.SpeechSynthesizer();
                        }
                        catch (Exception errVoice)
                        {
                            Log.GravaLog("Vozes não instaladas:" + errVoice.Message + ". Usará voz sistema");
                        }

                        if (speech != null && speech.GetInstalledVoices().Count() > 0)
                        {
                            speech.SetOutputToDefaultAudioDevice();
                            speech.SelectVoiceByHints(Microsoft.Speech.Synthesis.VoiceGender.Female, Microsoft.Speech.Synthesis.VoiceAge.Teen, 0, c);
                            speech.SpeakAsync(txt);
                        }
                        else
                        {
                            speech2 = new System.Speech.Synthesis.SpeechSynthesizer();
                            speech2.SelectVoiceByHints(System.Speech.Synthesis.VoiceGender.Female, System.Speech.Synthesis.VoiceAge.Teen, 0, c);
                            speech2.SpeakAsync(txt);
                        }
                        //reader.Volume = 100;
                    }
                }
                catch (Exception errVoice)
                {
                    Log.GravaLog("Voz não processada:" + errVoice.Message);
                }
            }
        }
        public static void SpeakTxt(string Instruction)
        {
            if (SharedData.gFalar)
            {
                if (Instruction != "")
                {
                    Instruction = Instruction + ".txt";
                    string Path = Falar.CriaArquivoFala(Instruction);
                    if (Path != "" && File.Exists(Path))
                    {
                        string[] lines = File.ReadAllLines(Path, Encoding.Default);
                        string text = string.Join(".", lines);

                        #region [ frases automatizadas ]
                        if (SharedData.User != null)
                            text = text.Replace("{UsuarioPrimeiroNome}", SharedData.User.NomeResponsavel.Substring(0, (SharedData.User.NomeResponsavel.IndexOf(" ") != -1 ? SharedData.User.NomeResponsavel.IndexOf(" ") : SharedData.User.NomeResponsavel.Length)));
                        else
                            text = text.Replace("{UsuarioPrimeiroNome}", "");
                        if (DateTime.Now.Hour < 12)
                            text = text.Replace("{CumprimentoHorario}", "Bom dia ");
                        else if (DateTime.Now.Hour < 18)
                            text = text.Replace("{CumprimentoHorario}", "Boa tarde ");
                        else
                            text = text.Replace("{CumprimentoHorario}", "Boa noite ");
                        #endregion

                        Falar.Speak(text);
                    }
                }
            }
        }
        public static string CriaArquivoFala(string Instruction)
        {
            string PathLOG = SharedData.LogPath;

            PathLOG += "Speak\\";

            Log.CriaDiretorioRede(PathLOG);

            string PathFull = PathLOG + Instruction;
            if (!File.Exists(PathFull))
            {
                using (System.IO.StreamWriter sw = System.IO.File.CreateText(PathFull))
                {
                    sw.Close();
                }
            }
            return PathFull;
        }
    }

    public static class Tempo
    {
        public static void Pausa(int Segundos, bool MostraContagem = false)
        {
            Loading L = null;
            if (MostraContagem)
            {
                L = new Loading();
                Loading.StaticFormVisible(true);
                Loading.EnableStaticTextBox("Aguardando " + Segundos + " segundos");
            }

            DateTime Inicio = DateTime.Now;
            TimeSpan Diferenca;

            for (; ; )
            {
                Diferenca = DateTime.Now.Subtract(Inicio);
                Application.DoEvents();
                if (MostraContagem)
                {
                    Loading.EnableStaticTextBox("Aguardando " + Math.Ceiling(Segundos - Diferenca.TotalSeconds) + " segundos");
                }
                if (Diferenca.TotalSeconds >= Segundos) break;
            }

            if (MostraContagem)
            {
                L.Close();
            }
        }
        public static void pausaMilisegundos(int MyMilliseconds)
        {
            Application.DoEvents();
            DateTime TimeNow = new DateTime();
            TimeNow = DateTime.Now;
            while ((DateTime.Now - TimeNow).TotalMilliseconds < MyMilliseconds)
            {
                if ((DateTime.Now - TimeNow).TotalMilliseconds > 5000 && (DateTime.Now - TimeNow).TotalMilliseconds < 5100) Console.Write("5 segundos");

                Application.DoEvents();
            }

        }
    }
    public static class LeitorPDF
    {
        public static string GetText(string FilePath, string Password = "")
        {
            string result = "";
            byte[] toBytes = Encoding.ASCII.GetBytes(Password);

            using (PdfReader reader = new PdfReader(FilePath, toBytes))
            {
                StringBuilder text = new StringBuilder();

                for (int i = 1; i <= reader.NumberOfPages; i++)
                {
                    text.Append(PdfTextExtractor.GetTextFromPage(reader, i));
                }

                result = text.ToString();
            }//
            return result;
        }

    }

    public static class WebMessage
    {
        #region [ DLL ]
        // Delegate we use to call methods when enumerating child windows.
        private delegate bool EnumWindowProc(IntPtr hWnd, IntPtr parameter);

        [DllImport("user32")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool EnumChildWindows(IntPtr window, EnumWindowProc callback, IntPtr i);

        [DllImport("user32.dll", EntryPoint = "FindWindow", SetLastError = true)]
        private static extern IntPtr FindWindowByCaption(IntPtr zeroOnly, string lpWindowName);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern IntPtr SendMessage(IntPtr hWnd, uint msg, IntPtr wParam, [Out] StringBuilder lParam);



        [DllImport("user32.dll")]
        static extern int GetFocus();

        [DllImport("user32.dll")]
        static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);

        [DllImport("kernel32.dll")]
        static extern uint GetCurrentThreadId();

        [DllImport("user32.dll")]
        static extern uint GetWindowThreadProcessId(int hWnd, int ProcessId);

        [DllImport("user32.dll")]
        static extern int GetForegroundWindow();

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        static extern int SendMessage(int hWnd, int Msg, int wParam, StringBuilder lParam);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, StringBuilder lParam);


        [DllImport("user32.dll", SetLastError = true)]
        static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string lpszClass, string lpszWindow);

        [DllImport("user32.dll", EntryPoint = "FindWindow", SetLastError = true)]
        private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        static extern IntPtr SendMessage(IntPtr hWnd, UInt32 Msg, IntPtr wParam, IntPtr lParam);
        #endregion        

        public static bool AguardaMensagem()
        {
            bool result = false;
            IntPtr hwnd = IntPtr.Zero;

            while (hwnd.ToString() == "0")
            {
                Application.DoEvents();
                hwnd = FindWindow(null, "Message from webpage");
                if (hwnd.ToString() == "0")
                {
                    hwnd = FindWindow(null, "Mensagem da página da web");
                }
            }
            
            result = true;
            return result;
        }

        public static bool PressOK()
        {
            bool result = false;
            IntPtr hwnd = FindWindow(null, "Message from webpage");
            if (hwnd.ToString() == "0")
            {
                hwnd = FindWindow(null, "Mensagem da página da web");
            }
            if (hwnd.ToString() != "0")
            {
                hwnd = FindWindowEx(hwnd, IntPtr.Zero, "Button", "OK");
                if (hwnd.ToString() != "0")
                {
                    uint message = 0xf5;
                    SendMessage(hwnd, message, IntPtr.Zero, IntPtr.Zero);

                    while (hwnd.ToString() != "0")
                    {
                        Application.DoEvents();
                        hwnd = FindWindow(null, "Message from webpage");
                        if (hwnd.ToString() == "0")
                        {
                            hwnd = FindWindow(null, "Mensagem da página da web");
                        }
                        if (hwnd.ToString() == "0")
                        {
                            result = true;
                        }
                    }
                }
            }
            return result;
        }

        public static string GetAllText()
        {
            string result = "";
            string nomeJanela = "Message from webpage";
            IntPtr hwnd = FindWindow(null, nomeJanela);
            
            if (hwnd.ToString() == "0")
            {
                nomeJanela = "Mensagem da página da web";
                hwnd = FindWindow(null, nomeJanela);
            }
            
            if (hwnd.ToString() != "0")
            {
                var allText = GetAllTextFromWindowByTitle(nomeJanela);
                result = allText.ToString();
            }
            return result;
        }

        // Callback method used to collect a list of child windows we need to capture text from.
        private static bool EnumChildWindowsCallback(IntPtr handle, IntPtr pointer)
        {
            // Creates a managed GCHandle object from the pointer representing a handle to the list created in GetChildWindows.
            var gcHandle = GCHandle.FromIntPtr(pointer);

            // Casts the handle back back to a List<IntPtr>
            var list = gcHandle.Target as List<IntPtr>;

            if (list == null)
            {
                throw new InvalidCastException("GCHandle Target could not be cast as List<IntPtr>");
            }

            // Adds the handle to the list.
            list.Add(handle);

            return true;
        }

        // Returns an IEnumerable<IntPtr> containing the handles of all child windows of the parent window.
        private static IEnumerable<IntPtr> GetChildWindows(IntPtr parent)
        {
            // Create list to store child window handles.
            var result = new List<IntPtr>();

            // Allocate list handle to pass to EnumChildWindows.
            var listHandle = GCHandle.Alloc(result);

            try
            {
                // Enumerates though all the child windows of the parent represented by IntPtr parent, executing EnumChildWindowsCallback for each. 
                EnumChildWindows(parent, EnumChildWindowsCallback, GCHandle.ToIntPtr(listHandle));
            }
            finally
            {
                // Free the list handle.
                if (listHandle.IsAllocated)
                    listHandle.Free();
            }

            // Return the list of child window handles.
            return result;
        }

        private static IEnumerable<IntPtr> GetChildWindowsExceptButtons(IntPtr parent)
        {
            // Create list to store child window handles.
            var result = new List<IntPtr>();
            var buttons = new List<IntPtr>();

            // Allocate list handle to pass to EnumChildWindows.
            var listHandle = GCHandle.Alloc(result);

            try
            {
                // Enumerates though all the child windows of the parent represented by IntPtr parent, executing EnumChildWindowsCallback for each. 
                EnumChildWindows(parent, EnumChildWindowsCallback, GCHandle.ToIntPtr(listHandle));
            }
            finally
            {
                // Free the list handle.
                if (listHandle.IsAllocated)
                    listHandle.Free();
            }


            IntPtr butHandle = IntPtr.Zero;
            do
            {
                butHandle = FindWindowEx(parent, butHandle, "Button", null);
                if (butHandle != IntPtr.Zero)
                    buttons.Add(butHandle);
            }
            while (butHandle != IntPtr.Zero);

            foreach (var b in buttons)
            {
                int indexButton = result.IndexOf(b);
                if (indexButton != -1)
                    result.RemoveAt(indexButton);
            }

            // Return the list of child window handles.
            return result;
        }

        // Gets text text from a control by it's handle.
        private static string GetText(IntPtr handle)
        {
            const uint WM_GETTEXTLENGTH = 0x000E;
            const uint WM_GETTEXT = 0x000D;

            // Gets the text length.
            var length = (int)SendMessage(handle, WM_GETTEXTLENGTH, IntPtr.Zero, null);

            // Init the string builder to hold the text.
            var sb = new StringBuilder(length + 1);

            // Writes the text from the handle into the StringBuilder
            SendMessage(handle, WM_GETTEXT, (IntPtr)sb.Capacity, sb);

            // Return the text as a string.
            return sb.ToString();
        }

        // Wraps everything together. Will accept a window title and return all text in the window that matches that window title.
        private static string GetAllTextFromWindowByTitle(string windowTitle)
        {
            var sb = new StringBuilder();

            try
            {
                // Find the main window's handle by the title.
                var windowHWnd = FindWindowByCaption(IntPtr.Zero, windowTitle);

                // Loop though the child windows, and execute the EnumChildWindowsCallback method
                var childWindows = GetChildWindowsExceptButtons(windowHWnd);

                // For each child handle, run GetText
                foreach (var childWindowText in childWindows.Select(GetText))
                {
                    // Append the text to the string builder.
                    sb.Append(childWindowText);
                }

                // Return the windows full text.
                return sb.ToString();
            }
            catch (Exception e)
            {
                Console.Write(e.Message);
            }

            return string.Empty;
        }

    }

    public static class WebFunctions
    {
        public static void PreenchePaginaWebById(WebBrowser wb, string HtmlElementId, string valor, string Evento = "", int TimeOut = 10)
        {
            DateTime Inicio;
            TimeSpan Diferenca;
            Inicio = DateTime.Now;
            while (wb.ReadyState != WebBrowserReadyState.Complete || wb.Url == null)
            {
                Diferenca = DateTime.Now.Subtract(Inicio);
                Application.DoEvents();
                if (Diferenca.TotalSeconds >= TimeOut)
                {
                    throw new Exception("TIMEOUT");
                }
                Application.DoEvents();
            }

            HtmlElement selector = null;
            Inicio = DateTime.Now;
            while (selector == null)
            {
                Application.DoEvents();
                selector = wb.Document.GetElementById(HtmlElementId);

                Diferenca = DateTime.Now.Subtract(Inicio);
                Application.DoEvents();
                if (Diferenca.TotalSeconds >= TimeOut)
                {
                    throw new Exception("TIMEOUT");
                }
            }


            if (selector != null)
            {
                if (selector.CanHaveChildren)
                {
                    while (selector == null || selector.Children.Count == 0)
                    {
                        Application.DoEvents();
                        selector = wb.Document.GetElementById(HtmlElementId);

                        Diferenca = DateTime.Now.Subtract(Inicio);
                        Application.DoEvents();
                        if (Diferenca.TotalSeconds >= TimeOut)
                        {
                            throw new Exception("TIMEOUT");
                        }

                    }
                    bool selecionado = false;
                    while (!selecionado)
                    {
                        foreach (HtmlElement e in selector.Children)
                        {
                            if (e.InnerText != null && e.InnerText.ToUpper() == (valor).ToUpper())
                            {
                                e.SetAttribute("selected", "true");
                                Application.DoEvents();
                                selecionado = true;
                                break;
                            }
                        }
                        Application.DoEvents();
                    }
                }
                else if (selector.GetAttribute("type").ToString().ToUpper() != "BUTTON" && selector.GetAttribute("type").ToString().ToUpper() != "SUBMIT")
                {
                    selector.SetAttribute("value", valor);
                    Application.DoEvents();
                    while (selector == null || selector.GetAttribute("value").ToString().ToUpper() != valor.ToUpper())
                    {
                        Application.DoEvents();
                        selector = wb.Document.GetElementById(HtmlElementId);
                    }
                }

                #region [ Executa evento ]
                if (Evento.ToUpper() != "NAVIGATE" && Evento.ToUpper() != "")
                {
                    try
                    {
                        selector.InvokeMember(Evento);
                    }
                    catch { }
                    //try
                    //{
                    //selector.RaiseEvent(trad.Evento);
                    //}
                    //catch { }
                }
                #endregion
            }
        }

        public static bool LoginMar2(string url, string funcional, string password, WebBrowser wb, string frameMar2 = "iframeLoginMar2", bool log = false, string SistemaLog = "", int Timeout = 30)
        {
            bool result = false;
            DateTime Inicio;
            TimeSpan Diferenca;

            wb.ScriptErrorsSuppressed = true;

            if (log)
                Log.GravaLog("Acessando: " + url, SistemaLog);
            wb.Navigate(url);

            Inicio = DateTime.Now;
            while (wb.ReadyState != WebBrowserReadyState.Complete || wb.Url == null)
            {
                Diferenca = DateTime.Now.Subtract(Inicio);
                Application.DoEvents();
                if (Diferenca.TotalSeconds >= Timeout)
                {
                    if (log)
                        Log.GravaLog("TIMEOUT", SistemaLog);
                    result = false;
                    return result;
                }
                Application.DoEvents();
            }

            if (wb.Url == null || wb.Url.ToString().Replace("https", "http") != url.Replace("https", "http"))
            {
                if (password != "")
                {
                    HtmlElement frame = wb.Document.GetElementById(frameMar2);

                    if (frame != null)
                    {
                        string urlFrame = frame.GetAttribute("src");
                        if (log)
                            Log.GravaLog("Frame: " + urlFrame, SistemaLog);
                        wb.Navigate(urlFrame);

                        Inicio = DateTime.Now;
                        while (wb.ReadyState != WebBrowserReadyState.Complete || wb.Url == null || wb.Url.ToString().Replace("https", "http") != urlFrame.Replace("https", "http"))
                        {
                            Diferenca = DateTime.Now.Subtract(Inicio);
                            if (Diferenca.TotalSeconds >= Timeout)
                            {
                                if (log)
                                    Log.GravaLog("TIMEOUT", SistemaLog);
                                result = false;
                                return result;
                            }
                            Application.DoEvents();
                        }

                        HtmlElement Htmlusername = wb.Document.GetElementById("formLoginNormal_username");
                        HtmlElement Htmlpassword = wb.Document.GetElementById("formLoginNormal_password");
                        HtmlElement Htmlbutton = wb.Document.GetElementById("button1");

                        if (Htmlusername != null && Htmlpassword != null && Htmlbutton != null)
                        {
                            Htmlusername.InnerText = funcional;
                            Htmlpassword.InnerText = password;
                            Application.DoEvents();
                            Htmlbutton.InvokeMember("click");
                            Application.DoEvents();
                            if (log)
                                Log.GravaLog("Logando Mar2", SistemaLog);

                            Inicio = DateTime.Now;
                            while (wb.ReadyState != WebBrowserReadyState.Complete || wb.Url == null || wb.Url.ToString().Replace("https", "http") == urlFrame.Replace("https", "http"))
                            {
                                Diferenca = DateTime.Now.Subtract(Inicio);
                                Application.DoEvents();
                                if (Diferenca.TotalSeconds >= Timeout)
                                {
                                    if (wb.ReadyState == WebBrowserReadyState.Complete)
                                    {
                                        if (log)
                                            Log.GravaLog("TIMEOUT", SistemaLog);
                                        result = false;
                                        return result;
                                    }
                                }
                                Application.DoEvents();
                            }

                            if (log)
                                Log.GravaLog("Acessando: " + url, SistemaLog);

                            if (wb.Url.ToString().ToUpper().Contains("HTTPS"))
                            {
                                url = url.Replace("http:", "https:");
                            }
                            else
                            {
                                url = url.Replace("https:", "http:");
                            }
                            wb.Navigate(url);

                            Inicio = DateTime.Now;
                            while (wb.ReadyState != WebBrowserReadyState.Complete || wb.Url == null || wb.Url.ToString().Replace("https", "http") != url.Replace("https", "http"))
                            {
                                frame = null;
                                if (wb.ReadyState == WebBrowserReadyState.Complete)
                                {
                                    frame = wb.Document.GetElementById(frameMar2);

                                    if (frame != null)
                                    {
                                        if (log)
                                            Log.GravaLog("Não conseguiu logar...", SistemaLog);
                                        result = false;
                                        return result;
                                    }
                                }
                                Diferenca = DateTime.Now.Subtract(Inicio);
                                Application.DoEvents();
                                if (Diferenca.TotalSeconds >= Timeout)
                                {
                                    if (log)
                                        Log.GravaLog("TIMEOUT", SistemaLog);
                                    result = false;
                                    return result;
                                }
                                Application.DoEvents();
                            }

                            if (log)
                                Log.GravaLog("Logado em: " + wb.Url.ToString(), SistemaLog);
                            result = true;
                        }
                        else
                        {
                            if (log)
                                Log.GravaLog("Falha ao identificar elementos na página: Username (" + (Htmlusername != null ? "OK" : "null") + ") - Password (" + (Htmlpassword != null ? "OK" : "null") + ") - Botão(" + (Htmlbutton != null ? "OK" : "null") + ")", SistemaLog);
                            result = false;
                        }
                    }
                    else
                    {
                        if (wb.Url.ToString().Replace("https", "http") == url.Replace("https", "http"))
                        {
                            if (log)
                                Log.GravaLog("Já logado em: " + url, SistemaLog);
                            result = true;
                        }
                        else
                        {
                            if (log)
                                Log.GravaLog("Frame do Mar2 não localizado: " + frameMar2, SistemaLog);
                            result = false;
                        }
                    }
                }
                else
                {
                    if (log)
                        Log.GravaLog("Senha não informada", SistemaLog);
                }
            }
            else
            {
                if (log)
                    Log.GravaLog("Já logado em: " + url, SistemaLog);
                result = true;
            }
            return result;
        }
    }
}
