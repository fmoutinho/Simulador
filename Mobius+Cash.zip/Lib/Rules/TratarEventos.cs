﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;
// Coloquei
using System.IO;
using System.Windows.Forms;
using System.Data;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using System.Configuration;


namespace Mobios
{
    public static class TratarEventos
    {
  
        //====================================================================================
        // Cria diretório
        //====================================================================================
        public static void CriarDiretorio(string path)
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }        
        }

        //**********************************************************************************
        // Função que grava a linha do evento 
        //**********************************************************************************
        public static void GravaLinhaEvento(int idServico, string tipoIndicador, string regraCalculo, string itemIndicador, string valor, string CampoTipoValor, string usuario, string evento, string Qdo, string chaveTimeStamp = "")
        {
            //GravaLinhaEvento(idServico, c.tipoIndicador, c.formula, c.itemIndicador, c.valor, usuario, c.evento,);
            // Recupera local para gravação do INDICADOR
            string pathInd = TratamentoCampo.AdicionaBarraPath(BuscaPathIndicadores());            
            string pathNome = pathInd + idServico + ".txt";
            string linha = "";

            // Verifica diretório
            CriarDiretorio(pathInd);

            // Abre ou cria arquivo
            StreamWriter objWriter = new StreamWriter(pathNome, true);

            // Grava eventoe somente; as regras está no tratamento do arquivo txt;                                      
            string vlrIndicador = "";
            if (CampoTipoValor.ToUpper() == "NOW")
            {
                vlrIndicador = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
            }
            else if (CampoTipoValor.ToUpper() == "VALUE")
            {
                vlrIndicador = valor;
            }
            else
            {
                vlrIndicador = valor;
            }

            string[] tipoInd = tipoIndicador.Split(';');
            foreach (string indicador in tipoInd)
            {
                linha = idServico + ";" + indicador + ";" + regraCalculo + ";" + itemIndicador + ";" + vlrIndicador + ";" + usuario + ";" + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + ";" + evento + ";" + Qdo + ";" + chaveTimeStamp;
                objWriter.WriteLine(linha);
            }
            // Fecha arquivo
            objWriter.Close();
        }

        //**********************************************************************************
        // Função que le arquivo indicadores 
        //**********************************************************************************
        public static void MontaIndicadoresServico(string pathNome, int idServico, string pathLido)
        {
            string linha = "";
            string[] arrText;
            
            // Verifica arquivo existe
            if (File.Exists(pathNome))
            {
                StreamReader objReader = new StreamReader(pathNome);
                
                while (linha != null)
                {
                    linha = objReader.ReadLine();
                    if (linha != null)
                    {
                        arrText = linha.Split(';');
                        if (arrText.Count() == 10)
                            DataAccess.IncluirIndicador(arrText[0], arrText[1], arrText[2], arrText[3], arrText[4], arrText[9]);
                        else
                            DataAccess.IncluirIndicador(arrText[0], arrText[1], arrText[2], arrText[3], arrText[4]);
                    }
                }                 
                // Fecha objeto
                objReader.Close();

                // Move arquivo
                File.Move(pathNome, pathLido);
            }
        }
                
        //**********************************************************************************
        // Processa o arquivo encontrado no diretório
        //**********************************************************************************
        public static void ProcessFile(string path)
        {
            string nomeArquivo = Path.GetFileName(path);
            int IdServico = Convert.ToInt32(nomeArquivo.Substring(0, nomeArquivo.IndexOf('.')));            
            //MessageBox.Show(IdServico.ToString());
            string pathLido = TratamentoCampo.AdicionaBarraPath(BuscaPathIndicadoresLidos()) + IdServico + DateTime.Now.ToString("yyyy-MM-dd_hhmmss") + ".txt";
            TratarEventos.MontaIndicadoresServico(path, IdServico, pathLido);            
        }

        //**********************************************************************************
        // Procura os arquivos no diretório
        //**********************************************************************************
        public static void ProcessDirectory(string targetDirectory)
        {
            // Process the list of files found in the directory.
            string[] fileEntries = Directory.GetFiles(targetDirectory);
            foreach (string fileName in fileEntries)
            {
                if (fileName.Contains("txt") == true)
                {
                    ProcessFile(fileName);
                }
            }

            ////// Recurse into subdirectories of this directory.
            ////string[] subdirectoryEntries = Directory.GetDirectories(targetDirectory);
            ////foreach (string subdirectory in subdirectoryEntries)
            ////    ProcessDirectory(subdirectory);
        }
        public static string BuscaPathIndicadores()
        {
            string result = "";
            if (SharedData.gHomologação)
            {
                result = ConfigurationManager.AppSettings["IndicadoresINIhomologacao"].ToString();
            }
            else
            {
                result = ConfigurationManager.AppSettings["IndicadoresINI"].ToString();
            }

            return result;
            
        }
        public static string BuscaPathIndicadoresLidos()
        {
            string result = "";
            if (SharedData.gHomologação)
            {
                result = ConfigurationManager.AppSettings["IndicadoresINILidosHomologacao"].ToString();
            }
            else
            {
                result = ConfigurationManager.AppSettings["IndicadoresINILidos"].ToString();
            }

            return result;

        }

        public static void ExportaDataGridView(DataGridView DG)
        {
            try
            {
                if (DG.Rows.Count > 0)
                {
                    SaveFileDialog SV = new SaveFileDialog();
                    SV.Filter = "CSV|*.csv";
                    if (SV.ShowDialog() == DialogResult.OK)
                    {
                        StringBuilder sb = new StringBuilder();
                        List<string> linhas = new List<string>();

                        List<string> columnNames = new List<string>();
                        List<string> columnHeader = new List<string>();
                        foreach (DataGridViewColumn c in DG.Columns)
                        {
                            if (c.Visible == true && c.Name != "Selecionar")
                            {
                                columnNames.Add(c.Name);
                                columnHeader.Add(c.HeaderText);
                            }
                        }

                        string columnsTitle = string.Join(";", columnHeader);
                        if (columnsTitle.Length > 2 && columnsTitle.Substring(0, 2).ToUpper() == "ID")
                        {
                            columnsTitle = "COD" + columnsTitle.Substring(2);
                        }
                        linhas.Add(columnsTitle);

                        foreach (DataGridViewRow row in DG.Rows)
                        {
                            List<string> fields = new List<string>();
                            foreach (string c in columnNames)
                            {
                                if (DG.Columns.Contains(c))
                                {
                                    fields.Add(row.Cells[c].Value.ToString().Replace(";", ",").Replace("\r", " | ").Replace("\n", " "));
                                }
                                else
                                {
                                    fields.Add("");
                                }
                            }
                            linhas.Add(string.Join(";", fields));
                        }

                        foreach (string l in linhas)
                        {
                            sb.AppendLine(l);
                        }

                        try
                        {
                            File.WriteAllText(SV.FileName, sb.ToString(), Encoding.Default);
                            MessageBox.Show("Relatório gerado com sucesso", "Relatórios", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            if (MessageBox.Show("Abrir relatório?", "MOBIOS+", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                            {
                                System.Diagnostics.Process.Start(SV.FileName);
                            }
                        }
                        catch
                        {
                            MessageBox.Show("Não foi possível salvar.\n\nVerifique se o arquivo já está em uso", "Relatórios", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Não há dados para geração do relatório com os parâmetros especificados.", "Relatórios", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro : " + ex.Message);
            }
        }

        public static void ExportaDataTable(DataTable dt, string SavePath = "", string SaveName = "", bool AbrirArquivo = false)
        {

            bool Salvar = false;
            string SavePathFull = "";

            if ((dt != null) && (dt.Rows.Count > 0))
            {
                if (SavePath == "")
                {
                    SaveFileDialog Save = new SaveFileDialog();
                    Save.Filter = "CSV|*.csv";
                    DialogResult ResultDialog = Save.ShowDialog();
                    if (ResultDialog == DialogResult.OK)
                    {
                        Salvar = true;
                        SavePathFull = Save.FileName;
                    }

                }
                else
                {
                    SavePathFull = SavePath + SaveName;
                    if (!Directory.Exists(SavePath))
                        Directory.CreateDirectory(SavePath);
                    Salvar = true;
                }


                if (Salvar)
                {
                    StringBuilder sb = new StringBuilder();
                    IEnumerable<string> columnNames = dt.Columns.Cast<DataColumn>().Select(column => column.ColumnName);
                    string columnsTitle = string.Join(";", columnNames);
                    if (columnsTitle.Length > 2 && columnsTitle.Substring(0, 2).ToUpper() == "ID")
                    {
                        columnsTitle = "COD" + columnsTitle.Substring(2);
                    }
                    sb.AppendLine(columnsTitle);
                    foreach (DataRow row in dt.Rows)
                    {
                        IEnumerable<string> fields = row.ItemArray.Select(field => field.ToString().Replace(";", ",").Replace("\r", " | ").Replace("\n", " "));
                        sb.AppendLine(string.Join(";", fields));
                    }
                    try
                    {
                        File.WriteAllText(SavePathFull, sb.ToString(), Encoding.Default);
                        if (AbrirArquivo)
                        {
                            if (MessageBox.Show("Relatório gerado com sucesso\nAbrir relatório?", "Relatório", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                            {
                                System.Diagnostics.Process.Start(SavePathFull);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Não foi possível salvar.\n\nVerifique se o arquivo já está em uso.\n\nErro: " + ex.Message, "Relatórios", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            else
            {
                MessageBox.Show("Não há dados para geração do relatório com os parâmetros especificados.", "Relatórios", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        
    }
}
