﻿namespace Mobios
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.pesqusarBoletoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.workFlowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registrarOperacaoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pipelineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripImports = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripImportWAO = new System.Windows.Forms.ToolStripMenuItem();
            this.integradoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestãoDeAtendimentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.analistasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.célulasDeAtendimentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.areasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.produtosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.associarAnalistasEProdutosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.relatóriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.cboRel = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.telasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cmbTelas = new System.Windows.Forms.ToolStripComboBox();
            this.abrirTelaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configuraçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parâmetrosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fecharInstânciasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.testeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pontoEletrônicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.suporteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.tslNome = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblAmbiente = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblStatusAmbiente = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblIntegradorWeb = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblStatusIntegradorWeb = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tssHoje = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tssTermo = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tssD0 = new System.Windows.Forms.ToolStripStatusLabel();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.backgroundWorker = new System.ComponentModel.BackgroundWorker();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.lbEmail = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpInicioPeriodo = new System.Windows.Forms.DateTimePicker();
            this.txtInicioPeriodo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFimPeriodo = new System.Windows.Forms.TextBox();
            this.dtpFimPeriodo = new System.Windows.Forms.DateTimePicker();
            this.txPass = new System.Windows.Forms.TextBox();
            this.bgwObrigaFechamento = new System.ComponentModel.BackgroundWorker();
            this.timerFechamento = new System.Windows.Forms.Timer(this.components);
            this.timerPipe = new System.Windows.Forms.Timer(this.components);
            this.timerPortal = new System.Windows.Forms.Timer(this.components);
            this.timerBackUp = new System.Windows.Forms.Timer(this.components);
            this.bgwBackup = new System.ComponentModel.BackgroundWorker();
            this.timerValidaPonto = new System.Windows.Forms.Timer(this.components);
            this.bgwValidaPonto = new System.ComponentModel.BackgroundWorker();
            this.menuStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pesqusarBoletoToolStripMenuItem,
            this.workFlowToolStripMenuItem,
            this.registrarOperacaoToolStripMenuItem,
            this.pipelineToolStripMenuItem,
            this.toolStripImports,
            this.gestãoDeAtendimentoToolStripMenuItem,
            this.relatóriosToolStripMenuItem,
            this.telasToolStripMenuItem,
            this.configuraçõesToolStripMenuItem,
            this.pontoEletrônicoToolStripMenuItem,
            this.suporteToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(1069, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "menuStrip";
            // 
            // pesqusarBoletoToolStripMenuItem
            // 
            this.pesqusarBoletoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("pesqusarBoletoToolStripMenuItem.Image")));
            this.pesqusarBoletoToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.pesqusarBoletoToolStripMenuItem.Name = "pesqusarBoletoToolStripMenuItem";
            this.pesqusarBoletoToolStripMenuItem.Size = new System.Drawing.Size(81, 20);
            this.pesqusarBoletoToolStripMenuItem.Text = "Pesquisar";
            this.pesqusarBoletoToolStripMenuItem.Click += new System.EventHandler(this.pesqusarBoletoToolStripMenuItem_Click);
            // 
            // workFlowToolStripMenuItem
            // 
            this.workFlowToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("workFlowToolStripMenuItem.Image")));
            this.workFlowToolStripMenuItem.Name = "workFlowToolStripMenuItem";
            this.workFlowToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
            this.workFlowToolStripMenuItem.Text = "Workflow";
            this.workFlowToolStripMenuItem.Click += new System.EventHandler(this.workFlowToolStripMenuItem_Click);
            // 
            // registrarOperacaoToolStripMenuItem
            // 
            this.registrarOperacaoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("registrarOperacaoToolStripMenuItem.Image")));
            this.registrarOperacaoToolStripMenuItem.Name = "registrarOperacaoToolStripMenuItem";
            this.registrarOperacaoToolStripMenuItem.Size = new System.Drawing.Size(116, 20);
            this.registrarOperacaoToolStripMenuItem.Text = "Registrar serviço";
            this.registrarOperacaoToolStripMenuItem.Click += new System.EventHandler(this.registrarOperacaoToolStripMenuItem_Click);
            // 
            // pipelineToolStripMenuItem
            // 
            this.pipelineToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("pipelineToolStripMenuItem.Image")));
            this.pipelineToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.pipelineToolStripMenuItem.Name = "pipelineToolStripMenuItem";
            this.pipelineToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.pipelineToolStripMenuItem.Text = "Pipeline";
            this.pipelineToolStripMenuItem.Click += new System.EventHandler(this.pipelineToolStripMenuItem_Click);
            // 
            // toolStripImports
            // 
            this.toolStripImports.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripImportWAO,
            this.integradoresToolStripMenuItem});
            this.toolStripImports.Image = ((System.Drawing.Image)(resources.GetObject("toolStripImports.Image")));
            this.toolStripImports.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripImports.Name = "toolStripImports";
            this.toolStripImports.Size = new System.Drawing.Size(90, 20);
            this.toolStripImports.Text = "Importação";
            // 
            // toolStripImportWAO
            // 
            this.toolStripImportWAO.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripImportWAO.AutoSize = false;
            this.toolStripImportWAO.Name = "toolStripImportWAO";
            this.toolStripImportWAO.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.toolStripImportWAO.Size = new System.Drawing.Size(260, 22);
            this.toolStripImportWAO.Text = "Importar WAO";
            this.toolStripImportWAO.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.toolStripImportWAO.Visible = false;
            this.toolStripImportWAO.Click += new System.EventHandler(this.toolStripImportWAO_Click);
            // 
            // integradoresToolStripMenuItem
            // 
            this.integradoresToolStripMenuItem.Name = "integradoresToolStripMenuItem";
            this.integradoresToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.integradoresToolStripMenuItem.Text = "Integradores";
            this.integradoresToolStripMenuItem.Click += new System.EventHandler(this.integradoresToolStripMenuItem_Click);
            // 
            // gestãoDeAtendimentoToolStripMenuItem
            // 
            this.gestãoDeAtendimentoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.analistasToolStripMenuItem,
            this.célulasDeAtendimentoToolStripMenuItem,
            this.areasToolStripMenuItem,
            this.produtosToolStripMenuItem,
            this.associarAnalistasEProdutosToolStripMenuItem});
            this.gestãoDeAtendimentoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("gestãoDeAtendimentoToolStripMenuItem.Image")));
            this.gestãoDeAtendimentoToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.gestãoDeAtendimentoToolStripMenuItem.Name = "gestãoDeAtendimentoToolStripMenuItem";
            this.gestãoDeAtendimentoToolStripMenuItem.Size = new System.Drawing.Size(148, 20);
            this.gestãoDeAtendimentoToolStripMenuItem.Text = "Gestão de Atendimento";
            // 
            // analistasToolStripMenuItem
            // 
            this.analistasToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("analistasToolStripMenuItem.Image")));
            this.analistasToolStripMenuItem.Name = "analistasToolStripMenuItem";
            this.analistasToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.analistasToolStripMenuItem.Text = "Analistas";
            this.analistasToolStripMenuItem.Click += new System.EventHandler(this.analistasToolStripMenuItem_Click);
            // 
            // célulasDeAtendimentoToolStripMenuItem
            // 
            this.célulasDeAtendimentoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("célulasDeAtendimentoToolStripMenuItem.Image")));
            this.célulasDeAtendimentoToolStripMenuItem.Name = "célulasDeAtendimentoToolStripMenuItem";
            this.célulasDeAtendimentoToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.célulasDeAtendimentoToolStripMenuItem.Text = "Células de Atendimento";
            this.célulasDeAtendimentoToolStripMenuItem.Click += new System.EventHandler(this.célulasDeAtendimentoToolStripMenuItem_Click);
            // 
            // areasToolStripMenuItem
            // 
            this.areasToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("areasToolStripMenuItem.Image")));
            this.areasToolStripMenuItem.Name = "areasToolStripMenuItem";
            this.areasToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.areasToolStripMenuItem.Text = "Áreas de Atuação";
            this.areasToolStripMenuItem.Click += new System.EventHandler(this.areasToolStripMenuItem_Click);
            // 
            // produtosToolStripMenuItem
            // 
            this.produtosToolStripMenuItem.Name = "produtosToolStripMenuItem";
            this.produtosToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.produtosToolStripMenuItem.Text = "Produtos/Serviços";
            this.produtosToolStripMenuItem.Click += new System.EventHandler(this.produtosToolStripMenuItem_Click);
            // 
            // associarAnalistasEProdutosToolStripMenuItem
            // 
            this.associarAnalistasEProdutosToolStripMenuItem.Name = "associarAnalistasEProdutosToolStripMenuItem";
            this.associarAnalistasEProdutosToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.associarAnalistasEProdutosToolStripMenuItem.Text = "Associar Analistas e Produtos";
            this.associarAnalistasEProdutosToolStripMenuItem.Click += new System.EventHandler(this.associarAnalistasEProdutosToolStripMenuItem_Click);
            // 
            // relatóriosToolStripMenuItem
            // 
            this.relatóriosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripTextBox1,
            this.cboRel,
            this.toolStripMenuItem1});
            this.relatóriosToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("relatóriosToolStripMenuItem.Image")));
            this.relatóriosToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.relatóriosToolStripMenuItem.Name = "relatóriosToolStripMenuItem";
            this.relatóriosToolStripMenuItem.Size = new System.Drawing.Size(83, 20);
            this.relatóriosToolStripMenuItem.Text = "Relatórios";
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.AutoSize = false;
            this.toolStripTextBox1.Enabled = false;
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(200, 21);
            this.toolStripTextBox1.Text = "Selecione o relatório  desejado abaixo:";
            // 
            // cboRel
            // 
            this.cboRel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cboRel.Name = "cboRel";
            this.cboRel.Size = new System.Drawing.Size(200, 21);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripMenuItem1.AutoSize = false;
            this.toolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem1.Image")));
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.toolStripMenuItem1.Size = new System.Drawing.Size(260, 22);
            this.toolStripMenuItem1.Text = "Gerar relatório";
            this.toolStripMenuItem1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // telasToolStripMenuItem
            // 
            this.telasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmbTelas,
            this.abrirTelaToolStripMenuItem});
            this.telasToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("telasToolStripMenuItem.Image")));
            this.telasToolStripMenuItem.Name = "telasToolStripMenuItem";
            this.telasToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.telasToolStripMenuItem.Text = "Ações";
            this.telasToolStripMenuItem.Click += new System.EventHandler(this.telasToolStripMenuItem_Click);
            // 
            // cmbTelas
            // 
            this.cmbTelas.Name = "cmbTelas";
            this.cmbTelas.Size = new System.Drawing.Size(152, 21);
            this.cmbTelas.Text = "Escolha uma Ação";
            this.cmbTelas.SelectedIndexChanged += new System.EventHandler(this.selecionaTelasToolStripMenuItem_SelectedIndexChanged);
            // 
            // abrirTelaToolStripMenuItem
            // 
            this.abrirTelaToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.abrirTelaToolStripMenuItem.AutoToolTip = true;
            this.abrirTelaToolStripMenuItem.Enabled = false;
            this.abrirTelaToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("abrirTelaToolStripMenuItem.Image")));
            this.abrirTelaToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.abrirTelaToolStripMenuItem.Name = "abrirTelaToolStripMenuItem";
            this.abrirTelaToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.abrirTelaToolStripMenuItem.Text = "Executar";
            this.abrirTelaToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.abrirTelaToolStripMenuItem.Click += new System.EventHandler(this.abrirTelaToolStripMenuItem_Click);
            // 
            // configuraçõesToolStripMenuItem
            // 
            this.configuraçõesToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.configuraçõesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parâmetrosToolStripMenuItem,
            this.fecharInstânciasToolStripMenuItem,
            this.logToolStripMenuItem,
            this.testeToolStripMenuItem});
            this.configuraçõesToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("configuraçõesToolStripMenuItem.Image")));
            this.configuraçõesToolStripMenuItem.Name = "configuraçõesToolStripMenuItem";
            this.configuraçõesToolStripMenuItem.Size = new System.Drawing.Size(104, 20);
            this.configuraçõesToolStripMenuItem.Text = "Configurações";
            // 
            // parâmetrosToolStripMenuItem
            // 
            this.parâmetrosToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("parâmetrosToolStripMenuItem.Image")));
            this.parâmetrosToolStripMenuItem.Name = "parâmetrosToolStripMenuItem";
            this.parâmetrosToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.parâmetrosToolStripMenuItem.Text = "Parâmetros";
            this.parâmetrosToolStripMenuItem.Click += new System.EventHandler(this.parâmetrosToolStripMenuItem_Click);
            // 
            // fecharInstânciasToolStripMenuItem
            // 
            this.fecharInstânciasToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("fecharInstânciasToolStripMenuItem.Image")));
            this.fecharInstânciasToolStripMenuItem.Name = "fecharInstânciasToolStripMenuItem";
            this.fecharInstânciasToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.fecharInstânciasToolStripMenuItem.Text = "Fechar Todos";
            this.fecharInstânciasToolStripMenuItem.Click += new System.EventHandler(this.fecharInstânciasToolStripMenuItem_Click);
            // 
            // logToolStripMenuItem
            // 
            this.logToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("logToolStripMenuItem.Image")));
            this.logToolStripMenuItem.Name = "logToolStripMenuItem";
            this.logToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.logToolStripMenuItem.Text = "Log";
            this.logToolStripMenuItem.Click += new System.EventHandler(this.logToolStripMenuItem_Click);
            // 
            // testeToolStripMenuItem
            // 
            this.testeToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("testeToolStripMenuItem.Image")));
            this.testeToolStripMenuItem.Name = "testeToolStripMenuItem";
            this.testeToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.testeToolStripMenuItem.Text = "Teste";
            // 
            // pontoEletrônicoToolStripMenuItem
            // 
            this.pontoEletrônicoToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.pontoEletrônicoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("pontoEletrônicoToolStripMenuItem.Image")));
            this.pontoEletrônicoToolStripMenuItem.Name = "pontoEletrônicoToolStripMenuItem";
            this.pontoEletrônicoToolStripMenuItem.Size = new System.Drawing.Size(113, 20);
            this.pontoEletrônicoToolStripMenuItem.Text = "Ponto Eletrônico";
            this.pontoEletrônicoToolStripMenuItem.Click += new System.EventHandler(this.pontoEletrônicoToolStripMenuItem_Click);
            // 
            // suporteToolStripMenuItem
            // 
            this.suporteToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.suporteToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("suporteToolStripMenuItem.Image")));
            this.suporteToolStripMenuItem.Name = "suporteToolStripMenuItem";
            this.suporteToolStripMenuItem.Size = new System.Drawing.Size(73, 20);
            this.suporteToolStripMenuItem.Text = "Suporte";
            this.suporteToolStripMenuItem.Click += new System.EventHandler(this.suporteToolStripMenuItem_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tslNome,
            this.lblAmbiente,
            this.lblStatusAmbiente,
            this.lblIntegradorWeb,
            this.lblStatusIntegradorWeb,
            this.toolStripStatusLabel1,
            this.tssHoje,
            this.toolStripStatusLabel3,
            this.tssTermo,
            this.toolStripStatusLabel5,
            this.tssD0});
            this.statusStrip.Location = new System.Drawing.Point(0, 533);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(1069, 22);
            this.statusStrip.TabIndex = 1;
            this.statusStrip.Text = "statusStrip";
            // 
            // tslNome
            // 
            this.tslNome.Name = "tslNome";
            this.tslNome.Size = new System.Drawing.Size(86, 17);
            this.tslNome.Text = "Bem vindo, {0} |";
            // 
            // lblAmbiente
            // 
            this.lblAmbiente.Name = "lblAmbiente";
            this.lblAmbiente.Size = new System.Drawing.Size(52, 17);
            this.lblAmbiente.Text = "Ambiente";
            // 
            // lblStatusAmbiente
            // 
            this.lblStatusAmbiente.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.lblStatusAmbiente.ForeColor = System.Drawing.Color.Red;
            this.lblStatusAmbiente.Name = "lblStatusAmbiente";
            this.lblStatusAmbiente.Size = new System.Drawing.Size(123, 17);
            this.lblStatusAmbiente.Text = "HOMOLOGAÇÃO";
            // 
            // lblIntegradorWeb
            // 
            this.lblIntegradorWeb.Name = "lblIntegradorWeb";
            this.lblIntegradorWeb.Size = new System.Drawing.Size(85, 17);
            this.lblIntegradorWeb.Text = "IntegradorWeb:";
            // 
            // lblStatusIntegradorWeb
            // 
            this.lblStatusIntegradorWeb.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.lblStatusIntegradorWeb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblStatusIntegradorWeb.Name = "lblStatusIntegradorWeb";
            this.lblStatusIntegradorWeb.Size = new System.Drawing.Size(30, 17);
            this.lblStatusIntegradorWeb.Text = "ON";
            this.lblStatusIntegradorWeb.Click += new System.EventHandler(this.lblStatusIntegrador_Click);
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(102, 17);
            this.toolStripStatusLabel1.Text = "Boletos vencendo:  ";
            this.toolStripStatusLabel1.Visible = false;
            // 
            // tssHoje
            // 
            this.tssHoje.Name = "tssHoje";
            this.tssHoje.Size = new System.Drawing.Size(23, 17);
            this.tssHoje.Text = "##";
            this.tssHoje.Visible = false;
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(98, 17);
            this.toolStripStatusLabel3.Text = "| Boletos a Termo: ";
            this.toolStripStatusLabel3.Visible = false;
            // 
            // tssTermo
            // 
            this.tssTermo.Name = "tssTermo";
            this.tssTermo.Size = new System.Drawing.Size(23, 17);
            this.tssTermo.Text = "##";
            this.tssTermo.Visible = false;
            // 
            // toolStripStatusLabel5
            // 
            this.toolStripStatusLabel5.Name = "toolStripStatusLabel5";
            this.toolStripStatusLabel5.Size = new System.Drawing.Size(72, 17);
            this.toolStripStatusLabel5.Text = "|  Boletos D0:";
            this.toolStripStatusLabel5.Visible = false;
            // 
            // tssD0
            // 
            this.tssD0.Name = "tssD0";
            this.tssD0.Size = new System.Drawing.Size(23, 17);
            this.tssD0.Text = "##";
            this.tssD0.Visible = false;
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.Filter = "Arquivo CSV | *.csv";
            // 
            // backgroundWorker
            // 
            this.backgroundWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker_DoWork);
            this.backgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker_RunWorkerCompleted);
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // lbEmail
            // 
            this.lbEmail.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbEmail.FormattingEnabled = true;
            this.lbEmail.Location = new System.Drawing.Point(0, 490);
            this.lbEmail.Name = "lbEmail";
            this.lbEmail.Size = new System.Drawing.Size(1069, 43);
            this.lbEmail.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(562, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Periodo:";
            this.label1.Visible = false;
            // 
            // dtpInicioPeriodo
            // 
            this.dtpInicioPeriodo.Location = new System.Drawing.Point(714, 43);
            this.dtpInicioPeriodo.Name = "dtpInicioPeriodo";
            this.dtpInicioPeriodo.Size = new System.Drawing.Size(19, 20);
            this.dtpInicioPeriodo.TabIndex = 10;
            this.dtpInicioPeriodo.Visible = false;
            this.dtpInicioPeriodo.ValueChanged += new System.EventHandler(this.dtpInicioPeriodo_ValueChanged);
            // 
            // txtInicioPeriodo
            // 
            this.txtInicioPeriodo.Location = new System.Drawing.Point(614, 43);
            this.txtInicioPeriodo.Name = "txtInicioPeriodo";
            this.txtInicioPeriodo.Size = new System.Drawing.Size(100, 20);
            this.txtInicioPeriodo.TabIndex = 7;
            this.txtInicioPeriodo.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(736, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(13, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "a";
            this.label2.Visible = false;
            // 
            // txtFimPeriodo
            // 
            this.txtFimPeriodo.Location = new System.Drawing.Point(755, 43);
            this.txtFimPeriodo.Name = "txtFimPeriodo";
            this.txtFimPeriodo.Size = new System.Drawing.Size(100, 20);
            this.txtFimPeriodo.TabIndex = 8;
            this.txtFimPeriodo.Visible = false;
            // 
            // dtpFimPeriodo
            // 
            this.dtpFimPeriodo.Location = new System.Drawing.Point(855, 43);
            this.dtpFimPeriodo.Name = "dtpFimPeriodo";
            this.dtpFimPeriodo.Size = new System.Drawing.Size(20, 20);
            this.dtpFimPeriodo.TabIndex = 11;
            this.dtpFimPeriodo.Visible = false;
            this.dtpFimPeriodo.ValueChanged += new System.EventHandler(this.dtpFimPeriodo_ValueChanged);
            // 
            // txPass
            // 
            this.txPass.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.txPass.Location = new System.Drawing.Point(877, 535);
            this.txPass.MaxLength = 6;
            this.txPass.Name = "txPass";
            this.txPass.PasswordChar = '*';
            this.txPass.Size = new System.Drawing.Size(87, 20);
            this.txPass.TabIndex = 17;
            this.txPass.Visible = false;
            // 
            // bgwObrigaFechamento
            // 
            this.bgwObrigaFechamento.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bgwObrigaFechamento_DoWork);
            this.bgwObrigaFechamento.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bgwObrigaFechamento_RunWorkerCompleted);
            // 
            // timerFechamento
            // 
            this.timerFechamento.Tick += new System.EventHandler(this.timerFechamento_Tick);
            // 
            // timerPipe
            // 
            this.timerPipe.Tick += new System.EventHandler(this.timerPipe_Tick);
            // 
            // timerPortal
            // 
            this.timerPortal.Tick += new System.EventHandler(this.timerPortal_Tick);
            // 
            // timerBackUp
            // 
            this.timerBackUp.Tick += new System.EventHandler(this.timerBackUp_Tick);
            // 
            // bgwBackup
            // 
            this.bgwBackup.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bgwBackup_DoWork);
            this.bgwBackup.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bgwBackup_RunWorkerCompleted);
            // 
            // timerValidaPonto
            // 
            this.timerValidaPonto.Tick += new System.EventHandler(this.timerValidaPonto_Tick);
            // 
            // bgwValidaPonto
            // 
            this.bgwValidaPonto.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bgwValidaPonto_DoWork);
            this.bgwValidaPonto.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bgwValidaPonto_RunWorkerCompleted);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1069, 555);
            this.Controls.Add(this.txPass);
            this.Controls.Add(this.dtpFimPeriodo);
            this.Controls.Add(this.dtpInicioPeriodo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtFimPeriodo);
            this.Controls.Add(this.txtInicioPeriodo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip);
            this.Controls.Add(this.lbEmail);
            this.Controls.Add(this.statusStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "MainForm";
            this.ShowIcon = false;
            this.Text = "Mobios+Cash";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem pesqusarBoletoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pipelineToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestãoDeAtendimentoToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel tslNome;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel tssHoje;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel tssTermo;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel5;
        private System.Windows.Forms.ToolStripStatusLabel tssD0;
        private System.Windows.Forms.ToolStripMenuItem analistasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem produtosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem associarAnalistasEProdutosToolStripMenuItem;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.ToolStripMenuItem workFlowToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registrarOperacaoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem relatóriosToolStripMenuItem;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripComboBox cboRel;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.ComponentModel.BackgroundWorker backgroundWorker;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.ListBox lbEmail;
        private System.Windows.Forms.ToolStripMenuItem toolStripImports;
        private System.Windows.Forms.ToolStripMenuItem toolStripImportWAO;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpInicioPeriodo;
        private System.Windows.Forms.TextBox txtInicioPeriodo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtFimPeriodo;
        private System.Windows.Forms.DateTimePicker dtpFimPeriodo;
        private System.Windows.Forms.ToolStripMenuItem telasToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox cmbTelas;
        private System.Windows.Forms.ToolStripMenuItem abrirTelaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem integradoresToolStripMenuItem;
        private System.Windows.Forms.TextBox txPass;
        private System.Windows.Forms.ToolStripStatusLabel lblIntegradorWeb;
        private System.Windows.Forms.ToolStripStatusLabel lblStatusIntegradorWeb;
        private System.ComponentModel.BackgroundWorker bgwObrigaFechamento;
        private System.Windows.Forms.Timer timerFechamento;
        private System.Windows.Forms.ToolStripMenuItem célulasDeAtendimentoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem areasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pontoEletrônicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel lblAmbiente;
        private System.Windows.Forms.ToolStripStatusLabel lblStatusAmbiente;
        private System.Windows.Forms.Timer timerPipe;
        private System.Windows.Forms.Timer timerPortal;
        private System.Windows.Forms.Timer timerBackUp;
        private System.ComponentModel.BackgroundWorker bgwBackup;
        private System.Windows.Forms.Timer timerValidaPonto;
        private System.ComponentModel.BackgroundWorker bgwValidaPonto;
        private System.Windows.Forms.ToolStripMenuItem suporteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configuraçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parâmetrosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fecharInstânciasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem testeToolStripMenuItem;
    }
}

