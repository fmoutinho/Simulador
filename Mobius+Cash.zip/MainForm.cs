﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Net;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;
using System.Reflection;
using iTextSharp.text;

namespace Mobios
{
    public partial class MainForm : Form
    {
        string msgLog;
        public ClassListMethod _MyMethod;
        public ClassListMethod _MyMethodBackground;
        DateTimePicker dtpInicio = new DateTimePicker();
        DateTimePicker dtpFim = new DateTimePicker();
        FollowUp _FollowUp = new FollowUp();
        private static MainForm form = null;
        bool _PortalCarregado;
        bool _fechamentoObrigatorio;
        bool _closing = false;

        public MainForm(string[] args)
        {
            //System.Media.SystemSounds.Beep.Play();
            //System.Media.SystemSounds.Exclamation.Play();
            //System.Media.SystemSounds.Asterisk.Play();
            //System.Media.SystemSounds.Question.Play();
            //System.Media.SystemSounds.Hand.Play();
            
            #region [ AppConfig Path ]
            SharedData.ApplicationPath = SharedData.ReturnApplicationPath();
            SharedData.gHomologação = SharedData.ReturnHomologacao();
            SharedData.BDPath = SharedData.ReturnPathBase();
            SharedData.BD = SharedData.ReturnBase("BDconsulta");
            SharedData.LogPath = SharedData.ReturnPathLog();
            SharedData.AcessosPath = SharedData.ReturnPathAcessos();
            SharedData.PathObrigarFechamento = SharedData.ReturnPathObrigarFechamento();
            SharedData.BackUpPath = SharedData.ReturnPathBackUp();
            SharedData.BackUpPathLog = SharedData.ReturnPathBackUpLog();
            #endregion

            Loading l = new Loading();
            Loading.EnableStaticTextBox("Carregando...");
            Loading.StaticFormVisible(true);

            BackgroundWorker tempBGW = new BackgroundWorker();
            tempBGW.WorkerSupportsCancellation = false;
            tempBGW.WorkerReportsProgress = false;
            tempBGW.DoWork += (s, e) =>
            {
                msgLog = "Path da aplicação (Application.ExecutablePath) : " + SharedData.ApplicationPath;
                Log.GravaLog(msgLog);
                msgLog = "Usuário logado: " + Environment.UserName.ToUpper();
                Log.GravaLog(msgLog);

                Loading.EnableStaticTextBox("Verificando Banco de Dados...");
                #region [ Verifica existência do banco de dados na rede ]
                if (!SharedData.ValidaBD())
                {
                    Loading.StaticFormVisible(false);
                    #region [ Realiza Back-Up ]
                    Log.GravaLog("Banco de dados não localizado...");
                    if (!SharedData.gHomologação)
                    {
                        if (MessageBox.Show("Não foi possível localizar o banco de dados na rede.\n\nVerificar back-up?", "Erro de Conexão", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                        {
                            Loading Load = new Loading();
                            if (!SharedData.VerificaArquivoBackUp())//verifica se nao há arquivo
                            {
                                Log.GravaLog("Verifica Back-ups...");
                                var di = new DirectoryInfo(SharedData.BackUpPath);
                                List<string> directories = di.EnumerateDirectories().OrderBy(d => d.CreationTime).Select(d => d.FullName).ToList();

                                if (directories.Count > 0)
                                {
                                    string ultimoBackUp = directories[directories.Count - 1];

                                    di = new DirectoryInfo(SharedData.BackUpPath);
                                    directories = di.EnumerateDirectories().OrderBy(d => d.CreationTime).Select(d => d.Name).ToList();

                                    string data = directories[directories.Count - 1].Substring(6, 2) + "/" + directories[directories.Count - 1].Substring(4, 2) + "/" + directories[directories.Count - 1].Substring(0, 4) + " " + directories[directories.Count - 1].Substring(8, 2) + ":" + directories[directories.Count - 1].Substring(10, 2) + ":" + directories[directories.Count - 1].Substring(12, 2);
                                    Log.GravaLog("Último Back-up: " + data);
                                    if (MessageBox.Show("Há um backup de " + data + ".\n\nRestaurar?", "Back-Up Localizado", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                                    {
                                        if (!SharedData.VerificaArquivoBackUp())//verifica se nao há arquivo
                                        {
                                            Loading.StaticFormVisible(true);
                                            Loading.EnableStaticTextBox("Realizando Back-Up...");
                                            SharedData.CriaArquivoBackUp();
                                            Log.GravaLog("Restaura Back-Up");

                                            Log.GravaLog("De: " + ultimoBackUp);
                                            Log.GravaLog("Para: " + SharedData.BDPath);
                                            try
                                            {
                                                Log.CopiaDiretorio(ultimoBackUp, SharedData.BDPath, true, false);
                                                Log.GravaLog("Cópia concluída...");
                                                SharedData.ExcluiArquivoBackUp();

                                                if (SharedData.ValidaBD())
                                                {
                                                    Loading.StaticFormVisible(false);
                                                    MessageBox.Show("Back-Up realizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                }
                                                else
                                                {
                                                    Loading.StaticFormVisible(false);
                                                    MessageBox.Show("A falha permanece...\n\nContate a equipe responsável.", "Erro de Conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                                    SharedData.Quit();
                                                }
                                            }
                                            catch (Exception errBackUp)
                                            {
                                                SharedData.ExcluiArquivoBackUp();
                                                Loading.StaticFormVisible(false);
                                                MessageBox.Show("Erro durante o backup, verifique o desempenho e espaço disponível na rede\n\nCaso necessário, contate a equipe responsável.\n\nErro: " + errBackUp.Message, "Erro de Conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                                SharedData.Quit();
                                            }
                                        }
                                        else
                                        {
                                            Loading.StaticFormVisible(true);
                                            Loading.EnableStaticTextBox("Backup já em andamento...");
                                            while (SharedData.VerificaArquivoBackUp())
                                            {
                                                Application.DoEvents();
                                            }
                                            if (SharedData.ValidaBD())
                                            {
                                                Loading.StaticFormVisible(false);
                                                MessageBox.Show("Back-Up realizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                            }
                                            else
                                            {
                                                Loading.StaticFormVisible(false);
                                                MessageBox.Show("A falha permanece...\n\nContate a equipe responsável.", "Erro de Conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                                SharedData.Quit();
                                            }
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Sem um banco de dados não é possível executar o sistema.\n\nEntre em contato com a equipe responsável", "Erro de Conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        SharedData.Quit();
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Não foi possível localizar back-ups.\n\nEntre em contato com a equipe responsável", "Erro de Conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    SharedData.Quit();
                                }
                            }
                            else
                            {
                                Loading.StaticFormVisible(true);
                                Loading.EnableStaticTextBox("Backup já em andamento...");
                                while (SharedData.VerificaArquivoBackUp())
                                {
                                    Application.DoEvents();
                                }
                                if (SharedData.ValidaBD())
                                {
                                    Loading.StaticFormVisible(false);
                                    MessageBox.Show("Back-Up realizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                else
                                {
                                    Loading.StaticFormVisible(false);
                                    MessageBox.Show("A falha permanece...\n\nContate a equipe responsável.", "Erro de Conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    SharedData.Quit();
                                }
                            }
                            try
                            {
                                Load.Close();
                            }
                            catch { }
                        }
                        else
                        {
                            SharedData.Quit();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Não foi possível localizar o banco de dados na rede.", "Erro de Conexão", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                        SharedData.Quit();
                    }
                    #endregion
                }
                #endregion

                string returnParametros = "";
                try
                {
                    Loading.EnableStaticTextBox("Buscando configurações...");
                    returnParametros = DataAccess.GetParametros();
                    if (returnParametros != "")
                    {
                        Loading.StaticFormVisible(false);
                        MessageBox.Show("Falha ao buscar parâmetro '" + returnParametros + "' de configuração do Mobios\n\nContate a equipe de automação de processos", "Parâmetros Incorretos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        SharedData.Quit();
                    }

                    Loading.EnableStaticTextBox("Validando versão...");
                    #region [ valida versão ]
                    string minha_versao = "";
                    string Plataforma = "Ini";
                    bool publish = false;

                    if (System.Deployment.Application.ApplicationDeployment.IsNetworkDeployed)
                    {
                        System.Deployment.Application.ApplicationDeployment cd = System.Deployment.Application.ApplicationDeployment.CurrentDeployment;
                        string publishVersion = cd.CurrentVersion.ToString();
                        // show publish version in title or About box...
                        minha_versao = publishVersion;
                        this.Text = this.Text + " | " + Plataforma + " | Publish Version: " + publishVersion;
                        publish = true;
                    }
                    else
                    {
                        System.Version version = Assembly.GetExecutingAssembly().GetName().Version;
                        minha_versao = version.Major + "." + version.Minor + "." + version.Build + "." + version.Revision; //change form title
                        this.Text = this.Text + " | " + Plataforma + " | Versão: " + minha_versao;
                        publish = false;
                    }
                    SharedData.gVersao = minha_versao;

                    if (!SharedData.versao_sistema(SharedData.gVersao, publish))
                    {
                        SharedData.Quit();
                    }
                    #endregion

                    Loading.EnableStaticTextBox("Carregando...");
                    SharedData.Queries = DataConnector.GetQueries("BDconsulta");


                }
                catch
                {
                    MessageBox.Show("Falha ao buscar parâmetro de configuração do Mobios\n\nContate a equipe de automação de processos", "Parâmetros Incorretos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    SharedData.Quit();
                }

                #region [ abre detalhe para exibir campos corretamente em maquinas itau ]
                Form frmDetalhe = new Detalhe(null);
                frmDetalhe.WindowState = FormWindowState.Normal;
                frmDetalhe.Show();
                frmDetalhe.Close();
                #endregion

                if (SharedData.gPreCarregarCampos)
                {
                    if (SharedData.gFormOperação == "MINUTAS")
                    {
                        Loading.EnableStaticTextBox("Carregando Campos dos Objetos...");
                        SharedData.gCamposObjeto = DataAccess.buscarCamposDinamicosMinuta();

                        if (SharedData.gCamposObjeto.Exists(n => n.CampoTipo.ToUpper() == "TABELA" || n.CampoTipo.ToUpper() == "TABELAGERAL"))
                        {
                            Loading.EnableStaticTextBox("Carregando Campos de Tabelas...");
                            SharedData.gCamposTabela = DataAccess.BuscarCamposTabela();
                        }
                    }
                    else
                    {
                        Loading.EnableStaticTextBox("Carregando Campos dos Objetos...");
                        SharedData.gCamposObjeto = DataAccess.buscarCamposDinamicos();
                        Loading.EnableStaticTextBox("Carregando Campos das etapas...");
                        SharedData.gCamposEtapa = DataAccess.buscarCamposEtapa();
                        if (SharedData.gCamposObjeto.Exists(n => n.CampoTipo.ToUpper() == "TABELA" || n.CampoTipo.ToUpper() == "TABELAGERAL") || SharedData.gCamposEtapa.Exists(n => n.CampoTipo.ToUpper() == "TABELA" || n.CampoTipo.ToUpper() == "TABELAGERAL"))
                        {
                            Loading.EnableStaticTextBox("Carregando Campos de Tabelas...");
                            SharedData.gCamposTabela = DataAccess.BuscarCamposTabela();
                        }
                        Loading.EnableStaticTextBox("Carregando Etapas...");
                        SharedData.gEtapasObjeto = DataAccess.BuscarEtapasObjeto();
                        Loading.EnableStaticTextBox("Carregando Status...");
                        SharedData.gStatusEtapa = DataAccess.BuscarStatus();
                    }

                    Loading.EnableStaticTextBox("Carregando Métodos...");
                    SharedData.gMetodos = DataAccess.GetListMethod();
                }
            };
            tempBGW.RunWorkerAsync();

            while (tempBGW.IsBusy){ Application.DoEvents(); }

            try
            {
                l.Close();
                l.Dispose();
                l = null;
            }
            catch { }
            try
            {
                tempBGW.Dispose();
                tempBGW = null;
            }
            catch { }
            GC.Collect();

            InitializeComponent();

            #region [Background]
            MdiClient ctlMDI;
            MenuStrip ctlMenu;
            StatusStrip ctlStatus;
            foreach (Control ctl in this.Controls)
            {
                try
                {
                    ctlMDI = (MdiClient)ctl;
                    ctlMDI.BackColor = this.BackColor;
                }
                catch { }

                try
                {
                    ctlMenu = (MenuStrip)ctl;
                    ctlMenu.BackColor = Color.White;
                }
                catch { }

                try
                {
                    ctlStatus = (StatusStrip)ctl;
                    ctlStatus.BackColor = Color.White;
                }
                catch { }
            }
            #endregion

            this.lblAmbiente.Visible = SharedData.gHomologação;
            lblStatusAmbiente.Visible = SharedData.gHomologação;

            if (SharedData.BuscarAcessos() == false)
            {
                #region [ fecha aplicação ]
                msgLog = "Responsável não está cadastrado ou o login está errado.";
                MessageBox.Show(msgLog, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Log.GravaLog(msgLog);
                SharedData.ExcluiArquivoAcesso();
                SharedData.Quit();
                #endregion
            }
            else
            {
                Falar.SpeakTxt("Abertura");

                #region [ exibe labels e strips ]
                this.tslNome.Text = String.Format(this.tslNome.Text, SharedData.User.NomeResponsavel);
                this.gestãoDeAtendimentoToolStripMenuItem.Visible = SharedData.User.FLG_Gestor;
                this.configuraçõesToolStripMenuItem.Visible = SharedData.User.FLG_AutoProc;
                this.pontoEletrônicoToolStripMenuItem.Visible = SharedData.gPontoEletronico;
                form = this;
                form.Text = form.Text + "| Versão " + SharedData.gVersao;
                lblStatusIntegradorWeb.Visible = SharedData.gLeitorWEB;
                this.lblIntegradorWeb.Visible = SharedData.gLeitorWEB;
                #endregion

                #region [ relatorios ]
                this.relatóriosToolStripMenuItem.Visible = SharedData.User.FLG_Gestor || SharedData.UserCelulas.Where(n => n.Integradores.ToUpper().Contains("RELATÓRIOS=TRUE")).Count() > 0;
                if (relatóriosToolStripMenuItem.Visible)
                {
                    DataTable dt = DataAccess.GetRelatorios();
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            this.cboRel.Items.Add(row[1]);
                        }
                        if (dt.Rows.Count == 1)
                            this.cboRel.FindStringExact(dt.Rows[0][1].ToString());

                        dtpInicio.Format = DateTimePickerFormat.Custom;
                        dtpInicio.CustomFormat = "dd/MM/yyyy";
                        dtpInicio.Width = 115;
                        dtpInicio.ValueChanged += (sender, e) =>
                        {
                            relatóriosToolStripMenuItem.DropDown.Show();
                        };
                        dtpFim.Format = DateTimePickerFormat.Custom;
                        dtpFim.CustomFormat = "dd/MM/yyyy";
                        dtpFim.Width = 115;
                        dtpFim.ValueChanged += (sender, e) =>
                        {
                            relatóriosToolStripMenuItem.DropDown.Show();
                        };
                        relatóriosToolStripMenuItem.DropDownItems.Add("Período De");
                        relatóriosToolStripMenuItem.DropDownItems.Add(new ToolStripControlHost(dtpInicio));
                        relatóriosToolStripMenuItem.DropDownItems.Add("Até");
                        relatóriosToolStripMenuItem.DropDownItems.Add(new ToolStripControlHost(dtpFim));

                        txtInicioPeriodo.Enabled = true;
                        txtFimPeriodo.Text = dtpFimPeriodo.Value.ToString("dd/MM/yyyy");

                        txtFimPeriodo.Enabled = true;
                        txtInicioPeriodo.Text = dtpInicioPeriodo.Value.ToString("dd/MM/yyyy");
                    }
                    else
                    {
                        this.relatóriosToolStripMenuItem.Visible = false;
                    }
                }
                #endregion

                #region [ telas ]
                DataTable dtTela = DataAccess.GetTelas();
                if (dtTela.Rows.Count > 0)
                {
                    this.cmbTelas.Items.Add("");
                    foreach (DataRow row in dtTela.Rows)
                    {
                        this.cmbTelas.Items.Add(row["Nometela"]);
                    }
                }
                else
                {
                    this.telasToolStripMenuItem.Visible = false;
                }
                #endregion

                _PortalCarregado = false;
                CarregaPortalItau();

                #region [ Ambiente homologação ]
                if (SharedData.gHomologação)
                {
                    MessageBox.Show("Esta é uma versão de homologação do sistema.\n\nTodas as informações têm por objetivo a realização de testes e não serão consideradas na versão de produção.", "Mobios", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                #endregion
                #region [ timer backgrounds ]
                
                _fechamentoObrigatorio = true;

                //O timer é desabilitado por padrão. Caso a variavel venha valor >0, o mesmo é ativado.
                this.timer.Enabled = false;
                this.timerFechamento.Enabled = false;
                this.timerBackUp.Enabled = false;

                if (SharedData.gTimerIntervalIntegracoes > 0)
                {
                    this.timer.Interval = SharedData.gTimerIntervalIntegracoes;
                    this.timer.Enabled = true;
                }
                if (SharedData.gTimerIntervalFechamento > 0)
                {
                    this.timerFechamento.Interval = SharedData.gTimerIntervalFechamento;
                    this.timerFechamento.Enabled = true;
                }
                if (SharedData.gTimerIntervalPortal > 0)
                {
                    this.timerPortal.Interval = SharedData.gTimerIntervalPortal;
                    this.timerPortal.Enabled = true;
                }

                if (SharedData.gBackUp && !SharedData.gHomologação)
                {
                    this.timerBackUp.Interval = (60000); //definido para rodar após 1 minuto da abertura do sistema.
                    this.timerBackUp.Enabled = true;
                }
                else
                {
                    this.timerBackUp.Enabled = false;
                }
                if (SharedData.gValidaPonto)
                {
                    this.timerValidaPonto.Interval = (60000); //definido para rodar após 1 minuto da abertura do sistema.
                    this.timerValidaPonto.Enabled = true;
                }
                else
                {
                    this.timerBackUp.Enabled = false;
                }

                this.timerPipe.Interval = (200);
                if (args == null || args.Length == 0)
                    this.timerPipe.Enabled = true;
                else
                {
                    bool CloseAfterRun = false;
                    try
                    {
                        
                        List<int> IdMethod = args[0].Split(';').Select(Int32.Parse).ToList();
                        List<ClassListMethod> Method = DataAccess.GetListMethod(IdMethod);
                        foreach (ClassListMethod met in Method)
                        {
                            try
                            {
                                if (!CloseAfterRun)
                                    CloseAfterRun = met.MethodParametro.ToString().ToUpper().Contains("CLOSEAFTERRUN");
                                _MyMethod = new ClassListMethod();
                                _MyMethod = (Mobios.ClassListMethod)(met);
                                CustomMethod.ChamarMetodo(met.MethodName, CustomMethod.MethodForm.Main);
                            }
                            catch (Exception ex)
                            {
                                //MessageBox.Show("MethodID " + args[0] + "\n\n" + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                Log.GravaLog("Method " + met.MethodName + " apresentou erro.\n\n" + ex.Message);
                            }

                        }
                    }
                    catch (Exception ex)
                    {
                        Log.GravaLog("ERRO: " + ex.Message);
                    }
                    finally
                    {
                        if(CloseAfterRun)
                            SharedData.Quit(); 
                        else
                            this.timerPipe.Enabled = true;
                    }

                }

                #endregion
            }
        }
        
        #region [ Resolução do Problema de Flickring ]
        protected override void OnResize(EventArgs e)
        {
            this.Visible = false;
            base.OnResize(e);
            this.Visible = true;
        }
        #endregion

        #region [ Menu Clicks ]

        private void pesqusarBoletoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            msgLog = "Abrindo tela de pesquisar boleto - " + Environment.UserName.ToUpper();
            Log.GravaLog(msgLog);
            if (!SharedData.isOpenForm(typeof(Search), false))
            {
                Form frm = new Search();
                //frm.MdiParent = this;
                frm.Show();
            }
        }

        private void pipelineToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!SharedData.isOpenForm(typeof(Pipeline), false))
            {
                Form frmPipe = new Pipeline();

                frmPipe.MdiParent = this;
                if (frmPipe.Width > frmPipe.ParentForm.ClientSize.Width - 5)
                {
                    frmPipe.Width = frmPipe.ParentForm.ClientSize.Width - 5;
                }
                if (frmPipe.Height > frmPipe.ParentForm.ClientSize.Height - 100)
                {
                    frmPipe.Height = frmPipe.ParentForm.ClientSize.Height - 100;
                }
                frmPipe.Left = 0;
                frmPipe.Top = 0;

                frmPipe.Show();

                if (SharedData.gPipeLineMaximizar)
                    frmPipe.WindowState = FormWindowState.Maximized;
                else
                    frmPipe.WindowState = FormWindowState.Normal;
            }
        }

        private void workFlowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Formulário de WorkFlow
            if (!SharedData.isOpenForm(typeof(Workflow), false))
            {
                Form frm = new Workflow();
                frm.MdiParent = this;
                frm.Show();
            }
        }

        private void registrarOperacaoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Formulário de Registrar operações
            if (!SharedData.isOpenForm(typeof(RegistrarOperacao), false))
            {
                Form frm = new RegistrarOperacao();
                frm.WindowState = FormWindowState.Normal;
                frm.MdiParent = this;
                frm.Show();
            }

        }

        public void CarregaPortalItau()
        {
            #region [ Carrega Info Portal Itaú ]
            if (SharedData.gPaginasPortalItau)
            {
                if (!_PortalCarregado)
                {
                    bool carregado = true;
                    Form x = this.ActiveMdiChild;
                    FormWindowState wState = FormWindowState.Normal;
                    if (x != null)
                        wState = x.WindowState;

                    try
                    {
                        if (!SharedData.isOpenForm(typeof(PortalManchete), false, false))
                        {
                            PortalManchete PtManc = new PortalManchete();
                            PtManc.MdiParent = this;
                            //PtManc.WindowState = FormWindowState.Normal;
                            PtManc.StartPosition = FormStartPosition.Manual;
                            PtManc.Left = this.ClientSize.Width - PtManc.Width - 10;
                            PtManc.Top = this.ClientSize.Height - PtManc.Height - lbEmail.Height - statusStrip.Height - 30;
                            PtManc.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
                            PtManc.SendToBack();
                            while (!PtManc.Complete)
                            {
                                try
                                {
                                    Application.DoEvents();
                                }
                                catch { }
                            }
                            if (!PtManc.SemAcesso)
                            {
                                PtManc.Show();
                            }
                            else
                            {
                                carregado = false;
                            }
                        }
                    }
                    catch { carregado = false; };

                    try
                    {
                        if (!SharedData.isOpenForm(typeof(FotoUsuario), false, false))
                        {
                            FotoUsuario ftUser = new FotoUsuario();
                            ftUser.MdiParent = this;
                            //ftUser.WindowState = FormWindowState.Normal;
                            ftUser.StartPosition = FormStartPosition.Manual;
                            ftUser.Left = 10;
                            ftUser.Top = this.ClientSize.Height - ftUser.Height - lbEmail.Height - statusStrip.Height - 30;
                            ftUser.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
                            ftUser.SendToBack();
                            while (!ftUser.Complete)
                            {
                                Application.DoEvents();
                            }
                            if (!ftUser.SemAcesso)
                            {
                                ftUser.Show();
                            }
                            else
                            {
                                carregado = false;
                            }
                        }
                    }
                    catch { carregado = false; };

                    if (x != null)
                    {
                        x.Activate();
                        x.WindowState = wState;
                    }

                    if (carregado)
                    {
                        _PortalCarregado = carregado;
                        timerPortal.Enabled = false;
                    }
                }
                else
                {
                    timerPortal.Enabled = false;
                }
            }
            else
            {
                timerPortal.Enabled = false;
            }
            #endregion
        }

        #region [ Relatórios ]
        private void dtpInicioPeriodo_ValueChanged(object sender, EventArgs e)
        {

            if (dtpInicioPeriodo.Value > dtpFimPeriodo.Value)
            {
                dtpFimPeriodo.Value = dtpInicioPeriodo.Value;
                txtFimPeriodo.Text = dtpFimPeriodo.Value.ToString("dd/MM/yyyy");
            }
            else
            {
                txtInicioPeriodo.Text = dtpInicioPeriodo.Value.ToString("dd/MM/yyyy");
            }
            txtInicioPeriodo.Text = dtpInicioPeriodo.Value.ToString("dd/MM/yyyy");


        }

        private void dtpFimPeriodo_ValueChanged(object sender, EventArgs e)
        {
            if (dtpInicioPeriodo.Value > dtpFimPeriodo.Value)
            {
                dtpInicioPeriodo.Value = dtpFimPeriodo.Value;
                txtInicioPeriodo.Text = dtpInicioPeriodo.Value.ToString("dd/MM/yyyy");
            }
            else
            {
                txtInicioPeriodo.Text = dtpInicioPeriodo.Value.ToString("dd/MM/yyyy");
            }
            txtFimPeriodo.Text = dtpFimPeriodo.Value.ToString("dd/MM/yyyy");
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (this.cboRel.Text != "")
            {
                if (dtpInicio.Value > dtpFim.Value)
                {
                    MessageBox.Show("A data inicial é maior que a final");
                }
                else
                {
                    if (MessageBox.Show(string.Format("Relatório: {0}\nData Inicial: {1}\nData Final: {2}\n\nExtrair relatório?", this.cboRel.Text, dtpInicio.Value.ToString("dd/MM/yyyy"), dtpFim.Value.ToString("dd/MM/yyyy")), "Relatórios", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        DataTable dt = DataAccess.GetRelatorioParm(this.cboRel.Text, Convert.ToDateTime(dtpInicio.Value.ToString("dd/MM/yyyy")), Convert.ToDateTime(dtpFim.Value.ToString("dd/MM/yyyy")));
                        TratarEventos.ExportaDataTable(dt, "", "", true);
                    }
                }
            }
        }

        #endregion

        #region [ Ações - Antigo Telas ]
        private void selecionaTelasToolStripMenuItem_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbTelas.SelectedItem != null && cmbTelas.SelectedItem.ToString() != "")
            {
                abrirTelaToolStripMenuItem.Enabled = true;
            }
            else
            {
                abrirTelaToolStripMenuItem.Enabled = false;
            }
        }

        private void abrirTelaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            string Tela = cmbTelas.SelectedItem.ToString();
            string _MethodName = DataAccess.GetTelasMethod(Tela);

            if (_MethodName != "")
            {
                CustomMethod.ChamarMetodo(_MethodName, CustomMethod.MethodForm.Main);
            }
        }

        private void telasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cmbTelas.Text = "Escolha uma Ação";
            abrirTelaToolStripMenuItem.Enabled = false;
        }
        #endregion

        #region [ Gestão de Atendimento ]
        private void analistasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!SharedData.isOpenForm(typeof(Analistas), false))
            {
                using (Form frm = new Analistas())
                {
                    //frm.MdiParent = this;
                    frm.ShowDialog();
                }
            }
        }

        private void produtosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!SharedData.isOpenForm(typeof(Produtos), false))
            {
                using (Form frm = new Produtos())
                {
                    //frm.MdiParent = this;
                    frm.ShowDialog();
                }
            }
        }

        private void associarAnalistasEProdutosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!SharedData.isOpenForm(typeof(Associar), false))
            {
                using (Form frm = new Associar())
                {
                    //frm.MdiParent = this;
                    frm.ShowDialog();
                }
            }
        }

        private void areasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!SharedData.isOpenForm(typeof(Areas), false))
            {
                using (Form frm = new Areas())
                {
                    //frm.MdiParent = this;
                    frm.ShowDialog();
                }
            }
        }

        private void pontoEletrônicoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!SharedData.isOpenForm(typeof(PontoEletronico), false))
            {
                using (Form frm = new PontoEletronico())
                {
                    //frm.MdiParent = this;
                    frm.WindowState = FormWindowState.Normal;
                    frm.Left = 0;
                    frm.Top = 0;
                    frm.ShowDialog();
                }
            }
        }

        private void célulasDeAtendimentoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!SharedData.isOpenForm(typeof(Celulas), false))
            {
                using (Form frm = new Celulas())
                {
                    //frm.MdiParent = this;
                    frm.ShowDialog();
                }
            }
        }
        #endregion

        #region [ Importação ]
        private void integradoresToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (!SharedData.isOpenForm(typeof(Integradores), false))
            {
                Form frm = new Integradores(SharedData.User.FuncionalResponsavel, SharedData.User.LoginResponsavel, SharedData.UserCelulas.Select(n => n.Integradores).ToList(), txPass.Text);
                //frm.MdiParent = this;
                frm.WindowState = FormWindowState.Normal;
                //frm.Left = 0;
                //frm.Top = 0;
                frm.Show();
            }
        }

        private void toolStripImportWAO_Click(object sender, EventArgs e)
        {
            using (Form frm = new IntegracaoExcel(2))
            {
                //frm.MdiParent = this;
                frm.WindowState = FormWindowState.Normal;
                frm.Left = 0;
                frm.Top = 0;
                frm.ShowDialog();
            }
        }
        
        private void lblStatusIntegrador_Click(object sender, EventArgs e)
        {
            if (!SharedData.isOpenForm(typeof(Integradores), false))
            {
                Form frm = new Integradores(SharedData.User.FuncionalResponsavel, SharedData.User.LoginResponsavel, SharedData.UserCelulas.Select(n => n.Integradores).ToList(), txPass.Text);
                //frm.MdiParent = this;
                frm.WindowState = FormWindowState.Normal;
                //frm.Left = 0;
                //frm.Top = 0;
                frm.Show();
            }
        }
        #region [ Delegate Senha ]
        private delegate void EnableDelegate(string texto);
        public static void EnableStaticTextBox(string texto)
        {
            if (form != null)
                form.EnableTextBox(texto);
        }
        private void EnableTextBox(string texto)
        {
            // If this returns true, it means it was called from an external thread.
            if (InvokeRequired)
            {
                // Create a delegate of this method and let the form run it.
                this.Invoke(new EnableDelegate(EnableTextBox), new object[] { texto });
                return; // Important
            }

            // Set textBox
            //label1.Enabled = enable;
            lbEmail.Items.Add(texto);
            lbEmail.TopIndex = lbEmail.Items.Count - 1;
            Application.DoEvents();
        }


        public static void SalvarSenha(string texto)
        {
            if (form != null)
                form.senha(texto);
        }
        private void senha(string texto)
        {
            // If this returns true, it means it was called from an external thread.
            if (InvokeRequired)
            {
                // Create a delegate of this method and let the form run it.
                this.Invoke(new EnableDelegate(senha), new object[] { texto });
                return; // Important
            }

            // Set textBox
            //label1.Enabled = enable;
            txPass.Text = (texto);
            if (texto == "")
            {
                lblStatusIntegradorWeb.Text = "OFF";
                lblStatusIntegradorWeb.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lblStatusIntegradorWeb.Text = "ON";
                lblStatusIntegradorWeb.ForeColor = System.Drawing.Color.Green;
            }
            Application.DoEvents();
        }
        #endregion
        #endregion
        #endregion

        public void addText(string Text)
        {
            string Dtagora = DateTime.Now.ToString();
            Text = Dtagora + " | " + Text;
            this.Invoke(new MethodInvoker(delegate() { lbEmail.Items.Insert(0, Text); }));
            Application.DoEvents();
        }

        #region [Background Worker]
        private void backgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                if (SharedData.UserCelulas.Where(n => n.Integra == true).Count() > 0)
                {
                    string Dtagora = DateTime.Now.ToString();
                    //this.Invoke(new MethodInvoker(delegate() {lbEmail.Items.Insert(0, new ListItem(Dtagora)); }));

                    string msgErro = null;
                    string msgAlerta = null;

                    #region [Leitor Email]
                    if (SharedData.gLeitorEmail)
                    {
                        if (SharedData.UserCelulas.Where(n => n.Integradores.ToUpper().Contains("EMAIL=TRUE")).Count() > 0)
                        {
                            if (Properties.Settings.Default.InboxRead != "")
                            {
                                try
                                {
                                    string[] chaveMOBIOS = null;
                                    string chaveResposta = null;
                                    string[] dadosEmail = null;

                                    this.Invoke(new MethodInvoker(delegate() { this.lbEmail.Items.Clear(); }));
                                    this.Invoke(new MethodInvoker(delegate() { lbEmail.Items.Add(DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + " - Verificando e-mails recebidos..."); }));


                                    dadosEmail = SharedData.ReadMailItem(Properties.Settings.Default.InboxRead, Properties.Settings.Default.EmailAssinatura.Trim()).ToString().Split('|');


                                    if (dadosEmail != null)
                                    {
                                        for (int i = 1; i < (Convert.ToInt32(dadosEmail[0]) + 1); i++)
                                        {
                                            if (dadosEmail[i].ToString() != "" && dadosEmail[i].Contains("[#") == true)
                                            {
                                                //chaveMOBIOS = dadosEmail[i].Substring(dadosEmail[i].IndexOf("[#")+2, dadosEmail[i].IndexOf("#]")-2);
                                                chaveMOBIOS = dadosEmail[i].Substring(dadosEmail[i].IndexOf("[#") + 2, (dadosEmail[i].IndexOf("#]") - (dadosEmail[i].IndexOf("[#") + 2))).Split('-');
                                                msgAlerta += dadosEmail[i].ToString() + ".\n";
                                                try
                                                {
                                                    chaveResposta = dadosEmail[2].Substring(dadosEmail[2].IndexOf("{#") + 2, (dadosEmail[2].IndexOf("#}") - (dadosEmail[2].IndexOf("{#") + 2)));
                                                    msgAlerta += "Resposta do cliente: " + chaveResposta + ".\n";

                                                    int IdObjeto = DataAccess.BuscarIdObjeto(Convert.ToInt32(chaveMOBIOS[0]));
                                                    int IdServico = Convert.ToInt32(chaveMOBIOS[0]);
                                                    int IdEtapa = Convert.ToInt32(chaveMOBIOS[1]);
                                                    List<EtapasObjeto> infoEtapa = DataAccess.BuscarEtapasObjeto(IdObjeto, IdEtapa);
                                                    string chaveTimeStamp = chaveMOBIOS[3].ToString();
                                                    string[] camposAtualizar;
                                                    string dataReadEmail = Convert.ToDateTime(dadosEmail[4]).ToString("dd/MM/yyyy HH:mm:ss");

                                                    //List<Campos> listaCamposServico = DataAccess.buscarCamposDinamicosConjunto(IdObjeto, IdServico);      // Preenche a tela com campos do serviço;                                                                
                                                    List<CamposInfo> listaCamposServico = DataAccess.BuscarInfoCampo(chaveMOBIOS[2]);
                                                    if (listaCamposServico.Count > 0)
                                                    {
                                                        switch (listaCamposServico[0].CampoAcaoRetorno.ToUpper())
                                                        {
                                                            case "RELOADBOLETO":
                                                                // reload boleto;
                                                                if (chaveResposta != "")
                                                                {
                                                                    try
                                                                    {
                                                                        BoletoBen.CapturaBoleto(chaveResposta, Environment.UserName.ToUpper().Trim(), "", Convert.ToInt32(chaveMOBIOS[0]));
                                                                        BoletoBen.AtualizaServicoBoleto(chaveResposta.ToString().Trim(), IdObjeto, IdServico);
                                                                        camposAtualizar = listaCamposServico[0].CamposAtualizar.ToString().Split(';');
                                                                        foreach (string campo in camposAtualizar)
                                                                        {
                                                                            List<CamposInfo> listaCampo = DataAccess.BuscarInfoCampo(campo);
                                                                            if (listaCampo[0].CampoIndicador == true)
                                                                            {
                                                                                TratarEventos.GravaLinhaEvento(IdServico, listaCampo[0].CampoIndicador.ToString(), listaCampo[0].CampoRegraCalculo, listaCampo[0].CampoItemIndicador, chaveResposta, listaCampo[0].CampoTipoValor, Environment.UserName.ToUpper(), listaCampo[0].CampoEvento, "Retorno e-mail -  - campos a atualizar", chaveTimeStamp);
                                                                            };
                                                                        }
                                                                    }
                                                                    catch
                                                                    { }
                                                                }
                                                                break;
                                                            case "ATUALIZARCAMPO":
                                                                if (chaveResposta != "")
                                                                {
                                                                    // Quando precisa atualizar campo com valor recebido
                                                                    camposAtualizar = listaCamposServico[0].CamposAtualizar.ToString().Split(';');

                                                                    List<Campos> camposInsert = new List<Campos>();
                                                                    List<Campos> camposUpdate = new List<Campos>();

                                                                    foreach (string campo in camposAtualizar)
                                                                    {
                                                                        List<CamposInfo> listaCampo = DataAccess.BuscarInfoCampo(campo);

                                                                        Campos campoInsert = new Campos();
                                                                        Campos campoUpdate = new Campos();

                                                                        if (DataAccess.BuscarCampoObjeto(IdServico, Convert.ToInt32(campo)))
                                                                        {
                                                                            campoInsert.ID_Servico = IdServico;
                                                                            campoInsert.ID_Campo = Convert.ToInt32(campo);
                                                                            campoInsert.ValorCampo = chaveResposta;
                                                                            camposInsert.Add(campoInsert);
                                                                        }
                                                                        else
                                                                        {
                                                                            campoUpdate.ID_Campo = Convert.ToInt32(campo);
                                                                            campoUpdate.ValorCampo = chaveResposta;
                                                                            camposUpdate.Add(campoUpdate);
                                                                        }

                                                                        if (listaCampo[0].CampoIndicador == true)
                                                                        {
                                                                            TratarEventos.GravaLinhaEvento(IdServico, listaCampo[0].CampoIndicador.ToString(), listaCampo[0].CampoRegraCalculo, listaCampo[0].CampoItemIndicador, chaveResposta, listaCampo[0].CampoTipoValor, Environment.UserName.ToUpper(), listaCampo[0].CampoEvento, "Retorno e-mail -  - campos a atualizar");
                                                                        };
                                                                    }

                                                                    if (camposInsert.Count > 0)
                                                                    {
                                                                        DataAccess.SalvarDadosServicoLote(camposInsert, "_MobiosBackGround");
                                                                    }

                                                                    if (camposUpdate.Count > 0)
                                                                    {
                                                                        DataAccess.AtualizarDadosServicoLote(IdServico, camposUpdate, "_MobiosBackGround");
                                                                    }


                                                                    // Campo origem: precis de indicador
                                                                    if (listaCamposServico[0].CampoIndicador == true)
                                                                    {
                                                                        TratarEventos.GravaLinhaEvento(IdServico, listaCamposServico[0].CampoIndicador.ToString(), listaCamposServico[0].CampoRegraCalculo, listaCamposServico[0].CampoItemIndicador, chaveResposta, listaCamposServico[0].CampoTipoValor, Environment.UserName.ToUpper(), listaCamposServico[0].CampoEvento, "Retorno e-mail - campo enviar", chaveTimeStamp);
                                                                    };
                                                                }
                                                                break;
                                                            case "GERARINDICADOR":
                                                                // Quando precisa apenas gerar um indicador
                                                                camposAtualizar = listaCamposServico[0].CamposAtualizar.ToString().Split(';');
                                                                foreach (string campo in camposAtualizar)
                                                                {
                                                                    List<CamposInfo> listaCampo = DataAccess.BuscarInfoCampo(campo);
                                                                    if (listaCampo[0].CampoIndicador == true)
                                                                    {
                                                                        TratarEventos.GravaLinhaEvento(IdServico, listaCampo[0].CampoIndicador.ToString(), listaCampo[0].CampoRegraCalculo, listaCampo[0].CampoItemIndicador, chaveResposta, listaCampo[0].CampoTipoValor, Environment.UserName.ToUpper(), listaCampo[0].CampoEvento, "Retorno e-mail -  - campos a atualizar");
                                                                    };
                                                                }
                                                                // Campo origem: precisa de indicador
                                                                if (listaCamposServico[0].CampoIndicador == true)
                                                                {
                                                                    TratarEventos.GravaLinhaEvento(IdServico, listaCamposServico[0].CampoIndicador.ToString(), listaCamposServico[0].CampoRegraCalculo, listaCamposServico[0].CampoItemIndicador, chaveResposta, listaCamposServico[0].CampoTipoValor, Environment.UserName.ToUpper(), listaCamposServico[0].CampoEvento, "Retorno e-mail - campo enviar", chaveTimeStamp);
                                                                };
                                                                break;
                                                            default:
                                                                // Quando não precisa fazer nada.
                                                                //if (listaCamposServico[0].CampoIndicador == true)
                                                                //{
                                                                //    TratarEventos.GravaLinhaEvento(IdServico, listaCamposServico[0].CampoIndicador.ToString(), listaCamposServico[0].CampoRegraCalculo, listaCamposServico[0].CampoItemIndicador, chaveResposta, Environment.UserName.ToUpper(), listaCamposServico[0].CampoEvento, "Retorno e-mail - sem ação retorno");
                                                                //};
                                                                break;
                                                        }

                                                        //
                                                        if (listaCamposServico[0].CampoGeraFUP == true)
                                                        {
                                                            // FUP de recebimento do e-mail
                                                            _FollowUp.ID_Servico = Convert.ToInt32(chaveMOBIOS[0]);
                                                            _FollowUp.ID_Fluxo = Convert.ToInt32(chaveMOBIOS[1]);
                                                            _FollowUp.ID_Campo = Convert.ToInt32(chaveMOBIOS[2]);
                                                            _FollowUp.FollowUpEtapa = dadosEmail[i].ToString();
                                                            _FollowUp.DataCriacao = DateTime.Now;                   //Opção foi usar a data que recebeu a caixa e não data/hora de envio (SentOn);
                                                            DataAccess.RegistrarFollowUpEtapaServico(_FollowUp, false);
                                                        }
                                                    }
                                                    // FUP de mudança de Status: Alterar Status para Análise MO
                                                    if (infoEtapa[0].ID_Status != Convert.ToInt32(Properties.Settings.Default.StatusMOAnalise))
                                                    {
                                                        infoEtapa[0].ID_Status = Convert.ToInt32(Properties.Settings.Default.StatusMOAnalise);
                                                        //DataAccess.GravarIndicadorStatus(IdServico, infoEtapa[0].ID_Etapa, infoEtapa[0].ID_Status, "_MobiosBackGround");
                                                        DataAccess.AtualizaStatusEtapa(IdServico, false, infoEtapa[0].ID_Status, infoEtapa[0].ID_Etapa, "_MobiosBackGround");
                                                    }
                                                    
                                                }
                                                catch (Exception err)
                                                {
                                                    msgErro = "Erro ao consultar emails.\nVeja se as pastas " + Properties.Settings.Default.InboxLido + " e " + Properties.Settings.Default.InboxRead + " estão criadas.\nErro: " + err.Message + ".";
                                                    this.Invoke(new MethodInvoker(delegate() { lbEmail.Items.Add(msgErro); }));
                                                    MessageBox.Show(msgErro);
                                                }


                                            }
                                        }

                                        if (msgAlerta != null)
                                        {
                                            this.Invoke(new MethodInvoker(delegate() { lbEmail.Items.Add("Você recebeu " + dadosEmail[0] + " email.\n\n" + msgAlerta); }));
                                        }
                                        else { this.Invoke(new MethodInvoker(delegate() { lbEmail.Items.Add("Nenhum email encontrado.\n\n"); })); }
                                    }
                                }
                                catch (Exception erro)
                                {
                                    msgErro = "Erro ao consultar emails.\nVeja se as pastas " + Properties.Settings.Default.InboxLido + " e " + Properties.Settings.Default.InboxRead + " estão criadas.\nErro: " + erro.Message + ".";
                                    this.Invoke(new MethodInvoker(delegate() { lbEmail.Items.Add(msgErro); }));
                                    //lbEmail.Items.Add(msgErro);
                                    //MessageBox.Show(msgErro);
                                }
                            }
                        }
                    }

                    #endregion

                    #region [ Leitor SharePoint ]

                    if (SharedData.gLeitorSharepoint)
                    {
                        if (SharedData.UserCelulas.Where(n => n.Integradores.ToUpper().Contains("SHAREPOINT=TRUE")).Count() > 0)
                        {
                            try
                            {
                                string msgListItem = "Verificando Novas Operações nos SharePoints...";
                                addText(msgListItem);

                                List<string> Idretornados = SharePoint.BuscaServicosSharePoint().Distinct().ToList();
                                string IdServicos = Idretornados.Count.ToString();
                                foreach (string item in Idretornados)
                                {
                                    //IdServicos = IdServicos + " - " + item.ToString();
                                    addText(item.ToString());
                                }

                                if (IdServicos != "0")
                                {
                                    //this.Invoke(new MethodInvoker(delegate() { lbEmail.Items.Add("Não foram localizadas novas operações nos Sharepoints"); }));
                                    msgListItem = "Não foram localizadas novas operações nos Sharepoints";
                                    addText(msgListItem);
                                    //this.Invoke(new MethodInvoker(delegate() { lbEmail.Items.Insert(0, new ListItem(msgListItem)); }));
                                }
                                else
                                {
                                    msgListItem = "Novos Serviços registrados: " + IdServicos + "\n\n";
                                    addText(msgListItem);
                                    //this.Invoke(new MethodInvoker(delegate() { lbEmail.Items.Insert(0, new ListItem(msgListItem)); }));
                                    //this.Invoke(new MethodInvoker(delegate() { lbEmail.Items.Add("Novos Serviços registrados: " + IdServicos + "\n\n"); }));
                                }
                            }
                            catch (Exception erro)
                            {
                                msgErro = "Erro ao consultar SharePoint.\nVeja se os acessos estão habilitados.\nErro: " + erro.Message + ".";
                                Log.GravaLog(msgLog, "_MobiosBackground");
                                MessageBox.Show(msgErro);
                                //this.Invoke(new MethodInvoker(delegate() { lbEmail.Items.Add(msgErro); }));
                                this.Invoke(new MethodInvoker(delegate() { lbEmail.Items.Insert(0, new ListItem(msgErro)); }));
                            }


                            try
                            {
                                this.Invoke(new MethodInvoker(delegate() { lbEmail.Items.Add("Verificando Operações nos SharePoints..."); }));
                                List<string> Idretornados = SharePoint.BuscaDadosSharePoint().Distinct().ToList();
                                string IdServicos = "";
                                foreach (string item in Idretornados)
                                {
                                    IdServicos = IdServicos + " - " + item.ToString();
                                }

                                if (IdServicos == "")
                                {
                                    this.Invoke(new MethodInvoker(delegate() { lbEmail.Items.Add("Não foi encontrada nenhuma alteração nos Sharepoints"); }));
                                }
                                else
                                {
                                    this.Invoke(new MethodInvoker(delegate() { lbEmail.Items.Add("Foram retornados dados do Sharepoint para os serviços: " + IdServicos + "\n\n"); }));
                                }
                            }
                            catch (Exception erro)
                            {
                                msgErro = "Erro ao consultar SharePoint.\nVeja se os acessos estão habilitados.\nErro: " + erro.Message + ".";
                                Log.GravaLog(msgLog, "_MobiosBackground");
                                MessageBox.Show(msgErro);
                                this.Invoke(new MethodInvoker(delegate() { lbEmail.Items.Add(msgErro); }));
                            }
                        }
                    }
                    # endregion

                    #region [ Leitor Web ]
                    if (SharedData.gLeitorWEB)
                    {
                        if (SharedData.UserCelulas.Where(n => n.Integradores.ToUpper().Contains("WEB=TRUE")).Count() > 0)
                        {
                            try
                            {
                                string OnOff = "";
                                this.Invoke(new MethodInvoker(delegate() { OnOff = lblStatusIntegradorWeb.Text; }));
                                if (OnOff == "ON")
                                {
                                    this.Invoke(new MethodInvoker(delegate() { lbEmail.Items.Add("Verificando Novas Operações..."); }));
                                    Form GetWeb = new Web(txPass.Text);
                                    this.Invoke(new MethodInvoker(delegate() { lbEmail.Items.Add("Processo concluído, verifique Pipeline"); }));
                                }

                            }
                            catch (Exception erro)
                            {
                                msgErro = "Erro ao consultar página WEB.\nVeja se os acessos estão habilitados.\nErro: " + erro.Message + ".";
                                Log.GravaLog(msgLog, "_MobiosBackground");
                                MessageBox.Show(msgErro);
                                this.Invoke(new MethodInvoker(delegate() { lbEmail.Items.Add(msgErro); }));
                            }
                        }
                        else
                        {
                            MainForm.SalvarSenha("");
                        }
                    }
                    else
                    {
                        MainForm.SalvarSenha("");
                    }
                    #endregion

                    #region [ Leitor Método ]
                    if (SharedData.gLeitorMetodo)
                    {
                        if (SharedData.UserCelulas.Where(n => n.Integradores.ToUpper().Contains("METODO=TRUE")).Count() > 0)
                        {
                            try
                            {
                                List<ClassListMethod> MetodosMain = new List<ClassListMethod>();
                                if (SharedData.gMetodos != null && SharedData.gMetodos.Count > 0)
                                {
                                    List<ClassListMethod> temp = SharedData.gMetodos.Where(n => n.MethodForm.ToString().ToUpper() == "MAIN").ToList();
                                    if (temp != null && temp.Count > 0)
                                    {
                                        foreach (ClassListMethod c in temp)
                                        {
                                            MetodosMain.Add(new ClassListMethod(c));
                                        }
                                    }
                                }

                                if (MetodosMain == null || MetodosMain.Count == 0)
                                {
                                    MetodosMain = DataAccess.GetListMethodMain();
                                }

                                foreach (ClassListMethod met in MetodosMain)
                                {
                                    try
                                    {
                                        _MyMethodBackground = new ClassListMethod();
                                        _MyMethodBackground = (Mobios.ClassListMethod)(met);
                                        CustomMethod.ChamarMetodo(met.MethodName, CustomMethod.MethodForm.MainBackGround);
                                    }
                                    catch (Exception ex)
                                    {
                                        Log.GravaLog("Método " + met.MethodDescricao + " apresentou erro.\n\n" + ex.Message);
                                        MessageBox.Show("Método " + met.MethodDescricao + " apresentou erro.\n\n" + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }

                                }
                            }
                            catch (Exception errMetodo)
                            {
                                msgErro = "Erro ao executar Métodos Main.\nErro: " + errMetodo.Message;
                                Log.GravaLog(msgLog, "_MobiosBackground");
                                MessageBox.Show(msgErro);
                                //this.Invoke(new MethodInvoker(delegate() { lbEmail.Items.Add(msgErro); }));
                                this.Invoke(new MethodInvoker(delegate() { lbEmail.Items.Insert(0, new ListItem(msgErro)); }));
                            }
                        }
                    }
                    #endregion
                }
            }
            catch (Exception err)
            {
                Log.GravaLog("Erro: " + err.Message, "_MobiosBackGround");
            }
        }

        private void backgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            this.timer.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            CustomMethod.AbrirDemandaFromTxt(347);
            return;


            List<string> MinhasDBs = new List<string>();
            MinhasDBs.Add(@"\\fswcorp\cat\DSMC\SSHS\Gerencia de Documentação e Cadastro\Unidade de Cadastro\Workflow - área de cadastro\Homologação\BD\DB_MOBIOS.accdb");
            MinhasDBs.Add(@"T:\_Mobios_CAGI\Homologação\BD\DB_MOBIOS.accdb");

            List<SharedData.COLUNA> COLUNAS = SharedData.ExportTableSchema(MinhasDBs);

            DataTable dt = new DataTable();
            System.Data.DataColumn newColumn1 = new System.Data.DataColumn("CAMINHO", typeof(System.String));
            dt.Columns.Add(newColumn1);
            System.Data.DataColumn newColumn2 = new System.Data.DataColumn("TABELA", typeof(System.String));
            dt.Columns.Add(newColumn2);
            System.Data.DataColumn newColumn3 = new System.Data.DataColumn("COLUNA", typeof(System.String));
            dt.Columns.Add(newColumn3);
            foreach (SharedData.COLUNA item in COLUNAS)
            {
                // generate the data you want to insert
                DataRow toInsert = dt.NewRow();
                toInsert[0] = item.CAMINHO;
                toInsert[1] = item.NOMETABELA;
                toInsert[2] = item.NOMECOLUNA;
                // insert in the desired place
                dt.Rows.Add(toInsert);
            }
            TratarEventos.ExportaDataTable(dt);
            /*
            //SharePoint.MoverAnexos("{8EA87CCB-B909-4652-B7A9-3DB2F3B94928}", @"http://sharepoint/sites/projetoseprocessos/IO/autoproc/teste/","4","");
            SharePoint.LimparLixeira(@"http://sharepoint/sites/projetoseprocessos/IO/autoproc/teste/");
            //string pdf = LeitorPDF.GetText(@"\\fswcorp\cat\DSMC\SSHS\Gerencia de Documentação e Cadastro\Unidade de Cadastro\Workflow - área de cadastro\BD\ind\Formulário Custódia.pdf");
            //bool contem = pdf.Contains("☒");
            WebCustom webCustom = new WebCustom("TranscreverPortalFY", CustomMethod.MethodForm.Minutas, true);
             * */
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            if (!backgroundWorker.IsBusy)
            {
                this.timer.Enabled = false;
                backgroundWorker.RunWorkerAsync();
            }
        }
        #endregion

        #region [ BackgroundWorker de Fechamento Forçado ]
        private void bgwObrigaFechamento_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                #region [ Fechamento Obrigatório ]
                string En = SharedData.PathObrigarFechamento;
                if (System.IO.File.Exists(En))
                {
                    using (MensagemConfirmacao msg = new MensagemConfirmacao("É necessário o fechamento do sistema para realização de atualizações.\n\nPodemos encerrar o sistema?\nCaso não possa no momento, em 3min receberá nova mensagem informando o fechamento obrigatório."))
                    {
                        if (msg.ShowDialog() == DialogResult.Yes)
                        {
                            SharedData.Quit();
                        }
                        else
                        {
                            Tempo.Pausa(150);

                            using (MensagemConfirmacao msg2 = new MensagemConfirmacao("É necessário o fechamento do sistema para realização de atualizações.\n\nPodemos encerrar o sistema?\nCaso não possa no momento, em 3min receberá nova mensagem informando o fechamento obrigatório."))
                            {
                                if (msg2.ShowDialog() == DialogResult.Yes)
                                {
                                    SharedData.Quit();
                                }
                                else
                                {
                                    Tempo.Pausa(30);
                                    SharedData.Quit();
                                }
                            }
                        }
                    }
                }
                #endregion
            }
            catch(Exception err)
            {
                Log.GravaLog("Erro: " + err.Message, "_MobiosBackGroundVerificadorOff");
            }

            try
            {
                #region [ Verifica Acessos ]
                if (SharedData.VerificaArquivoAcesso())
                {
                    bool fecha = false;

                    if (!SharedData.BuscarAcessos())
                    {
                        fecha = true;
                    }

                    SharedData.ExcluiArquivoAcesso();

                    if (fecha)
                    {
                        SharedData.Quit();
                    }
                }
                #endregion
            }
            catch (Exception err)
            {
                Log.GravaLog("Erro: " + err.Message, "_MobiosBackGroundVerificadorAcessos");
            }
            //IntegraRemoto(true);

        }

        private void timerFechamento_Tick(object sender, EventArgs e)
        {
            if (!bgwObrigaFechamento.IsBusy && _fechamentoObrigatorio)
            {
                this.timerFechamento.Enabled = false;
                bgwObrigaFechamento.RunWorkerAsync();
            }
        }

        private void bgwObrigaFechamento_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            this.timerFechamento.Enabled = true;
        }
        #endregion

        private void timerPipe_Tick(object sender, EventArgs e)
        {
            #region [ abre pipeline ]
            if (!SharedData.isOpenForm(typeof(Pipeline), false))
            {
                Form frm = new Pipeline();
                frm.MdiParent = this;
                #region [ ajusta tamanho ]
                if (frm.Width > frm.ParentForm.ClientSize.Width - 5)
                {
                    frm.Width = frm.ParentForm.ClientSize.Width - 5;
                }
                if (frm.Height > frm.ParentForm.ClientSize.Height - 100)
                {
                    frm.Height = frm.ParentForm.ClientSize.Height - 100;
                }
                #endregion

                frm.Left = 0;
                frm.Top = 0;
                frm.Show();
                if (SharedData.gPipeLineMaximizar)
                    frm.WindowState = FormWindowState.Maximized;
                else
                    frm.WindowState = FormWindowState.Normal;
                timerPipe.Enabled = false;
            }
            #endregion
        }

        private void timerPortal_Tick(object sender, EventArgs e)
        {
            CarregaPortalItau();
        }

        #region [ BackGroundWorker BackUp ]
        private void bgwBackup_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                Log.GravaLog("Iniciando BackUp do banco de dados...", "_BackUpBD");

                string PathBackup = SharedData.BackUpPath;
                string PathDest = PathBackup + DateTime.Now.ToString("yyyyMMddHHmmss") + "\\";
                Log.GravaLog(PathDest, "_BackUpBD");
                Log.CopiaDiretorio(SharedData.BDPath, PathDest, false);
                Log.GravaLog("Cópia concluída...", "_BackUpBD");

                var di = new DirectoryInfo(PathBackup);
                List<string> directories = di.EnumerateDirectories().OrderBy(d => d.CreationTime).Select(d => d.FullName).ToList();

                Log.GravaLog("Qtd Diretórios: " + directories.Count + ". Limite: " + SharedData.gBackUpQtd, "_BackUpBD");
                int i = 0;
                while (directories.Count > SharedData.gBackUpQtd)
                {
                    Log.GravaLog("Deletando diretório mais antigo: " + directories[i], "_BackUpBD");
                    Log.DeletaDiretorio(directories[0]);
                    
                    di = new DirectoryInfo(PathBackup);
                    directories = di.EnumerateDirectories().OrderBy(d => d.CreationTime).Select(d => d.FullName).ToList();
                }
                Log.GravaLog("BackUp Concluído: " + directories[directories.Count - 1], "_BackUpBD");
            }
            catch (Exception erroBackUp)
            {
                Log.GravaLog("Erro: " + erroBackUp.Message, "_BackUpBD");
                MessageBox.Show("Houve um erro ao realizar o backup do banco de dados.\n\nVerifique se sua máquina está com pouco espaço ou sem acesso à rede.\n\nErro: " + erroBackUp.Message);
            }
        }

        private void timerBackUp_Tick(object sender, EventArgs e)
        {
            if (!bgwBackup.IsBusy)
            {
                this.timerBackUp.Enabled = false;
                bgwBackup.RunWorkerAsync();
            }
        }

        private void bgwBackup_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            this.timerBackUp.Interval = SharedData.gBackUpInterval;
            this.timerBackUp.Enabled = true;
        }
        #endregion

        #region [ BackGroundWorker Valida Ponto ]
        private void bgwValidaPonto_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                System.Threading.Thread t = new System.Threading.Thread(AbreFormValidaPonto);
                t.SetApartmentState(System.Threading.ApartmentState.STA);
                t.Start();
                t.Join();
            }
            catch (Exception err)
            {
                Log.GravaLog("Erro: " + err.Message, "_ValidaPonto");
            }
        }
        private void AbreFormValidaPonto()
        {
            try
            {
                PontoEletronicoValida validaPonto = new PontoEletronicoValida();
            }
            catch (Exception err)
            {
                Log.GravaLog("Erro: " + err.Message, "_ValidaPonto");
            }
        }
        private void timerValidaPonto_Tick(object sender, EventArgs e)
        {
            if (!bgwBackup.IsBusy)
            {
                this.timerValidaPonto.Enabled = false;
                bgwValidaPonto.RunWorkerAsync();
            }
        }

        private void bgwValidaPonto_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            this.timerValidaPonto.Interval = SharedData.gValidaPontoInterval;
            this.timerValidaPonto.Enabled = true;
        }
        #endregion

        private void suporteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
            SharedData.CreateMailItem(SharedData.gSuporteAssunto, SharedData.gSuporteEmail, SharedData.gSuporteMensagem, "", true);
            }
            catch(Exception errEmail)
            {
                MessageBox.Show(errEmail.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void fecharInstânciasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Forçar fechamento de todas as instâncias abertas do Mobios em todos os usuários?", "Fechamento Obrigatório", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                _fechamentoObrigatorio = false;
                Log.GravaLog("Forçar fechamento de todos os Mobios");
                SharedData.CriaArquivoOFF();
                Log.GravaLog("Arquivo OFF criado");
                Tempo.Pausa(60, true);
                Log.GravaLog("Timer 60s");
                if (SharedData.ExcluiArquivoOFF())
                {
                    MessageBox.Show("Processo concluído.\n\nTodos os Mobios serão fechados em até 4min.");
                    Log.GravaLog("Arquivo OFF excluído");
                }
                else
                {
                    MessageBox.Show("Falha ao excluir arquivo OFF");
                    Log.GravaLog("Falha ao excluir arquivo OFF");
                }
                _fechamentoObrigatorio = true;
            }
        }

        private void parâmetrosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!SharedData.isOpenForm(typeof(Parametros), false))
            {
                Form frm = new Parametros();
                frm.WindowState = FormWindowState.Normal;
                frm.Left = 0;
                frm.Top = 0;
                frm.Show();
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!_closing)
            {
                _closing = true;
                SharedData.CloseAllForms(typeof(MainForm));
                Falar.SpeakTxt("Fechando");

                try
                {
                    if (Falar.speech != null)
                    {
                        while (Falar.speech.State == Microsoft.Speech.Synthesis.SynthesizerState.Speaking)
                        {
                            Application.DoEvents();
                        }
                    }
                }
                catch { }

                try
                {
                    if (Falar.speech2 != null)
                    {
                        while (Falar.speech2.State == System.Speech.Synthesis.SynthesizerState.Speaking)
                        {
                            Application.DoEvents();
                        }
                    }
                }
                catch { }

                SharedData.Quit();
            }
        }

        private void logToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string path = SharedData.LogPath + "Log\\" + DateTime.Today.ToString("yyyy") + "\\" + DateTime.Today.ToString("MM") + "\\" + DateTime.Today.ToString("yyyyMMdd") + "\\";
            if (Directory.Exists(path))
            {
                System.Diagnostics.Process.Start(path);    
            }
            else
                System.Diagnostics.Process.Start(SharedData.LogPath);            
        }

        //private void IntegraRemoto(bool Pinta = false)
        //{

        //    if (Properties.Settings.Default.Remoto == true && SharedData.User.Integra == true)
        //    {
        //        Integra.DadosFlag d = new Integra.DadosFlag();

        //        d = VerificaIntegrador();
        //        tssHoje.Text = d.Horario.ToString("HH:mm");

        //        if (Pinta == true)
        //            if (d.Tempo > Properties.Settings.Default.TempoIntegra)
        //                tssHoje.ForeColor = System.Drawing.Color.Red;
        //            else
        //                tssHoje.ForeColor = System.Drawing.Color.Black;

        //    }

        //}
    }
}


