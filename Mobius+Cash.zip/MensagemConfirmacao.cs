﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mobios
{
    public partial class MensagemConfirmacao : Form
    {
        public MensagemConfirmacao(string msg)
        {
            InitializeComponent();
            this.lblMensagem.Text = msg;
            Timer timer = new Timer(); // cria um temporizador para fechar o form
            timer.Interval = 30000;
            timer.Tick += delegate { this.DialogResult = DialogResult.Yes; };
            timer.Start(); // inicia o timer
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Yes;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.No;
        }
    }
}
