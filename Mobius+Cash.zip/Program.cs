﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Deployment.Application;

namespace Mobios
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] Args)
        {
            //Args apenas vem de um consolo (.exe)
            string[] args = null;
            if (ApplicationDeployment.IsNetworkDeployed)
            {
                //Click-once
                var inputArgs = AppDomain.CurrentDomain.SetupInformation.ActivationArguments.ActivationData;
                if (inputArgs != null && inputArgs.Length > 0)
                {
                    args = inputArgs[0].Split(new char[] { ';', ',' });
                }
            }
            else
            {
                //console
                args = Args;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Add the event handler for handling UI thread exceptions to the event.
            Application.ThreadException += new
                ThreadExceptionEventHandler(new Error().TrataErro);

            // Set the unhandled exception mode to force all Windows Forms errors to go through our handler.
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);

            // Add the event handler for handling non-UI thread exceptions to the event. 
            AppDomain.CurrentDomain.UnhandledException +=
                new UnhandledExceptionEventHandler(new Error().TrataErro);




            string En = SharedData.ReturnPathObrigarFechamento();
            if (System.IO.File.Exists(En))
            {
                MessageBox.Show("O sistema está em modo de manutenção. Aguarde alguns minutos.\nCaso necessário, contate a equipe de Automação de Processos.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                SharedData.Quit();
            }

            if (SharedData.verExec(System.Diagnostics.Process.GetCurrentProcess().ProcessName) == true)
                SharedData.Quit();

                Application.Run(new MainForm(args));            
        }

        public class Error
        {
            public void TrataErro(object sender, ThreadExceptionEventArgs e)
            {
                StringBuilder err = new StringBuilder();
                //StreamWriter file = File.AppendText(AppDomain.CurrentDomain.BaseDirectory + @"\error.txt");                
                Log.GravaLog(this.FormatarErro(err, e.Exception),"_Error");
                //file.Close();

                MessageBox.Show("Desculpe, houve um erro na aplicação.\nContate a equipe de Automação de Processos.", "Erro no Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            public void TrataErro(object sender, UnhandledExceptionEventArgs e)
            {
                StringBuilder err = new StringBuilder();
                
                Log.GravaLog(e.ExceptionObject.ToString(), "_ErrorThread");

                MessageBox.Show("Desculpe, houve um erro na aplicação.\nContate a equipe de Automação de Processos.", "Erro no Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                SharedData.Quit();
            }

            public string FormatarErro(StringBuilder sb, Exception e)
            {
                string user = WindowsIdentity.GetCurrent().Name.Split('\\')[1].ToUpper();
                sb.AppendFormat("\n\n\n\n\nUser: {0}  | Date: {1} \n\n\n", user, DateTime.Now);
                sb.AppendFormat("Exception Found:\nType: {0}", e.GetType().FullName);
                sb.AppendFormat("\nMessage: {0}", e.Message);
                sb.AppendFormat("\nSource: {0}", e.Source);
                sb.AppendFormat("\nStacktrace: {0} \n\n\n", e.StackTrace);

                if (e.InnerException != null)
                {
                    sb.Append("\n");
                    FormatarErro(sb, e.InnerException);
                }

                return sb.ToString();
            }
        }

       
    }
}
