﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;
// Coloquei
using System.IO;
using System.Windows.Forms;
using System.Data;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;


namespace Mobios
{
    public static class TratarEventos
    {
  
        //====================================================================================
        //FUNÇÕES
        //====================================================================================
        public static void CriarDiretorio(string path)
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }        
        }

        //**********************************************************************************
        // Função que grava a linha do evento 
        //**********************************************************************************
        public static void GravaLinhaEvento(int idServico, string tipoIndicador, string regraCalculo, string itemIndicador, string valor, string usuario, string evento, string Qdo)
        {
            //GravaLinhaEvento(idServico, c.tipoIndicador, c.formula, c.itemIndicador, c.valor, usuario, c.evento,);
            // Recupera local para gravação do INDICADOR
            string pathInd = "C:\\Users\\Adriano\\Desktop\\MOBIOS\\Indicadores";
            string pathNome = pathInd + "\\" + idServico + ".txt";
            string linha = "";

            // Verifica diretório
            CriarDiretorio(pathInd);

            // Abre ou cria arquivo
            StreamWriter objWriter = new StreamWriter(pathNome, true);

            string[] tipoInd = tipoIndicador.Split(';');
            foreach (string indicador in tipoInd)
            {
                linha = idServico + ";" + indicador + ";" + regraCalculo + ";" + itemIndicador + ";" + valor + ";" + usuario + ";" + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + ";" + evento + ";" + Qdo;
                objWriter.WriteLine(linha);
            }

            //linha = idServico + ";" + tipoIndicador + ";" + formula + ";" + itemIndicador + ";" + valor + ";" + usuario + ";" + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + ";" + evento + ";"  + Qdo;
            //objWriter.WriteLine(linha);
            objWriter.Close();

        }
        
        //**********************************************************************************
        // Função que prepara os dados e grava a linha do evento 
        //**********************************************************************************
        public static void GravaLinhaEvento(int idServico, int IdCampo, string valorcampo, string usuario, string Qdo)
        {
            // Recupera os dados do campo pelo ID
            Campos c = new Campos();
            // Entrada do boleto
            c.CampoTipoIndicador = "TempoMiddle";
            c.CampoRegraCalculo = "Minimo";
            c.CampoItemIndicador = "Entrada da operação";
            c.ValorCampo = valorcampo;
            c.CampoEvento = "ENTRADA";
            c.CampoIndicador = true;
            // Se campo indicador
            if (c.CampoIndicador)
            {
                // Grava a linha no arquivo
                GravaLinhaEvento(idServico, c.CampoTipoIndicador, c.CampoRegraCalculo, c.CampoItemIndicador, c.ValorCampo, usuario, c.CampoEvento, Qdo);
            }
        }
        
        //**********************************************************************************
        // Função que le arquivo indicadores 
        //**********************************************************************************
        public static void MontaIndicadoresServico(string pathNome, int idServico)
        {

            string linha = "";
            string[] arrText;


            // Verifica arquivo existe
            if (File.Exists(pathNome))
            {
                //MessageBox.Show("Arquivo '" + pathNome + "' encontrado");
                // Excluir dados dos indicadores
                DataAccess.ExcluirIndicadorServico(idServico);

                StreamReader objReader = new StreamReader(pathNome);
                
                while (linha != null)
                {
                    linha = objReader.ReadLine();
                    if (linha != null)
                    {
                        //MessageBox.Show("Linha: " + linha + ".");
                        arrText = linha.Split(';');

                        //for (int i = 0; i < arrText.Count(); i++)
                        //{
                        //    MessageBox.Show("Item " + i + ": " + arrText[i] + ".");                            
                        //    Clipboard.SetData(DataFormats.Text, arrText[i]);
                        //}
                        DataAccess.IncluirIndicador(arrText[0], arrText[1], arrText[2], arrText[3], arrText[4]);
                    }
                    else
                    {
                        MessageBox.Show("Fim do processamento.");
                    }
                }                 
                // Fecha objeto
                objReader.Close();
            }
            else
            {
                MessageBox.Show("Arquivo '" + pathNome + "' não encontrado");
            }

        }

        //**********************************************************************************
        // Função que mostra indicador no Excel 
        //**********************************************************************************

        /// <summary>
        /// Método responsável por converter um objeto Array para um objeto array de string
        /// </summary>
        /// <param name="values">valor do array</param>
        /// <returns></returns>
        private static string[] ConvertToStringArray(System.Array values)
        {
            // cria uma nova string de array
            string[] array = new string[values.Length];
            // percorrer o array e vai obtendo os valores de cada celula 
            for (int i = 1; i <= values.Length; i++)
            {
                if (values.GetValue(1, i) == null)
                    array[i - 1] = "";
                else
                    array[i - 1] = (string)values.GetValue(1, i).ToString();
            }
            return array;
        }
    

        /// <summary>
        /// Método responsável por Obter os Valores das colunas 
        /// </summary>
        /// <param name="range">quantidade colunas</param>
        /// <param name="excelWorksheet">objeto que contém worksheet</param>
        /// <returns></returns>
        public static string[] GetRange(string range, Excel.Worksheet excelWorksheet)
        {
            // obtém as celulas
            Excel.Range cells = excelWorksheet.get_Range(range, Type.Missing);

            // setar os valores para um array
            System.Array array = (System.Array)cells.Cells.Value2;

            // chama o método ConvertToStringArray que converterá o array objeto para uma string de array
            string[] arrayS = ConvertToStringArray(array);

            return arrayS;
        }
        
        public static void MontaeExcelIndicadoresServico(string idServico, string pathTemplateIndicador, string pathInd, int linhaDados)
        {
            DataTable dadosIndicadores = DataAccess.Listagem(Convert.ToInt16(idServico));            
            
            pathInd = pathInd + "\\" + idServico + ".xlsx";

            // Variáveis
            Excel.Application xlApp = null;
            Excel.Workbook xlWorkBook = null;
            Excel.Worksheet xlWorkSheet = null;

            xlApp = new Excel.Application();
            xlWorkBook = xlApp.Workbooks.Open(pathTemplateIndicador);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item("Base");

            // Le planilha
            try
            {
                xlApp.Visible = true;
                //xlWorkSheet.Visible = true;

                // cria um objeto que definirá quantos colunas será lidas
                Excel.Range excelRange = xlWorkSheet.UsedRange;
                string[] colunas = GetRange("A2:BK2", xlWorkSheet);

                // Grava os valores no Excel
                foreach (DataRow row in dadosIndicadores.Rows)
                {
                    for (int i = 0; i < colunas.Count(); i++)
                    {
                        if (colunas[i].ToUpper() == row[2].ToString().ToUpper())
                        {
                            xlWorkSheet.Cells[linhaDados, i + 1] = row[3].ToString();
                            //MessageBox.Show(row[2].ToString());
                        }
                    }
                }

                // Salva indicador
                xlWorkBook.SaveAs(pathInd);
                MessageBox.Show("Arquivo de indicadores gerado em " + pathInd + ".");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (xlWorkBook != null) { Marshal.ReleaseComObject(xlWorkBook); } //release each workbook like this
                if (xlWorkSheet != null) { Marshal.ReleaseComObject(xlWorkSheet); } //release each worksheet like this
                if (xlApp != null) { Marshal.ReleaseComObject(xlApp); } //release the Excel application
                xlWorkBook = null; //set each memory reference to null.
                xlWorkSheet = null;
                xlApp = null;
                GC.Collect();
            } 
        }
               

        //**********************************************************************************
        // Process all files in the directory passed in, recurse on any directories 
        // that are found, and process the files they contain.
        //**********************************************************************************
        // Insert logic for processing found files here.
        public static void ProcessFile(string path)
        {
            MontaIndicadoresServico(path, 0);
        }
        
        public static void ProcessDirectory(string targetDirectory)
        {
            
            // Process the list of files found in the directory.
            string[] fileEntries = Directory.GetFiles(targetDirectory);
            foreach (string fileName in fileEntries)
                ProcessFile(fileName);

            // Recurse into subdirectories of this directory.
            string[] subdirectoryEntries = Directory.GetDirectories(targetDirectory);
            foreach (string subdirectory in subdirectoryEntries)
                ProcessDirectory(subdirectory);
        }

    // Fim classe
    }
}
