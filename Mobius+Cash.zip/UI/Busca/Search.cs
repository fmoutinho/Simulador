﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mobios
{
    public partial class Search : Form
    {
        public Search()
        {
            InitializeComponent();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            List<ResponsavelServico> lsv = new List<ResponsavelServico>();
            ResponsavelServico sv;

            if (rdbContato.Checked)
            {
                lsv = DataAccess.BuscarServico(this.txtCod.Text.Trim(), SharedData.User.ID_Responsavel);                
            }
            else
            {
                //sv = DataAccess.BuscarServico(null, this.txtCod.Text);
                sv = DataAccess.BuscarServicoResponsavel(1, 1);
            }

            if (lsv.Count == 0)
                MessageBox.Show("Operação não encontrada", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            else if (lsv.Count == 1)
            {
                string ParametroForm = SharedData.gFormOperação;
                Form frm;
                if (ParametroForm == "MINUTAS")
                {
                    frm = new Minutas(lsv[0]);
                }
                else
                {
                    frm = new Detalhe(lsv[0]);
                    frm.WindowState = FormWindowState.Maximized;
                }
                frm.MdiParent = ((MainForm)Application.OpenForms["MainForm"]);
                frm.Show();
                this.Close();
            }
            else
            {
                Form frm = new SimilaritySearch(lsv);
                //frm.MdiParent = this.MdiParent;
                frm.Show();
                this.Close();
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtCod_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.ToString() == "Return")
            {
                this.btnPesquisar.PerformClick();
            }
        }
    }
}
