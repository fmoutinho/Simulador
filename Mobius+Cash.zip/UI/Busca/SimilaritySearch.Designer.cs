﻿namespace Mobios
{
    partial class SimilaritySearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SimilaritySearch));
            this.dgvSearch = new System.Windows.Forms.DataGridView();
            this.ID_Objeto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID_Responsavel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID_Servico = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ServicoName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Segmento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Prioridade = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.DataCriacao = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NomeObjeto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gboxRegistrosEncontrados = new System.Windows.Forms.GroupBox();
            this.lblQtdRegistros = new System.Windows.Forms.Label();
            this.txtNumRegistros = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSearch)).BeginInit();
            this.gboxRegistrosEncontrados.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvSearch
            // 
            this.dgvSearch.AllowUserToAddRows = false;
            this.dgvSearch.AllowUserToDeleteRows = false;
            this.dgvSearch.BackgroundColor = System.Drawing.Color.White;
            this.dgvSearch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSearch.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID_Objeto,
            this.ID_Responsavel,
            this.ID_Servico,
            this.ServicoName,
            this.Segmento,
            this.Prioridade,
            this.DataCriacao,
            this.NomeObjeto});
            this.dgvSearch.Location = new System.Drawing.Point(6, 19);
            this.dgvSearch.Name = "dgvSearch";
            this.dgvSearch.ReadOnly = true;
            this.dgvSearch.Size = new System.Drawing.Size(726, 254);
            this.dgvSearch.TabIndex = 0;
            this.dgvSearch.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSearch_CellContentClick);
            this.dgvSearch.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSearch_CellDoubleClick);
            // 
            // ID_Objeto
            // 
            this.ID_Objeto.DataPropertyName = "ID_Objeto";
            this.ID_Objeto.HeaderText = "ID Objeto";
            this.ID_Objeto.Name = "ID_Objeto";
            this.ID_Objeto.ReadOnly = true;
            this.ID_Objeto.Visible = false;
            // 
            // ID_Responsavel
            // 
            this.ID_Responsavel.DataPropertyName = "ID_Responsavel";
            this.ID_Responsavel.HeaderText = "ID_Responsavel";
            this.ID_Responsavel.Name = "ID_Responsavel";
            this.ID_Responsavel.ReadOnly = true;
            this.ID_Responsavel.Visible = false;
            // 
            // ID_Servico
            // 
            this.ID_Servico.DataPropertyName = "ID_Servico";
            this.ID_Servico.HeaderText = "Serviço";
            this.ID_Servico.Name = "ID_Servico";
            this.ID_Servico.ReadOnly = true;
            this.ID_Servico.Width = 200;
            // 
            // ServicoName
            // 
            this.ServicoName.DataPropertyName = "ServicoName";
            this.ServicoName.HeaderText = "Identificação";
            this.ServicoName.Name = "ServicoName";
            this.ServicoName.ReadOnly = true;
            this.ServicoName.Width = 150;
            // 
            // Segmento
            // 
            this.Segmento.DataPropertyName = "Segmento";
            this.Segmento.HeaderText = "Segmento";
            this.Segmento.Name = "Segmento";
            this.Segmento.ReadOnly = true;
            // 
            // Prioridade
            // 
            this.Prioridade.DataPropertyName = "Prioridade";
            this.Prioridade.HeaderText = "Prioridade";
            this.Prioridade.Name = "Prioridade";
            this.Prioridade.ReadOnly = true;
            // 
            // DataCriacao
            // 
            this.DataCriacao.DataPropertyName = "DataCriacao";
            this.DataCriacao.HeaderText = "Data Criação";
            this.DataCriacao.Name = "DataCriacao";
            this.DataCriacao.ReadOnly = true;
            // 
            // NomeObjeto
            // 
            this.NomeObjeto.DataPropertyName = "NomeObjeto";
            this.NomeObjeto.HeaderText = "NomeObjeto";
            this.NomeObjeto.Name = "NomeObjeto";
            this.NomeObjeto.ReadOnly = true;
            this.NomeObjeto.Visible = false;
            // 
            // gboxRegistrosEncontrados
            // 
            this.gboxRegistrosEncontrados.Controls.Add(this.dgvSearch);
            this.gboxRegistrosEncontrados.Location = new System.Drawing.Point(12, 49);
            this.gboxRegistrosEncontrados.Name = "gboxRegistrosEncontrados";
            this.gboxRegistrosEncontrados.Size = new System.Drawing.Size(738, 279);
            this.gboxRegistrosEncontrados.TabIndex = 1;
            this.gboxRegistrosEncontrados.TabStop = false;
            this.gboxRegistrosEncontrados.Text = "Registros Encontrados";
            // 
            // lblQtdRegistros
            // 
            this.lblQtdRegistros.AutoSize = true;
            this.lblQtdRegistros.Location = new System.Drawing.Point(24, 20);
            this.lblQtdRegistros.Name = "lblQtdRegistros";
            this.lblQtdRegistros.Size = new System.Drawing.Size(190, 13);
            this.lblQtdRegistros.TabIndex = 2;
            this.lblQtdRegistros.Text = "Quantidade de Registros Encontrados:";
            // 
            // txtNumRegistros
            // 
            this.txtNumRegistros.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNumRegistros.Location = new System.Drawing.Point(220, 20);
            this.txtNumRegistros.Name = "txtNumRegistros";
            this.txtNumRegistros.Size = new System.Drawing.Size(100, 13);
            this.txtNumRegistros.TabIndex = 3;
            // 
            // SimilaritySearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(762, 335);
            this.Controls.Add(this.txtNumRegistros);
            this.Controls.Add(this.lblQtdRegistros);
            this.Controls.Add(this.gboxRegistrosEncontrados);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SimilaritySearch";
            this.ShowIcon = false;
            this.Text = "Search";
            ((System.ComponentModel.ISupportInitialize)(this.dgvSearch)).EndInit();
            this.gboxRegistrosEncontrados.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvSearch;
        private System.Windows.Forms.GroupBox gboxRegistrosEncontrados;
        private System.Windows.Forms.Label lblQtdRegistros;
        private System.Windows.Forms.TextBox txtNumRegistros;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_Objeto;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_Responsavel;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_Servico;
        private System.Windows.Forms.DataGridViewTextBoxColumn ServicoName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Segmento;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Prioridade;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataCriacao;
        private System.Windows.Forms.DataGridViewTextBoxColumn NomeObjeto;

    }
}