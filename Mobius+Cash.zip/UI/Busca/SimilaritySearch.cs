﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mobios
{
    public partial class SimilaritySearch : Form
    {
        public SimilaritySearch(List<ResponsavelServico> lsv)
        {
            InitializeComponent();
            this.dgvSearch.AutoGenerateColumns = false;
            txtNumRegistros.Text = lsv.Count.ToString();
            this.dgvSearch.DataSource = lsv;
        }

        private void dgvSearch_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            ResponsavelServico sv = new ResponsavelServico();
            sv.ID_Servico = Convert.ToInt32(this.dgvSearch.Rows[e.RowIndex].Cells["ID_Servico"].Value.ToString());
            sv.ID_Responsavel = Convert.ToInt32(this.dgvSearch.Rows[e.RowIndex].Cells["ID_Responsavel"].Value.ToString());
            sv.ID_Objeto = Convert.ToInt32(this.dgvSearch.Rows[e.RowIndex].Cells["ID_Objeto"].Value.ToString());
            sv.ServicoName = this.dgvSearch.Rows[e.RowIndex].Cells["ServicoName"].Value.ToString();
            sv.DataCriacao = Convert.ToDateTime(this.dgvSearch.Rows[e.RowIndex].Cells["DataCriacao"].Value.ToString());
            sv.NomeObjeto = this.dgvSearch.Rows[e.RowIndex].Cells["NomeObjeto"].Value.ToString();
            sv.Segmento = this.dgvSearch.Rows[e.RowIndex].Cells["Segmento"].Value.ToString();
            sv.Prioridade = Convert.ToBoolean(this.dgvSearch.Rows[e.RowIndex].Cells["Prioridade"].Value);

            string ParametroForm = SharedData.gFormOperação;
            Form frm;
            if (ParametroForm == "MINUTAS")
            {
                frm = new Minutas(sv);
            }
            else
            {
                frm = new Detalhe(sv);
                frm.WindowState = FormWindowState.Maximized;
            }

            frm.MdiParent = ((MainForm)Application.OpenForms["MainForm"]);
            //frm.WindowState = FormWindowState.Normal;
            frm.Left = 0;
            frm.Top = 0;
            frm.Show();
            this.Close();
        }

        private void dgvSearch_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
