﻿namespace Mobios
{
    partial class Detalhe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Detalhe));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tabControlServico = new System.Windows.Forms.TabControl();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.btnConcluirServico = new System.Windows.Forms.Button();
            this.btnIndicador = new System.Windows.Forms.Button();
            this.btnCancelarServico = new System.Windows.Forms.Button();
            this.btnSalvarServico = new System.Windows.Forms.Button();
            this.cbAtualizar = new System.Windows.Forms.CheckBox();
            this.btnResumo = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtSegmento = new System.Windows.Forms.TextBox();
            this.lblSegmento = new System.Windows.Forms.Label();
            this.chkPrioridade = new System.Windows.Forms.CheckBox();
            this.txtIdentificacao = new System.Windows.Forms.TextBox();
            this.btnImportarBoleto = new System.Windows.Forms.Button();
            this.lbNomeServico = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cbBoletador = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tabControlCheck = new System.Windows.Forms.TabControl();
            this.label_ListMethod = new System.Windows.Forms.Label();
            this.cmb_ListMethod = new System.Windows.Forms.ComboBox();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnRedirecionar = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.lblFluxoAtual = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnPlayMethod = new System.Windows.Forms.Button();
            this.cboStatus = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gBoxWorkFlow = new System.Windows.Forms.GroupBox();
            this.gBoxFollowUp = new System.Windows.Forms.GroupBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnIncluirFollow = new System.Windows.Forms.Button();
            this.lboxFollowUP = new System.Windows.Forms.ListBox();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.backgroundWorkerDetalhe = new System.ComponentModel.BackgroundWorker();
            this.timerDetalhe = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.gBoxFollowUp.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tabControlServico);
            this.groupBox1.Controls.Add(this.panel4);
            this.groupBox1.Controls.Add(this.panel3);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(219, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1025, 309);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Detalhe";
            // 
            // tabControlServico
            // 
            this.tabControlServico.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlServico.Location = new System.Drawing.Point(3, 78);
            this.tabControlServico.Name = "tabControlServico";
            this.tabControlServico.SelectedIndex = 0;
            this.tabControlServico.Size = new System.Drawing.Size(1019, 190);
            this.tabControlServico.TabIndex = 7;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnExcluir);
            this.panel4.Controls.Add(this.btnConcluirServico);
            this.panel4.Controls.Add(this.btnIndicador);
            this.panel4.Controls.Add(this.btnCancelarServico);
            this.panel4.Controls.Add(this.btnSalvarServico);
            this.panel4.Controls.Add(this.cbAtualizar);
            this.panel4.Controls.Add(this.btnResumo);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(3, 268);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1019, 38);
            this.panel4.TabIndex = 53;
            // 
            // btnExcluir
            // 
            this.btnExcluir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnExcluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcluir.Image = ((System.Drawing.Image)(resources.GetObject("btnExcluir.Image")));
            this.btnExcluir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExcluir.Location = new System.Drawing.Point(915, 7);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(101, 23);
            this.btnExcluir.TabIndex = 52;
            this.btnExcluir.Text = "Excluir Serviço";
            this.btnExcluir.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExcluir.UseVisualStyleBackColor = false;
            this.btnExcluir.Visible = false;
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // btnConcluirServico
            // 
            this.btnConcluirServico.Enabled = false;
            this.btnConcluirServico.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConcluirServico.Image = ((System.Drawing.Image)(resources.GetObject("btnConcluirServico.Image")));
            this.btnConcluirServico.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnConcluirServico.Location = new System.Drawing.Point(501, 7);
            this.btnConcluirServico.Name = "btnConcluirServico";
            this.btnConcluirServico.Size = new System.Drawing.Size(110, 23);
            this.btnConcluirServico.TabIndex = 18;
            this.btnConcluirServico.Text = "Concluir serviço";
            this.btnConcluirServico.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnConcluirServico.UseVisualStyleBackColor = true;
            this.btnConcluirServico.Visible = false;
            this.btnConcluirServico.Click += new System.EventHandler(this.btnConcluirServico_Click);
            // 
            // btnIndicador
            // 
            this.btnIndicador.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIndicador.Image = ((System.Drawing.Image)(resources.GetObject("btnIndicador.Image")));
            this.btnIndicador.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnIndicador.Location = new System.Drawing.Point(811, 7);
            this.btnIndicador.Name = "btnIndicador";
            this.btnIndicador.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnIndicador.Size = new System.Drawing.Size(100, 23);
            this.btnIndicador.TabIndex = 29;
            this.btnIndicador.Text = "Ver Indicador";
            this.btnIndicador.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnIndicador.UseVisualStyleBackColor = true;
            this.btnIndicador.Click += new System.EventHandler(this.btnIndicador_Click);
            // 
            // btnCancelarServico
            // 
            this.btnCancelarServico.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelarServico.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelarServico.Image")));
            this.btnCancelarServico.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelarServico.Location = new System.Drawing.Point(694, 7);
            this.btnCancelarServico.Name = "btnCancelarServico";
            this.btnCancelarServico.Size = new System.Drawing.Size(113, 23);
            this.btnCancelarServico.TabIndex = 22;
            this.btnCancelarServico.Text = "Cancelar Serviço";
            this.btnCancelarServico.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelarServico.UseVisualStyleBackColor = true;
            this.btnCancelarServico.Click += new System.EventHandler(this.btnCancelarServico_Click);
            // 
            // btnSalvarServico
            // 
            this.btnSalvarServico.Enabled = false;
            this.btnSalvarServico.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvarServico.Image = ((System.Drawing.Image)(resources.GetObject("btnSalvarServico.Image")));
            this.btnSalvarServico.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalvarServico.Location = new System.Drawing.Point(75, 7);
            this.btnSalvarServico.Name = "btnSalvarServico";
            this.btnSalvarServico.Size = new System.Drawing.Size(106, 23);
            this.btnSalvarServico.TabIndex = 16;
            this.btnSalvarServico.Text = "Salvar Dados";
            this.btnSalvarServico.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSalvarServico.UseVisualStyleBackColor = true;
            this.btnSalvarServico.Visible = false;
            this.btnSalvarServico.Click += new System.EventHandler(this.btnSalvarServico_Click);
            // 
            // cbAtualizar
            // 
            this.cbAtualizar.AutoSize = true;
            this.cbAtualizar.Location = new System.Drawing.Point(3, 10);
            this.cbAtualizar.Name = "cbAtualizar";
            this.cbAtualizar.Size = new System.Drawing.Size(66, 17);
            this.cbAtualizar.TabIndex = 17;
            this.cbAtualizar.Text = "Atualizar";
            this.cbAtualizar.UseVisualStyleBackColor = true;
            this.cbAtualizar.Visible = false;
            this.cbAtualizar.CheckedChanged += new System.EventHandler(this.cbAtualizar_CheckedChanged);
            // 
            // btnResumo
            // 
            this.btnResumo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnResumo.Image = ((System.Drawing.Image)(resources.GetObject("btnResumo.Image")));
            this.btnResumo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnResumo.Location = new System.Drawing.Point(615, 7);
            this.btnResumo.Name = "btnResumo";
            this.btnResumo.Size = new System.Drawing.Size(75, 23);
            this.btnResumo.TabIndex = 19;
            this.btnResumo.Text = "Resumo";
            this.btnResumo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnResumo.UseVisualStyleBackColor = true;
            this.btnResumo.Click += new System.EventHandler(this.btnResumo_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.txtSegmento);
            this.panel3.Controls.Add(this.lblSegmento);
            this.panel3.Controls.Add(this.chkPrioridade);
            this.panel3.Controls.Add(this.txtIdentificacao);
            this.panel3.Controls.Add(this.btnImportarBoleto);
            this.panel3.Controls.Add(this.lbNomeServico);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.cbBoletador);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(3, 16);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1019, 62);
            this.panel3.TabIndex = 52;
            // 
            // txtSegmento
            // 
            this.txtSegmento.Enabled = false;
            this.txtSegmento.Location = new System.Drawing.Point(175, 36);
            this.txtSegmento.Name = "txtSegmento";
            this.txtSegmento.Size = new System.Drawing.Size(141, 20);
            this.txtSegmento.TabIndex = 54;
            // 
            // lblSegmento
            // 
            this.lblSegmento.AutoSize = true;
            this.lblSegmento.Location = new System.Drawing.Point(117, 40);
            this.lblSegmento.Name = "lblSegmento";
            this.lblSegmento.Size = new System.Drawing.Size(58, 13);
            this.lblSegmento.TabIndex = 53;
            this.lblSegmento.Text = "Segmento:";
            // 
            // chkPrioridade
            // 
            this.chkPrioridade.AutoSize = true;
            this.chkPrioridade.Location = new System.Drawing.Point(37, 39);
            this.chkPrioridade.Name = "chkPrioridade";
            this.chkPrioridade.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.chkPrioridade.Size = new System.Drawing.Size(73, 17);
            this.chkPrioridade.TabIndex = 52;
            this.chkPrioridade.Text = "Prioridade";
            this.chkPrioridade.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkPrioridade.UseVisualStyleBackColor = true;
            this.chkPrioridade.CheckedChanged += new System.EventHandler(this.chkPrioridade_CheckedChanged);
            // 
            // txtIdentificacao
            // 
            this.txtIdentificacao.Enabled = false;
            this.txtIdentificacao.Location = new System.Drawing.Point(97, 13);
            this.txtIdentificacao.Name = "txtIdentificacao";
            this.txtIdentificacao.Size = new System.Drawing.Size(219, 20);
            this.txtIdentificacao.TabIndex = 24;
            // 
            // btnImportarBoleto
            // 
            this.btnImportarBoleto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnImportarBoleto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImportarBoleto.Image = ((System.Drawing.Image)(resources.GetObject("btnImportarBoleto.Image")));
            this.btnImportarBoleto.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnImportarBoleto.Location = new System.Drawing.Point(863, 7);
            this.btnImportarBoleto.Name = "btnImportarBoleto";
            this.btnImportarBoleto.Size = new System.Drawing.Size(150, 23);
            this.btnImportarBoleto.TabIndex = 43;
            this.btnImportarBoleto.Text = "Capturar";
            this.btnImportarBoleto.UseVisualStyleBackColor = true;
            this.btnImportarBoleto.Visible = false;
            this.btnImportarBoleto.Click += new System.EventHandler(this.btnImportarBoleto_Click);
            // 
            // lbNomeServico
            // 
            this.lbNomeServico.AutoSize = true;
            this.lbNomeServico.Location = new System.Drawing.Point(23, 17);
            this.lbNomeServico.Name = "lbNomeServico";
            this.lbNomeServico.Size = new System.Drawing.Size(71, 13);
            this.lbNomeServico.TabIndex = 23;
            this.lbNomeServico.Text = "Identificação:";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(726, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 49;
            this.label3.Text = "Importar:";
            this.label3.Visible = false;
            // 
            // cbBoletador
            // 
            this.cbBoletador.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cbBoletador.DisplayMember = "NomeBoletador";
            this.cbBoletador.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBoletador.FormattingEnabled = true;
            this.cbBoletador.Location = new System.Drawing.Point(785, 8);
            this.cbBoletador.Name = "cbBoletador";
            this.cbBoletador.Size = new System.Drawing.Size(72, 21);
            this.cbBoletador.TabIndex = 48;
            this.cbBoletador.ValueMember = "IdBoletador";
            this.cbBoletador.Visible = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tabControlCheck);
            this.groupBox2.Controls.Add(this.label_ListMethod);
            this.groupBox2.Controls.Add(this.cmb_ListMethod);
            this.groupBox2.Controls.Add(this.btnSalvar);
            this.groupBox2.Controls.Add(this.panel2);
            this.groupBox2.Controls.Add(this.panel1);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(219, 309);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1025, 290);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Checklist";
            // 
            // tabControlCheck
            // 
            this.tabControlCheck.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlCheck.Location = new System.Drawing.Point(3, 60);
            this.tabControlCheck.Name = "tabControlCheck";
            this.tabControlCheck.SelectedIndex = 0;
            this.tabControlCheck.Size = new System.Drawing.Size(1019, 198);
            this.tabControlCheck.TabIndex = 8;
            // 
            // label_ListMethod
            // 
            this.label_ListMethod.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label_ListMethod.AutoSize = true;
            this.label_ListMethod.Location = new System.Drawing.Point(11, 266);
            this.label_ListMethod.Name = "label_ListMethod";
            this.label_ListMethod.Size = new System.Drawing.Size(51, 13);
            this.label_ListMethod.TabIndex = 17;
            this.label_ListMethod.Text = "Métodos:";
            this.label_ListMethod.Visible = false;
            // 
            // cmb_ListMethod
            // 
            this.cmb_ListMethod.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmb_ListMethod.DisplayMember = "MethodDescricao";
            this.cmb_ListMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_ListMethod.FormattingEnabled = true;
            this.cmb_ListMethod.Location = new System.Drawing.Point(65, 263);
            this.cmb_ListMethod.Name = "cmb_ListMethod";
            this.cmb_ListMethod.Size = new System.Drawing.Size(361, 21);
            this.cmb_ListMethod.TabIndex = 16;
            this.cmb_ListMethod.ValueMember = "MethodName";
            this.cmb_ListMethod.Visible = false;
            // 
            // btnSalvar
            // 
            this.btnSalvar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSalvar.Enabled = false;
            this.btnSalvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvar.Image = ((System.Drawing.Image)(resources.GetObject("btnSalvar.Image")));
            this.btnSalvar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalvar.Location = new System.Drawing.Point(858, 261);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(150, 23);
            this.btnSalvar.TabIndex = 2;
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.UseVisualStyleBackColor = true;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnRedirecionar);
            this.panel2.Controls.Add(this.btnRefresh);
            this.panel2.Controls.Add(this.lblFluxoAtual);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(3, 16);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1019, 44);
            this.panel2.TabIndex = 20;
            // 
            // btnRedirecionar
            // 
            this.btnRedirecionar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRedirecionar.Image = ((System.Drawing.Image)(resources.GetObject("btnRedirecionar.Image")));
            this.btnRedirecionar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRedirecionar.Location = new System.Drawing.Point(129, 12);
            this.btnRedirecionar.Name = "btnRedirecionar";
            this.btnRedirecionar.Size = new System.Drawing.Size(95, 23);
            this.btnRedirecionar.TabIndex = 30;
            this.btnRedirecionar.Text = "Redirecionar";
            this.btnRedirecionar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRedirecionar.UseVisualStyleBackColor = true;
            this.btnRedirecionar.Visible = false;
            // 
            // btnRefresh
            // 
            this.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefresh.Image = ((System.Drawing.Image)(resources.GetObject("btnRefresh.Image")));
            this.btnRefresh.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRefresh.Location = new System.Drawing.Point(19, 12);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(104, 23);
            this.btnRefresh.TabIndex = 18;
            this.btnRefresh.Text = "Atualizar";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // lblFluxoAtual
            // 
            this.lblFluxoAtual.AutoSize = true;
            this.lblFluxoAtual.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFluxoAtual.Location = new System.Drawing.Point(432, 6);
            this.lblFluxoAtual.Name = "lblFluxoAtual";
            this.lblFluxoAtual.Size = new System.Drawing.Size(129, 29);
            this.lblFluxoAtual.TabIndex = 15;
            this.lblFluxoAtual.Text = "Fluxo atual";
            this.lblFluxoAtual.Visible = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnPlayMethod);
            this.panel1.Controls.Add(this.cboStatus);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(3, 258);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1019, 29);
            this.panel1.TabIndex = 19;
            // 
            // btnPlayMethod
            // 
            this.btnPlayMethod.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnPlayMethod.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnPlayMethod.Image = ((System.Drawing.Image)(resources.GetObject("btnPlayMethod.Image")));
            this.btnPlayMethod.Location = new System.Drawing.Point(429, 3);
            this.btnPlayMethod.Name = "btnPlayMethod";
            this.btnPlayMethod.Size = new System.Drawing.Size(29, 23);
            this.btnPlayMethod.TabIndex = 59;
            this.btnPlayMethod.UseVisualStyleBackColor = false;
            this.btnPlayMethod.Visible = false;
            this.btnPlayMethod.Click += new System.EventHandler(this.btnPlayMethod_Click);
            // 
            // cboStatus
            // 
            this.cboStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cboStatus.DisplayMember = "StatusDescricao";
            this.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboStatus.Enabled = false;
            this.cboStatus.FormattingEnabled = true;
            this.cboStatus.Location = new System.Drawing.Point(677, 5);
            this.cboStatus.Name = "cboStatus";
            this.cboStatus.Size = new System.Drawing.Size(135, 21);
            this.cboStatus.TabIndex = 12;
            this.cboStatus.ValueMember = "ID_Status";
            this.cboStatus.SelectedIndexChanged += new System.EventHandler(this.cboStatus_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(620, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Status:";
            // 
            // gBoxWorkFlow
            // 
            this.gBoxWorkFlow.Dock = System.Windows.Forms.DockStyle.Left;
            this.gBoxWorkFlow.Location = new System.Drawing.Point(0, 0);
            this.gBoxWorkFlow.Name = "gBoxWorkFlow";
            this.gBoxWorkFlow.Size = new System.Drawing.Size(219, 736);
            this.gBoxWorkFlow.TabIndex = 6;
            this.gBoxWorkFlow.TabStop = false;
            this.gBoxWorkFlow.Text = "Workflow";
            // 
            // gBoxFollowUp
            // 
            this.gBoxFollowUp.Controls.Add(this.btnClose);
            this.gBoxFollowUp.Controls.Add(this.btnIncluirFollow);
            this.gBoxFollowUp.Controls.Add(this.lboxFollowUP);
            this.gBoxFollowUp.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.gBoxFollowUp.Location = new System.Drawing.Point(219, 599);
            this.gBoxFollowUp.Name = "gBoxFollowUp";
            this.gBoxFollowUp.Size = new System.Drawing.Size(1025, 137);
            this.gBoxFollowUp.TabIndex = 7;
            this.gBoxFollowUp.TabStop = false;
            this.gBoxFollowUp.Text = "Follow Up";
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.Location = new System.Drawing.Point(858, 92);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(150, 23);
            this.btnClose.TabIndex = 17;
            this.btnClose.Text = "Fechar";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnIncluirFollow
            // 
            this.btnIncluirFollow.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnIncluirFollow.Enabled = false;
            this.btnIncluirFollow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIncluirFollow.Image = ((System.Drawing.Image)(resources.GetObject("btnIncluirFollow.Image")));
            this.btnIncluirFollow.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnIncluirFollow.Location = new System.Drawing.Point(12, 92);
            this.btnIncluirFollow.Name = "btnIncluirFollow";
            this.btnIncluirFollow.Size = new System.Drawing.Size(60, 23);
            this.btnIncluirFollow.TabIndex = 16;
            this.btnIncluirFollow.Text = "Incluir";
            this.btnIncluirFollow.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnIncluirFollow.UseVisualStyleBackColor = true;
            this.btnIncluirFollow.Click += new System.EventHandler(this.btnIncluirFollow_Click);
            // 
            // lboxFollowUP
            // 
            this.lboxFollowUP.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lboxFollowUP.Enabled = false;
            this.lboxFollowUP.FormattingEnabled = true;
            this.lboxFollowUP.Location = new System.Drawing.Point(6, 17);
            this.lboxFollowUP.Name = "lboxFollowUP";
            this.lboxFollowUP.ScrollAlwaysVisible = true;
            this.lboxFollowUP.Size = new System.Drawing.Size(1002, 69);
            this.lboxFollowUP.TabIndex = 0;
            this.lboxFollowUP.DoubleClick += new System.EventHandler(this.lboxFollowUP_DoubleClick);
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.Filter = "Arquivo CSV | *.csv";
            // 
            // backgroundWorkerDetalhe
            // 
            this.backgroundWorkerDetalhe.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorkerDetalhe_DoWork);
            this.backgroundWorkerDetalhe.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorkerDetalhe_RunWorkerCompleted);
            // 
            // timerDetalhe
            // 
            this.timerDetalhe.Tick += new System.EventHandler(this.timerDetalhe_Tick);
            // 
            // Detalhe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1244, 736);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gBoxFollowUp);
            this.Controls.Add(this.gBoxWorkFlow);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimizeBox = false;
            this.Name = "Detalhe";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Detalhe da operação";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Detalhe_FormClosed);
            this.groupBox1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gBoxFollowUp.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.GroupBox gBoxWorkFlow;
        private System.Windows.Forms.TabControl tabControlServico;
        private System.Windows.Forms.TabControl tabControlCheck;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cboStatus;
        private System.Windows.Forms.Label lblFluxoAtual;
        private System.Windows.Forms.Button btnSalvarServico;
        private System.Windows.Forms.GroupBox gBoxFollowUp;
        private System.Windows.Forms.Button btnIncluirFollow;
        private System.Windows.Forms.ListBox lboxFollowUP;
        private System.Windows.Forms.CheckBox cbAtualizar;
        private System.Windows.Forms.Button btnConcluirServico;
        private System.Windows.Forms.Button btnResumo;
        private System.Windows.Forms.Label label_ListMethod;
        private System.Windows.Forms.ComboBox cmb_ListMethod;
        private System.Windows.Forms.Button btnCancelarServico;
        private System.Windows.Forms.TextBox txtIdentificacao;
        private System.Windows.Forms.Label lbNomeServico;
        private System.Windows.Forms.Button btnIndicador;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.Button btnRefresh;
        private System.ComponentModel.BackgroundWorker backgroundWorkerDetalhe;
        private System.Windows.Forms.Timer timerDetalhe;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbBoletador;
        private System.Windows.Forms.Button btnImportarBoleto;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnExcluir;
        private System.Windows.Forms.CheckBox chkPrioridade;
        private System.Windows.Forms.TextBox txtSegmento;
        private System.Windows.Forms.Label lblSegmento;
        private System.Windows.Forms.Button btnRedirecionar;
        private System.Windows.Forms.Button btnPlayMethod;
    }
}