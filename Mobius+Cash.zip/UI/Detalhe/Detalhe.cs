﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Reflection;
using System.Configuration;

namespace Mobios
{
    public partial class Detalhe : Form
    {
        #region [Variáveis]
        string msgLog;
        public ResponsavelServico _Responsavel;

        #region [dados follow-up]
        public List<FollowUp> _listaFollowUpServico = new List<FollowUp>();
        List<string> _FollowUpChaveList = new List<string>();
        #endregion

        #region [dados para montagem dos campos]
        public ClassListMethod _MyMethod = new ClassListMethod();
        public List<ClassListMethod> _Metodos = new List<ClassListMethod>();

        List<Status> _listStatus = new List<Status>();
        
        public List<Campos> _listaCamposServico = new List<Campos>();                  // Contem os campos para preenchimento da tela - Dados Servicos;
        public List<Campos> _listaCamposEtapas = new List<Campos>();                   // Contem os campos para preenchimento da tela - Dados do Fluxo [CheckList];                
        List<Campos> _listaCamposEtapasTotal = new List<Campos>();
        List<CamposTabela> _camposTabela = new List<CamposTabela>();
        List<Boletador> _listaBoletador = new List<Boletador>();

        public EtapasObjeto _Etapa = new EtapasObjeto();                        // Etapa Selecionada
        List<EtapasObjeto> _etapasObjeto = new List<EtapasObjeto>();            // Configurações das Etapas do objeto;
        public List<FluxoServico> _fluxoServico = new List<FluxoServico>();            // Status Atual das Etapas do Objeto nos Serviços;

        bool _MudarPrioridade;
        bool btnEtapaClick;
        bool SalvandoServiço;
        DateTime _UltimaAtualizacaoServico;
        string _ArquivoServico;
        #endregion

        #endregion

        private static Detalhe form = null;

        public Detalhe(ResponsavelServico sv)
        {
            _Responsavel = sv;
            InitializeComponent();
            if (sv == null)
            {
                return;
            }

            msgLog = "Formulário de DETALHE SERVICO aberto. Servico: " + _Responsavel.ID_Objeto + " / " + _Responsavel.ID_Servico + " / " + _Responsavel.ID_Responsavel + ".";
            Log.GravaLog(msgLog);

            groupBox1.Text = "[Servico: " + _Responsavel.ID_Servico + " - Fluxo: " + _Responsavel.NomeObjeto + (_Etapa.ID_Etapa == 0 ? "" : " Etapa - " + _Etapa.ID_Etapa + " (" + _Etapa.NomeEtapa + ")");
            txtIdentificacao.Text = _Responsavel.ServicoName;
            _MudarPrioridade = false;
            chkPrioridade.Checked = _Responsavel.Prioridade;
            _MudarPrioridade = true;
            txtSegmento.Text = _Responsavel.Segmento;

            this.Text = this.Text + " | " + SharedData.gVersao;

            #region [ Boletador ]
            
            bool exibeBoletador = SharedData.gBoletadorTela.Contains("DETALHE=TRUE");

            if (exibeBoletador)
            {
                _listaBoletador = DataAccess.buscarBoletador();
                //this.cbBoletador.DataSource = _listaBoletador;

                if (_listaBoletador.Count > 0)
                {
                    this.cbBoletador.DataSource = _listaBoletador;
                    this.label3.Visible = true;
                    this.cbBoletador.Visible = true;
                    this.btnImportarBoleto.Visible = true;
                }
            }
            #endregion

            #region [ Botões Gestor ]
            if (SharedData.User.FLG_Gestor)
            {
                btnExcluir.Visible = true;
                cbAtualizar.Visible = true;
                btnSalvarServico.Visible = true;
                btnConcluirServico.Visible = true;
            }
            #endregion

            #region [ Dados do Serviço ]
            if (SharedData.gCamposObjeto != null && SharedData.gCamposObjeto.Count > 0)
            {
                List<Campos> temp = SharedData.gCamposObjeto.Where(n => n.ID_Objeto == _Responsavel.ID_Objeto).ToList();
                if (temp != null && temp.Count > 0)
                {
                    foreach (Campos c in temp)
                    {
                        c.ID_Servico = _Responsavel.ID_Servico;
                        _listaCamposServico.Add(new Campos(c));
                    }
                }
            }

            if (_listaCamposServico == null || _listaCamposServico.Count == 0)
            {
                _listaCamposServico = DataAccess.buscarCamposDinamicosConjunto(_Responsavel.ID_Servico);      // Preenche a tela com campos do serviço;
            }
            else
            {
                _listaCamposServico = TelaDinamica.RecuperarServico(_listaCamposServico, _Responsavel.ID_Servico);
            }
            #endregion

            #region [ Dados da Etapa ]
            
            #region [ Campos ]
            if (SharedData.gCamposEtapa != null && SharedData.gCamposEtapa.Count > 0)
            {
                List<Campos> temp = SharedData.gCamposEtapa.Where(n => n.ID_Objeto == _Responsavel.ID_Objeto).ToList();
                if (temp != null && temp.Count > 0)
                {
                    foreach (Campos c in temp)
                    {
                        c.ID_Servico = _Responsavel.ID_Servico;
                        _listaCamposEtapasTotal.Add(new Campos(c));
                    }
                }
            }

            if (_listaCamposEtapasTotal == null || _listaCamposEtapasTotal.Count == 0)
            {
                _listaCamposEtapasTotal = DataAccess.buscarCamposEtapaConjunto(_Responsavel.ID_Servico);
            }
            else
            {
                _listaCamposEtapasTotal = TelaDinamica.RecuperarServico(_listaCamposEtapasTotal, _Responsavel.ID_Servico);
            }
            #endregion

            #region [ Métodos ]
            if (SharedData.gMetodos != null && SharedData.gMetodos.Count > 0)
            {
                List<ClassListMethod> temp = SharedData.gMetodos.Where(n => n.ID_Method == 0 || (n.ID_Objeto == _Responsavel.ID_Objeto && n.MethodForm.ToUpper() == "DETALHE")).ToList();
                if (temp != null && temp.Count > 0)
                {
                    foreach (ClassListMethod c in temp)
                    {
                        _Metodos.Add(new ClassListMethod(c));
                    }
                }
            }

            if (_Metodos == null || _Metodos.Count == 0)
            {
                _Metodos = DataAccess.GetListMethodDetalhe(_Responsavel.ID_Objeto);
            }
            #endregion

            #region [ Status ]
            if (SharedData.gStatusEtapa != null && SharedData.gStatusEtapa.Count > 0)
            {
                List<Status> temp = SharedData.gStatusEtapa.Where(n => n.ID_Objeto == _Responsavel.ID_Objeto).ToList();
                if (temp != null && temp.Count > 0)
                {
                    foreach (Status c in temp)
                    {
                        _listStatus.Add(new Status(c));
                    }
                }
            }

            if (_listStatus == null || _listStatus.Count == 0)
            {
                _listStatus = DataAccess.BuscarStatus(_Responsavel.ID_Objeto);
            }
            #endregion
            
            #endregion

            #region [ Campos Tabela ]
            if ((_listaCamposServico != null || _listaCamposEtapasTotal != null)  && (_listaCamposServico.Exists(n => n.CampoTipo.ToUpper() == "TABELA" || n.CampoTipo.ToUpper() == "TABELAGERAL") || _listaCamposEtapasTotal.Exists(n => n.CampoTipo.ToUpper() == "TABELA" || n.CampoTipo.ToUpper() == "TABELAGERAL")))
            {
                if (SharedData.gCamposTabela != null && SharedData.gCamposTabela.Count > 0)
                {
                    foreach (CamposTabela c in SharedData.gCamposTabela)
                    {
                        _camposTabela.Add(new CamposTabela(c));
                    }
                }

                if (_camposTabela == null || _camposTabela.Count == 0)
                {
                    if (_listaCamposServico.Exists(n => n.CampoTipo.ToUpper() == "TABELAGERAL") || _listaCamposEtapasTotal.Exists(n => n.CampoTipo.ToUpper() == "TABELAGERAL"))
                    {
                        _camposTabela = DataAccess.BuscarCamposTabela(_Responsavel.ID_Servico, true);
                    }
                    else
                    {
                        _camposTabela = DataAccess.BuscarCamposTabela(_Responsavel.ID_Servico, false);
                    }
                }
                else
                {
                    if (_listaCamposServico.Exists(n => n.CampoTipo.ToUpper() == "TABELAGERAL") || _listaCamposEtapasTotal.Exists(n => n.CampoTipo.ToUpper() == "TABELAGERAL"))
                    {
                        _camposTabela = TelaDinamica.RecuperarServico(_camposTabela, _Responsavel.ID_Servico, true);
                    }
                    else
                    {
                        _camposTabela = TelaDinamica.RecuperarServico(_camposTabela, _Responsavel.ID_Servico, false);
                    }
                }
            }
            #endregion
            
            #region [ Fluxo ]
            if (SharedData.gEtapasObjeto != null && SharedData.gEtapasObjeto.Count > 0)
            {
                List<EtapasObjeto> temp = SharedData.gEtapasObjeto.Where(n => n.ID_Objeto == _Responsavel.ID_Objeto).ToList();
                if (temp != null && temp.Count > 0)
                {
                    foreach (EtapasObjeto c in temp)
                    {
                        _etapasObjeto.Add(new EtapasObjeto(c));
                    }
                }
            }

            if (_etapasObjeto == null || _etapasObjeto.Count == 0)
            {
                _etapasObjeto = DataAccess.BuscarEtapasObjeto(_Responsavel.ID_Objeto);
            }

            MontarCamposServiço(false, _listaCamposServico);
            MontaTelaFluxo();
            #endregion

            form = this;

            string Path = SharedData.BDPath;
            Path = Path + "Historico\\";
            _ArquivoServico = Path + _Responsavel.ID_Servico + ".txt";

            #region [ Timer ]
            int TimerInterval = SharedData.gTimerIntervalDetalhe;
            if (TimerInterval > 0)
            {    
                if (File.Exists(_ArquivoServico))
                {
                    _UltimaAtualizacaoServico = File.GetLastWriteTime(_ArquivoServico);
                }

                this.timerDetalhe.Interval = TimerInterval;
                this.timerDetalhe.Enabled = true;
            }
            else
            {
                this.timerDetalhe.Enabled = false;
            }
            #endregion
        }

        private void btnResumo_Click(object sender, EventArgs e)
        {
            if (!SharedData.isOpenForm(typeof(Resumo), false))
            {
                using (Form frm = new Resumo(_Responsavel))
                {
                    //frm.MdiParent = this.MdiParent;
                    frm.WindowState = FormWindowState.Normal;
                    frm.StartPosition = FormStartPosition.CenterScreen;
                    frm.Left = 0;
                    frm.Top = 0;
                    frm.ShowDialog();
                }
            }
        }

        #region [ Montar Telas]
        private void MontarCamposServiço(bool camposAtivos = false, List<Campos> c = null, bool background = false)
        {

            //tabControlServico.TabPages.Clear();
            if (c == null || c.Count == 0)
            {
                if (!background)
                _listaCamposServico = TelaDinamica.RecuperarServico(_listaCamposServico, _Responsavel.ID_Servico);
                c = new List<Campos>();
                c = _listaCamposServico;

                if (_listaCamposServico.Exists(n => n.CampoTipo.ToUpper() == "TABELAGERAL" || n.CampoTipo.ToUpper() == "TABELA"))
                {
                    if (_listaCamposServico.Exists(n => n.CampoTipo.ToUpper() == "TABELAGERAL"))
                    {
                        if (!background)
                        _camposTabela = TelaDinamica.RecuperarServico(_camposTabela, _Responsavel.ID_Servico, true);
                    }
                    else
                    {
                        if (!background)
                        _camposTabela = TelaDinamica.RecuperarServico(_camposTabela, _Responsavel.ID_Servico, false);
                    }
                }
            }

            #region [ invoke se background ]
            if (InvokeRequired)
            {
                // Create a delegate of this method and let the form run it.
                this.Invoke(new execBackgroundCamposServico(MontarCamposServiço), new object[] { false, null, true });
                return; // Important
            }
            #endregion

            if (!background || (background && !cbAtualizar.Checked))
                TelaDinamica.MontarFormulario(c, this, tabControlServico, camposAtivos, _camposTabela);
        }
        private void MontarCamposEtapa(bool Habilitado, List<Campos> c = null, bool recapturarDados = false, bool background = false)
        {
            if (!background && !InvokeRequired)
                cboStatus.SelectedValue = _Etapa.ID_Status;

            #region [ recapturar ]
            if (recapturarDados)
            {
                if (_listaCamposEtapasTotal == null || _listaCamposEtapasTotal.Count == 0)
                {
                    if (!background)
                    _listaCamposEtapasTotal = DataAccess.buscarCamposEtapaConjunto(_Responsavel.ID_Servico);
                }
                else
                {
                    if (!background)
                    _listaCamposEtapasTotal = TelaDinamica.RecuperarServico(_listaCamposEtapasTotal, _Responsavel.ID_Servico);
                }
            }
            #endregion

            #region [ busca campos ]
            if (c == null || c.Count == 0)
            {
                #region [ busca valor campos ]
                _listaCamposEtapas = _listaCamposEtapasTotal.Where(n => n.ID_Etapa == _Etapa.ID_Etapa).ToList();

                if ((!SharedData.gValidarResponsavel || !btnEtapaClick) && !recapturarDados)
                {
                    btnEtapaClick = false;
                    if (!background)
                        _listaCamposEtapas = TelaDinamica.RecuperarServico(_listaCamposEtapas, _Responsavel.ID_Servico);
                }                
                c = new List<Campos>();
                c = _listaCamposEtapas;
                #endregion

                #region [ buscar campos tabelas ]
                if (_listaCamposEtapas.Exists(n => n.CampoTipo.ToUpper() == "TABELAGERAL" || n.CampoTipo.ToUpper() == "TABELA"))
                {
                    if (_listaCamposEtapas.Exists(n => n.CampoTipo.ToUpper() == "TABELAGERAL"))
                    {
                        if (!background)
                            _camposTabela = TelaDinamica.RecuperarServico(_camposTabela, _Responsavel.ID_Servico, true);
                    }
                    else
                    {
                        if (!background)
                            _camposTabela = TelaDinamica.RecuperarServico(_camposTabela, _Responsavel.ID_Servico, false);
                    }
                }
                #endregion
            }
            #endregion

            #region [ Recupera Follow-up]
            if (!background)
                _listaFollowUpServico = DataAccess.RecuperaFollowUpServico(_Etapa.ID_Servico);
            #endregion

            #region [ invoke se background ]
            if (InvokeRequired)
            {
                // Create a delegate of this method and let the form run it.
                this.Invoke(new execBackgroundCamposEtapa(MontarCamposEtapa), new object[] { cboStatus.Enabled, null, true, true});
                return; // Important
            }
            #endregion

            btnSalvar.Enabled = Habilitado;
            cmb_ListMethod.Enabled = Habilitado;
            btnIncluirFollow.Enabled = Habilitado;
            lboxFollowUP.Enabled = Habilitado;

            groupBox1.Text = "Detalhe:[Servico: " + _Etapa.ID_Servico + " - " + _Responsavel.NomeObjeto + " - Identificação: " + _Responsavel.ServicoName + "]" + " Etapa - " + _Etapa.ID_Etapa + " (" + _Etapa.NomeEtapa + ")";
            if (!background)
                TelaDinamica.MontarFormulario(c, this, tabControlCheck, Habilitado, _camposTabela);
            AtualizaFollowUp();

            #region [ Carrega Métodos ]
            List<ClassListMethod> metodosEtapa = _Metodos.FindAll(n => n.ID_Method == 0 || (n.ID_Etapa == _Etapa.ID_Etapa || n.ID_Etapa == 0));

            List<ClassListMethod> l = metodosEtapa.Where(n => n.CriterioCampo != "").ToList();
            if (l.Count > 0)
            {
                DataTable Resp = TratamentoCampo.ConvertObjectToDataTable(_Responsavel);
                List<ClassListMethod> removerMetodo = new List<ClassListMethod>();
                foreach (ClassListMethod m in l)
                {
                    string[] criterios = m.CriterioCampo.Split(';');
                    string[] valores = m.CriterioValor.Split(';');
                    for (int i = 0; i < criterios.Count(); i++)
                    {
                        int IdCampo = 0;
                        if (criterios[i].StartsWith("[") && criterios[i].EndsWith("]"))
                        {
                            criterios[i] = Resp.Rows[0][criterios[i].Substring(1, criterios[i].Length - 2)].ToString();
                            if (criterios[i].ToUpper() != valores[i].ToUpper())
                            {
                                removerMetodo.Add(m);
                                break;
                            }
                        }
                        else if (int.TryParse(criterios[i], out IdCampo))
                        {
                            if (!_listaCamposServico.Exists(n => n.ID_Campo == IdCampo && n.ValorCampo.ToUpper() == valores[i].ToUpper()))
                            {
                                removerMetodo.Add(m);
                                break;
                            }
                        }
                    }
                }

                if (removerMetodo.Count > 0)
                {
                    foreach (ClassListMethod m in removerMetodo)
                        metodosEtapa.Remove(m);
                }
            }
            #endregion

            cmb_ListMethod.DataSource = metodosEtapa;
            cmb_ListMethod.Visible = (cmb_ListMethod.Items.Count > 1);      // sempre é adicionado o campo vazio, por isso >1
            label_ListMethod.Visible = (cmb_ListMethod.Items.Count > 1);
            btnPlayMethod.Visible = (cmb_ListMethod.Items.Count > 1);
            if (cmb_ListMethod.Visible)
                cmb_ListMethod.SelectedValue = 0;
        }
        private void AlteraCamposServiço()
        {
            List<Campos> campos = new List<Campos>();
            foreach (Campos c in _listaCamposEtapas)
            {
                if (c.ValorCampo != "" || !cbAtualizar.Checked)
                {
                    List<Campos> temp = _listaCamposServico.Where(n => n.ID_Campo == c.ID_Campo).ToList();
                    if (temp.Count > 0)
                    {
                        temp[0].ValorCampo = c.ValorCampo;
                        temp[0].ValorCampoAntigo = c.ValorCampo;

                        campos.Add(temp[0]);
                    }
                }
            }
            if (campos.Count > 0)
            {
                TelaDinamica.MontarFormulario(campos, this, tabControlServico, cbAtualizar.Checked, _camposTabela);
            }
        }
        private void AlteraCamposEtapa()
        {
            List<Campos> campos = new List<Campos>();
            foreach (Campos c in _listaCamposServico)
            {
                if (c.ValorCampo != "")
                {
                    List<Campos> temp = _listaCamposEtapas.Where(n => n.ID_Campo == c.ID_Campo).ToList();
                    if (temp.Count > 0)
                    {
                        temp[0].ValorCampo = c.ValorCampo;
                        temp[0].ValorCampoAntigo = c.ValorCampo;

                        campos.Add(temp[0]);
                    }
                }
            }

            if (_listaCamposServico.Exists(n => n.CampoTipo.ToUpper() == "TABELAGERAL" || n.CampoTipo.ToUpper() == "TABELA"))
            {
                if (_listaCamposServico.Exists(n => n.CampoTipo.ToUpper() == "TABELAGERAL"))
                {
                    _camposTabela = TelaDinamica.RecuperarServico(_camposTabela, _Responsavel.ID_Servico, true);
                }
                else
                {
                    _camposTabela = TelaDinamica.RecuperarServico(_camposTabela, _Responsavel.ID_Servico, false);
                }
            }

            if (campos.Count > 0)
            {
                TelaDinamica.MontarFormulario(campos, this, tabControlCheck, btnRefresh.Enabled, _camposTabela);
            }

            #region [ Carrega Métodos ]
            List<ClassListMethod> metodosEtapa = _Metodos.FindAll(n => n.ID_Method == 0 || (n.ID_Etapa == _Etapa.ID_Etapa || n.ID_Etapa == 0));

            List<ClassListMethod> l = metodosEtapa.Where(n => n.CriterioCampo != "").ToList();
            if (l.Count > 0)
            {
                DataTable Resp = TratamentoCampo.ConvertObjectToDataTable(_Responsavel);
                List<ClassListMethod> removerMetodo = new List<ClassListMethod>();
                foreach (ClassListMethod m in l)
                {
                    string[] criterios = m.CriterioCampo.Split(';');
                    string[] valores = m.CriterioValor.Split(';');
                    for (int i = 0; i < criterios.Count(); i++)
                    {
                        int IdCampo = 0;
                        if (criterios[i].StartsWith("[") && criterios[i].EndsWith("]"))
                        {
                            criterios[i] = Resp.Rows[0][criterios[i].Substring(1, criterios[i].Length - 2)].ToString();
                            if (criterios[i].ToUpper() != valores[i].ToUpper())
                            {
                                removerMetodo.Add(m);
                                break;
                            }
                        }
                        else if (int.TryParse(criterios[i], out IdCampo))
                        {
                            if (!_listaCamposServico.Exists(n => n.ID_Campo == IdCampo && n.ValorCampo.ToUpper() == valores[i].ToUpper()))
                            {
                                removerMetodo.Add(m);
                                break;
                            }
                        }
                    }
                }

                if (removerMetodo.Count > 0)
                {
                    foreach (ClassListMethod m in removerMetodo)
                        metodosEtapa.Remove(m);
                }
            }

            cmb_ListMethod.DataSource = metodosEtapa;
            cmb_ListMethod.Visible = (cmb_ListMethod.Items.Count > 1);      // sempre é adicionado o campo vazio, por isso >1
            label_ListMethod.Visible = (cmb_ListMethod.Items.Count > 1);
            btnPlayMethod.Visible = (cmb_ListMethod.Items.Count > 1);
            if (cmb_ListMethod.Visible)
                cmb_ListMethod.SelectedValue = 0;
            #endregion
        }

        private void MontaTelaFluxo(bool background = false)
        {
            #region [ busca fluxo ]
            if (!background)
            {
                if (SharedData.gValidaDependenciaResponsavel)
                {
                    _fluxoServico = DataAccess.BuscarFluxoServicoValidaResponsavel(_Responsavel.ID_Servico, _Responsavel.ID_Responsavel);
                }
                else
                {
                    _fluxoServico = DataAccess.BuscarFluxoServico(_Responsavel.ID_Servico);
                }
            }
            #endregion

            #region [ Definir único responsável para todas as etapas ]
            int Id_responsavel_para_etapasSemFluxo = 0;
            string Nome_responsavel_para_etapasSemFluxo = "";
            if (SharedData.gAtribuiResponsavelServico)
            {
                List<FluxoServico> FluxoServicoTeste = new List<FluxoServico>();
                FluxoServicoTeste = _fluxoServico.FindAll(a => a.IdResponsavel != 0).GroupBy(s => s.IdResponsavel).Select(g => g.First()).ToList();

                if (FluxoServicoTeste.Count == 1)
                {
                    Id_responsavel_para_etapasSemFluxo = FluxoServicoTeste[0].IdResponsavel;
                    Nome_responsavel_para_etapasSemFluxo = FluxoServicoTeste[0].NomeResponsavel;
                }
                else
                {
                    msgLog = "Serviço ID: " + _Responsavel.ID_Servico + " tem mais de um responsável. Por isso o parametro gAtribuiResponsavelServico foi ignorado";
                    Log.GravaLog(msgLog);
                }
            }
            #endregion

            #region [ invoke se background ]
            if (InvokeRequired)
            {
                // Create a delegate of this method and let the form run it.
                this.Invoke(new execBackground(MontaTelaFluxo), new object[] { true });
                return; // Important
            }
            #endregion

            int tamanhoHeightBotao = 23;
            int posicaoColunaFolga = 8;
            int btnTop = 15;

            #region [ Cria Fluxos Novos ]
            List<EtapasObjeto> EtapasSemFluxo = new List<EtapasObjeto>();
            foreach (EtapasObjeto etapa in _etapasObjeto)
            {
                FluxoServico flx = _fluxoServico.Find(n => n.ID_Fluxo == etapa.ID_Etapa);
                if (flx == null)
                {
                    etapa.ID_Status = etapa.StatusInicial;
                    etapa.ID_Servico = _Responsavel.ID_Servico;

                    if (!SharedData.gAtribuiResponsavelServico && SharedData.gValidaMesmoResponsavel)
                    {
                        EtapasObjeto etp = _etapasObjeto.Find(n => n.IdMesmoResponsavel == etapa.IdMesmoResponsavel && n.IdResponsavel != 0);
                        if (etp != null)
                        {
                            Id_responsavel_para_etapasSemFluxo = etp.IdResponsavel;
                            Nome_responsavel_para_etapasSemFluxo = etp.NomeResponsavel;
                        }
                    }
                    etapa.IdResponsavel = Id_responsavel_para_etapasSemFluxo;
                    etapa.NomeResponsavel = Nome_responsavel_para_etapasSemFluxo;

                    EtapasSemFluxo.Add(etapa);
                }
            }

            if (EtapasSemFluxo.Count > 0)
            {
                DataAccess.RegistrarFluxoServicoLote(EtapasSemFluxo);
            }
            #endregion

            foreach (EtapasObjeto etapa in _etapasObjeto)
            {

                #region [Busca dados do fluxo]
                FluxoServico fluxo = _fluxoServico.Find(n => n.ID_Fluxo == etapa.ID_Etapa);

                if (fluxo != null)
                {
                    etapa.ID_Servico = _Responsavel.ID_Servico;
                    etapa.ID_Status = fluxo.ID_Status;
                    etapa.StatusPrimeiro = fluxo.StatusPrimeiro;
                    etapa.StatusFecha = fluxo.StatusFecha;
                    etapa.StatusParalisa = fluxo.StatusParalisa;
                    etapa.StatusCancela = fluxo.StatusCancela;
                    etapa.StatusNaoInicia = fluxo.StatusNaoInicia;
                    etapa.IdResponsavel = fluxo.IdResponsavel;
                    etapa.NomeResponsavel = fluxo.NomeResponsavel;
                    etapa.ValidaResponsavel = fluxo.ValidaResponsavel;
                }
                #endregion

                #region [Cria lista de botões de etapa]

                bool btnExists = gBoxWorkFlow.Controls.ContainsKey(etapa.NomeEtapa);

                // cria botão
                Button btnEtapa;
                if (!btnExists)
                {
                    btnEtapa = new Button();
                    btnEtapa.Name = etapa.NomeEtapa;
                    btnEtapa.Text = etapa.DescricaoEtapa;
                    btnEtapa.Visible = true;
                    //btnEtapa.FlatStyle = FlatStyle.Flat;

                    btnEtapa.Width = 150;
                    btnEtapa.Left = ((gBoxWorkFlow.Width - btnEtapa.Width) / 2);
                    btnEtapa.Top = btnTop;

                    btnEtapa.Click += new EventHandler(btnEtapa_Click);
                }
                else
                    btnEtapa = (Button)gBoxWorkFlow.Controls[etapa.NomeEtapa];

                btnEtapa.Tag = etapa.ID_Etapa.ToString();
                #endregion

                #region [Cores Etapas]
                try
                {
                    string[] corStatus = _listStatus.Find(element => element.ID_Status == etapa.ID_Status).CorStatus.ToString().Split(';');
                    btnEtapa.BackColor = (corStatus[0] != null) ? System.Drawing.Color.FromName(corStatus[0]) : System.Drawing.Color.FromName("White");
                    btnEtapa.ForeColor = (corStatus[1] != null) ? System.Drawing.Color.FromName(corStatus[1]) : System.Drawing.Color.FromName("Black");
                }
                catch
                {
                    btnEtapa.BackColor = System.Drawing.Color.FromName("White");
                    btnEtapa.ForeColor = System.Drawing.Color.FromName("Black");
                }

                #endregion

                #region [posiciona label do botão]
                if (!btnExists)
                {
                    Label lblIdFluxo = new Label();
                    lblIdFluxo.AutoSize = true;
                    lblIdFluxo.Visible = true;
                    lblIdFluxo.Top = btnEtapa.Top + 5;
                    lblIdFluxo.Text = etapa.OrdemEtapa.ToString().PadLeft(2, '0') + ".";
                    lblIdFluxo.Left = (btnEtapa.Left - lblIdFluxo.PreferredWidth - 5);
                    gBoxWorkFlow.Controls.Add(lblIdFluxo);
                }
                #endregion

                // Posição
                btnTop = btnTop + (tamanhoHeightBotao + posicaoColunaFolga);

                if (!btnExists)
                    gBoxWorkFlow.Controls.Add(btnEtapa);
            }
        }

        // Função clique genérica para o botão
        private void btnEtapa_Click(object sender, System.EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            Button b = sender as Button;

            int ID_Etapa = Convert.ToInt32(b.Tag);
            
            _Etapa.NomeEtapa = b.Name;
            _Etapa = new EtapasObjeto(_etapasObjeto.Find(n => n.ID_Etapa == ID_Etapa));

            if (lblFluxoAtual.Text != _Etapa.DescricaoEtapa)
            {
                btnEtapaClick = true;
                tabControlCheck.TabPages.Clear();

                #region [ Valida Acesso Etapa ]
                bool validadoAcesso = true;
                bool validadoPendente = true;
                bool validadoParalisado = false;
                bool validadoResponsavel = false;

                if (!SharedData.gValidarResponsavel || SharedData.User.FLG_Gestor)
                    validadoResponsavel = true;

                if (_Etapa.StatusNaoInicia == true)
                {
                    validadoPendente = false;
                }
                if (SharedData.UserAcessoCelulas.Exists(n => n == _Etapa.Id_Celula_Responsavel))
                {

                    #region [ Atribuir Responsavel ]
                    if (validadoPendente)
                    {
                        if (_Etapa.IdResponsavel == 0 && !SharedData.User.FLG_Gestor && _Etapa.ValidaResponsavel)
                        {
                            if (MessageBox.Show("Assumir atuação na etapa?", "MOBIOS+", MessageBoxButtons.YesNo) == DialogResult.Yes)
                            {
                                string[] ResponsavelFluxo = DataAccess.BuscaResponsavelFluxo(_Etapa.ID_Servico, _Etapa.ID_Etapa);
                                if (ResponsavelFluxo[0] == "")
                                {
                                    if (SharedData.gValidaMesmoResponsavel)
                                    {
                                        List<EtapasObjeto> etp = _etapasObjeto.FindAll(n => n.IdMesmoResponsavel == _Etapa.IdMesmoResponsavel && n.IdResponsavel != _Responsavel.ID_Responsavel);

                                        List<FluxoServico> fluxos = new List<FluxoServico>();

                                        if (etp.Count > 0)
                                        {
                                            foreach (EtapasObjeto et in etp)
                                            {
                                                FluxoServico fluxoLoop = new FluxoServico();
                                                fluxoLoop.ID_Servico = _Responsavel.ID_Servico;
                                                fluxoLoop.ID_Fluxo = et.ID_Etapa;
                                                fluxoLoop.IdResponsavel = _Responsavel.ID_Responsavel;
                                                fluxos.Add(fluxoLoop);
                                            }
                                        }
                                        if (fluxos.Count > 0)
                                        {
                                            DataAccess.AtribuirResponsavelFluxoLote(fluxos);
                                        }
                                        if (etp.Count > 0)
                                        {
                                            foreach (EtapasObjeto et in etp)
                                            {
                                                FluxoServico fluxoLoop = new FluxoServico();
                                                et.ID_Servico = _Responsavel.ID_Servico;
                                                et.IdResponsavel = _Responsavel.ID_Responsavel;
                                                et.NomeResponsavel = SharedData.User.NomeResponsavel;
                                            }
                                        }
                                        _Etapa.IdResponsavel = _Responsavel.ID_Responsavel;
                                        _Etapa.NomeResponsavel = SharedData.User.NomeResponsavel;
                                    }
                                    else
                                    {
                                        DataAccess.AtribuirResponsavelFluxo(_Etapa.ID_Servico, _Etapa.ID_Etapa, _Responsavel.ID_Responsavel);
                                        _Etapa.IdResponsavel = _etapasObjeto.Find(n => n.ID_Etapa == ID_Etapa).IdResponsavel = _Responsavel.ID_Responsavel;
                                        _Etapa.NomeResponsavel = _etapasObjeto.Find(n => n.ID_Etapa == ID_Etapa).NomeResponsavel = SharedData.User.NomeResponsavel;
                                    }
                                    validadoResponsavel = true;
                                }
                                else
                                {
                                    _Etapa.IdResponsavel = Convert.ToInt32(ResponsavelFluxo[0]);
                                    _Etapa.NomeResponsavel = ResponsavelFluxo[1];
                                    MontaTelaFluxo();
                                }
                            }
                            else
                            {
                                validadoAcesso = false;
                            }
                        }
                        else if (_Etapa.IdResponsavel == _Responsavel.ID_Responsavel)
                        {
                            validadoResponsavel = true;
                        }
                    }
                    #endregion

                    if (!_Etapa.StatusParalisa)
                    {
                        if (validadoResponsavel)
                        {
                            if (_Etapa.StatusPrimeiro)
                            {
                                #region [Indicador]
                                if (MessageBox.Show("Iniciar Etapa?", "MOBIOS+", MessageBoxButtons.YesNo) == DialogResult.Yes)
                                {
                                    //DataAccess.GravarIndicadorStatus(_Etapa.ID_Servico, _Etapa.ID_Etapa, _Etapa.ID_Status);

                                    Status StatusAlterar = new Status();
                                    StatusAlterar = _listStatus.Find(n => n.IdEtapa == _Etapa.ID_Etapa && n.ID_Status == _Etapa.ID_Status);
                                    if (StatusAlterar.IdEtapaAlterar != "" && StatusAlterar.IdStatusAlterar != "")
                                    {
                                        string[] StatusAlterados = StatusAlterar.IdStatusAlterar.Split(';');
                                        string[] EtapasAlteradas = StatusAlterar.IdEtapaAlterar.Split(';');

                                        List<FluxoServico> FluxosStatusAlterados = new List<FluxoServico>();
                                        for (int i = 0; i < EtapasAlteradas.Count(); i++)
                                        {
                                            StatusAlterar = new Status();
                                            StatusAlterar = _listStatus.Find(n => n.IdEtapa == Convert.ToInt32(EtapasAlteradas[i]) && n.ID_Status == Convert.ToInt32(StatusAlterados[i]));

                                            //if (!StatusAlterar.Primeiro)
                                            //{
                                            //DataAccess.GravarIndicadorStatus(_Responsavel.ID_Servico, StatusAlterar.IdEtapa, StatusAlterar.ID_Status);
                                            //}

                                            if (_Etapa.ID_Etapa == StatusAlterar.IdEtapa)
                                            {
                                                _Etapa.ID_Status = StatusAlterar.ID_Status;
                                                _Etapa.StatusPrimeiro = StatusAlterar.Primeiro;
                                                _Etapa.StatusFecha = StatusAlterar.Fecha;
                                                _Etapa.StatusParalisa = StatusAlterar.Paralisa;
                                                _Etapa.StatusCancela = StatusAlterar.Cancela;
                                                _Etapa.StatusNaoInicia = StatusAlterar.NaoInicia;
                                            }
                                            FluxoServico FluxoStatusAlterado = new FluxoServico();
                                            FluxoStatusAlterado.ID_Fluxo = StatusAlterar.IdEtapa;
                                            FluxoStatusAlterado.ID_Status = StatusAlterar.ID_Status;
                                            FluxoStatusAlterado.StatusFecha = StatusAlterar.Fecha;

                                            FluxosStatusAlterados.Add(FluxoStatusAlterado);
                                        }
                                        if (FluxosStatusAlterados.Count > 0)
                                        {
                                            //DataAccess.GravarIndicadorStatusLote(_Responsavel.ID_Servico, FluxosStatusAlterados);
                                            DataAccess.AtualizaStatusEtapaLote(_Responsavel.ID_Servico, FluxosStatusAlterados);
                                        }
                                        MontaTelaFluxo();
                                    }
                                }
                                else
                                {
                                    validadoAcesso = false;
                                }
                                #endregion
                            }
                        }
                    }
                    else
                    {
                        validadoPendente = false;
                        validadoParalisado = true;
                        validadoAcesso = false;
                    }

                }
                else
                {
                    validadoAcesso = false;
                }
                #endregion

                #region [Exibe campos]
                List<Status> sourceStatus = new List<Status>();
                sourceStatus = _listStatus.Where(n => n.IdEtapa == _Etapa.ID_Etapa).ToList();

                lblFluxoAtual.Text = _Etapa.DescricaoEtapa;
                lblFluxoAtual.Visible = true;


                if (validadoPendente || validadoParalisado)
                {
                    if (validadoAcesso && validadoResponsavel)
                    {
                        bool etapaConcluida = (_Etapa.StatusFecha || _Etapa.StatusCancela || _Etapa.StatusParalisa);

                        this.btnIncluirFollow.Enabled = true;
                        this.lboxFollowUP.Enabled = true;
                        this.cboStatus.Enabled = true;
                        this.btnSalvar.Enabled = true;
                        this.cmb_ListMethod.Enabled = true;
                        this.btnRefresh.Enabled = true;
                        cboStatus.DataSource = sourceStatus.Where(n => n.Primeiro == false && n.NaoInicia == false).ToList();

                        SharedData.Etapa = _Etapa;

                        MontarCamposEtapa(!etapaConcluida);
                    }
                    else
                    {
                        this.btnIncluirFollow.Enabled = false;
                        this.lboxFollowUP.Enabled = false;
                        this.cboStatus.Enabled = false;
                        this.btnSalvar.Enabled = false;
                        this.cmb_ListMethod.Enabled = false;
                        this.btnRefresh.Enabled = false;
                        cboStatus.DataSource = sourceStatus;

                        MontarCamposEtapa(false);
                        if (validadoParalisado)
                        {
                            if (_Etapa.StatusFecha)
                            {
                                MessageBox.Show("Etapa já concluída");
                            }
                            else
                            {
                                MessageBox.Show("Aguardando atuação");
                            }
                        }
                        else
                        {
                            if (validadoAcesso == true && validadoResponsavel == false)
                            {
                                if (_Etapa.NomeResponsavel == "")
                                {
                                    MessageBox.Show("Você já atuou em uma etapa dependente desta.\n\nCaso necessário, solicite o redirecionamento.");
                                }
                                else
                                {
                                    MessageBox.Show("A etapa já está atribuída a " + _Etapa.NomeResponsavel + ".\n\nCaso necessário, solicite o redirecionamento.");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Seu acesso a esta etapa permite apenas consulta");
                            }
                        }
                        _Etapa.ID_Etapa = 0;
                    }
                }
                else
                {
                    this.btnIncluirFollow.Enabled = false;
                    this.lboxFollowUP.Enabled = false;
                    this.cboStatus.Enabled = false;
                    this.btnSalvar.Enabled = false;
                    this.cmb_ListMethod.Enabled = false;
                    this.btnRefresh.Enabled = false;
                    cboStatus.DataSource = sourceStatus;

                    MontarCamposEtapa(false);
                    MessageBox.Show("Esta etapa não está disponível para atuação ainda");
                }
                #endregion
            }
            this.Cursor = Cursors.Default;
        }
        #endregion

        #region [ Salvar Dados ]
        private void cboStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(this.cboStatus.SelectedValue) != 0)
            {
                Status tempStatus = new Status();
                tempStatus = _listStatus.Find(n => n.ID_Status == Convert.ToInt32(this.cboStatus.SelectedValue));

                _Etapa.StatusFecha = tempStatus.Fecha;
                _Etapa.StatusParalisa = tempStatus.Paralisa;
                _Etapa.StatusPrimeiro = tempStatus.Primeiro;
                _Etapa.StatusCancela = tempStatus.Cancela;
                _Etapa.StatusNaoInicia = tempStatus.NaoInicia;

                if (Convert.ToInt32(this.cboStatus.SelectedValue) != _Etapa.ID_Status)
                {
                    btnSalvar.Enabled = true;
                }
                else if (_Etapa.StatusFecha)
                {
                    btnSalvar.Enabled = false;
                }
            }
            else
            {
                _Etapa.StatusFecha = false;
                _Etapa.StatusParalisa = false;
                _Etapa.StatusPrimeiro = false;
                _Etapa.StatusCancela = false;
                _Etapa.StatusNaoInicia = false;
            }
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            #region [ Não selecionar o StatusPrimeiro ]
            if (_Etapa.StatusPrimeiro || _Etapa.StatusNaoInicia)
            {
                MessageBox.Show("Selecione o status atual da etapa");
                return;
            }
            #endregion

            #region [ Valida responsável fluxo ]
            if (SharedData.gValidarResponsavel == true && !SharedData.User.FLG_Gestor)
            {
                string[] ResponsavelFluxo = DataAccess.BuscaResponsavelFluxo(_Etapa.ID_Servico, _Etapa.ID_Etapa);
                _Etapa.IdResponsavel = Convert.ToInt32(ResponsavelFluxo[0]);
                _Etapa.NomeResponsavel = ResponsavelFluxo[1];
                if (_Etapa.IdResponsavel != _Responsavel.ID_Responsavel)
                {
                    MessageBox.Show("A etapa está atribuída para " + _Etapa.NomeResponsavel + ".\n\nCaso necessário, solicite o redirecionamento.");
                    return;
                }
            }
            #endregion

            int etapasOk = 0;
            msgLog = "Conferindo conclusão do Serviço. Servico: " + _Etapa.ID_Objeto + " / " + _Etapa.ID_Servico + ".";
            Log.GravaLog(msgLog);

            #region [ Verifica etapas concluídas ]
            int IdEtapaConcluindo = 0;
            foreach (EtapasObjeto c in _etapasObjeto)
            {
                //if (c.GetType().Name == "Button")
                //{
                    //se status não fecha, então não pode concluir serviço
                    if (Convert.ToBoolean(c.StatusFecha) == false)
                    {
                        etapasOk++;
                        IdEtapaConcluindo = c.ID_Etapa;
                    }
                //}
            }
            #endregion

            #region [ Valida obrigatoriedade de concluir serviço ]
            bool concluirServico = false;
            if (etapasOk == 1 && _Etapa.StatusFecha && IdEtapaConcluindo == _Etapa.ID_Etapa)
            {
                if (MessageBox.Show("Esta é a última etapa do serviço.\n\nConfirma conclusão do serviço?", "Mobios", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    concluirServico = true;
                }
                else
                {
                    return;
                }
            }
            #endregion

            #region [ Valida dados cadastrados ]
            var tupla = TelaDinamica.ValidarCamposObrigatorios(_listaCamposEtapas, tabControlCheck, _Etapa.StatusFecha, _camposTabela);
            var tupla2 = TelaDinamica.ValidarTIPOSCampos(_listaCamposEtapas, tabControlCheck, _camposTabela);
            #endregion

            #region [ Salvar ]
            if ((tupla.Item1 || !_Etapa.StatusFecha || _Etapa.StatusCancela) && tupla2.Item1)
            {
                if (_Etapa.ID_Etapa > 0)
                {
                    msgLog = "Salvando dados da etapa. Servico: " + _Etapa.ID_Objeto + " / " + _Etapa.ID_Servico + " / " + _Etapa.ID_Etapa + ".";
                    Log.GravaLog(msgLog);

                    int IdStatusEtapaCasoErro = _Etapa.ID_Status;
                    try
                    {
                        #region [ Salva Campos ]
                        msgLog = "Salvando campos";
                        Log.GravaLog(msgLog);
                        DataAccess.AtualizarDadosCamposGenerico(_listaCamposEtapas, tabControlCheck, _Etapa.ID_Servico, "", _camposTabela);
                        #endregion
                        
                        Status StatusAlterar = new Status();
                        StatusAlterar = _listStatus.Find(n => n.IdEtapa == _Etapa.ID_Etapa && n.ID_Status == Convert.ToInt32(cboStatus.SelectedValue));

                        #region [ trata erro de cadastro ]
                        if (StatusAlterar == null)
                        {
                            throw new Exception("Status não cadastrado na base.\n\nContate a equipe de automação de processos.\n\nDetalhe: Status '" + cboStatus.Text + "' (Id " + cboStatus.SelectedValue.ToString() + ") não cadastrado para etapa '" + _Etapa.DescricaoEtapa + " (Id " + _Etapa.ID_Etapa + ")");
                        }
                        #endregion

                        #region [ Escrever FollowUp Status ]
                        msgLog = "Escreve Follow-Up";
                        Log.GravaLog(msgLog);
                        List<FollowUp> InsertListFollow = new List<FollowUp>();
                        FollowUp InsertFollow = new FollowUp();
                        InsertFollow.FollowUpEtapa = "";
                        if (StatusAlterar.FollowUp)
                        {
                            bool registrarFUP = false;
                            if (StatusAlterar.FollowUpObrigatorio)
                            {
                                registrarFUP = true;
                            }
                            else
                            {
                                registrarFUP = (MessageBox.Show("Registrar Follow-Up?", "Mobios", MessageBoxButtons.YesNo) == DialogResult.Yes);
                            }

                            if (registrarFUP)
                            {
                                InsertFollow.ID_Servico = _Etapa.ID_Servico;
                                InsertFollow.ID_Fluxo = _Etapa.ID_Etapa;
                                InsertFollow.FollowUpEtapa = "";
                                for (; ; )
                                {
                                    if (!SharedData.isOpenForm(typeof(FollowUpEtapa), false))
                                    {
                                        FollowUpEtapa frm = new FollowUpEtapa(InsertFollow, false);
                                        frm.WindowState = FormWindowState.Normal;
                                        frm.StartPosition = FormStartPosition.CenterScreen;
                                        frm.Left = 0;
                                        frm.Top = 0;
                                        frm.ShowDialog();
                                        InsertFollow.FollowUpEtapa = frm._Follow.FollowUpEtapa.Trim();
                                    }

                                    if (InsertFollow.FollowUpEtapa != "")
                                    {
                                        InsertListFollow.Add(InsertFollow);
                                        break;
                                    }
                                    else
                                    {
                                        if (StatusAlterar.FollowUpObrigatorio)
                                        {
                                            if (MessageBox.Show("O follow-up é obrigatório para realizar esta ação.\n\nSelecione para continuar ou cancelar a ação.", "Follow-Up Obrigatório", MessageBoxButtons.RetryCancel) == DialogResult.Cancel)
                                            {
                                                #region [ Recriar a tela ]
                                                msgLog = "Recria tela";
                                                Log.GravaLog(msgLog);

                                                MontaTelaFluxo();
                                                cboStatus.Enabled = true;
                                                
                                                MontarCamposEtapa(true);
                                                AlteraCamposServiço();
                                                #endregion
                                                return;
                                            }
                                        }
                                        else
                                        {
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        #endregion

                        #region [ Método Status ]
                        if (StatusAlterar.CustomMethod)
                        {
                            msgLog = "Executa métodos";
                            Log.GravaLog(msgLog);
                            List<int> IdMethod = StatusAlterar.IdMethod.Split(';').Select(Int32.Parse).ToList();
                            List<ClassListMethod> Method = DataAccess.GetListMethod(IdMethod);

                            #region [ Filtra métodos ]
                            List<ClassListMethod> l = Method.Where(n => n.CriterioCampo != "").ToList();
                            if (l.Count > 0)
                            {
                                DataTable Resp = TratamentoCampo.ConvertObjectToDataTable(_Responsavel);
                                List<ClassListMethod> removerMetodo = new List<ClassListMethod>();
                                foreach (ClassListMethod m in l)
                                {
                                    string[] criterios = m.CriterioCampo.Split(';');
                                    string[] valores = m.CriterioValor.Split(';');
                                    for (int i = 0; i < criterios.Count(); i++)
                                    {
                                        int IdCampo = 0;
                                        if (criterios[i].StartsWith("[") && criterios[i].EndsWith("]"))
                                        {
                                            criterios[i] = Resp.Rows[0][criterios[i].Substring(1, criterios[i].Length - 2)].ToString();
                                            if (criterios[i].ToUpper() != valores[i].ToUpper())
                                            {
                                                removerMetodo.Add(m);
                                                break;
                                            }
                                        }
                                        else if (int.TryParse(criterios[i], out IdCampo))
                                        {
                                            if (!_listaCamposServico.Exists(n => n.ID_Campo == IdCampo && n.ValorCampo.ToUpper() == valores[i].ToUpper()))
                                            {
                                                removerMetodo.Add(m);
                                                break;
                                            }
                                        }
                                    }
                                }

                                if (removerMetodo.Count > 0)
                                {
                                    foreach (ClassListMethod m in removerMetodo)
                                        Method.Remove(m);
                                }
                            }
                            #endregion

                            #region [ executa método ]
                            int indexmethod = 0;
                            try
                            {
                                foreach (ClassListMethod met in Method)
                                {
                                    _MyMethod = new ClassListMethod();
                                    _MyMethod = (ClassListMethod)(met);
                                    CustomMethod.ChamarMetodo(met.MethodName, CustomMethod.MethodForm.Detalhe);

                                    #region [ Follow-up ]
                                    if (_MyMethod.MethodFUP == true)
                                    {
                                        FollowUp FollowUpMetodo = new FollowUp();
                                        FollowUpMetodo.ID_Servico = _Responsavel.ID_Servico;
                                        FollowUpMetodo.ID_Fluxo = _Etapa.ID_Etapa;
                                        FollowUpMetodo.FollowUpEtapa = _MyMethod.MethodDescricao;

                                        msgLog = "Gravando Follow-Up Método: " + FollowUpMetodo.FollowUpEtapa;
                                        DataAccess.RegistrarFollowUpEtapaServico(FollowUpMetodo, false);
                                    }
                                    #endregion
                                    indexmethod++;
                                }
                            }
                            catch (Exception errMethod)
                            {
                                throw new Exception("Falha ao executar método '" + Method[indexmethod].MethodDescricao + "'.\n\nDetalhe: " + errMethod.Message);
                            }
                            #endregion
                        }
                        #endregion

                        #region [ Salva Status ]
                        if (_Etapa.ID_Status != Convert.ToInt32(cboStatus.SelectedValue))
                        {
                            msgLog = "Salvando status";
                            Log.GravaLog(msgLog);

                            _Etapa.ID_Status = Convert.ToInt32(cboStatus.SelectedValue);

                            List<FluxoServico> FluxosStatusAlterados = new List<FluxoServico>();

                            FluxoServico FluxoStatusAlterado = new FluxoServico();
                            FluxoStatusAlterado.ID_Fluxo = _Etapa.ID_Etapa;
                            FluxoStatusAlterado.ID_Status = _Etapa.ID_Status;
                            FluxoStatusAlterado.StatusFecha = _Etapa.StatusFecha;
                            FluxosStatusAlterados.Add(FluxoStatusAlterado);

                            #region [ Altera Etapas Dependentes ]
                            if (StatusAlterar.IdEtapaAlterar != "" && StatusAlterar.IdStatusAlterar != "")
                            {
                                msgLog = "Busca etapas dependentes";
                                Log.GravaLog(msgLog);
                                string[] StatusAlterados = StatusAlterar.IdStatusAlterar.Split(';');
                                string[] EtapasAlteradas = StatusAlterar.IdEtapaAlterar.Split(';');

                                for (int i = 0; i < EtapasAlteradas.Count(); i++)
                                {
                                    if (_Etapa.ID_Etapa != Convert.ToInt32(EtapasAlteradas[i])) // não pode alterar própria etapa
                                    {
                                        Status StatusAlterarEtapas = new Status();
                                        StatusAlterarEtapas = _listStatus.Find(n => n.IdEtapa == Convert.ToInt32(EtapasAlteradas[i]) && n.ID_Status == Convert.ToInt32(StatusAlterados[i]));

                                        #region [ trata erro de cadastro ]
                                        if (StatusAlterarEtapas == null)
                                        {
                                            throw new Exception("Não foi possível alterar os status das etapas.\n\nContate a equipe de automação de processos.\n\nOs status das etapas a alterar não possuem o parâmetro informado.\n\nDetalhe: Status (Id " + StatusAlterados[i].ToString() + ") não cadastrado para etapa (Id " + EtapasAlteradas[i].ToString() + ")");
                                        }
                                        #endregion

                                        if (StatusAlterar.FollowUp && StatusAlterarEtapas.FollowUp)
                                        {
                                            #region [ Junta FollowUp para as Etapas alteradas ]
                                            if (InsertFollow.FollowUpEtapa != "")
                                            {
                                                FollowUp f = new FollowUp();
                                                f.ID_Servico = _Responsavel.ID_Servico;
                                                f.ID_Fluxo = StatusAlterarEtapas.IdEtapa;
                                                f.FollowUpEtapa = InsertFollow.FollowUpEtapa;
                                                InsertListFollow.Add(f);
                                            }
                                            #endregion
                                        }

                                        #region [ Adiciona etapas alteradas à lista de atualização ]
                                        FluxoStatusAlterado = new FluxoServico();
                                        FluxoStatusAlterado.ID_Fluxo = StatusAlterarEtapas.IdEtapa;
                                        FluxoStatusAlterado.ID_Status = StatusAlterarEtapas.ID_Status;
                                        FluxoStatusAlterado.StatusFecha = StatusAlterarEtapas.Fecha;
                                        
                                        FluxosStatusAlterados.Add(FluxoStatusAlterado);
                                        #endregion
                                    }
                                }
                            }
                            #endregion

                            #region [ Salva FollowUps ]
                            if (StatusAlterar.FollowUp)
                            {
                                if (InsertListFollow.Count > 0)
                                {
                                    msgLog = "Salva Follow-Up";
                                    Log.GravaLog(msgLog);
                                    DataAccess.InserirListaFollowUp(InsertListFollow);
                                }
                            }
                            #endregion

                            #region [ Salva Status ]
                            if (FluxosStatusAlterados.Count > 0)
                            {
                                msgLog = "Salva Status";
                                Log.GravaLog(msgLog);
                                DataAccess.AtualizaStatusEtapaLote(_Responsavel.ID_Servico, FluxosStatusAlterados);
                            }
                            #endregion
                        }
                        #endregion

                        IdStatusEtapaCasoErro = _Etapa.ID_Status;

                        #region [ Recriar a tela ]
                        msgLog = "Recria tela";
                        Log.GravaLog(msgLog);
                        
                        MontaTelaFluxo();

                        if (_Etapa.StatusParalisa)
                        {
                            cboStatus.Enabled = false;
                        }

                        MontarCamposEtapa(!(_Etapa.StatusFecha || _Etapa.StatusCancela || _Etapa.StatusParalisa), null, true);
                        AlteraCamposServiço();
                        #endregion

                        if (File.Exists(_ArquivoServico))
                        {
                            _UltimaAtualizacaoServico = File.GetLastWriteTime(_ArquivoServico);
                        }

                        MessageBox.Show("Dados da etapa salvos com sucesso.");
                    }
                    catch (Exception exp)
                    {
                        #region [ Trata erro, evita finalizar serviço e volta o status anterior da etapa ]
                        Log.GravaLog(exp.Message);
                        MessageBox.Show("Erro ao salvar dados da etapa.\n\nErro: " + exp.Message);
                        concluirServico = false;
                        _Etapa.ID_Status = IdStatusEtapaCasoErro;
                        #endregion
                    }
                }
                else
                {
                    MessageBox.Show("Selecione uma ETAPA do fluxo para ser salva.");
                }
            }
            else
            {
                #region [ Mensagem dados inválidos ]
                if ((tupla.Item1 || !_Etapa.StatusFecha || _Etapa.StatusCancela) && !tupla2.Item1)
                {
                    MessageBox.Show(tupla2.Item2);
                }
                else if (tupla.Item1 == false)
                {
                    MessageBox.Show(tupla.Item2);
                }
                return;
                #endregion
            }
            #endregion

            #region [ Concluir Serviço ]
            if (concluirServico)
            {
                DataAccess.ConcluirServico(_Responsavel.ID_Servico);

                if (File.Exists(_ArquivoServico))
                {
                    _UltimaAtualizacaoServico = File.GetLastWriteTime(_ArquivoServico);
                }

                MessageBox.Show("Serviço concluído com sucesso.");
                cbAtualizar.Checked = false;
                cbAtualizar.Visible = false;
                this.btnIncluirFollow.Enabled = false;
                this.lboxFollowUP.Enabled = false;
                this.btnSalvar.Enabled = false;
                this.cmb_ListMethod.Enabled = false;
            }
            #endregion

            this.Cursor = Cursors.Default;

        }

        private void btnSalvarServico_Click(object sender, EventArgs e)
        {
            btnSalvarServico.Enabled = false;
            this.btnConcluirServico.Enabled = false;
            this.Cursor = Cursors.WaitCursor;

            try
            {
                msgLog = "Salvando dados do servico: " + _Etapa.ID_Objeto + " / " + _Etapa.ID_Servico + " / " + _Etapa.ID_Etapa + ".";
                Log.GravaLog(msgLog);

                var tupla = TelaDinamica.ValidarCamposObrigatorios(_listaCamposServico, tabControlServico, false, _camposTabela);
                var tupla2 = TelaDinamica.ValidarTIPOSCampos(_listaCamposServico, tabControlServico, _camposTabela);
                if (tupla.Item1 && tupla2.Item1)
                {
                    DataAccess.AtualizarDadosCamposGenerico(_listaCamposServico, tabControlServico, _Responsavel.ID_Servico, "", _camposTabela);

                    if (_Etapa.ID_Etapa != 0)
                    {
                        AlteraCamposEtapa();
                    }
                    
                    if (File.Exists(_ArquivoServico))
                    {
                        _UltimaAtualizacaoServico = File.GetLastWriteTime(_ArquivoServico);
                    }

                    MessageBox.Show("Registro salvo com sucesso!");
                    SalvandoServiço = true;
                    this.cbAtualizar.Checked = false;
                }
                else
                {
                    if (tupla.Item1 == false)
                    {
                        MessageBox.Show(tupla.Item2);
                    }
                    else if (tupla2.Item1 == false)
                    {
                        MessageBox.Show(tupla2.Item2);
                    }
                    btnSalvarServico.Enabled = true;
                    this.btnConcluirServico.Enabled = true;
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show("Erro ao salvar registro. Erro: " + exp.Message);
            }
            this.Cursor = Cursors.Default;

        }

        private void btnConcluirServico_Click(object sender, EventArgs e)
        {
            bool etapasOk = true;
            msgLog = "Conferindo conclusão do Serviço. Servico: " + _Responsavel.ID_Servico + ".";
            Log.GravaLog(msgLog);

            #region [ Verifica etapas concluídas ]
            foreach (EtapasObjeto c in _etapasObjeto)
            {
                if (c.GetType().Name == "Button")
                {
                    //se status não fecha, então não pode concluir serviço
                    if (Convert.ToBoolean(c.StatusFecha) == false)
                    {
                        etapasOk = false;
                    }
                }
            }
            #endregion

            bool concluirServico = false;
            if (etapasOk == true)
            {
                if (MessageBox.Show("Confirma conclusão do serviço?", "Mobios", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    concluirServico = true;
                }
            }
            else
            {
                if (MessageBox.Show("O serviço ainda tem etapas em aberto.\n\nProsseguir com conclusão?", "Mobios", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    concluirServico = true;
                }
            }

            if (concluirServico)
            {
                msgLog = "Concluindo Serviço. Servico: " + _Responsavel.ID_Responsavel + ".";
                Log.GravaLog(msgLog);
                DataAccess.ConcluirServico(_Responsavel.ID_Servico);

                if (File.Exists(_ArquivoServico))
                {
                    _UltimaAtualizacaoServico = File.GetLastWriteTime(_ArquivoServico);
                }

                MessageBox.Show("Serviço concluído com sucesso.");
                cbAtualizar.Checked = false;
                cbAtualizar.Visible = false;
            }
            else
            {
                //MessageBox.Show("Operação cancelada!", "Mobios");
            }
        }

        private void btnCancelarServico_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Confirma cancelamento do serviço?", "Mobios", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                DataAccess.CancelarServico(_Responsavel.ID_Servico);

                if (File.Exists(_ArquivoServico))
                {
                    _UltimaAtualizacaoServico = File.GetLastWriteTime(_ArquivoServico);
                }

                MessageBox.Show("Serviço cancelado.");
                cbAtualizar.Checked = false;
                cbAtualizar.Visible = false;
                this.Close();
            }
            else
            {
                //MessageBox.Show("Operação cancelada!", "Mobios");
            }
        }

        private void cbAtualizar_CheckedChanged(object sender, EventArgs e)
        {
            btnSalvarServico.Enabled = cbAtualizar.Checked;
            this.btnConcluirServico.Enabled = cbAtualizar.Checked;

            if (!SalvandoServiço)
            {
                MontarCamposServiço(cbAtualizar.Checked, _listaCamposServico);
            }
            else
            {
                SalvandoServiço = false;
                MontarCamposServiço(cbAtualizar.Checked);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("ATENÇÃO: Confirma exclusão do serviço?", "Mobios", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                msgLog = "Excluindo dados da etapa. Servico: " + _Etapa.ID_Objeto + " / " + _Etapa.ID_Servico + ".";
                Log.GravaLog(msgLog);
                try
                {
                    DataAccess.ExcluirServico(_Responsavel.ID_Servico);

                    this.Close();
                    
                    if (File.Exists(_ArquivoServico))
                    {
                        _UltimaAtualizacaoServico = File.GetLastWriteTime(_ArquivoServico);
                    }
                    MessageBox.Show("Serviço excluído com sucesso!");
                }
                catch (Exception exp)
                {
                    MessageBox.Show("Erro ao tentar deletar registro. Erro: " + exp.Message);
                }
            }

        }
        #endregion

        #region [ Follow-up ]
        public void AtualizaFollowUp()
        {
            // Refresh no objeto          
            lboxFollowUP.Items.Clear();
            List<FollowUp> listaFollowUpEtapaServico = new List<FollowUp>();
            listaFollowUpEtapaServico = _listaFollowUpServico.FindAll(n => n.ID_Fluxo == _Etapa.ID_Etapa);
            _FollowUpChaveList.Clear();

            foreach (FollowUp Follow in listaFollowUpEtapaServico)
            {
                string msgFollow = "[" + Follow.DataCriacao.ToString("dd/MM/yyyy HH:mm") + "] " + Follow.Nome.ToUpper() + " | " + Follow.FollowUpEtapa;
                _FollowUpChaveList.Add(Follow.ID_Follow.ToString());
                this.lboxFollowUP.Items.Add(msgFollow);
            }

        }

        private void btnIncluirFollow_Click(object sender, EventArgs e)
        {
            if (_Etapa.ID_Etapa > 0)
            {
                FollowUp InsertFollow = new FollowUp();
                InsertFollow.ID_Servico = _Etapa.ID_Servico;
                InsertFollow.ID_Fluxo = _Etapa.ID_Etapa;
                InsertFollow.FollowUpEtapa = "";

                if (!SharedData.isOpenForm(typeof(FollowUpEtapa), false))
                {
                    Form frm = new FollowUpEtapa(InsertFollow);
                    frm.WindowState = FormWindowState.Normal;
                    frm.StartPosition = FormStartPosition.CenterScreen;
                    frm.Left = 0;
                    frm.Top = 0;
                    frm.Show();
                }
            }
            else
            {
                MessageBox.Show("Selecione uma ETAPA do fluxo para incluir o Follow Up.");
            }
        }

        private void lboxFollowUP_DoubleClick(object sender, EventArgs e)
        {

            if (lboxFollowUP.GetItemText(lboxFollowUP.SelectedItem).ToString() != "")
            {
                FollowUp ReturnFollow = new FollowUp();
                string token = _FollowUpChaveList[lboxFollowUP.SelectedIndex];
                ReturnFollow.ID_Follow = Convert.ToInt32(token);

                if (!SharedData.isOpenForm(typeof(FollowUpEtapa), false))
                {
                    Form frm = new FollowUpEtapa(ReturnFollow);
                    //frm.MdiParent = this.MdiParent;
                    frm.WindowState = FormWindowState.Normal;
                    frm.StartPosition = FormStartPosition.CenterScreen;
                    frm.Left = 0;
                    frm.Top = 0;
                    frm.ShowDialog();
                }
            }
        }
        #endregion

        #region[ Importação automática ]
        private void btnImportarBoleto_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(cbBoletador.SelectedValue) != 0)
            {
                try
                {
                    Boletador bol = (Boletador)(cbBoletador.SelectedItem);
                    if (bol.NomeMetodo != "")
                    {
                        CustomMethod.ChamarMetodo(bol.NomeMetodo, CustomMethod.MethodForm.Detalhe);
                    }
                    MontarCamposServiço();
                }
                catch (Exception Excep)
                {
                    msgLog = "Erro ao chamar serviço de importação. Erro: " + Excep.Message;
                    Log.GravaLog(msgLog);
                    MessageBox.Show(msgLog);
                }                
            }
            else
            {
                MessageBox.Show("Escolha a forma de importação.", "Mobios", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
        #endregion

        #region [ Indicador ]
        private void btnIndicador_Click(object sender, EventArgs e)
        {
            DataTable dt = DataAccess.GetIndicadoresEtapas(_Responsavel.ID_Servico);
            TratarEventos.ExportaDataTable(dt, "", "", true);
        }
        #endregion

        #region [ Atualizar Tela Automático ]

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            #region [ Confirma Refresh ]

            {
                if (MessageBox.Show("Valores não salvos serão perdidos.\n\nConfirma atualização da tela?", "Atualizar", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.No)
                {
                    return;
                }
            }
            #endregion

            MontarCamposServiço();
            MontaTelaFluxo();

            #region [ Dados da Etapa ]
            if (_Etapa.ID_Etapa != 0)
            {
                FluxoServico fluxoServ = new FluxoServico();
                fluxoServ = DataAccess.BuscarStatusFluxoServico(_Responsavel.ID_Servico, _Etapa.ID_Etapa);
                _Etapa.ID_Status = fluxoServ.ID_Status;
                _Etapa.StatusFecha = fluxoServ.StatusFecha;
                _Etapa.StatusParalisa = fluxoServ.StatusParalisa;
                _Etapa.StatusCancela = fluxoServ.StatusCancela;
                _Etapa.StatusPrimeiro = fluxoServ.StatusPrimeiro;
                _Etapa.StatusNaoInicia = fluxoServ.StatusNaoInicia; 

                if (_Etapa.StatusParalisa)
                {
                    cboStatus.Enabled = false;
                }
                MontarCamposEtapa(!(_Etapa.StatusFecha || _Etapa.StatusParalisa || _Etapa.StatusCancela));
            }
            #endregion
        }

        #region [ delegates ]
        private delegate void execBackgroundCamposEtapa(bool ativo = false, List<Campos> c = null, bool recapturar = true, bool background = true);
        private delegate void execBackgroundCamposServico(bool ativo = false, List<Campos> c = null, bool background = true);
        private delegate void execBackground(bool background = true);
        #endregion

        private void backgroundWorkerDetalhe_DoWork(object sender, DoWorkEventArgs e)
        {
            string Path = SharedData.BDPath;
            Path = Path + "Historico\\";
            string PathFull = Path + _Responsavel.ID_Servico + ".txt";

            if (File.Exists(PathFull))
            {
                DateTime ConsultaUltimaAtualizacao = File.GetLastWriteTime(PathFull);

                if (_UltimaAtualizacaoServico < ConsultaUltimaAtualizacao)
                {
                    MontaTelaFluxoStatic();

                    #region [ status ]
                    if (_Etapa.ID_Etapa != 0)
                    {
                        FluxoServico s = _fluxoServico.Find(n => n.ID_Fluxo == _Etapa.ID_Etapa);
                        if (s != null)
                        {
                            if (s.StatusParalisa)
                            {
                                cboStatus.Invoke(new MethodInvoker(delegate() { cboStatus.SelectedValue = s.ID_Status; cboStatus.Enabled = false; cmb_ListMethod.Enabled = false; }));
                            }
                            _Etapa.ID_Status = s.ID_Status;
                        }
                    }
                    #endregion

                    MontarCamposEtapaStatic(cboStatus.Enabled);

                    MontarCamposServiçoStatic();

                    _UltimaAtualizacaoServico = ConsultaUltimaAtualizacao;
                }
            }
        }

        #region [ funções static que utilizam que delegam ao form ] 
        public static void MontaTelaFluxoStatic()
        {
            if (form != null)
                form.MontaTelaFluxo();
        }
        public static void MontarCamposServiçoStatic()
        {
            if (form != null)
                form.MontarCamposServiço();
        }
        public static void MontarCamposEtapaStatic(bool ativo)
        {
            if (form != null)
                form.MontarCamposEtapa(ativo);
        }
        #endregion

        private void timerDetalhe_Tick(object sender, EventArgs e)
        {
            this.timerDetalhe.Enabled = false;
            if (!backgroundWorkerDetalhe.IsBusy)
            {
                backgroundWorkerDetalhe.RunWorkerAsync();
            }
        }

        private void backgroundWorkerDetalhe_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            this.timerDetalhe.Enabled = true;
        }
        #endregion

        #region [ Retorno ao Pipeline ]
        private void Detalhe_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (SharedData.isOpenForm(typeof(Pipeline), false, false))
            {
                ((Pipeline)Application.OpenForms["Pipeline"]).Bind();
            }
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion

        private void chkPrioridade_CheckedChanged(object sender, EventArgs e)
        {
            if (_MudarPrioridade)
            {
                List<FollowUp> InsertListFollow = new List<FollowUp>();
                FollowUp InsertFollow = new FollowUp();
                InsertFollow.FollowUpEtapa = "";

                bool registrarFUP = false;
                if (registrarFUP = MessageBox.Show("Alterar prioridade do serviço?", "Mobios", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    registrarFUP = true;
                }
                else
                {
                    _MudarPrioridade = false;
                    chkPrioridade.Checked = !chkPrioridade.Checked;
                    return;
                }

                if (registrarFUP)
                {
                    InsertFollow.ID_Servico = _Responsavel.ID_Servico;
                    InsertFollow.FollowUpEtapa = "";

                    for (; ; )
                    {
                        if (!SharedData.isOpenForm(typeof(FollowUpEtapa), false))
                        {
                            FollowUpEtapa frm = new FollowUpEtapa(InsertFollow, false);
                            frm.WindowState = FormWindowState.Normal;
                            frm.StartPosition = FormStartPosition.CenterScreen;
                            frm.Left = 0;
                            frm.Top = 0;
                            frm.ShowDialog();
                            InsertFollow.FollowUpEtapa = frm._Follow.FollowUpEtapa.Trim();
                        }

                        if (InsertFollow.FollowUpEtapa != "")
                        {
                            string msgFUP = InsertFollow.FollowUpEtapa;
                            foreach (EtapasObjeto etp in _etapasObjeto)
                            {
                                InsertFollow = new FollowUp();
                                InsertFollow.ID_Servico = _Responsavel.ID_Servico;
                                InsertFollow.ID_Fluxo = etp.ID_Etapa;
                                InsertFollow.FollowUpEtapa = msgFUP;
                                InsertListFollow.Add(InsertFollow);
                            }
                            break;
                        }
                        else
                        {
                            if (MessageBox.Show("O follow-up é obrigatório para realizar esta ação.\n\nSelecione para continuar ou cancelar a ação.", "Follow-Up Obrigatório", MessageBoxButtons.RetryCancel) == DialogResult.Cancel)
                            {
                                _MudarPrioridade = false;
                                chkPrioridade.Checked = !chkPrioridade.Checked;
                                return;
                            }
                        }
                    }
                }

                if (InsertListFollow.Count > 0)
                {
                    DataAccess.InserirListaFollowUp(InsertListFollow);
                    DataAccess.AtualizarPrioridadeServico(_Responsavel.ID_Servico, chkPrioridade.Checked);
                    if (_Etapa.ID_Etapa != 0)
                    {
                        _listaFollowUpServico = DataAccess.RecuperaFollowUpServico(_Etapa.ID_Servico);
                        AtualizaFollowUp();
                    }
                }

                if (File.Exists(_ArquivoServico))
                {
                    _UltimaAtualizacaoServico = File.GetLastWriteTime(_ArquivoServico);
                }
            }
            else
            {
                _MudarPrioridade = true;
            }
        }

        private void btnPlayMethod_Click(object sender, EventArgs e)
        {
            if (cbAtualizar.Checked == false)
            {
                if (cmb_ListMethod.SelectedValue.ToString() != "")
                {
                    if (MessageBox.Show("Executar " + cmb_ListMethod.Text.ToString() + "?", "Método", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        _MyMethod = new ClassListMethod();
                        _MyMethod = (ClassListMethod)(cmb_ListMethod.SelectedItem);

                        string _MethodName = cmb_ListMethod.SelectedValue.ToString();

                        CustomMethod.ChamarMetodo(_MethodName, CustomMethod.MethodForm.Detalhe);

                        #region [ Follow-up ]
                        if (_MyMethod.MethodFUP == true)
                        {
                            FollowUp FollowUpMetodo = new FollowUp();
                            FollowUpMetodo.ID_Servico = _Responsavel.ID_Servico;
                            FollowUpMetodo.ID_Fluxo = _Etapa.ID_Etapa;
                            FollowUpMetodo.FollowUpEtapa = _MyMethod.MethodDescricao;

                            msgLog = "Gravando Follow-Up " + FollowUpMetodo.FollowUpEtapa;
                            DataAccess.RegistrarFollowUpEtapaServico(FollowUpMetodo, false);
                            _listaFollowUpServico = DataAccess.RecuperaFollowUpServico(_Etapa.ID_Servico);
                            this.AtualizaFollowUp();
                        }
                        #endregion

                        #region [ Altera Status da Etapa ]
                        try
                        {
                            if (_MyMethod.MethodStatusEtapa > 0)
                            {
                                if (MessageBox.Show("Alterar Status da Etapa?", "MOBIOS+", MessageBoxButtons.YesNo) == DialogResult.Yes)
                                {
                                    int Status = _MyMethod.MethodStatusEtapa;
                                    cboStatus.SelectedValue = Status;
                                    btnSalvar.PerformClick();
                                }
                                else
                                {
                                    MessageBox.Show("Status não alterado", "Mobios");
                                }
                            }
                        }
                        catch (Exception exp)
                        {
                            msgLog = "Erro ao alterar status da etapa " + _Etapa.ID_Etapa + " do serviço " + _Etapa.ID_Objeto + " / " + _Etapa.ID_Servico + ".";
                            Log.GravaLog(msgLog);
                            MessageBox.Show(exp.Message);
                        }
                        #endregion
                    }
                }
            }
            else
            {
                MessageBox.Show("Salve os campos da Operação primeiro.", "Método", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
    }
}

