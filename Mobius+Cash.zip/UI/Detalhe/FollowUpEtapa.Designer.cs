﻿namespace Mobios
{
    partial class FollowUpEtapa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FollowUpEtapa));
            this.rtbFollowUp = new System.Windows.Forms.RichTextBox();
            this.btnSalvarFollow = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnPlayMethod = new System.Windows.Forms.Button();
            this.label_ListMethod = new System.Windows.Forms.Label();
            this.cmb_ListMethod = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // rtbFollowUp
            // 
            this.rtbFollowUp.Location = new System.Drawing.Point(12, 25);
            this.rtbFollowUp.Name = "rtbFollowUp";
            this.rtbFollowUp.Size = new System.Drawing.Size(364, 211);
            this.rtbFollowUp.TabIndex = 0;
            this.rtbFollowUp.Text = "";
            // 
            // btnSalvarFollow
            // 
            this.btnSalvarFollow.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnSalvarFollow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvarFollow.Image = ((System.Drawing.Image)(resources.GetObject("btnSalvarFollow.Image")));
            this.btnSalvarFollow.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalvarFollow.Location = new System.Drawing.Point(308, 244);
            this.btnSalvarFollow.Name = "btnSalvarFollow";
            this.btnSalvarFollow.Size = new System.Drawing.Size(66, 23);
            this.btnSalvarFollow.TabIndex = 17;
            this.btnSalvarFollow.Text = "Salvar";
            this.btnSalvarFollow.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSalvarFollow.UseVisualStyleBackColor = true;
            this.btnSalvarFollow.Click += new System.EventHandler(this.btnSalvarFollow_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "Dados:";
            // 
            // btnPlayMethod
            // 
            this.btnPlayMethod.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnPlayMethod.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnPlayMethod.Image = ((System.Drawing.Image)(resources.GetObject("btnPlayMethod.Image")));
            this.btnPlayMethod.Location = new System.Drawing.Point(260, 244);
            this.btnPlayMethod.Name = "btnPlayMethod";
            this.btnPlayMethod.Size = new System.Drawing.Size(29, 23);
            this.btnPlayMethod.TabIndex = 62;
            this.btnPlayMethod.UseVisualStyleBackColor = false;
            this.btnPlayMethod.Visible = false;
            this.btnPlayMethod.Click += new System.EventHandler(this.btnPlayMethod_Click);
            // 
            // label_ListMethod
            // 
            this.label_ListMethod.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label_ListMethod.AutoSize = true;
            this.label_ListMethod.Location = new System.Drawing.Point(11, 249);
            this.label_ListMethod.Name = "label_ListMethod";
            this.label_ListMethod.Size = new System.Drawing.Size(51, 13);
            this.label_ListMethod.TabIndex = 61;
            this.label_ListMethod.Text = "Métodos:";
            this.label_ListMethod.Visible = false;
            // 
            // cmb_ListMethod
            // 
            this.cmb_ListMethod.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmb_ListMethod.DisplayMember = "MethodDescricao";
            this.cmb_ListMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_ListMethod.FormattingEnabled = true;
            this.cmb_ListMethod.Location = new System.Drawing.Point(65, 246);
            this.cmb_ListMethod.Name = "cmb_ListMethod";
            this.cmb_ListMethod.Size = new System.Drawing.Size(189, 21);
            this.cmb_ListMethod.TabIndex = 60;
            this.cmb_ListMethod.ValueMember = "MethodName";
            this.cmb_ListMethod.Visible = false;
            // 
            // FollowUpEtapa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(388, 282);
            this.Controls.Add(this.btnPlayMethod);
            this.Controls.Add(this.label_ListMethod);
            this.Controls.Add(this.cmb_ListMethod);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSalvarFollow);
            this.Controls.Add(this.rtbFollowUp);
            this.Name = "FollowUpEtapa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Follow Up";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FollowUpEtapa_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtbFollowUp;
        private System.Windows.Forms.Button btnSalvarFollow;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnPlayMethod;
        private System.Windows.Forms.Label label_ListMethod;
        private System.Windows.Forms.ComboBox cmb_ListMethod;
    }
}