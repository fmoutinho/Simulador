﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mobios
{
    public partial class FollowUpEtapa : Form
    {
        public FollowUp _Follow;
        bool _salva;
        bool _salvo;
        public ClassListMethod _MyMethod = new ClassListMethod();
        public List<ClassListMethod> _Metodos = new List<ClassListMethod>();

        public FollowUpEtapa(FollowUp fw, bool salva = true)
        {
            InitializeComponent();
            _salva = salva;
            if (fw.ID_Follow != 0)
            {
                _Follow = DataAccess.RecuperaFollowUpEtapaServicoByID(fw.ID_Follow); // buscar follow up
                if (_Follow != null)
                {
                    rtbFollowUp.Text = _Follow.FollowUpEtapa;
                    if (_Follow.LOGIN.ToUpper() != Environment.UserName.ToUpper())
                    {
                        this.btnSalvarFollow.Enabled = false;
                    }
                }
            }
            else
            {
                _Follow = fw; // Inserir novo follow up
            }
            
            #region [ Carrega Métodos ]
            if (SharedData.gMetodos != null && SharedData.gMetodos.Count > 0)
            {
                List<ClassListMethod> temp = SharedData.gMetodos.Where(n => n.ID_Method == 0 || n.MethodForm.ToUpper() == "FOLLOWUP").ToList();
                if (temp != null && temp.Count > 0)
                {
                    foreach (ClassListMethod c in temp)
                    {
                        _Metodos.Add(new ClassListMethod(c));
                    }
                }
            }

            if (_Metodos == null || _Metodos.Count == 0)
            {
                _Metodos = DataAccess.GetListMethodFollowUp();
            }

            cmb_ListMethod.DataSource = _Metodos;
            cmb_ListMethod.Visible = (cmb_ListMethod.Items.Count > 1);      // sempre é adicionado o campo vazio, por isso >1
            label_ListMethod.Visible = (cmb_ListMethod.Items.Count > 1);
            btnPlayMethod.Visible = (cmb_ListMethod.Items.Count > 1);
            if (cmb_ListMethod.Visible)
                cmb_ListMethod.SelectedValue = 0;
            #endregion
            
        }

        private void btnSalvarFollow_Click(object sender, EventArgs e)
        {
            try
            {
                _Follow.FollowUpEtapa = TratamentoCampo.AntiInjection(rtbFollowUp.Text);
                if (_Follow.ID_Fluxo != 0 && _salva)
                {
                    if (_Follow.ID_Follow != 0)
                    {
                        DataAccess.RegistrarFollowUpEtapaServico(_Follow, true);
                    }
                    else
                    {
                        DataAccess.RegistrarFollowUpEtapaServico(_Follow, false);
                    }
                    _salvo = true;
                    MessageBox.Show("Mensagem de FollowUp incluída.");
                }
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao inserir acompanhamento. Erro: " + ex.Message);
            }

        }

        private void FollowUpEtapa_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (_salvo)
            {
                if (SharedData.isOpenForm(typeof(Detalhe), false))
                {
                    ((Detalhe)Application.OpenForms["Detalhe"])._listaFollowUpServico = DataAccess.RecuperaFollowUpServico(_Follow.ID_Servico);
                    ((Detalhe)Application.OpenForms["Detalhe"]).AtualizaFollowUp();
                }
            }
        }

        private void btnPlayMethod_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmb_ListMethod.SelectedValue.ToString() != "")
                {
                    if (MessageBox.Show("Executar " + cmb_ListMethod.Text.ToString() + "?", "Método", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        _MyMethod = new ClassListMethod();
                        _MyMethod = (Mobios.ClassListMethod)(cmb_ListMethod.SelectedItem);

                        string _MethodName = cmb_ListMethod.SelectedValue.ToString();

                        CustomMethod.ChamarMetodo(_MethodName, CustomMethod.MethodForm.FollowUp);
                    }
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "Métodos", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


    }
}
