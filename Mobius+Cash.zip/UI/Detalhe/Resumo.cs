﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mobios
{
    public partial class Resumo : Form
    {
        List<Campos> listaCamposServico = new List<Campos>();                  // Contem os campos para preenchimento da tela - Dados Servicos;

        //int camposPorLinha;
        ResponsavelServico _Responsavel;
        List<Boleta4131Dados> listaBoletoBen = new List<Boleta4131Dados>();
        string _tipoBoleto;
        string linhaArq;        

        public Resumo(ResponsavelServico resp, string IdBoleto = null, List<Campos> c = null)
        {
            InitializeComponent();

            if (IdBoleto != null)   // Carrega dados capturados do boleto
            {
                this.Text = "Resumo Boleto Capturado.";
                MostraBoletoBEN(IdBoleto);
            }
            else // Carrega dados cadastrados na operação
            {
                this.Text = "Resumo Serviço cadastrado.";
                _Responsavel = resp;
                linhaArq = "Servico: [" + _Responsavel.ID_Objeto + "/" + _Responsavel.ID_Servico + "] " + _Responsavel.ServicoName + ".\n";

                //listaCamposServico = DataAccess.buscarCamposDinamicos(_Responsavel.ID_Objeto);            // Preenche a tela com campos do serviço;
                //TelaDinamica.RecuperarServico(ref listaCamposServico, _Responsavel.ID_Servico);
                if (c == null || c.Count == 0)
                {
                    c = new List<Campos>();
                    c = DataAccess.buscarCamposDinamicosConjunto(_Responsavel.ID_Servico);            // Preenche a tela com campos do serviço;
                }

                foreach (Campos dc in c)
                {
                    //linhaArq = linhaArq + "[" + dc.CampoNome + "] - " + dc.CampoLabel + ": " + dc.ValorCampo + ".\n";
                    linhaArq = linhaArq + dc.CampoLabel.PadRight((dc.CampoLabel.Length + (30 - dc.CampoLabel.Length)), '.') + ": " + dc.ValorCampo + ".\n";
                }
                rtbResumoServ.Text = linhaArq;
            }
        }

        // Buscar dados Boleto BEN
        private void MostraBoletoBEN(string boleto)
        {
            linhaArq = "Boleto: " + boleto + ".\n\n";
            // Localiza boleto
            string sqlCommand = "SELECT * FROM vw_MontaDraftBoleto4131 Where Boleto = '{0}'";
            sqlCommand = String.Format(sqlCommand, boleto);

            DataTable result = DataConnector.ExecuteDataTable(sqlCommand, "BDconsulta");
            if (result.Rows.Count != 0)
            {
                foreach (DataRow row in result.Rows)
                {
                    linhaArq = linhaArq + row["NM_CAMPO"].ToString().PadRight((row["NM_CAMPO"].ToString().Length + (30 - row["NM_CAMPO"].ToString().Length)), '.') + ": " + row["NM_VALOR"].ToString().Trim() + ".\n";
                }
            }
            else
            {
                linhaArq = "Boleto " + boleto + " não encontrado.";
            }

            //
            rtbResumoServ.Text = linhaArq;
        }               

        private void btnCopiar_Click(object sender, EventArgs e)
        {
            rtbResumoServ.SelectAll();
            rtbResumoServ.Copy();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
