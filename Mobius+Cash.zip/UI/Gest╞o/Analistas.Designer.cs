﻿namespace Mobios
{
    partial class Analistas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Analistas));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.grpAnalistas = new System.Windows.Forms.GroupBox();
            this.dgvAnalista = new System.Windows.Forms.DataGridView();
            this.Selecionar = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.ID_Responsavel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NomeResponsavel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LoginResponsavel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Funcional = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Gestor = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Ativo = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.RemoverAnalista = new System.Windows.Forms.DataGridViewImageColumn();
            this.button1 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCadastrar = new System.Windows.Forms.Button();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtLogin = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button_filtro = new System.Windows.Forms.Button();
            this.txtFuncional = new System.Windows.Forms.TextBox();
            this.checkBox_valores_exatos = new System.Windows.Forms.CheckBox();
            this.chkGestor = new System.Windows.Forms.CheckBox();
            this.btnLimparFiltro = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtIdResp = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button7 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.cboCelula = new System.Windows.Forms.ComboBox();
            this.btnArea = new System.Windows.Forms.Button();
            this.lblArea = new System.Windows.Forms.Label();
            this.cboArea = new System.Windows.Forms.ComboBox();
            this.btnDgvAcesso = new System.Windows.Forms.Button();
            this.dgvAcessos = new System.Windows.Forms.DataGridView();
            this.IdArea = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NomeArea = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IdCelula = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NomeCelula = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RemoverAcesso = new System.Windows.Forms.DataGridViewImageColumn();
            this.btnAtualizar = new System.Windows.Forms.Button();
            this.grpAnalistas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAnalista)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAcessos)).BeginInit();
            this.SuspendLayout();
            // 
            // grpAnalistas
            // 
            this.grpAnalistas.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpAnalistas.Controls.Add(this.dgvAnalista);
            this.grpAnalistas.Controls.Add(this.button1);
            this.grpAnalistas.Controls.Add(this.button4);
            this.grpAnalistas.Controls.Add(this.button5);
            this.grpAnalistas.Controls.Add(this.button3);
            this.grpAnalistas.Controls.Add(this.button2);
            this.grpAnalistas.Location = new System.Drawing.Point(12, 313);
            this.grpAnalistas.Name = "grpAnalistas";
            this.grpAnalistas.Size = new System.Drawing.Size(600, 212);
            this.grpAnalistas.TabIndex = 0;
            this.grpAnalistas.TabStop = false;
            this.grpAnalistas.Text = "Analistas Cadastrados";
            // 
            // dgvAnalista
            // 
            this.dgvAnalista.AllowUserToAddRows = false;
            this.dgvAnalista.AllowUserToDeleteRows = false;
            this.dgvAnalista.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.AliceBlue;
            this.dgvAnalista.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvAnalista.BackgroundColor = System.Drawing.Color.White;
            this.dgvAnalista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAnalista.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Selecionar,
            this.ID_Responsavel,
            this.NomeResponsavel,
            this.LoginResponsavel,
            this.Funcional,
            this.Gestor,
            this.Ativo,
            this.RemoverAnalista});
            this.dgvAnalista.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgvAnalista.Location = new System.Drawing.Point(3, 16);
            this.dgvAnalista.Name = "dgvAnalista";
            this.dgvAnalista.RowHeadersVisible = false;
            this.dgvAnalista.Size = new System.Drawing.Size(594, 161);
            this.dgvAnalista.TabIndex = 0;
            this.dgvAnalista.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAnalista_CellClick);
            this.dgvAnalista.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAnalista_CellDoubleClick);
            this.dgvAnalista.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvAnalista_CellFormatting);
            // 
            // Selecionar
            // 
            this.Selecionar.HeaderText = "";
            this.Selecionar.Name = "Selecionar";
            this.Selecionar.Width = 30;
            // 
            // ID_Responsavel
            // 
            this.ID_Responsavel.DataPropertyName = "ID_Responsavel";
            this.ID_Responsavel.HeaderText = "ID_Responsavel";
            this.ID_Responsavel.Name = "ID_Responsavel";
            this.ID_Responsavel.ReadOnly = true;
            this.ID_Responsavel.Visible = false;
            // 
            // NomeResponsavel
            // 
            this.NomeResponsavel.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.NomeResponsavel.DataPropertyName = "NomeResponsavel";
            this.NomeResponsavel.HeaderText = "Nome";
            this.NomeResponsavel.Name = "NomeResponsavel";
            this.NomeResponsavel.ReadOnly = true;
            this.NomeResponsavel.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // LoginResponsavel
            // 
            this.LoginResponsavel.DataPropertyName = "LoginResponsavel";
            this.LoginResponsavel.HeaderText = "Login";
            this.LoginResponsavel.Name = "LoginResponsavel";
            this.LoginResponsavel.ReadOnly = true;
            this.LoginResponsavel.Width = 80;
            // 
            // Funcional
            // 
            this.Funcional.DataPropertyName = "FuncionalResponsavel";
            this.Funcional.HeaderText = "Funcional";
            this.Funcional.Name = "Funcional";
            this.Funcional.Width = 80;
            // 
            // Gestor
            // 
            this.Gestor.DataPropertyName = "FLG_GESTOR";
            this.Gestor.HeaderText = "Gestor";
            this.Gestor.Name = "Gestor";
            this.Gestor.ReadOnly = true;
            this.Gestor.Width = 50;
            // 
            // Ativo
            // 
            this.Ativo.DataPropertyName = "UsuarioAtivo";
            this.Ativo.HeaderText = "Ativo";
            this.Ativo.Name = "Ativo";
            this.Ativo.ReadOnly = true;
            this.Ativo.Width = 40;
            // 
            // RemoverAnalista
            // 
            this.RemoverAnalista.HeaderText = "";
            this.RemoverAnalista.Image = ((System.Drawing.Image)(resources.GetObject("RemoverAnalista.Image")));
            this.RemoverAnalista.Name = "RemoverAnalista";
            this.RemoverAnalista.ReadOnly = true;
            this.RemoverAnalista.Width = 30;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(272, 183);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 23);
            this.button1.TabIndex = 24;
            this.button1.Text = "Desmarcar todos";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.btnNone_Click);
            // 
            // button4
            // 
            this.button4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(527, 183);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(63, 23);
            this.button4.TabIndex = 20;
            this.button4.Text = "Excluir";
            this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // button5
            // 
            this.button5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(156, 183);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(111, 23);
            this.button5.TabIndex = 23;
            this.button5.Text = "Selecionar todos";
            this.button5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.btnAll_Click);
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(389, 183);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(60, 23);
            this.button3.TabIndex = 21;
            this.button3.Text = "Ativar";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.btnAtivar_Click);
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(454, 183);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(68, 23);
            this.button2.TabIndex = 22;
            this.button2.Text = "Inativar";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.btnDesativar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(82, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnCadastrar
            // 
            this.btnCadastrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCadastrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCadastrar.Image = ((System.Drawing.Image)(resources.GetObject("btnCadastrar.Image")));
            this.btnCadastrar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCadastrar.Location = new System.Drawing.Point(529, 284);
            this.btnCadastrar.Name = "btnCadastrar";
            this.btnCadastrar.Size = new System.Drawing.Size(80, 23);
            this.btnCadastrar.TabIndex = 2;
            this.btnCadastrar.Text = "Cadastrar";
            this.btnCadastrar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCadastrar.UseVisualStyleBackColor = true;
            this.btnCadastrar.Click += new System.EventHandler(this.btnCadastrar_Click);
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(120, 22);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(270, 20);
            this.txtNome.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Login";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtLogin
            // 
            this.txtLogin.Location = new System.Drawing.Point(53, 48);
            this.txtLogin.Name = "txtLogin";
            this.txtLogin.Size = new System.Drawing.Size(120, 20);
            this.txtLogin.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(179, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Funcional";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // button_filtro
            // 
            this.button_filtro.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_filtro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_filtro.Image = ((System.Drawing.Image)(resources.GetObject("button_filtro.Image")));
            this.button_filtro.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_filtro.Location = new System.Drawing.Point(446, 19);
            this.button_filtro.Name = "button_filtro";
            this.button_filtro.Size = new System.Drawing.Size(69, 23);
            this.button_filtro.TabIndex = 12;
            this.button_filtro.Text = "Filtrar";
            this.button_filtro.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_filtro.UseVisualStyleBackColor = true;
            this.button_filtro.Click += new System.EventHandler(this.button_filtro_Click);
            // 
            // txtFuncional
            // 
            this.txtFuncional.Location = new System.Drawing.Point(234, 48);
            this.txtFuncional.MaxLength = 9;
            this.txtFuncional.Name = "txtFuncional";
            this.txtFuncional.Size = new System.Drawing.Size(86, 20);
            this.txtFuncional.TabIndex = 7;
            // 
            // checkBox_valores_exatos
            // 
            this.checkBox_valores_exatos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBox_valores_exatos.BackColor = System.Drawing.Color.Transparent;
            this.checkBox_valores_exatos.Location = new System.Drawing.Point(523, 16);
            this.checkBox_valores_exatos.Name = "checkBox_valores_exatos";
            this.checkBox_valores_exatos.Size = new System.Drawing.Size(67, 31);
            this.checkBox_valores_exatos.TabIndex = 13;
            this.checkBox_valores_exatos.Text = "Valores Exatos";
            this.checkBox_valores_exatos.UseVisualStyleBackColor = false;
            // 
            // chkGestor
            // 
            this.chkGestor.AutoSize = true;
            this.chkGestor.Location = new System.Drawing.Point(329, 50);
            this.chkGestor.Name = "chkGestor";
            this.chkGestor.Size = new System.Drawing.Size(57, 17);
            this.chkGestor.TabIndex = 12;
            this.chkGestor.Text = "Gestor";
            this.chkGestor.UseVisualStyleBackColor = true;
            // 
            // btnLimparFiltro
            // 
            this.btnLimparFiltro.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLimparFiltro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLimparFiltro.Image = ((System.Drawing.Image)(resources.GetObject("btnLimparFiltro.Image")));
            this.btnLimparFiltro.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLimparFiltro.Location = new System.Drawing.Point(446, 48);
            this.btnLimparFiltro.Name = "btnLimparFiltro";
            this.btnLimparFiltro.Size = new System.Drawing.Size(69, 23);
            this.btnLimparFiltro.TabIndex = 14;
            this.btnLimparFiltro.Text = "Limpar";
            this.btnLimparFiltro.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLimparFiltro.UseVisualStyleBackColor = true;
            this.btnLimparFiltro.Click += new System.EventHandler(this.btnLimparFiltro_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "ID";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtIdResp
            // 
            this.txtIdResp.Enabled = false;
            this.txtIdResp.Location = new System.Drawing.Point(53, 22);
            this.txtIdResp.Name = "txtIdResp";
            this.txtIdResp.Size = new System.Drawing.Size(28, 20);
            this.txtIdResp.TabIndex = 19;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.txtIdResp);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.btnLimparFiltro);
            this.groupBox1.Controls.Add(this.chkGestor);
            this.groupBox1.Controls.Add(this.checkBox_valores_exatos);
            this.groupBox1.Controls.Add(this.txtFuncional);
            this.groupBox1.Controls.Add(this.button_filtro);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtLogin);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtNome);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(600, 79);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Usuário";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.button7);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.cboCelula);
            this.groupBox2.Controls.Add(this.btnArea);
            this.groupBox2.Controls.Add(this.lblArea);
            this.groupBox2.Controls.Add(this.cboArea);
            this.groupBox2.Controls.Add(this.btnDgvAcesso);
            this.groupBox2.Controls.Add(this.dgvAcessos);
            this.groupBox2.Location = new System.Drawing.Point(12, 92);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(600, 187);
            this.groupBox2.TabIndex = 25;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Atuação";
            // 
            // button7
            // 
            this.button7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Image = ((System.Drawing.Image)(resources.GetObject("button7.Image")));
            this.button7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.Location = new System.Drawing.Point(305, 47);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(117, 23);
            this.button7.TabIndex = 21;
            this.button7.Text = "Add Nova Célula";
            this.button7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 51);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 13);
            this.label5.TabIndex = 20;
            this.label5.Text = "Célula";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cboCelula
            // 
            this.cboCelula.DisplayMember = "NomeCelula";
            this.cboCelula.Enabled = false;
            this.cboCelula.FormattingEnabled = true;
            this.cboCelula.Location = new System.Drawing.Point(53, 48);
            this.cboCelula.Name = "cboCelula";
            this.cboCelula.Size = new System.Drawing.Size(244, 21);
            this.cboCelula.TabIndex = 19;
            this.cboCelula.ValueMember = "ID_Celula";
            // 
            // btnArea
            // 
            this.btnArea.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnArea.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnArea.Image = ((System.Drawing.Image)(resources.GetObject("btnArea.Image")));
            this.btnArea.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnArea.Location = new System.Drawing.Point(305, 19);
            this.btnArea.Name = "btnArea";
            this.btnArea.Size = new System.Drawing.Size(117, 23);
            this.btnArea.TabIndex = 17;
            this.btnArea.Text = "Add Nova Área";
            this.btnArea.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnArea.UseVisualStyleBackColor = true;
            this.btnArea.Click += new System.EventHandler(this.btnArea_Click);
            // 
            // lblArea
            // 
            this.lblArea.AutoSize = true;
            this.lblArea.Location = new System.Drawing.Point(18, 23);
            this.lblArea.Name = "lblArea";
            this.lblArea.Size = new System.Drawing.Size(29, 13);
            this.lblArea.TabIndex = 16;
            this.lblArea.Text = "Área";
            this.lblArea.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cboArea
            // 
            this.cboArea.DisplayMember = "NomeArea";
            this.cboArea.FormattingEnabled = true;
            this.cboArea.Location = new System.Drawing.Point(53, 20);
            this.cboArea.Name = "cboArea";
            this.cboArea.Size = new System.Drawing.Size(244, 21);
            this.cboArea.TabIndex = 15;
            this.cboArea.ValueMember = "ID_Area";
            this.cboArea.SelectedValueChanged += new System.EventHandler(this.cboArea_SelectedValueChanged);
            // 
            // btnDgvAcesso
            // 
            this.btnDgvAcesso.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDgvAcesso.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDgvAcesso.Image = ((System.Drawing.Image)(resources.GetObject("btnDgvAcesso.Image")));
            this.btnDgvAcesso.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDgvAcesso.Location = new System.Drawing.Point(498, 45);
            this.btnDgvAcesso.Name = "btnDgvAcesso";
            this.btnDgvAcesso.Size = new System.Drawing.Size(92, 23);
            this.btnDgvAcesso.TabIndex = 2;
            this.btnDgvAcesso.Text = "Add Acesso";
            this.btnDgvAcesso.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDgvAcesso.UseVisualStyleBackColor = true;
            this.btnDgvAcesso.Click += new System.EventHandler(this.btnDgvAcesso_Click);
            // 
            // dgvAcessos
            // 
            this.dgvAcessos.AllowUserToAddRows = false;
            this.dgvAcessos.AllowUserToDeleteRows = false;
            this.dgvAcessos.AllowUserToResizeRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.AliceBlue;
            this.dgvAcessos.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvAcessos.BackgroundColor = System.Drawing.Color.White;
            this.dgvAcessos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAcessos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IdArea,
            this.NomeArea,
            this.IdCelula,
            this.NomeCelula,
            this.RemoverAcesso});
            this.dgvAcessos.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvAcessos.Location = new System.Drawing.Point(3, 77);
            this.dgvAcessos.Name = "dgvAcessos";
            this.dgvAcessos.RowHeadersVisible = false;
            this.dgvAcessos.Size = new System.Drawing.Size(594, 107);
            this.dgvAcessos.TabIndex = 18;
            this.dgvAcessos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAcessos_CellClick);
            // 
            // IdArea
            // 
            this.IdArea.DataPropertyName = "ID_Area";
            this.IdArea.HeaderText = "IdArea";
            this.IdArea.Name = "IdArea";
            this.IdArea.ReadOnly = true;
            this.IdArea.Visible = false;
            // 
            // NomeArea
            // 
            this.NomeArea.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.NomeArea.DataPropertyName = "NomeArea";
            this.NomeArea.HeaderText = "Área";
            this.NomeArea.Name = "NomeArea";
            this.NomeArea.ReadOnly = true;
            this.NomeArea.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.NomeArea.Width = 291;
            // 
            // IdCelula
            // 
            this.IdCelula.DataPropertyName = "ID_Celula";
            this.IdCelula.HeaderText = "IdCelula";
            this.IdCelula.Name = "IdCelula";
            this.IdCelula.ReadOnly = true;
            this.IdCelula.Visible = false;
            // 
            // NomeCelula
            // 
            this.NomeCelula.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.NomeCelula.DataPropertyName = "NomeCelula";
            this.NomeCelula.HeaderText = "Nome Célula";
            this.NomeCelula.Name = "NomeCelula";
            this.NomeCelula.ReadOnly = true;
            // 
            // RemoverAcesso
            // 
            this.RemoverAcesso.HeaderText = "";
            this.RemoverAcesso.Image = ((System.Drawing.Image)(resources.GetObject("RemoverAcesso.Image")));
            this.RemoverAcesso.Name = "RemoverAcesso";
            this.RemoverAcesso.ReadOnly = true;
            this.RemoverAcesso.Width = 30;
            // 
            // btnAtualizar
            // 
            this.btnAtualizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAtualizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAtualizar.Image = ((System.Drawing.Image)(resources.GetObject("btnAtualizar.Image")));
            this.btnAtualizar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAtualizar.Location = new System.Drawing.Point(529, 284);
            this.btnAtualizar.Name = "btnAtualizar";
            this.btnAtualizar.Size = new System.Drawing.Size(80, 23);
            this.btnAtualizar.TabIndex = 26;
            this.btnAtualizar.Text = "Atualizar";
            this.btnAtualizar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAtualizar.UseVisualStyleBackColor = true;
            this.btnAtualizar.Visible = false;
            this.btnAtualizar.Click += new System.EventHandler(this.btnCadastrar_Click);
            // 
            // Analistas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(624, 537);
            this.Controls.Add(this.btnAtualizar);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.grpAnalistas);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnCadastrar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Analistas";
            this.ShowIcon = false;
            this.Text = "Cadastro de Analistas";
            this.grpAnalistas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAnalista)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAcessos)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpAnalistas;
        private System.Windows.Forms.DataGridView dgvAnalista;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCadastrar;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtLogin;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button_filtro;
        private System.Windows.Forms.TextBox txtFuncional;
        private System.Windows.Forms.CheckBox checkBox_valores_exatos;
        private System.Windows.Forms.CheckBox chkGestor;
        private System.Windows.Forms.Button btnLimparFiltro;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtIdResp;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cboCelula;
        private System.Windows.Forms.Button btnArea;
        private System.Windows.Forms.Label lblArea;
        private System.Windows.Forms.ComboBox cboArea;
        private System.Windows.Forms.Button btnDgvAcesso;
        private System.Windows.Forms.DataGridView dgvAcessos;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Selecionar;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_Responsavel;
        private System.Windows.Forms.DataGridViewTextBoxColumn NomeResponsavel;
        private System.Windows.Forms.DataGridViewTextBoxColumn LoginResponsavel;
        private System.Windows.Forms.DataGridViewTextBoxColumn Funcional;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Gestor;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Ativo;
        private System.Windows.Forms.DataGridViewImageColumn RemoverAnalista;
        private System.Windows.Forms.DataGridViewTextBoxColumn IdArea;
        private System.Windows.Forms.DataGridViewTextBoxColumn NomeArea;
        private System.Windows.Forms.DataGridViewTextBoxColumn IdCelula;
        private System.Windows.Forms.DataGridViewTextBoxColumn NomeCelula;
        private System.Windows.Forms.DataGridViewImageColumn RemoverAcesso;
        private System.Windows.Forms.Button btnAtualizar;
    }
}