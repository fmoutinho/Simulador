﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mobios
{
    public partial class Analistas : Form
    {
        #region [ Variáveis ]
        DataTable CamposFiltro;
        List<Responsavel> _AreasCelulas = new List<Responsavel>();
        List<Responsavel> _AcessosDataSource = new List<Responsavel>();
        List<Responsavel> _AreasCelulasResponsavel = new List<Responsavel>();
        bool _filtrar;
        string _filtro;
        #endregion

        public Analistas()
        {
            InitializeComponent();
            this.dgvAnalista.AutoGenerateColumns = false;
            this.dgvAcessos.AutoGenerateColumns = false;
            
            CamposFiltro = new DataTable();

            #region [ Datatable filtro ]
            CamposFiltro.Columns.Add("NomeCampo");
            CamposFiltro.Columns.Add("TipoCampo");
            CamposFiltro.Columns.Add("NomeColuna");
            CamposFiltro.Rows.Add("txtNome", "Textbox", "NomeResponsavel");
            CamposFiltro.Rows.Add("txtLogin", "Textbox", "LoginResponsavel");
            CamposFiltro.Rows.Add("txtFuncional", "Textbox", "FuncionalResponsavel");
            #endregion

            BindDataGrid();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.txtNome.Text.Trim() != "" && this.txtLogin.Text.Trim() != "" && this.txtFuncional.Text.Trim() != "" && dgvAcessos.Rows.Count > 0)
                {
                    Responsavel obj = new Responsavel();
                    if (this.txtIdResp.Text.Trim() != "")
                    {
                        obj.ID_Responsavel = Convert.ToInt32(this.txtIdResp.Text.Trim());
                    }
                    obj.NomeResponsavel = this.txtNome.Text.Trim();
                    obj.LoginResponsavel = this.txtLogin.Text.ToUpper().Trim();
                    obj.FuncionalResponsavel = this.txtFuncional.Text.Trim();
                    obj.FLG_Gestor = this.chkGestor.Checked;

                    string msg = "";
                    if (obj.LoginResponsavel != Environment.UserName.ToUpper())
                    {
                        bool atualiza = false;
                        bool apenasAcrescentaAcessoArea = false;
                        if (obj.ID_Responsavel != 0)
                        {
                            atualiza = true;
                        }
                        else
                        {

                            List<Responsavel> targetTable = new List<Responsavel>();
                            targetTable = DataAccess.BuscarResponsaveisArea(obj.LoginResponsavel);
                            if (targetTable.Count != 0)
                            {
                                if (_AreasCelulasResponsavel.Exists(n => n.LoginResponsavel == obj.LoginResponsavel))
                                {
                                    MessageBox.Show("Já há um analista cadastrado com este login", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    return;
                                }
                                else
                                {
                                    apenasAcrescentaAcessoArea = true;
                                }
                            }
                        }

                        Log.GravaLog("Atualizando cadastro de usuário: " + obj.LoginResponsavel);
                        if (atualiza)
                        {
                            DataAccess.AtualizarAnalista(obj);
                            List<Responsavel> resp = new List<Responsavel>();
                            resp = _AreasCelulasResponsavel.Where(n => n.ID_Responsavel == obj.ID_Responsavel).GroupBy(x => new { x.ID_Area, x.ID_Celula }).Select(g => g.First()).ToList();

                            List<int> delete = new List<int>();
                            foreach (Responsavel r in resp)
                            {
                                if (!_AcessosDataSource.Exists(n => n.ID_Celula == r.ID_Celula))
                                {
                                    delete.Add(r.ID_Celula);
                                }
                            }
                            if (delete.Count > 0)
                            {
                                DataAccess.ExcluiCelulaAnalistaLote(delete, obj.ID_Responsavel);
                            }

                            List<int> insert = new List<int>();
                            foreach (Responsavel a in _AcessosDataSource)
                            {
                                if (!resp.Exists(n => n.ID_Celula == a.ID_Celula))
                                {
                                    insert.Add(a.ID_Celula);
                                }
                            }
                            if (insert.Count > 0)
                            {
                                DataAccess.SalvaCelulaAnalistaLote(insert, obj.ID_Responsavel);
                            }

                            msg = "Analista atualizado!";
                        }
                        else
                        {
                            int IdResp = 0;
                            try
                            {
                                if (!apenasAcrescentaAcessoArea)
                                {
                                    DataAccess.SalvarAnalista(obj);
                                }
                                IdResp = DataAccess.BuscarIdResponsavel(obj.LoginResponsavel);
                                DataAccess.SalvaCelulaAnalistaLote(_AcessosDataSource.Select(n => n.ID_Celula).Distinct().ToList(), IdResp);
                                msg = "Analista cadastrado!";
                            }
                            catch (Exception err)
                            {
                                Log.GravaLog(err.Message);
                                DataAccess.ExcluirUsuario(IdResp);
                            }
                        }
                        this.btnLimparFiltro.PerformClick();
                        BindDataGrid();
                        Log.GravaLog("Cria arquivo de atualzação de acesso: " + obj.LoginResponsavel);
                        SharedData.CriaArquivoAcesso(obj.LoginResponsavel);
                        MessageBox.Show(msg, "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Você não pode alterar seu próprio cadastro.", "Gestão de Acessos", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
                else
                {
                    MessageBox.Show("Preencha todos os dados!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            catch(Exception err)
            {
                Log.GravaLog(err.Message);
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void BindDataGrid()
        {
            _AreasCelulasResponsavel = new List<Responsavel>();
            Responsavel LinhaNula = new Responsavel();
            LinhaNula.NomeArea = "";
            LinhaNula.NomeCelula = "";
            LinhaNula.AreaAtiva = true;
            LinhaNula.CelulaAtiva = true;
            LinhaNula.UsuarioAtivo = true;
            _AreasCelulasResponsavel.Add(LinhaNula);

            List<Responsavel> t = new List<Responsavel>();
            t = DataAccess.BuscarResponsaveisArea(SharedData.UserCelulas.Select(n => n.ID_Area).Distinct().ToList(), false);
            if (!SharedData.User.FLG_AutoProc)
            {
                t = t.Where(s => s.FLG_AutoProc == false).ToList();
            }
            _AreasCelulasResponsavel.AddRange(t);

            #region [ Atualiza Data Grid ]
            DataTable AreasCelulasResp = TratamentoCampo.ConvertListToDataTable(_AreasCelulasResponsavel);
            DataTable dt = new DataTable();
            DataRow[] dgvRows = AreasCelulasResp.Select("ID_Responsavel <> 0");
            if (dgvRows.Count() > 0)
            {
                dt = dgvRows.CopyToDataTable();
                string[] columns = { "ID_Responsavel" };
                dt = TratamentoCampo.DataTableGroupBy(columns, dt);

                DataView dv = dt.DefaultView;
                string sort = "[NomeResponsavel] ASC";
                dv.Sort = sort;
                dt = dv.ToTable();
            }
            this.dgvAnalista.DataSource = dt;
            #endregion

            #region [ Atualiza Combo Áreas ]
            _AreasCelulas = _AreasCelulasResponsavel.Where(z => z.AreaAtiva == true && z.CelulaAtiva == true).GroupBy(n => new { n.ID_Area, n.ID_Celula }).Select(g => g.First()).OrderBy(x => x.NomeArea).ToList();
            this.cboArea.DataSource = _AreasCelulas.GroupBy(n => n.ID_Area).Select(g => g.First()).ToList();
            this.cboArea.SelectedValue = 0;
            this.cboCelula.DataSource = _AreasCelulas.Where(n => n.ID_Area == 0).ToList();
            #endregion

            Filtro();
        }

        #region [ eventos ]
        private void dgvAnalista_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                bool validado = false;
                string UserSelecionado = dgvAnalista.Rows[e.RowIndex].Cells["LoginResponsavel"].Value.ToString().ToUpper();
                if (UserSelecionado == Environment.UserName.ToUpper() && (dgvAnalista.Columns[e.ColumnIndex].Name == "RemoverAnalista" || dgvAnalista.Columns[e.ColumnIndex].Name.ToUpper() == "ATIVO" || dgvAnalista.Columns[e.ColumnIndex].Name.ToUpper() == "GESTOR"))
                {
                    validado = false;
                    MessageBox.Show("Você não pode alterar seu próprio cadastro.", "Gestão de Acessos", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    validado = true;
                }

                if (validado)
                {
                    if (dgvAnalista.Columns[e.ColumnIndex].Name == "RemoverAnalista")
                    {
                        string Responsavel = this.dgvAnalista.Rows[e.RowIndex].Cells["NomeResponsavel"].Value.ToString();
                        DialogResult result = MessageBox.Show("Deseja mesmo excluir " + Responsavel + "?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                        if (result == DialogResult.Yes)
                        {
                            int ID_Responsavel = Convert.ToInt32(this.dgvAnalista.Rows[e.RowIndex].Cells["ID_Responsavel"].Value);

                            DataAccess.ExcluirUsuario(ID_Responsavel);
                            if (this.txtIdResp.Text == ID_Responsavel.ToString())
                            {
                                btnLimparFiltro.PerformClick();
                            }
                            BindDataGrid();
                            Log.GravaLog("Cria arquivo de atualzação de acesso: " + UserSelecionado);
                            SharedData.CriaArquivoAcesso(UserSelecionado);
                        }
                    }
                    if (e.RowIndex != -1 && dgvAnalista.Columns[e.ColumnIndex].Name.ToUpper() == "ATIVO")
                    {
                        string Responsavel = this.dgvAnalista.Rows[e.RowIndex].Cells["NomeResponsavel"].Value.ToString();

                        DialogResult result;
                        bool status;
                        if (Convert.ToBoolean(dgvAnalista.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString()))
                        {
                            result = MessageBox.Show("Deseja mesmo inativar " + Responsavel + "?\nO cadastro do usuário permanecerá salvo.", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                            status = false;
                        }
                        else
                        {
                            result = MessageBox.Show("Deseja mesmo ativar " + Responsavel + "?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                            status = true;
                        }

                        if (result == DialogResult.Yes)
                        {
                            int ID_Responsavel = Convert.ToInt32(this.dgvAnalista.Rows[e.RowIndex].Cells["ID_Responsavel"].Value);

                            DataAccess.AtivarUsuario(ID_Responsavel, status);
                            BindDataGrid();

                            if (!status)
                            {
                                Log.GravaLog("Cria arquivo de atualzação de acesso: " + UserSelecionado);
                                SharedData.CriaArquivoAcesso(UserSelecionado);
                            }
                        }
                    }
                    if (e.RowIndex != -1 && dgvAnalista.Columns[e.ColumnIndex].Name.ToUpper() == "GESTOR")
                    {
                        string Responsavel = this.dgvAnalista.Rows[e.RowIndex].Cells["NomeResponsavel"].Value.ToString();

                        DialogResult result;
                        bool status;
                        if (Convert.ToBoolean(dgvAnalista.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString()))
                        {
                            result = MessageBox.Show("Retirar acesso gestor de " + Responsavel + "?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                            status = false;
                        }
                        else
                        {
                            result = MessageBox.Show("Tornar " + Responsavel + " um usuário gestor?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                            status = true;
                        }

                        if (result == DialogResult.Yes)
                        {
                            int ID_Responsavel = Convert.ToInt32(this.dgvAnalista.Rows[e.RowIndex].Cells["ID_Responsavel"].Value);

                            DataAccess.AtivarUsuarioGestor(ID_Responsavel, status);
                            BindDataGrid();
                            Log.GravaLog("Cria arquivo de atualzação de acesso: " + UserSelecionado);
                            SharedData.CriaArquivoAcesso(UserSelecionado);
                        }
                    }
                }
            }
        }

        private void dgvAnalista_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex != -1 && dgvAnalista.Columns[e.ColumnIndex].Name.ToUpper() == "ATIVO")
            {
                if (Convert.ToBoolean(e.Value) == true)
                    e.CellStyle.BackColor = Color.Green;
                else
                    e.CellStyle.BackColor = Color.Red;
            }
        }

        private void dgvAnalista_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                if (Convert.ToBoolean(dgvAnalista.Rows[e.RowIndex].Cells["ATIVO"].Value))
                {
                    string Login = this.dgvAnalista.Rows[e.RowIndex].Cells["LoginResponsavel"].Value.ToString();
                    string Funcional = this.dgvAnalista.Rows[e.RowIndex].Cells["Funcional"].Value.ToString();
                    bool Gestor = Convert.ToBoolean(this.dgvAnalista.Rows[e.RowIndex].Cells["Gestor"].Value);
                    int Id = Convert.ToInt32(this.dgvAnalista.Rows[e.RowIndex].Cells["ID_Responsavel"].Value);
                    string Nome = this.dgvAnalista.Rows[e.RowIndex].Cells["NomeResponsavel"].Value.ToString();

                    this.txtIdResp.Text = Id.ToString();
                    this.txtFuncional.Text = Funcional;
                    this.txtLogin.Text = Login;
                    this.chkGestor.Checked = Gestor;
                    this.txtNome.Text = Nome;

                    this.txtLogin.Enabled = false;

                    dgvAcessos.DataSource = null;
                    _AcessosDataSource = _AreasCelulasResponsavel.Where(n => n.ID_Responsavel == Id).GroupBy(x => new { x.ID_Area, x.ID_Celula }).Select(g => g.First()).OrderBy(y => y.NomeArea).ThenBy(z => z.NomeCelula).ToList();
                    dgvAcessos.DataSource = _AcessosDataSource;
                    cboArea.SelectedValue = 0;

                    this.btnAtualizar.Visible = true;
                    this.btnCadastrar.Visible = false;
                }
                else
                {
                    MessageBox.Show("O usuário está inativo.\n\nPara editar o cadastro, reative o usuário.", "Usuário Inativo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void dgvAcessos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1 && dgvAcessos.Columns[e.ColumnIndex].Name == "RemoverAcesso")
            {
                string NomeCelula = this.dgvAcessos.Rows[e.RowIndex].Cells["NomeCelula"].Value.ToString();
                int IdCel = Convert.ToInt32(this.dgvAcessos.Rows[e.RowIndex].Cells["IdCelula"].Value);
                DialogResult result = MessageBox.Show("Remover acesso a " + NomeCelula + "?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    Responsavel Cel = _AcessosDataSource.Find(n => n.ID_Celula == IdCel);
                    if (Cel != null)
                    {
                        _AcessosDataSource.Remove(Cel);
                        dgvAcessos.DataSource = null;
                        dgvAcessos.DataSource = _AcessosDataSource;
                        cboArea.SelectedValue = 0;
                    }
                }
            }
        }
        #endregion

        #region [ Filtro ]
        private void Filtro()
        {
            if ((dgvAnalista.DataSource as DataTable) != null)
            {
                if (_filtrar == true)
                {
                    _filtrar = false;
                    bool first = true;
                    string filter = string.Empty;

                    foreach (DataRow c in CamposFiltro.Rows)
                    {
                        string obj = "";
                        if (c["TipoCampo"].ToString().ToUpper() == "TEXTBOX" || c["TipoCampo"].ToString() == "COMBOBOX")
                        {
                            obj = this.groupBox1.Controls[c["NomeCampo"].ToString()].Text;
                        }
                        else if (c["TipoCampo"].ToString() == "CHECKBOX")
                        {
                            if (this.groupBox1.Controls[c["NomeCampo"].ToString()].Text == "SIM")
                            {
                                obj = "true";
                            }
                            else if (this.groupBox1.Controls[c["NomeCampo"].ToString()].Text == "NÃO")
                            {
                                obj = "false";
                            }
                        }

                        if (obj != null)
                        {
                            if (obj != "")
                            {
                                if (c["TipoCampo"].ToString().ToUpper() == "CHECKBOX")
                                {
                                    if (first)
                                    {
                                        filter = string.Format("{0} = {1}", c["NomeColuna"].ToString(), obj);
                                        first = false;
                                    }
                                    else
                                        filter += string.Format(" AND {0} = {1}", c["NomeColuna"].ToString(), obj);
                                }
                                else if (this.checkBox_valores_exatos.Checked)
                                {
                                    if (first)
                                    {
                                        filter = string.Format("{0} = '{1}'", c["NomeColuna"].ToString(), obj);
                                        first = false;
                                    }
                                    else
                                        filter += string.Format(" AND {0} = '{1}'", c["NomeColuna"].ToString(), obj);
                                }
                                else
                                {
                                    if (first)
                                    {
                                        filter = string.Format("{0} LIKE '%{1}%'", c["NomeColuna"].ToString(), obj);
                                        first = false;
                                    }
                                    else
                                        filter += string.Format(" AND {0} LIKE '%{1}%'", c["NomeColuna"].ToString(), obj);
                                }

                            }

                        }
                    }
                    _filtro = filter;
                }
                (dgvAnalista.DataSource as DataTable).DefaultView.RowFilter = _filtro;
            }
        }

        private void button_filtro_Click(object sender, EventArgs e)
        {
            _filtrar = true;
            Filtro();
        }

        private void btnLimparFiltro_Click(object sender, EventArgs e)
        {
            foreach (DataRow c in CamposFiltro.Rows)
            {
                if (c["TipoCampo"].ToString().ToUpper() == "TEXTBOX" || c["TipoCampo"].ToString().ToUpper() == "COMBOBOX" || c["TipoCampo"].ToString().ToUpper() == "CHECKBOX")
                {
                    this.groupBox1.Controls[c["NomeCampo"].ToString()].Text = "";
                }
            }
            this.txtIdResp.Text = "";
            this.chkGestor.Checked = false;
            this.txtLogin.Enabled = true;
            this.btnAtualizar.Visible = false;
            this.btnCadastrar.Visible = true;
            if (_AcessosDataSource.Count > 0)
            {
                _AcessosDataSource.RemoveRange(0, _AcessosDataSource.Count);
                dgvAcessos.DataSource = null;
                dgvAcessos.DataSource = _AcessosDataSource;
            }
            _filtrar = true;
            Filtro();
        }
        #endregion

        #region [ buttons ]
        private void btnAll_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in this.dgvAnalista.Rows)
            {
                if (row.Index != -1)
                {
                    if (row.Cells["LoginResponsavel"].Value.ToString().ToUpper() == Environment.UserName.ToUpper())
                    {
                        row.Cells["Selecionar"].Value = false;
                    }
                    else
                    {
                        row.Cells["Selecionar"].Value = true;
                    }
                }
            }
        }
        private void btnNone_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in this.dgvAnalista.Rows)
            {
                if (row.Index != -1)
                {
                    row.Cells["Selecionar"].Value = false;
                }
            }
        }
        private void btnExcluir_Click(object sender, EventArgs e)
        {
            List<int> IdServicoExcluir = new List<int>();

            foreach (DataGridViewRow row in this.dgvAnalista.Rows)
            {
                if (row.Index != -1)
                {
                    bool checkd = Convert.ToBoolean(row.Cells["Selecionar"].Value);

                    if (checkd)
                    {
                        IdServicoExcluir.Add(Convert.ToInt32(row.Cells["ID_Responsavel"].Value));
                    }
                }
            }

            if (IdServicoExcluir.Count > 0)
            {
                if (MessageBox.Show(IdServicoExcluir.Count + " " + (IdServicoExcluir.Count == 1 ? "Usuário selecionado." : "Usuários selecionados") + "\n\nEsta ação excluirá permanentemente o usuário do sistema.\n\nConfirma exclusão?", "Mobios", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    DataAccess.ExcluirUsuarioLote(IdServicoExcluir);
                    BindDataGrid();
                    MessageBox.Show("Usuários excluídos", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Nenhum usuário selecionado.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void btnDesativar_Click(object sender, EventArgs e)
        {
            AtualizarStatusUsuarioLote(false);
        }
        private void btnAtivar_Click(object sender, EventArgs e)
        {
            AtualizarStatusUsuarioLote(true);
        }
        private void AtualizarStatusUsuarioLote(bool status)
        {
            List<int> IdServicoCancelar = new List<int>();

            foreach (DataGridViewRow row in this.dgvAnalista.Rows)
            {
                if (row.Index != -1)
                {
                    bool checkd = Convert.ToBoolean(row.Cells["Selecionar"].Value);

                    if (checkd)
                    {
                        IdServicoCancelar.Add(Convert.ToInt32(row.Cells["ID_Responsavel"].Value));
                    }
                }
            }

            if (IdServicoCancelar.Count > 0)
            {
                if (MessageBox.Show(IdServicoCancelar.Count + " " + (IdServicoCancelar.Count == 1 ? "Usuário selecionado." : "Usuários selecionados") + "\n\n" + (status ? "Confirma ativar usuários?" : "Confirma inativar usuários?"), "Mobios", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    DataAccess.AtivarUsuarioLote(IdServicoCancelar, status);
                    BindDataGrid();
                    MessageBox.Show("Alterações realizadas.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Nenhum usuário selecionado.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        
        private void btnArea_Click(object sender, EventArgs e)
        {
            if (!SharedData.isOpenForm(typeof(Areas), false))
            {
                using (Form frm = new Areas())
                {
                    frm.ShowDialog();
                }
            }
        }
        private void btnDgvAcesso_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(cboCelula.SelectedValue) != 0)
            {
                Responsavel Cel = (Responsavel)(cboCelula.SelectedItem);
                if (!_AcessosDataSource.Exists(n => n.ID_Celula == Cel.ID_Celula))
                {
                    _AcessosDataSource.Add(Cel);
                    dgvAcessos.DataSource = null;
                    dgvAcessos.DataSource = _AcessosDataSource;
                    cboArea.SelectedValue = 0;
                }
                else
                {
                    MessageBox.Show("Acesso já adicionado à lista", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Selecione uma área e célula!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
        #endregion
        
        private void cboArea_SelectedValueChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(cboArea.SelectedValue) != 0)
            {
                cboCelula.Enabled = true;
                List<Responsavel> FiltroCelula = _AreasCelulas.Where(n => n.ID_Area == Convert.ToInt32(cboArea.SelectedValue) || n.ID_Area == 0).OrderBy(x => x.NomeCelula).ToList();
                if (_AcessosDataSource.Count() > 0)
                {
                    List<Responsavel> _cboCelulaDataSource = new List<Responsavel>();
                    foreach (Responsavel r in FiltroCelula)
                    {
                        if (!_AcessosDataSource.Exists(n => n.ID_Celula == r.ID_Celula))
                        {
                            _cboCelulaDataSource.Add(r);
                        }
                    }
                    cboCelula.DataSource = _cboCelulaDataSource;
                }
                else
                {
                    cboCelula.DataSource = FiltroCelula;
                }
                cboCelula.SelectedValue = 0;
            }
            else
            {
                cboCelula.DataSource = _AreasCelulas.Where(n => n.ID_Area == 0).ToList();
                cboCelula.SelectedValue = 0;
                cboCelula.Enabled = false;
            }
        }
        
    }
}

