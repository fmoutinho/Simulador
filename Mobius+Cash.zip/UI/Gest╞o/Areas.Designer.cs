﻿namespace Mobios
{
    partial class Areas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Areas));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtIdArea = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.btnCadastrar = new System.Windows.Forms.Button();
            this.lblNomeArea = new System.Windows.Forms.Label();
            this.AreasCadastradas = new System.Windows.Forms.GroupBox();
            this.dgvAreas= new System.Windows.Forms.DataGridView();
            this.Selecionar = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.ID_Area = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NomeArea = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ativo = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.RemoverArea = new System.Windows.Forms.DataGridViewImageColumn();
            this.btnDesativar = new System.Windows.Forms.Button();
            this.btnAtivar = new System.Windows.Forms.Button();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.btnNone = new System.Windows.Forms.Button();
            this.btnAll = new System.Windows.Forms.Button();
            this.btnLimparFiltro = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.AreasCadastradas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAreas)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnLimparFiltro);
            this.groupBox1.Controls.Add(this.txtIdArea);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtNome);
            this.groupBox1.Controls.Add(this.btnCadastrar);
            this.groupBox1.Controls.Add(this.lblNomeArea);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(427, 77);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cadastrar";
            // 
            // txtIdArea
            // 
            this.txtIdArea.Enabled = false;
            this.txtIdArea.Location = new System.Drawing.Point(29, 19);
            this.txtIdArea.Name = "txtIdArea";
            this.txtIdArea.Size = new System.Drawing.Size(47, 20);
            this.txtIdArea.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "ID";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(114, 20);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(296, 20);
            this.txtNome.TabIndex = 3;
            // 
            // btnCadastrar
            // 
            this.btnCadastrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCadastrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCadastrar.Image = ((System.Drawing.Image)(resources.GetObject("btnCadastrar.Image")));
            this.btnCadastrar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCadastrar.Location = new System.Drawing.Point(258, 45);
            this.btnCadastrar.Name = "btnCadastrar";
            this.btnCadastrar.Size = new System.Drawing.Size(78, 23);
            this.btnCadastrar.TabIndex = 2;
            this.btnCadastrar.Text = "Cadastrar";
            this.btnCadastrar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCadastrar.UseVisualStyleBackColor = true;
            this.btnCadastrar.Click += new System.EventHandler(this.btnCadastrar_Click);
            // 
            // lblNomeArea
            // 
            this.lblNomeArea.AutoSize = true;
            this.lblNomeArea.Location = new System.Drawing.Point(82, 22);
            this.lblNomeArea.Name = "lblNomeArea";
            this.lblNomeArea.Size = new System.Drawing.Size(29, 13);
            this.lblNomeArea.TabIndex = 0;
            this.lblNomeArea.Text = "Área";
            this.lblNomeArea.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // AreasCadastradas
            // 
            this.AreasCadastradas.Controls.Add(this.dgvAreas);
            this.AreasCadastradas.Location = new System.Drawing.Point(12, 95);
            this.AreasCadastradas.Name = "AreasCadastradas";
            this.AreasCadastradas.Size = new System.Drawing.Size(430, 181);
            this.AreasCadastradas.TabIndex = 2;
            this.AreasCadastradas.TabStop = false;
            this.AreasCadastradas.Text = "Áreas Cadastradas";
            // 
            // dgvAreas
            // 
            this.dgvAreas.AllowUserToAddRows = false;
            this.dgvAreas.AllowUserToDeleteRows = false;
            this.dgvAreas.BackgroundColor = System.Drawing.Color.White;
            this.dgvAreas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAreas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Selecionar,
            this.ID_Area,
            this.NomeArea,
            this.Ativo,
            this.RemoverArea});
            this.dgvAreas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAreas.Location = new System.Drawing.Point(3, 16);
            this.dgvAreas.Name = "dgvAreas";
            this.dgvAreas.RowHeadersVisible = false;
            this.dgvAreas.Size = new System.Drawing.Size(424, 162);
            this.dgvAreas.TabIndex = 0;
            this.dgvAreas.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAreas_CellClick);
            this.dgvAreas.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAreas_CellDoubleClick);
            this.dgvAreas.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvAreas_CellFormatting);
            // 
            // Selecionar
            // 
            this.Selecionar.HeaderText = "";
            this.Selecionar.Name = "Selecionar";
            this.Selecionar.Width = 30;
            // 
            // ID_Area
            // 
            this.ID_Area.DataPropertyName = "ID_AREA";
            this.ID_Area.HeaderText = "ID_Area";
            this.ID_Area.Name = "ID_Area";
            this.ID_Area.ReadOnly = true;
            this.ID_Area.Visible = false;
            // 
            // NomeArea
            // 
            this.NomeArea.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.NomeArea.DataPropertyName = "NomeArea";
            this.NomeArea.HeaderText = "Nome";
            this.NomeArea.Name = "NomeArea";
            this.NomeArea.ReadOnly = true;
            this.NomeArea.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // Ativo
            // 
            this.Ativo.DataPropertyName = "AtivoArea";
            this.Ativo.HeaderText = "Ativa";
            this.Ativo.Name = "Ativo";
            this.Ativo.ReadOnly = true;
            this.Ativo.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Ativo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Ativo.Width = 40;
            // 
            // RemoverArea
            // 
            this.RemoverArea.HeaderText = "";
            this.RemoverArea.Image = ((System.Drawing.Image)(resources.GetObject("RemoverArea.Image")));
            this.RemoverArea.Name = "RemoverArea";
            this.RemoverArea.ReadOnly = true;
            this.RemoverArea.Width = 30;
            // 
            // btnDesativar
            // 
            this.btnDesativar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDesativar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDesativar.Image = ((System.Drawing.Image)(resources.GetObject("btnDesativar.Image")));
            this.btnDesativar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDesativar.Location = new System.Drawing.Point(306, 280);
            this.btnDesativar.Name = "btnDesativar";
            this.btnDesativar.Size = new System.Drawing.Size(68, 23);
            this.btnDesativar.TabIndex = 19;
            this.btnDesativar.Text = "Inativar";
            this.btnDesativar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDesativar.UseVisualStyleBackColor = true;
            this.btnDesativar.Click += new System.EventHandler(this.btnDesativar_Click);
            // 
            // btnAtivar
            // 
            this.btnAtivar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAtivar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAtivar.Image = ((System.Drawing.Image)(resources.GetObject("btnAtivar.Image")));
            this.btnAtivar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAtivar.Location = new System.Drawing.Point(243, 280);
            this.btnAtivar.Name = "btnAtivar";
            this.btnAtivar.Size = new System.Drawing.Size(60, 23);
            this.btnAtivar.TabIndex = 18;
            this.btnAtivar.Text = "Ativar";
            this.btnAtivar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAtivar.UseVisualStyleBackColor = true;
            this.btnAtivar.Click += new System.EventHandler(this.btnAtivar_Click);
            // 
            // btnExcluir
            // 
            this.btnExcluir.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExcluir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnExcluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcluir.Image = ((System.Drawing.Image)(resources.GetObject("btnExcluir.Image")));
            this.btnExcluir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExcluir.Location = new System.Drawing.Point(376, 280);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(63, 23);
            this.btnExcluir.TabIndex = 17;
            this.btnExcluir.Text = "Excluir";
            this.btnExcluir.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExcluir.UseVisualStyleBackColor = false;
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // btnNone
            // 
            this.btnNone.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNone.Image = ((System.Drawing.Image)(resources.GetObject("btnNone.Image")));
            this.btnNone.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNone.Location = new System.Drawing.Point(128, 280);
            this.btnNone.Name = "btnNone";
            this.btnNone.Size = new System.Drawing.Size(112, 23);
            this.btnNone.TabIndex = 16;
            this.btnNone.Text = "Desmarcar todos";
            this.btnNone.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNone.UseVisualStyleBackColor = true;
            this.btnNone.Click += new System.EventHandler(this.btnNone_Click);
            // 
            // btnAll
            // 
            this.btnAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAll.Image = ((System.Drawing.Image)(resources.GetObject("btnAll.Image")));
            this.btnAll.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAll.Location = new System.Drawing.Point(15, 280);
            this.btnAll.Name = "btnAll";
            this.btnAll.Size = new System.Drawing.Size(111, 23);
            this.btnAll.TabIndex = 15;
            this.btnAll.Text = "Selecionar todos";
            this.btnAll.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAll.UseVisualStyleBackColor = true;
            this.btnAll.Click += new System.EventHandler(this.btnAll_Click);
            // 
            // btnLimparFiltro
            // 
            this.btnLimparFiltro.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLimparFiltro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLimparFiltro.Image = ((System.Drawing.Image)(resources.GetObject("btnLimparFiltro.Image")));
            this.btnLimparFiltro.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLimparFiltro.Location = new System.Drawing.Point(342, 45);
            this.btnLimparFiltro.Name = "btnLimparFiltro";
            this.btnLimparFiltro.Size = new System.Drawing.Size(68, 23);
            this.btnLimparFiltro.TabIndex = 15;
            this.btnLimparFiltro.Text = "Limpar";
            this.btnLimparFiltro.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLimparFiltro.UseVisualStyleBackColor = true;
            this.btnLimparFiltro.Click += new System.EventHandler(this.btnLimparFiltro_Click);
            // 
            // Areas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(460, 312);
            this.Controls.Add(this.btnDesativar);
            this.Controls.Add(this.btnAtivar);
            this.Controls.Add(this.btnExcluir);
            this.Controls.Add(this.btnNone);
            this.Controls.Add(this.btnAll);
            this.Controls.Add(this.AreasCadastradas);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Areas";
            this.Text = "Cadastro de Áreas de Atuação";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Areas_FormClosed);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.AreasCadastradas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAreas)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Button btnCadastrar;
        private System.Windows.Forms.Label lblNomeArea;
        private System.Windows.Forms.GroupBox AreasCadastradas;
        private System.Windows.Forms.DataGridView dgvAreas;
        private System.Windows.Forms.Button btnDesativar;
        private System.Windows.Forms.Button btnAtivar;
        private System.Windows.Forms.Button btnExcluir;
        private System.Windows.Forms.Button btnNone;
        private System.Windows.Forms.Button btnAll;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Selecionar;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_Area;
        private System.Windows.Forms.DataGridViewTextBoxColumn NomeArea;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Ativo;
        private System.Windows.Forms.DataGridViewImageColumn RemoverArea;
        private System.Windows.Forms.TextBox txtIdArea;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLimparFiltro;
    }
}