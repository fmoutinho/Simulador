﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mobios
{
    public partial class Areas : Form
    {
        public Areas()
        {
            InitializeComponent();
            this.dgvAreas.AutoGenerateColumns = false;
            BindDataGrid();
        }

        private void BindDataGrid()
        {
            this.dgvAreas.DataSource = TratamentoCampo.ConvertListToDataTable(DataAccess.buscarAreas());
            //Filtro();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            string txt = this.txtNome.Text.Trim();

            if (txt != string.Empty)
            {
                if (this.txtIdArea.Text == "")
                {
                    List<Area> targetTable = new List<Area>();
                    targetTable = DataAccess.buscarAreas(txt);
                    if (targetTable.Count == 0)
                    {
                        DataAccess.SalvarArea(txt);
                        MessageBox.Show("Área cadastrada!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        BindDataGrid();
                        btnLimparFiltro.PerformClick();
                    }
                    else
                    {
                        MessageBox.Show("Já consta uma área cadastrada com este nome!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        BindDataGrid();
                    }
                }
                else
                {
                    DataAccess.AtualizaArea(Convert.ToInt32(txtIdArea.Text), txt);
                    MessageBox.Show("Área atualizada!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    BindDataGrid();
                    btnLimparFiltro.PerformClick();
                }
            }
        }

        private void dgvAreas_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1 && dgvAreas.Columns[e.ColumnIndex].Name == "RemoverArea")
            {
                string Area = this.dgvAreas.Rows[e.RowIndex].Cells["NomeArea"].Value.ToString();
                DialogResult result = MessageBox.Show("Deseja mesmo excluir " + Area + "?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    int ID_Area = Convert.ToInt32(this.dgvAreas.Rows[e.RowIndex].Cells["ID_Area"].Value);

                    DataAccess.ExcluirArea(ID_Area);
                    BindDataGrid();
                    MessageBox.Show("Área excluída.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnLimparFiltro.PerformClick();
                }
            }
            if (e.RowIndex != -1 && dgvAreas.Columns[e.ColumnIndex].Name.ToUpper() == "ATIVO")
            {
                string Area = this.dgvAreas.Rows[e.RowIndex].Cells["NomeArea"].Value.ToString();

                DialogResult result;
                bool status;
                if (Convert.ToBoolean(dgvAreas.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString()))
                {
                    result = MessageBox.Show("Deseja mesmo inativar " + Area + "?\nO cadastro da área permanecerá salvo.", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    status = false;
                }
                else
                {
                    result = MessageBox.Show("Deseja mesmo ativar " + Area + "?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    status = true;
                }

                if (result == DialogResult.Yes)
                {
                    int ID_Area = Convert.ToInt32(this.dgvAreas.Rows[e.RowIndex].Cells["ID_Area"].Value);

                    DataAccess.AtivarArea(ID_Area, status);
                    BindDataGrid();
                    MessageBox.Show("Status alterado.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void dgvAreas_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex != -1 && dgvAreas.Columns[e.ColumnIndex].Name.ToUpper() == "ATIVO")
            {
                if (Convert.ToBoolean(e.Value) == true)
                    e.CellStyle.BackColor = Color.Green;
                else
                    e.CellStyle.BackColor = Color.Red;
            }
        }

        #region [ buttons ]
        private void btnAll_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in this.dgvAreas.Rows)
            {
                if (row.Index != -1)
                {
                    row.Cells["Selecionar"].Value = true;
                }
            }
        }

        private void btnNone_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in this.dgvAreas.Rows)
            {
                if (row.Index != -1)
                {
                    row.Cells["Selecionar"].Value = false;
                }
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            List<int> IdServicoExcluir = new List<int>();

            foreach (DataGridViewRow row in this.dgvAreas.Rows)
            {
                if (row.Index != -1)
                {
                    bool checkd = Convert.ToBoolean(row.Cells["Selecionar"].Value);

                    if (checkd)
                    {
                        IdServicoExcluir.Add(Convert.ToInt32(row.Cells["ID_Area"].Value));
                    }
                }
            }

            if (IdServicoExcluir.Count > 0)
            {
                if (MessageBox.Show(IdServicoExcluir.Count + " " + (IdServicoExcluir.Count == 1 ? "Área selecionada." : "Áreas selecionadas") + "\n\nEsta ação excluirá permanentemente do sistema.\n\nConfirma exclusão?", "Mobios", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    DataAccess.ExcluirAreaLote(IdServicoExcluir);
                    MessageBox.Show("Áreas excluídas com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    BindDataGrid();
                }
            }
            else
            {
                MessageBox.Show("Nenhuma área selecionada.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnDesativar_Click(object sender, EventArgs e)
        {
            AtualizarStatusAreaLote(false);
        }

        private void btnAtivar_Click(object sender, EventArgs e)
        {
            AtualizarStatusAreaLote(true);
        }

        private void AtualizarStatusAreaLote(bool status)
        {
            List<int> IdServicoCancelar = new List<int>();

            foreach (DataGridViewRow row in this.dgvAreas.Rows)
            {
                if (row.Index != -1)
                {
                    bool checkd = Convert.ToBoolean(row.Cells["Selecionar"].Value);

                    if (checkd)
                    {
                        IdServicoCancelar.Add(Convert.ToInt32(row.Cells["ID_Area"].Value));
                    }
                }
            }

            if (IdServicoCancelar.Count > 0)
            {
                if (MessageBox.Show(IdServicoCancelar.Count + " " + (IdServicoCancelar.Count == 1 ? "Área selecionada." : "Áreas selecionadas") + "\n\n" + (status ? "Confirma ativar áreas?" : "Confirma inativar áreas?"), "Mobios", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    DataAccess.AtivarAreaLote(IdServicoCancelar, status);
                    MessageBox.Show("Alterações realizadas.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    BindDataGrid();
                }
            }
            else
            {
                MessageBox.Show("Nenhuma área selecionada.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        #endregion

        private void Areas_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (SharedData.isOpenForm(typeof(Analistas), false))
            {
                ((Analistas)Application.OpenForms["Analistas"]).BindDataGrid();
            }
        }

        private void dgvAreas_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                string Area = this.dgvAreas.Rows[e.RowIndex].Cells["NomeArea"].Value.ToString();
                string Id = this.dgvAreas.Rows[e.RowIndex].Cells["ID_Area"].Value.ToString();

                this.txtIdArea.Text = Id;
                this.txtNome.Text = Area;
            }
        }

        private void btnLimparFiltro_Click(object sender, EventArgs e)
        {
            this.txtIdArea.Text = string.Empty;
            this.txtNome.Text = string.Empty;
        }

    }
}
