﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mobios
{
    public partial class Associar : Form
    {
        public Associar()
        {
            InitializeComponent();

            this.cboAnalista.DataSource = DataAccess.BuscarAnalistas();
            this.cboProduto.DataSource = DataAccess.BuscarProdutos();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cboAnalista_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.dgvProduto.DataSource = DataAccess.BuscarProdutosAssociados(this.cboAnalista.SelectedValue.ToString());
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            DataAccess.Associar(this.cboAnalista.SelectedValue.ToString(), (int)this.cboProduto.SelectedValue);
            this.dgvProduto.DataSource = DataAccess.BuscarProdutosAssociados(this.cboAnalista.SelectedValue.ToString());

            MessageBox.Show("Associação realizada com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void dgvProduto_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1 && e.ColumnIndex == 0)
            {
                DialogResult result = MessageBox.Show("Deseja mesmo excluir?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    string idProduto = this.dgvProduto.Rows[e.RowIndex].Cells["Id"].Value.ToString();
                    string login = this.cboAnalista.SelectedValue.ToString();

                    DataAccess.ApagarAssociacao(idProduto, login);
                    this.dgvProduto.DataSource = DataAccess.BuscarProdutosAssociados(login);
                    MessageBox.Show("Associação excluída com sucesso.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
    }
}
