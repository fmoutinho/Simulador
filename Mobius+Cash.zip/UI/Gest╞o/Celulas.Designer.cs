﻿namespace Mobios
{
    partial class Celulas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Celulas));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.btnPesquisar = new System.Windows.Forms.Button();
            this.NomeCelula = new System.Windows.Forms.Label();
            this.CelulasCadastradas = new System.Windows.Forms.GroupBox();
            this.dgvCelulas = new System.Windows.Forms.DataGridView();
            this.ID_Celula = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NomeResponsavel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.X = new System.Windows.Forms.DataGridViewImageColumn();
            this.groupBox1.SuspendLayout();
            this.CelulasCadastradas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCelulas)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtNome);
            this.groupBox1.Controls.Add(this.btnPesquisar);
            this.groupBox1.Controls.Add(this.NomeCelula);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(381, 59);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cadastrar";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(72, 19);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(210, 20);
            this.txtNome.TabIndex = 3;
            // 
            // btnPesquisar
            // 
            this.btnPesquisar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPesquisar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPesquisar.Location = new System.Drawing.Point(288, 17);
            this.btnPesquisar.Name = "btnPesquisar";
            this.btnPesquisar.Size = new System.Drawing.Size(75, 23);
            this.btnPesquisar.TabIndex = 2;
            this.btnPesquisar.Text = "Cadastrar";
            this.btnPesquisar.UseVisualStyleBackColor = true;
            // 
            // NomeCelula
            // 
            this.NomeCelula.AutoSize = true;
            this.NomeCelula.Location = new System.Drawing.Point(32, 22);
            this.NomeCelula.Name = "NomeCelula";
            this.NomeCelula.Size = new System.Drawing.Size(36, 13);
            this.NomeCelula.TabIndex = 0;
            this.NomeCelula.Text = "Célula";
            this.NomeCelula.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CelulasCadastradas
            // 
            this.CelulasCadastradas.Controls.Add(this.dgvCelulas);
            this.CelulasCadastradas.Location = new System.Drawing.Point(12, 76);
            this.CelulasCadastradas.Name = "CelulasCadastradas";
            this.CelulasCadastradas.Size = new System.Drawing.Size(381, 181);
            this.CelulasCadastradas.TabIndex = 2;
            this.CelulasCadastradas.TabStop = false;
            this.CelulasCadastradas.Text = "Células Cadastradas";
            // 
            // dgvCelulas
            // 
            this.dgvCelulas.AllowUserToAddRows = false;
            this.dgvCelulas.AllowUserToDeleteRows = false;
            this.dgvCelulas.BackgroundColor = System.Drawing.Color.White;
            this.dgvCelulas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCelulas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID_Celula,
            this.NomeResponsavel,
            this.X});
            this.dgvCelulas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCelulas.Location = new System.Drawing.Point(3, 16);
            this.dgvCelulas.Name = "dgvCelulas";
            this.dgvCelulas.ReadOnly = true;
            this.dgvCelulas.RowHeadersVisible = false;
            this.dgvCelulas.Size = new System.Drawing.Size(375, 162);
            this.dgvCelulas.TabIndex = 0;
            // 
            // ID_Celula
            // 
            this.ID_Celula.DataPropertyName = "ID_CELULA";
            this.ID_Celula.HeaderText = "ID_Celula";
            this.ID_Celula.Name = "ID_Celula";
            this.ID_Celula.ReadOnly = true;
            this.ID_Celula.Visible = false;
            // 
            // NomeResponsavel
            // 
            this.NomeResponsavel.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.NomeResponsavel.DataPropertyName = "NomeResponsavel";
            this.NomeResponsavel.HeaderText = "Nome";
            this.NomeResponsavel.Name = "NomeResponsavel";
            this.NomeResponsavel.ReadOnly = true;
            this.NomeResponsavel.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // X
            // 
            this.X.HeaderText = "";
            this.X.Image = ((System.Drawing.Image)(resources.GetObject("X.Image")));
            this.X.Name = "X";
            this.X.ReadOnly = true;
            this.X.Width = 30;
            // 
            // Celulas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(405, 270);
            this.Controls.Add(this.CelulasCadastradas);
            this.Controls.Add(this.groupBox1);
            this.Name = "Celulas";
            this.Text = "Cadastro de Células de Atendimento";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.CelulasCadastradas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCelulas)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Button btnPesquisar;
        private System.Windows.Forms.Label NomeCelula;
        private System.Windows.Forms.GroupBox CelulasCadastradas;
        private System.Windows.Forms.DataGridView dgvCelulas;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_Celula;
        private System.Windows.Forms.DataGridViewTextBoxColumn NomeResponsavel;
        private System.Windows.Forms.DataGridViewImageColumn X;
    }
}