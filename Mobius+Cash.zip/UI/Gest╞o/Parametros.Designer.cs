﻿namespace Mobios
{
    partial class Parametros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Parametros));
            this.grpParametros = new System.Windows.Forms.GroupBox();
            this.dgvParametros = new System.Windows.Forms.DataGridView();
            this.btnAtualizar = new System.Windows.Forms.Button();
            this.NomeParametro = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ValorParametro = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Descrição = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grpParametros.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvParametros)).BeginInit();
            this.SuspendLayout();
            // 
            // grpParametros
            // 
            this.grpParametros.Controls.Add(this.dgvParametros);
            this.grpParametros.Location = new System.Drawing.Point(12, 12);
            this.grpParametros.Name = "grpParametros";
            this.grpParametros.Size = new System.Drawing.Size(902, 451);
            this.grpParametros.TabIndex = 2;
            this.grpParametros.TabStop = false;
            this.grpParametros.Text = "Parâmetros";
            // 
            // dgvParametros
            // 
            this.dgvParametros.AllowUserToAddRows = false;
            this.dgvParametros.AllowUserToDeleteRows = false;
            this.dgvParametros.BackgroundColor = System.Drawing.Color.White;
            this.dgvParametros.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvParametros.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.NomeParametro,
            this.ValorParametro,
            this.Descrição});
            this.dgvParametros.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvParametros.Location = new System.Drawing.Point(3, 16);
            this.dgvParametros.Name = "dgvParametros";
            this.dgvParametros.RowHeadersVisible = false;
            this.dgvParametros.Size = new System.Drawing.Size(896, 432);
            this.dgvParametros.TabIndex = 0;
            // 
            // btnAtualizar
            // 
            this.btnAtualizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAtualizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAtualizar.Image = ((System.Drawing.Image)(resources.GetObject("btnAtualizar.Image")));
            this.btnAtualizar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAtualizar.Location = new System.Drawing.Point(837, 469);
            this.btnAtualizar.Name = "btnAtualizar";
            this.btnAtualizar.Size = new System.Drawing.Size(74, 23);
            this.btnAtualizar.TabIndex = 18;
            this.btnAtualizar.Text = "Salvar";
            this.btnAtualizar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAtualizar.UseVisualStyleBackColor = true;
            this.btnAtualizar.Click += new System.EventHandler(this.btnAtualizar_Click);
            // 
            // NomeParametro
            // 
            this.NomeParametro.DataPropertyName = "Nome";
            this.NomeParametro.HeaderText = "Nome";
            this.NomeParametro.Name = "NomeParametro";
            this.NomeParametro.ReadOnly = true;
            this.NomeParametro.Width = 200;
            // 
            // ValorParametro
            // 
            this.ValorParametro.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ValorParametro.DataPropertyName = "Valor";
            this.ValorParametro.HeaderText = "Valor";
            this.ValorParametro.Name = "ValorParametro";
            this.ValorParametro.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // Descrição
            // 
            this.Descrição.DataPropertyName = "Descrição";
            this.Descrição.HeaderText = "Descrição";
            this.Descrição.Name = "Descrição";
            this.Descrição.Width = 400;
            // 
            // Parametros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(935, 501);
            this.Controls.Add(this.btnAtualizar);
            this.Controls.Add(this.grpParametros);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Parametros";
            this.Text = "Cadastro de Parâmetros";
            this.grpParametros.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvParametros)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpParametros;
        private System.Windows.Forms.DataGridView dgvParametros;
        private System.Windows.Forms.Button btnAtualizar;
        private System.Windows.Forms.DataGridViewTextBoxColumn NomeParametro;
        private System.Windows.Forms.DataGridViewTextBoxColumn ValorParametro;
        private System.Windows.Forms.DataGridViewTextBoxColumn Descrição;
    }
}