﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mobios
{
    public partial class Parametros : Form
    {
        public Parametros()
        {
            InitializeComponent();
            this.dgvParametros.AutoGenerateColumns = false;
            BindDataGrid();
        }

        private void BindDataGrid()
        {
            this.dgvParametros.DataSource = null;
            this.dgvParametros.DataSource = SharedData.Parametros;
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            if ((dgvParametros.DataSource as DataTable) != null)
            {
                DataTable dt = (dgvParametros.DataSource as DataTable).DefaultView.ToTable().Copy();
                DataAccess.SalvarParametrosLote(dt);
                DataAccess.GetParametros();
                BindDataGrid();
                MessageBox.Show("Parâmetros Atualizados");
            }
        }
    }
}
