﻿namespace Mobios
{
    partial class Produtos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Produtos));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtNovo = new System.Windows.Forms.TextBox();
            this.btnPesquisar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Analis = new System.Windows.Forms.GroupBox();
            this.dgvProduto = new System.Windows.Forms.DataGridView();
            this.ID_OBJETO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NomeObjeto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CategoriaObjeto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.X = new System.Windows.Forms.DataGridViewImageColumn();
            this.btnFechar = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCategoria = new System.Windows.Forms.TextBox();
            this.ckBoxAtivo = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.Analis.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProduto)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.ckBoxAtivo);
            this.groupBox1.Controls.Add(this.txtCategoria);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtNovo);
            this.groupBox1.Controls.Add(this.btnPesquisar);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 9);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(460, 93);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cadastrar novo";
            // 
            // txtNovo
            // 
            this.txtNovo.Location = new System.Drawing.Point(61, 16);
            this.txtNovo.Name = "txtNovo";
            this.txtNovo.Size = new System.Drawing.Size(391, 20);
            this.txtNovo.TabIndex = 3;
            // 
            // btnPesquisar
            // 
            this.btnPesquisar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPesquisar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPesquisar.Location = new System.Drawing.Point(377, 64);
            this.btnPesquisar.Name = "btnPesquisar";
            this.btnPesquisar.Size = new System.Drawing.Size(75, 23);
            this.btnPesquisar.TabIndex = 2;
            this.btnPesquisar.Text = "Cadastrar";
            this.btnPesquisar.UseVisualStyleBackColor = true;
            this.btnPesquisar.Click += new System.EventHandler(this.btnPesquisar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Produto:";
            // 
            // Analis
            // 
            this.Analis.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Analis.Controls.Add(this.dgvProduto);
            this.Analis.Location = new System.Drawing.Point(12, 108);
            this.Analis.Name = "Analis";
            this.Analis.Size = new System.Drawing.Size(460, 280);
            this.Analis.TabIndex = 0;
            this.Analis.TabStop = false;
            this.Analis.Text = "Produtos";
            // 
            // dgvProduto
            // 
            this.dgvProduto.AllowUserToAddRows = false;
            this.dgvProduto.AllowUserToDeleteRows = false;
            this.dgvProduto.BackgroundColor = System.Drawing.Color.White;
            this.dgvProduto.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProduto.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID_OBJETO,
            this.NomeObjeto,
            this.CategoriaObjeto,
            this.X});
            this.dgvProduto.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvProduto.Location = new System.Drawing.Point(3, 16);
            this.dgvProduto.Name = "dgvProduto";
            this.dgvProduto.ReadOnly = true;
            this.dgvProduto.RowHeadersVisible = false;
            this.dgvProduto.Size = new System.Drawing.Size(454, 261);
            this.dgvProduto.TabIndex = 0;
            this.dgvProduto.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProduto_CellClick);
            // 
            // ID_OBJETO
            // 
            this.ID_OBJETO.DataPropertyName = "ID_OBJETO";
            this.ID_OBJETO.HeaderText = "ID";
            this.ID_OBJETO.Name = "ID_OBJETO";
            this.ID_OBJETO.ReadOnly = true;
            this.ID_OBJETO.Visible = false;
            // 
            // NomeObjeto
            // 
            this.NomeObjeto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.NomeObjeto.DataPropertyName = "NomeObjeto";
            this.NomeObjeto.HeaderText = "Nome";
            this.NomeObjeto.Name = "NomeObjeto";
            this.NomeObjeto.ReadOnly = true;
            this.NomeObjeto.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // CategoriaObjeto
            // 
            this.CategoriaObjeto.DataPropertyName = "CategoriaObjeto";
            this.CategoriaObjeto.HeaderText = "Categoria";
            this.CategoriaObjeto.Name = "CategoriaObjeto";
            this.CategoriaObjeto.ReadOnly = true;
            // 
            // X
            // 
            this.X.HeaderText = "";
            this.X.Image = ((System.Drawing.Image)(resources.GetObject("X.Image")));
            this.X.Name = "X";
            this.X.ReadOnly = true;
            this.X.Width = 30;
            // 
            // btnFechar
            // 
            this.btnFechar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFechar.Location = new System.Drawing.Point(397, 394);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(75, 23);
            this.btnFechar.TabIndex = 3;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Categoria:";
            // 
            // txtCategoria
            // 
            this.txtCategoria.Location = new System.Drawing.Point(61, 41);
            this.txtCategoria.Name = "txtCategoria";
            this.txtCategoria.Size = new System.Drawing.Size(391, 20);
            this.txtCategoria.TabIndex = 5;
            // 
            // ckBoxAtivo
            // 
            this.ckBoxAtivo.AutoSize = true;
            this.ckBoxAtivo.Location = new System.Drawing.Point(61, 67);
            this.ckBoxAtivo.Name = "ckBoxAtivo";
            this.ckBoxAtivo.Size = new System.Drawing.Size(50, 17);
            this.ckBoxAtivo.TabIndex = 6;
            this.ckBoxAtivo.Text = "Ativo";
            this.ckBoxAtivo.UseVisualStyleBackColor = true;
            // 
            // Produtos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(484, 429);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.Analis);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Produtos";
            this.ShowIcon = false;
            this.Text = "Cadastro de Produtos";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.Analis.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProduto)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox Analis;
        private System.Windows.Forms.DataGridView dgvProduto;
        private System.Windows.Forms.Button btnPesquisar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnFechar;
        private System.Windows.Forms.TextBox txtNovo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_OBJETO;
        private System.Windows.Forms.DataGridViewTextBoxColumn NomeObjeto;
        private System.Windows.Forms.DataGridViewTextBoxColumn CategoriaObjeto;
        private System.Windows.Forms.DataGridViewImageColumn X;
        private System.Windows.Forms.CheckBox ckBoxAtivo;
        private System.Windows.Forms.TextBox txtCategoria;
        private System.Windows.Forms.Label label2;
    }
}