﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mobios
{
    public partial class Produtos : Form
    {
        public Produtos()
        {
            InitializeComponent();

            this.dgvProduto.AutoGenerateColumns = false;
            this.dgvProduto.DataSource = DataAccess.BuscarProdutos();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            if (this.txtNovo.Text != string.Empty)
            {
                Objeto obj = new Objeto();
                obj.NomeObjeto = this.txtNovo.Text;
                obj.CategoriaObjeto = this.txtCategoria.Text;
                obj.AtivoObjeto = this.ckBoxAtivo.Checked;

                DataAccess.SalvarProduto(obj);
                MessageBox.Show("Produto Cadastrado!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.dgvProduto.DataSource = DataAccess.BuscarProdutos();
                this.txtNovo.Text = string.Empty;
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvProduto_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string NomeObjeto = this.dgvProduto.Rows[e.RowIndex].Cells["NomeObjeto"].Value.ToString();
            if (e.RowIndex != -1 && e.ColumnIndex == 3)
            {
                DialogResult result = MessageBox.Show("Deseja mesmo excluir " + NomeObjeto + "?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    int idProduto = Convert.ToInt32(this.dgvProduto.Rows[e.RowIndex].Cells["ID_OBJETO"].Value);

                    DataAccess.ApagarProduto(idProduto);
                    this.dgvProduto.DataSource = DataAccess.BuscarProdutos();
                    MessageBox.Show("Produto excluído com sucesso.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
    }
}
