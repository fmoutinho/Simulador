﻿namespace Mobios
{
    partial class Atribuir
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Atribuir));
            this.label1 = new System.Windows.Forms.Label();
            this.cboAnalista = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnCadastrar = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dgvOp = new System.Windows.Forms.DataGridView();
            this.NovoResponsavel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IdNovoResponsavel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Espaço = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnNone = new System.Windows.Forms.Button();
            this.btnAll = new System.Windows.Forms.Button();
            this.btnRedirecionar = new System.Windows.Forms.Button();
            this.btnFechar = new System.Windows.Forms.Button();
            this.btnLimparFiltro = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOp)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(245, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Analista:";
            // 
            // cboAnalista
            // 
            this.cboAnalista.DisplayMember = "NomeResponsavel";
            this.cboAnalista.FormattingEnabled = true;
            this.cboAnalista.Location = new System.Drawing.Point(298, 20);
            this.cboAnalista.Name = "cboAnalista";
            this.cboAnalista.Size = new System.Drawing.Size(445, 21);
            this.cboAnalista.TabIndex = 1;
            this.cboAnalista.Tag = "";
            this.cboAnalista.ValueMember = "IdResponsavel";
            this.cboAnalista.SelectedValueChanged += new System.EventHandler(this.cboAnalista_SelectedValueChanged);
            this.cboAnalista.Enter += new System.EventHandler(this.cboAnalista_Enter);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.btnLimparFiltro);
            this.groupBox1.Controls.Add(this.btnCadastrar);
            this.groupBox1.Controls.Add(this.btnNone);
            this.groupBox1.Controls.Add(this.btnAll);
            this.groupBox1.Controls.Add(this.cboAnalista);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(4, 394);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1094, 53);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Definir Analista";
            // 
            // btnCadastrar
            // 
            this.btnCadastrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCadastrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCadastrar.Image = ((System.Drawing.Image)(resources.GetObject("btnCadastrar.Image")));
            this.btnCadastrar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCadastrar.Location = new System.Drawing.Point(749, 18);
            this.btnCadastrar.Name = "btnCadastrar";
            this.btnCadastrar.Size = new System.Drawing.Size(79, 23);
            this.btnCadastrar.TabIndex = 3;
            this.btnCadastrar.Text = "Cadastrar";
            this.btnCadastrar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCadastrar.UseVisualStyleBackColor = true;
            this.btnCadastrar.Click += new System.EventHandler(this.btnCadastrar_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.dgvOp);
            this.groupBox2.Location = new System.Drawing.Point(4, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1094, 376);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Operações";
            // 
            // dgvOp
            // 
            this.dgvOp.AllowUserToAddRows = false;
            this.dgvOp.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.AliceBlue;
            this.dgvOp.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvOp.BackgroundColor = System.Drawing.Color.White;
            this.dgvOp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOp.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.NovoResponsavel,
            this.IdNovoResponsavel,
            this.Espaço});
            this.dgvOp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvOp.EnableHeadersVisualStyles = false;
            this.dgvOp.Location = new System.Drawing.Point(3, 16);
            this.dgvOp.Name = "dgvOp";
            this.dgvOp.RowHeadersVisible = false;
            this.dgvOp.Size = new System.Drawing.Size(1088, 357);
            this.dgvOp.TabIndex = 0;
            this.dgvOp.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvOp_CellContentClick);
            this.dgvOp.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvOp_CellFormatting);
            // 
            // NovoResponsavel
            // 
            this.NovoResponsavel.Frozen = true;
            this.NovoResponsavel.HeaderText = "Novo Responsável";
            this.NovoResponsavel.Name = "NovoResponsavel";
            this.NovoResponsavel.ReadOnly = true;
            this.NovoResponsavel.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.NovoResponsavel.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.NovoResponsavel.Width = 150;
            // 
            // IdNovoResponsavel
            // 
            this.IdNovoResponsavel.Frozen = true;
            this.IdNovoResponsavel.HeaderText = "IdNovoResponsavel";
            this.IdNovoResponsavel.Name = "IdNovoResponsavel";
            this.IdNovoResponsavel.ReadOnly = true;
            this.IdNovoResponsavel.Visible = false;
            // 
            // Espaço
            // 
            this.Espaço.Frozen = true;
            this.Espaço.HeaderText = "";
            this.Espaço.Name = "Espaço";
            this.Espaço.ReadOnly = true;
            this.Espaço.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Espaço.Width = 50;
            // 
            // btnNone
            // 
            this.btnNone.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNone.Image = ((System.Drawing.Image)(resources.GetObject("btnNone.Image")));
            this.btnNone.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNone.Location = new System.Drawing.Point(125, 18);
            this.btnNone.Name = "btnNone";
            this.btnNone.Size = new System.Drawing.Size(112, 23);
            this.btnNone.TabIndex = 31;
            this.btnNone.Text = "Desmarcar todos";
            this.btnNone.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNone.UseVisualStyleBackColor = true;
            this.btnNone.Click += new System.EventHandler(this.btnNone_Click);
            // 
            // btnAll
            // 
            this.btnAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAll.Image = ((System.Drawing.Image)(resources.GetObject("btnAll.Image")));
            this.btnAll.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAll.Location = new System.Drawing.Point(9, 18);
            this.btnAll.Name = "btnAll";
            this.btnAll.Size = new System.Drawing.Size(111, 23);
            this.btnAll.TabIndex = 30;
            this.btnAll.Text = "Selecionar todos";
            this.btnAll.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAll.UseVisualStyleBackColor = true;
            this.btnAll.Click += new System.EventHandler(this.btnAll_Click);
            // 
            // btnRedirecionar
            // 
            this.btnRedirecionar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRedirecionar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRedirecionar.Image = ((System.Drawing.Image)(resources.GetObject("btnRedirecionar.Image")));
            this.btnRedirecionar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRedirecionar.Location = new System.Drawing.Point(925, 462);
            this.btnRedirecionar.Name = "btnRedirecionar";
            this.btnRedirecionar.Size = new System.Drawing.Size(95, 23);
            this.btnRedirecionar.TabIndex = 29;
            this.btnRedirecionar.Text = "Redirecionar";
            this.btnRedirecionar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRedirecionar.UseVisualStyleBackColor = true;
            this.btnRedirecionar.Click += new System.EventHandler(this.btnRedirecionar_Click);
            // 
            // btnFechar
            // 
            this.btnFechar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFechar.Image = ((System.Drawing.Image)(resources.GetObject("btnFechar.Image")));
            this.btnFechar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFechar.Location = new System.Drawing.Point(1026, 462);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(69, 23);
            this.btnFechar.TabIndex = 28;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // btnLimparFiltro
            // 
            this.btnLimparFiltro.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLimparFiltro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLimparFiltro.Image = ((System.Drawing.Image)(resources.GetObject("btnLimparFiltro.Image")));
            this.btnLimparFiltro.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLimparFiltro.Location = new System.Drawing.Point(834, 18);
            this.btnLimparFiltro.Name = "btnLimparFiltro";
            this.btnLimparFiltro.Size = new System.Drawing.Size(86, 23);
            this.btnLimparFiltro.TabIndex = 32;
            this.btnLimparFiltro.Text = "  Reset";
            this.btnLimparFiltro.UseVisualStyleBackColor = true;
            this.btnLimparFiltro.Click += new System.EventHandler(this.btnLimparFiltro_Click);
            // 
            // Atribuir
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1103, 488);
            this.Controls.Add(this.btnRedirecionar);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Atribuir";
            this.ShowIcon = false;
            this.Text = "Redirecionar operações";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Atribuir_FormClosed);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOp)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cboAnalista;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dgvOp;
        private System.Windows.Forms.Button btnNone;
        private System.Windows.Forms.Button btnAll;
        private System.Windows.Forms.Button btnRedirecionar;
        private System.Windows.Forms.Button btnFechar;
        private System.Windows.Forms.Button btnLimparFiltro;
        private System.Windows.Forms.Button btnCadastrar;
        private System.Windows.Forms.DataGridViewTextBoxColumn NovoResponsavel;
        private System.Windows.Forms.DataGridViewTextBoxColumn IdNovoResponsavel;
        private System.Windows.Forms.DataGridViewTextBoxColumn Espaço;
    }
}