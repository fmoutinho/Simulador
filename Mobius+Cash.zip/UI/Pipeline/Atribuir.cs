﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace Mobios
{
    public partial class Atribuir : Form
    {
        List<ResponsavelCelula> _ResponsavelCelula = new List<ResponsavelCelula>();
        List<FluxoValidaResponsavel> _ValidaResponsavel = new List<FluxoValidaResponsavel>();

        public Atribuir(DataTable Pipeline, DataGridView DataGridEstrutura)
        {
            InitializeComponent();
            this.dgvOp.AutoGenerateColumns = false;
            foreach (DataGridViewColumn col in DataGridEstrutura.Columns)
            {
                this.dgvOp.Columns.Add((DataGridViewColumn)col.Clone());
            }
            this.dgvOp.DataSource = Pipeline;
            
            DataTable dt = (dgvOp.DataSource as DataTable).DefaultView.ToTable().Copy();
            List<int> IdCelulasAcessadas = new List<int>();
            if (dt != null)
            {
                IdCelulasAcessadas = dt.AsEnumerable().Select(s => s.Field<int>("ID_Celula")).Distinct().ToList();
            }

            _ResponsavelCelula = DataAccess.BuscarAcessoCelula(IdCelulasAcessadas);

            if (!SharedData.User.FLG_AutoProc)
            {
                _ResponsavelCelula = _ResponsavelCelula.Where(s => s.FLG_AutoProc == false).ToList();
            }
        }

        private void btnRedirecionar_Click(object sender, EventArgs e) 
        {
            try
            {
                List<FluxoServico> NovoResponsavel = new List<FluxoServico>();

                foreach (DataGridViewRow row in this.dgvOp.Rows)
                {
                    if (row.Index != -1)
                    {
                        if (row.Cells["NovoResponsavel"].Value != null && row.Cells["NovoResponsavel"].Value.ToString() != "")
                        {
                            FluxoServico Resp = new FluxoServico();
                            Resp.IdResponsavel = Convert.ToInt32(row.Cells["IdNovoResponsavel"].Value);
                            Resp.ID_Fluxo = Convert.ToInt32(row.Cells["ID_Fluxo"].Value);
                            Resp.ID_Servico = Convert.ToInt32(row.Cells["ID_SERVICO"].Value);
                            Resp.ID_Objeto = Convert.ToInt32(row.Cells["ID_OBJETO"].Value);
                            NovoResponsavel.Add(Resp);
                            Log.GravaLog("Alterando responsáveis - Serviço: " + Resp.ID_Servico + " - Fluxo: " + Resp.ID_Fluxo + " - Responsável: " + Resp.IdResponsavel);
                        }
                    }
                }

                if (NovoResponsavel.Count > 0)
                {
                    if (MessageBox.Show("Transferir responsáveis?", "MOBIOS+", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        List<EtapasObjeto> EtapasObj = new List<EtapasObjeto>();
                        #region [ Atribui todas as etapas ao mesmo usuário ]
                        if (SharedData.gAtribuiResponsavelServico)
                        {
                            EtapasObj = SharedData.gEtapasObjeto;

                            List<FluxoServico> RespServico = new List<FluxoServico>();
                            foreach (FluxoServico f in NovoResponsavel)
                            {
                                List<EtapasObjeto> EtapasObjFiltro = EtapasObj.FindAll(n => n.ID_Objeto == f.ID_Objeto && n.ID_Etapa != f.ID_Fluxo);
                                foreach (EtapasObjeto etp in EtapasObjFiltro)
                                {
                                    FluxoServico Resp = new FluxoServico();
                                    Resp.IdResponsavel = f.IdResponsavel;
                                    Resp.ID_Fluxo = etp.ID_Etapa;
                                    Resp.ID_Servico = f.ID_Servico;
                                    Resp.ID_Objeto = f.ID_Objeto;
                                    RespServico.Add(Resp);
                                }
                            }
                            if (RespServico.Count > 0)
                            {
                                NovoResponsavel.AddRange(RespServico);
                            }
                        }
                        #endregion

                        #region [ altera responsável que deve assumir um grupo de etapas ]
                        if (SharedData.gValidaMesmoResponsavel)
                        {
                            EtapasObj = SharedData.gEtapasObjeto;

                            List<FluxoServico> RespEtapas = new List<FluxoServico>();
                            foreach (FluxoServico f in NovoResponsavel)
                            {
                                EtapasObjeto EtapasIDMesmoResponsavel = new EtapasObjeto();
                                EtapasIDMesmoResponsavel = EtapasObj.Find(n => n.ID_Objeto == f.ID_Objeto && n.ID_Etapa == f.ID_Fluxo);

                                if (EtapasIDMesmoResponsavel != null)
                                {
                                    f.IdMesmoResponsavel = EtapasIDMesmoResponsavel.IdMesmoResponsavel;
                                }

                                List<EtapasObjeto> EtapasObjFiltro = EtapasObj.FindAll(n => n.ID_Objeto == f.ID_Objeto && n.ID_Etapa != f.ID_Fluxo && n.IdMesmoResponsavel == f.IdMesmoResponsavel);
                                foreach (EtapasObjeto etp in EtapasObjFiltro)
                                {
                                    FluxoServico Resp = new FluxoServico();
                                    Resp.IdResponsavel = f.IdResponsavel;
                                    Resp.ID_Fluxo = etp.ID_Etapa;
                                    Resp.ID_Servico = f.ID_Servico;
                                    Resp.ID_Objeto = f.ID_Objeto;
                                    RespEtapas.Add(Resp);
                                }
                            }
                            if (RespEtapas.Count > 0)
                            {
                                NovoResponsavel.AddRange(RespEtapas);
                            }
                        }
                        #endregion

                        #region [ Altera responsável dependente da etapa ]
                        if (SharedData.gValidaDependenciaResponsavel)
                        {
                            _ValidaResponsavel = DataAccess.BuscaResponsavelValidaFluxo();
                            
                            List<FluxoServico> limparResponsavel = new List<FluxoServico>();
                            foreach (FluxoServico r in NovoResponsavel)
                            {
                                List<FluxoValidaResponsavel> validaResp = _ValidaResponsavel.FindAll(n => n.ID_Servico == r.ID_Servico && n.ID_Etapa == r.ID_Fluxo && n.ID_Fluxo != r.ID_Fluxo && n.IdResponsavel == r.IdResponsavel);

                                foreach (FluxoValidaResponsavel v in validaResp)
                                {
                                    FluxoServico f = new FluxoServico();
                                    f.IdResponsavel = 0;
                                    f.ID_Fluxo = v.ID_Fluxo;
                                    f.ID_Servico = v.ID_Servico;
                                    limparResponsavel.Add(f);
                                    Log.GravaLog("Alterando responsáveis - Serviço: " + f.ID_Servico + " - Fluxo: " + f.ID_Fluxo + " - Responsável: " + f.IdResponsavel);
                                }
                            }
                            if (limparResponsavel.Count > 0)
                            {
                                NovoResponsavel.AddRange(limparResponsavel);
                            }
                        }
                        #endregion

                        DataAccess.AtribuirResponsavelFluxoLote(NovoResponsavel);

                        foreach (DataGridViewRow row in this.dgvOp.Rows)
                        {
                            if (row.Index != -1)
                            {
                                if (row.Cells["NovoResponsavel"].Value != null && row.Cells["NovoResponsavel"].Value.ToString() != "")
                                {
                                    if (row.Cells["NovoResponsavel"].Value.ToString() != "Sem Responsável")
                                    {
                                        row.Cells["ResponsavelFluxo"].Value = row.Cells["NovoResponsavel"].Value;
                                    }
                                    else
                                    {
                                        row.Cells["ResponsavelFluxo"].Value = "";
                                    }
                                    row.Cells["NovoResponsavel"].Value = "";
                                }
                                if (Convert.ToBoolean(row.Cells["Selecionar"].Value) == true)
                                {
                                    row.Cells["Selecionar"].Value = false;
                                }

                            }
                        }

                        cboAnalista.SelectedValue = 0;

                        MessageBox.Show("Serviços redirecionados.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Nenhuma alteração de responsável cadastrada.", "MOBIOS+", MessageBoxButtons.OK);
                }
            }
            catch(Exception err)
            {
                MessageBox.Show(err.Message,"Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Log.GravaLog(err.Message);
            }
            
        }

        private void btnAll_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in this.dgvOp.Rows)
            {
                if (row.Index != -1)
                {
                    row.Cells["Selecionar"].Value = true;
                }
            }
            cboAnalista.SelectedValue = 0;
        }

        private void btnNone_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in this.dgvOp.Rows)
            {
                if (row.Index != -1)
                {
                    row.Cells["Selecionar"].Value = false;
                }
            }
            cboAnalista.SelectedValue = 0;
        }

        private void btnLimparFiltro_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Limpar lista de Novos Responsáveis?", "MOBIOS+", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                foreach (DataGridViewRow r in dgvOp.Rows)
                {
                    r.Cells["NovoResponsavel"].Value = "";
                }
            }
            cboAnalista.SelectedValue = 0;
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Atribuir_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (SharedData.isOpenForm(typeof(Pipeline), false))
            {
                ((Pipeline)Application.OpenForms["Pipeline"]).Bind();
            }
        }

        private void dgvOp_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1 && dgvOp.Columns[e.ColumnIndex].Name.ToUpper() == "SELECIONAR")
            {
                cboAnalista.SelectedValue = 0;
            }
        }

        private void cboAnalista_Enter(object sender, EventArgs e)
        {
            cboAnalista.DataSource = BuscaAnalistasRedirecionar();
        }

        private List<ResponsavelCelula> BuscaAnalistasRedirecionar()
        {
            List<int> IdCelulas = new List<int>();
            foreach (DataGridViewRow row in this.dgvOp.Rows)
            {
                if (row.Index != -1)
                {
                    if (Convert.ToBoolean(row.Cells["Selecionar"].Value) == true)
                    {
                        IdCelulas.Add(Convert.ToInt32(row.Cells["ID_Celula"].Value));
                    }
                }
            }

            IdCelulas = IdCelulas.Distinct().ToList();

            List<ResponsavelCelula> list = new List<ResponsavelCelula>();
            ResponsavelCelula SemResp = new ResponsavelCelula();
            SemResp.NomeResponsavel = "Sem Responsável";
            SemResp.IdResponsavel = 0;
            list.Add(SemResp);

            if (IdCelulas.Count > 0)
            {
                List<ResponsavelCelula> conjuntoCelulas = new List<ResponsavelCelula>();
                List<int> IdResponsaveis = _ResponsavelCelula.Select(n => n.IdResponsavel).Distinct().ToList();

                foreach (int resp in IdResponsaveis)
                {
                    foreach (int cel in IdCelulas)
                    {
                        ResponsavelCelula conjunto = new ResponsavelCelula();
                        conjunto.IdResponsavel = resp;
                        conjunto.IdCelula = cel;
                        conjuntoCelulas.Add(conjunto);
                    }
                }

                List<int> AnalistasSemAcesso = new List<int>();                
                foreach(ResponsavelCelula conj in conjuntoCelulas)
                {
                    ResponsavelCelula temp = new ResponsavelCelula();
                    temp = _ResponsavelCelula.Find(n => n.IdResponsavel == conj.IdResponsavel && n.IdCelula == conj.IdCelula);
                    if (temp == null)
                    {
                        AnalistasSemAcesso.Add(conj.IdResponsavel);
                    }
                }
                
                AnalistasSemAcesso = AnalistasSemAcesso.Distinct().ToList();
                
                List<ResponsavelCelula> Analistas = new List<ResponsavelCelula>();

                Analistas = _ResponsavelCelula.GroupBy(n => n.IdResponsavel).Select(g => g.First()).Where(n => AnalistasSemAcesso.IndexOf(n.IdResponsavel) == -1).ToList();
                list.AddRange(Analistas);    
            }
            return list;
            
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in this.dgvOp.Rows)
            {
                if (row.Index != -1)
                {
                    if (Convert.ToBoolean(row.Cells["Selecionar"].Value) == true)
                    {
                        row.Cells["NovoResponsavel"].Value = cboAnalista.Text;
                        row.Cells["IdNovoResponsavel"].Value = cboAnalista.SelectedValue;
                    }
                }
            }
        }

        private void cboAnalista_SelectedValueChanged(object sender, EventArgs e)
        {
        }

        private void dgvOp_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex != -1 && dgvOp.Columns[e.ColumnIndex].Name.ToUpper() == "ESPAÇO")
            {
                    e.CellStyle.BackColor = Color.Gray;
            }
        }
    }
}
