﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mobios
{
    public partial class PersonalizarPipe : Form
    {
        int id_Resp;
        public bool Feito = false;

        public PersonalizarPipe(int Responsavel)
        {

            InitializeComponent();
            id_Resp = Responsavel;
            bool Padrao = false;
            

            DataTable dt = new DataTable();

            //dt=BaseDados.getData("SELECT * FROM CAMPOS_PIPE_RESP WHERE ATIVO=-1 And id_responsavel=" + id_Resp +" And Sistema=0 Order by ordem", true);

            if (dt.Rows.Count == 0)
            {
                //dt = BaseDados.getData("SELECT * FROM CAMPOS_PIPE WHERE ATIVO=-1 And Sistema=0 Order by ordem", true);
                Padrao = true;
            }


            for (int i = 0; i < dt.Rows.Count; i++)
            {

                TreeNode n = new TreeNode();

                n.Text = dt.Rows[i]["Descricao"].ToString();
                n.Tag = dt.Rows[i]["Nome"].ToString() + ";" + dt.Rows[i]["Tipo"].ToString();

                TV.Nodes.Add(n);

                if(Padrao==true)
                    TV.Nodes[i].Checked = true;
                else
                    TV.Nodes[i].Checked = Convert.ToBoolean( dt.Rows[i]["Visivel"].ToString());

            }


        }

        private void btnUp_Click(object sender, EventArgs e)
        {


            if (TV.SelectedNode.Index == 0) return;

            TreeNode parent = TV.Nodes[TV.SelectedNode.Index-1] ;
            TreeNode node = TV.SelectedNode;

            int Posicao = node.Index;

            TV.Nodes.Remove(parent);
            TV.Nodes.Insert(Posicao, parent);



        }

        private void btnDown_Click(object sender, EventArgs e)
        {

            if (TV.SelectedNode.Index == TV.Nodes.Count - 1) return;

            TreeNode parent = TV.Nodes[TV.SelectedNode.Index + 1];
            TreeNode node = TV.SelectedNode;

            int Posicao = node.Index;

            TV.Nodes.Remove(parent);
            TV.Nodes.Insert(Posicao, parent);

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {

            this.Close();

        }

        private void btnGrav_Click(object sender, EventArgs e)
        {

            //BaseDados.setData("DELETE FROM CAMPOS_PIPE_RESP WHERE ID_RESPONSAVEL=" + id_Resp, true);
            List<string> SQL = new List<string>();

            SQL.Add("INSERT INTO CAMPOS_PIPE_RESP (TIPO, ID_RESPONSAVEL, NOME, DESCRICAO, SISTEMA, ORDEM, ATIVO, VISIVEL) VALUES ('T', " + id_Resp + ", 'ID_OBJETO', 'ID_OBJETO', -1, 1, -1, -1)");
            SQL.Add("INSERT INTO CAMPOS_PIPE_RESP (TIPO, ID_RESPONSAVEL, NOME, DESCRICAO, SISTEMA, ORDEM, ATIVO, VISIVEL) VALUES ('T', " + id_Resp + ", 'ID_SERVICO', 'ID_SERVICO', -1, 2, -1, -1)");
            SQL.Add("INSERT INTO CAMPOS_PIPE_RESP (TIPO, ID_RESPONSAVEL, NOME, DESCRICAO, SISTEMA, ORDEM, ATIVO, VISIVEL) VALUES ('T', " + id_Resp + ", 'Usuario', 'Tratador', -1, 3, -1, -1)");
            

            for (int i = 0; i < TV.Nodes.Count; i++)
            {

                string[] P = TV.Nodes[i].Tag.ToString().Split(';');

                SQL.Add("INSERT INTO CAMPOS_PIPE_RESP (TIPO, ID_RESPONSAVEL, NOME, DESCRICAO, SISTEMA, ORDEM, ATIVO, VISIVEL) VALUES ('"+ P[1] +"', " + id_Resp + ", '" + P[0] + "', '" + TV.Nodes[i].Text + "', 0, " + (i + 4) + ", -1, " + (TV.Nodes[i].Checked == true ? -1 : 0) + ")");

            }

            //BaseDados.setData(SQL, true);

            Feito = true;

            this.Close();

        }
    }
}
