﻿namespace Mobios
{
    partial class Pipeline
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Pipeline));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.botPer = new System.Windows.Forms.PictureBox();
            this.label_registros = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.img_loading = new System.Windows.Forms.PictureBox();
            this.button_exportar_datagrid = new System.Windows.Forms.Button();
            this.bindingNavigator1 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cboAnalista = new System.Windows.Forms.ComboBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.rdCelula = new System.Windows.Forms.RadioButton();
            this.rdResponsavel = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.btnAll = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnNone = new System.Windows.Forms.Button();
            this.btnRedirect = new System.Windows.Forms.Button();
            this.cmb_ListMethod = new System.Windows.Forms.ComboBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnPlayMethod = new System.Windows.Forms.Button();
            this.chkAtualizaAuto = new System.Windows.Forms.CheckBox();
            this.label_ListMethod = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.grpfiltro = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button_filtro = new System.Windows.Forms.Button();
            this.checkBox_valores_exatos = new System.Windows.Forms.CheckBox();
            this.btnLimparFiltro = new System.Windows.Forms.Button();
            this.panel_filtro = new System.Windows.Forms.Panel();
            this.pnlFiltro = new System.Windows.Forms.Panel();
            this.dgvOp = new Mobios.SuperGrid();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.botPer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_loading)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).BeginInit();
            this.bindingNavigator1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.grpfiltro.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pnlFiltro.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOp)).BeginInit();
            this.SuspendLayout();
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            this.backgroundWorker1.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker1_RunWorkerCompleted);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.dgvOp);
            this.groupBox2.Controls.Add(this.bindingNavigator1);
            this.groupBox2.Controls.Add(this.panel1);
            this.groupBox2.Location = new System.Drawing.Point(12, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1125, 356);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Operações";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button_exportar_datagrid);
            this.panel1.Controls.Add(this.img_loading);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.btnRefresh);
            this.panel1.Controls.Add(this.label_registros);
            this.panel1.Controls.Add(this.botPer);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(3, 16);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1119, 35);
            this.panel1.TabIndex = 1;
            // 
            // botPer
            // 
            this.botPer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.botPer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.botPer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.botPer.Image = ((System.Drawing.Image)(resources.GetObject("botPer.Image")));
            this.botPer.Location = new System.Drawing.Point(996, 4);
            this.botPer.Name = "botPer";
            this.botPer.Size = new System.Drawing.Size(29, 26);
            this.botPer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.botPer.TabIndex = 8;
            this.botPer.TabStop = false;
            this.botPer.Visible = false;
            this.botPer.Click += new System.EventHandler(this.botPer_Click);
            // 
            // label_registros
            // 
            this.label_registros.AutoSize = true;
            this.label_registros.Location = new System.Drawing.Point(86, 11);
            this.label_registros.Name = "label_registros";
            this.label_registros.Size = new System.Drawing.Size(66, 13);
            this.label_registros.TabIndex = 0;
            this.label_registros.Text = "Qtd registros";
            // 
            // btnRefresh
            // 
            this.btnRefresh.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefresh.Image = ((System.Drawing.Image)(resources.GetObject("btnRefresh.Image")));
            this.btnRefresh.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRefresh.Location = new System.Drawing.Point(1031, 4);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(28, 28);
            this.btnRefresh.TabIndex = 19;
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Visible = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(926, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Personalizar";
            this.label2.Visible = false;
            // 
            // img_loading
            // 
            this.img_loading.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.img_loading.Image = ((System.Drawing.Image)(resources.GetObject("img_loading.Image")));
            this.img_loading.Location = new System.Drawing.Point(1062, 4);
            this.img_loading.Name = "img_loading";
            this.img_loading.Size = new System.Drawing.Size(28, 28);
            this.img_loading.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.img_loading.TabIndex = 2;
            this.img_loading.TabStop = false;
            // 
            // button_exportar_datagrid
            // 
            this.button_exportar_datagrid.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_exportar_datagrid.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button_exportar_datagrid.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_exportar_datagrid.Image = ((System.Drawing.Image)(resources.GetObject("button_exportar_datagrid.Image")));
            this.button_exportar_datagrid.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_exportar_datagrid.Location = new System.Drawing.Point(7, 6);
            this.button_exportar_datagrid.Name = "button_exportar_datagrid";
            this.button_exportar_datagrid.Size = new System.Drawing.Size(73, 23);
            this.button_exportar_datagrid.TabIndex = 28;
            this.button_exportar_datagrid.Text = "Exportar";
            this.button_exportar_datagrid.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_exportar_datagrid.UseVisualStyleBackColor = false;
            this.button_exportar_datagrid.Click += new System.EventHandler(this.button_exportar_datagrid_Click);
            // 
            // bindingNavigator1
            // 
            this.bindingNavigator1.AddNewItem = null;
            this.bindingNavigator1.CountItem = this.bindingNavigatorCountItem;
            this.bindingNavigator1.CountItemFormat = "de {0}";
            this.bindingNavigator1.DeleteItem = null;
            this.bindingNavigator1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem});
            this.bindingNavigator1.Location = new System.Drawing.Point(3, 51);
            this.bindingNavigator1.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bindingNavigator1.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bindingNavigator1.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bindingNavigator1.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bindingNavigator1.Name = "bindingNavigator1";
            this.bindingNavigator1.PositionItem = this.bindingNavigatorPositionItem;
            this.bindingNavigator1.Size = new System.Drawing.Size(1119, 25);
            this.bindingNavigator1.TabIndex = 2;
            this.bindingNavigator1.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            this.bindingNavigatorMoveFirstItem.Click += new System.EventHandler(this.bindingNavigatorMoveFirstItem_Click);
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            this.bindingNavigatorMovePreviousItem.Click += new System.EventHandler(this.bindingNavigatorMovePreviousItem_Click);
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 21);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            this.bindingNavigatorPositionItem.Leave += new System.EventHandler(this.bindingNavigatorPositionItem_Leave);
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(38, 22);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            this.bindingNavigatorMoveNextItem.Click += new System.EventHandler(this.bindingNavigatorMoveNextItem_Click);
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            this.bindingNavigatorMoveLastItem.Click += new System.EventHandler(this.bindingNavigatorMoveLastItem_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.panel3);
            this.groupBox1.Controls.Add(this.cboAnalista);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1124, 73);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Analista";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Analista:";
            // 
            // cboAnalista
            // 
            this.cboAnalista.DisplayMember = "NomeResponsavel";
            this.cboAnalista.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboAnalista.FormattingEnabled = true;
            this.cboAnalista.Location = new System.Drawing.Point(79, 19);
            this.cboAnalista.Name = "cboAnalista";
            this.cboAnalista.Size = new System.Drawing.Size(485, 21);
            this.cboAnalista.TabIndex = 1;
            this.cboAnalista.ValueMember = "ID_Responsavel";
            this.cboAnalista.SelectedValueChanged += new System.EventHandler(this.cboAnalista_SelectedValueChanged);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.rdResponsavel);
            this.panel3.Controls.Add(this.rdCelula);
            this.panel3.Location = new System.Drawing.Point(79, 43);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 24);
            this.panel3.TabIndex = 14;
            // 
            // rdCelula
            // 
            this.rdCelula.AutoSize = true;
            this.rdCelula.Checked = true;
            this.rdCelula.Location = new System.Drawing.Point(3, 7);
            this.rdCelula.Name = "rdCelula";
            this.rdCelula.Size = new System.Drawing.Size(54, 17);
            this.rdCelula.TabIndex = 10;
            this.rdCelula.TabStop = true;
            this.rdCelula.Text = "Célula";
            this.rdCelula.UseVisualStyleBackColor = true;
            this.rdCelula.CheckedChanged += new System.EventHandler(this.rdCelula_CheckedChanged);
            // 
            // rdResponsavel
            // 
            this.rdResponsavel.AutoSize = true;
            this.rdResponsavel.Location = new System.Drawing.Point(74, 7);
            this.rdResponsavel.Name = "rdResponsavel";
            this.rdResponsavel.Size = new System.Drawing.Size(87, 17);
            this.rdResponsavel.TabIndex = 11;
            this.rdResponsavel.Text = "Responsável";
            this.rdResponsavel.UseVisualStyleBackColor = true;
            this.rdResponsavel.CheckedChanged += new System.EventHandler(this.rdResponsavel_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "Visualização:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(986, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(68, 61);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1041, 8);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(48, 34);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 17;
            this.pictureBox2.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.groupBox2);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 218);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1153, 368);
            this.panel4.TabIndex = 63;
            // 
            // btnExcluir
            // 
            this.btnExcluir.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExcluir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnExcluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcluir.Image = ((System.Drawing.Image)(resources.GetObject("btnExcluir.Image")));
            this.btnExcluir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExcluir.Location = new System.Drawing.Point(586, 4);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(63, 23);
            this.btnExcluir.TabIndex = 25;
            this.btnExcluir.Text = "Excluir";
            this.btnExcluir.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExcluir.UseVisualStyleBackColor = false;
            this.btnExcluir.Visible = false;
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // btnAll
            // 
            this.btnAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAll.Image = ((System.Drawing.Image)(resources.GetObject("btnAll.Image")));
            this.btnAll.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAll.Location = new System.Drawing.Point(733, 4);
            this.btnAll.Name = "btnAll";
            this.btnAll.Size = new System.Drawing.Size(111, 23);
            this.btnAll.TabIndex = 26;
            this.btnAll.Text = "Selecionar todos";
            this.btnAll.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAll.UseVisualStyleBackColor = true;
            this.btnAll.Visible = false;
            this.btnAll.Click += new System.EventHandler(this.btnAll_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelar.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelar.Image")));
            this.btnCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelar.Location = new System.Drawing.Point(654, 4);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(74, 23);
            this.btnCancelar.TabIndex = 6;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Visible = false;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnNone
            // 
            this.btnNone.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNone.Image = ((System.Drawing.Image)(resources.GetObject("btnNone.Image")));
            this.btnNone.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNone.Location = new System.Drawing.Point(849, 4);
            this.btnNone.Name = "btnNone";
            this.btnNone.Size = new System.Drawing.Size(112, 23);
            this.btnNone.TabIndex = 27;
            this.btnNone.Text = "Desmarcar todos";
            this.btnNone.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNone.UseVisualStyleBackColor = true;
            this.btnNone.Visible = false;
            this.btnNone.Click += new System.EventHandler(this.btnNone_Click);
            // 
            // btnRedirect
            // 
            this.btnRedirect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRedirect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRedirect.Image = ((System.Drawing.Image)(resources.GetObject("btnRedirect.Image")));
            this.btnRedirect.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRedirect.Location = new System.Drawing.Point(966, 4);
            this.btnRedirect.Name = "btnRedirect";
            this.btnRedirect.Size = new System.Drawing.Size(95, 23);
            this.btnRedirect.TabIndex = 3;
            this.btnRedirect.Text = "Redirecionar";
            this.btnRedirect.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRedirect.UseVisualStyleBackColor = true;
            this.btnRedirect.Visible = false;
            this.btnRedirect.Click += new System.EventHandler(this.btnRedirect_Click);
            // 
            // cmb_ListMethod
            // 
            this.cmb_ListMethod.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmb_ListMethod.DisplayMember = "MethodDescricao";
            this.cmb_ListMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_ListMethod.FormattingEnabled = true;
            this.cmb_ListMethod.Location = new System.Drawing.Point(222, 5);
            this.cmb_ListMethod.Name = "cmb_ListMethod";
            this.cmb_ListMethod.Size = new System.Drawing.Size(297, 21);
            this.cmb_ListMethod.TabIndex = 60;
            this.cmb_ListMethod.ValueMember = "MethodName";
            this.cmb_ListMethod.Visible = false;
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.Location = new System.Drawing.Point(1066, 4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(69, 23);
            this.btnClose.TabIndex = 2;
            this.btnClose.Text = "Fechar";
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnPlayMethod
            // 
            this.btnPlayMethod.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnPlayMethod.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnPlayMethod.Image = ((System.Drawing.Image)(resources.GetObject("btnPlayMethod.Image")));
            this.btnPlayMethod.Location = new System.Drawing.Point(525, 4);
            this.btnPlayMethod.Name = "btnPlayMethod";
            this.btnPlayMethod.Size = new System.Drawing.Size(29, 23);
            this.btnPlayMethod.TabIndex = 62;
            this.btnPlayMethod.UseVisualStyleBackColor = false;
            this.btnPlayMethod.Visible = false;
            this.btnPlayMethod.Click += new System.EventHandler(this.btnPlayMethod_Click);
            // 
            // chkAtualizaAuto
            // 
            this.chkAtualizaAuto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.chkAtualizaAuto.AutoSize = true;
            this.chkAtualizaAuto.Image = ((System.Drawing.Image)(resources.GetObject("chkAtualizaAuto.Image")));
            this.chkAtualizaAuto.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.chkAtualizaAuto.Location = new System.Drawing.Point(11, 6);
            this.chkAtualizaAuto.Name = "chkAtualizaAuto";
            this.chkAtualizaAuto.Size = new System.Drawing.Size(147, 17);
            this.chkAtualizaAuto.TabIndex = 4;
            this.chkAtualizaAuto.Text = "Atualização Automática";
            this.chkAtualizaAuto.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.chkAtualizaAuto.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.chkAtualizaAuto.UseVisualStyleBackColor = true;
            this.chkAtualizaAuto.CheckedChanged += new System.EventHandler(this.chkAtualizaAuto_CheckedChanged);
            // 
            // label_ListMethod
            // 
            this.label_ListMethod.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label_ListMethod.AutoSize = true;
            this.label_ListMethod.Location = new System.Drawing.Point(168, 8);
            this.label_ListMethod.Name = "label_ListMethod";
            this.label_ListMethod.Size = new System.Drawing.Size(51, 13);
            this.label_ListMethod.TabIndex = 61;
            this.label_ListMethod.Text = "Métodos:";
            this.label_ListMethod.Visible = false;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.label_ListMethod);
            this.panel5.Controls.Add(this.chkAtualizaAuto);
            this.panel5.Controls.Add(this.btnPlayMethod);
            this.panel5.Controls.Add(this.btnClose);
            this.panel5.Controls.Add(this.cmb_ListMethod);
            this.panel5.Controls.Add(this.btnRedirect);
            this.panel5.Controls.Add(this.btnNone);
            this.panel5.Controls.Add(this.btnCancelar);
            this.panel5.Controls.Add(this.btnAll);
            this.panel5.Controls.Add(this.btnExcluir);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel5.Location = new System.Drawing.Point(0, 586);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1153, 33);
            this.panel5.TabIndex = 64;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.groupBox1);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1153, 94);
            this.panel6.TabIndex = 65;
            // 
            // grpfiltro
            // 
            this.grpfiltro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpfiltro.Controls.Add(this.panel_filtro);
            this.grpfiltro.Controls.Add(this.panel2);
            this.grpfiltro.Location = new System.Drawing.Point(12, 3);
            this.grpfiltro.Name = "grpfiltro";
            this.grpfiltro.Size = new System.Drawing.Size(1123, 117);
            this.grpfiltro.TabIndex = 11;
            this.grpfiltro.TabStop = false;
            this.grpfiltro.Text = "Filtro";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnLimparFiltro);
            this.panel2.Controls.Add(this.checkBox_valores_exatos);
            this.panel2.Controls.Add(this.button_filtro);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(967, 16);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(153, 98);
            this.panel2.TabIndex = 14;
            // 
            // button_filtro
            // 
            this.button_filtro.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_filtro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_filtro.Image = ((System.Drawing.Image)(resources.GetObject("button_filtro.Image")));
            this.button_filtro.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_filtro.Location = new System.Drawing.Point(6, 24);
            this.button_filtro.Name = "button_filtro";
            this.button_filtro.Size = new System.Drawing.Size(68, 23);
            this.button_filtro.TabIndex = 12;
            this.button_filtro.Text = "Filtrar";
            this.button_filtro.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_filtro.UseVisualStyleBackColor = true;
            this.button_filtro.Click += new System.EventHandler(this.button_filtro_Click);
            // 
            // checkBox_valores_exatos
            // 
            this.checkBox_valores_exatos.Location = new System.Drawing.Point(88, 36);
            this.checkBox_valores_exatos.Name = "checkBox_valores_exatos";
            this.checkBox_valores_exatos.Size = new System.Drawing.Size(64, 31);
            this.checkBox_valores_exatos.TabIndex = 13;
            this.checkBox_valores_exatos.Text = "Valores Exatos";
            this.checkBox_valores_exatos.UseVisualStyleBackColor = true;
            // 
            // btnLimparFiltro
            // 
            this.btnLimparFiltro.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLimparFiltro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLimparFiltro.Image = ((System.Drawing.Image)(resources.GetObject("btnLimparFiltro.Image")));
            this.btnLimparFiltro.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLimparFiltro.Location = new System.Drawing.Point(6, 58);
            this.btnLimparFiltro.Name = "btnLimparFiltro";
            this.btnLimparFiltro.Size = new System.Drawing.Size(68, 23);
            this.btnLimparFiltro.TabIndex = 14;
            this.btnLimparFiltro.Text = "Limpar";
            this.btnLimparFiltro.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLimparFiltro.UseVisualStyleBackColor = true;
            this.btnLimparFiltro.Click += new System.EventHandler(this.btnLimparFiltro_Click);
            // 
            // panel_filtro
            // 
            this.panel_filtro.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_filtro.Location = new System.Drawing.Point(3, 16);
            this.panel_filtro.Name = "panel_filtro";
            this.panel_filtro.Size = new System.Drawing.Size(964, 98);
            this.panel_filtro.TabIndex = 13;
            // 
            // pnlFiltro
            // 
            this.pnlFiltro.Controls.Add(this.grpfiltro);
            this.pnlFiltro.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlFiltro.Location = new System.Drawing.Point(0, 94);
            this.pnlFiltro.Name = "pnlFiltro";
            this.pnlFiltro.Size = new System.Drawing.Size(1153, 124);
            this.pnlFiltro.TabIndex = 66;
            // 
            // dgvOp
            // 
            this.dgvOp.AllowUserToAddRows = false;
            this.dgvOp.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.AliceBlue;
            this.dgvOp.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvOp.BackgroundColor = System.Drawing.Color.White;
            this.dgvOp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvOp.EnableHeadersVisualStyles = false;
            this.dgvOp.Location = new System.Drawing.Point(3, 76);
            this.dgvOp.Name = "dgvOp";
            this.dgvOp.PageSize = 10;
            this.dgvOp.RowHeadersVisible = false;
            this.dgvOp.Size = new System.Drawing.Size(1119, 277);
            this.dgvOp.TabIndex = 0;
            this.dgvOp.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvOp_CellClick);
            this.dgvOp.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvOp_CellDoubleClick);
            this.dgvOp.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvOp_CellFormatting);
            this.dgvOp.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvOp_ColumnHeaderMouseClick);
            // 
            // Pipeline
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1153, 619);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.pnlFiltro);
            this.Controls.Add(this.panel6);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(1161, 646);
            this.Name = "Pipeline";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Pipeline dos analistas";
            this.Activated += new System.EventHandler(this.Pipeline_Activated);
            this.Deactivate += new System.EventHandler(this.Pipeline_Deactivate);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Pipeline_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Pipeline_FormClosed);
            this.SizeChanged += new System.EventHandler(this.Pipeline_SizeChanged);
            this.Move += new System.EventHandler(this.Pipeline_Move);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.botPer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_loading)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).EndInit();
            this.bindingNavigator1.ResumeLayout(false);
            this.bindingNavigator1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.grpfiltro.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.pnlFiltro.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOp)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox groupBox2;
        private SuperGrid dgvOp;
        private System.Windows.Forms.BindingNavigator bindingNavigator1;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button_exportar_datagrid;
        private System.Windows.Forms.PictureBox img_loading;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Label label_registros;
        private System.Windows.Forms.PictureBox botPer;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton rdResponsavel;
        private System.Windows.Forms.RadioButton rdCelula;
        private System.Windows.Forms.ComboBox cboAnalista;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnExcluir;
        private System.Windows.Forms.Button btnAll;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnNone;
        private System.Windows.Forms.Button btnRedirect;
        private System.Windows.Forms.ComboBox cmb_ListMethod;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnPlayMethod;
        private System.Windows.Forms.CheckBox chkAtualizaAuto;
        private System.Windows.Forms.Label label_ListMethod;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.GroupBox grpfiltro;
        private System.Windows.Forms.Panel panel_filtro;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnLimparFiltro;
        private System.Windows.Forms.CheckBox checkBox_valores_exatos;
        private System.Windows.Forms.Button button_filtro;
        private System.Windows.Forms.Panel pnlFiltro;
    }
}