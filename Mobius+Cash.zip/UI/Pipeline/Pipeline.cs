﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;

namespace Mobios
{
    public partial class Pipeline : Form
    {
        #region [ Variáveis ]

        private static string msgLog;

        private static ResponsavelServico mysv; // Objeto a passar para Detalhe da Operação

        private static DataTable _Dt_ListaPipeline; //Dt_Grid

        private static DataTable _Dt_FiltroSort; //

        private static List<PipelineCampos> pipeline; //Campos a retornar para o Grid

        public ClassListMethod _MyMethod = new ClassListMethod();
        public List<ClassListMethod> _Metodos = new List<ClassListMethod>();

        #region [ Atualizar e Ordenar Pipeline ]
        private static bool bind = false;
        private int ID_Responsavel; //usado na rotina em background
        private List<int> _sb_selected_rows = new List<int>();
        private string _sortDirection = "";
        private string _sort = "";
        private int _sortIndex = -1;
        private bool _RealizarSort = false;
        private bool _pipelineAtualiza;
        private bool _pipelineAtualizaObrigatorio;
        private int _IdAnalistaSelecionado; // valida mudança de analista
        private List<PipelineCampos> _pipelineFiltro;
        private List<PipelineVisual> _MudarCorPipeline;
        private Timer t;
        private bool _FiltroPipelineAtivo;
        private string _filter;
        private bool _filtrar;
        private FormWindowState _Maximizado;
        private bool _AbrindoForm;
        #endregion
        #endregion

        public Pipeline()
        {
            InitializeComponent();

            img_loading.Visible = false;
            bind = false;
            if (_Dt_ListaPipeline != null)
            {
                _Dt_ListaPipeline.Clear();
                _Dt_ListaPipeline.Dispose();
                _Dt_ListaPipeline = null;
            }
            _Dt_ListaPipeline = new DataTable();
            this.dgvOp.AutoGenerateColumns = false;

            label_registros.Text = "";
            _pipelineFiltro = new List<PipelineCampos>();
            _MudarCorPipeline = new List<PipelineVisual>();

            if (SharedData.User.FLG_Gestor)
            {
                this.btnCancelar.Visible = true;
                this.btnExcluir.Visible = true;
                this.btnAll.Visible = true;
                this.btnNone.Visible = true;
                this.btnRedirect.Visible = true;
            }

            _FiltroPipelineAtivo = (SharedData.gPipelineFiltro);
            MontaPipeline();

            if (_FiltroPipelineAtivo == false || _pipelineFiltro.Count() == 0)
            {
                this.pnlFiltro.Visible = false;
                //this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
                //this.Height = this.Height - this.grpfiltro.Height;
                //this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            }
            else
            {
                Flutuoso f = new Flutuoso();
                //PAINEL FLUTUANTE GOSTOSO
                f.Alca.FlatStyle = FlatStyle.Standard;
                f.Alca.Text = "F I L T R O";
                f.Alca.ForeColor = Color.Yellow;
                f.Alca.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Bold);
                f.Alca.TextAlign = ContentAlignment.MiddleLeft;
                f.Alca.BackColor = Color.DarkBlue;
                //Flutuoso.Alca.BackgroundImage = Image.FromFile(oMotor.CurrentPath() + "\\FUNDO.JPG");
                f.Criar(Flutuoso.Posicao.Topo, 120, this.grpfiltro, true, true);
                //================
            }

            #region [ Timer ]
            int TimerInterval = SharedData.gTimerIntervalPipeline;
            if (TimerInterval > 0)
            {
                t = new Timer();
                t.Enabled = true;
                _pipelineAtualiza = SharedData.gPipelineAutomatico;
                chkAtualizaAuto.Checked = SharedData.gPipelineAutomatico;
                btnRefresh.Visible = !SharedData.gPipelineAutomatico;
                t.Interval = TimerInterval;
                t.Tick += t_Tick;
                //t.Enabled = true;
                t.Start();

                t.Interval = TimerInterval;
            }
            else
            {
                _pipelineAtualiza = false;
                t.Enabled = false;
            }
            _pipelineAtualizaObrigatorio = false;

            #endregion

            #region [ Seleciona Analista ]
            if (!SharedData.User.FLG_Gestor)
            {
                List<Responsavel> onlyOne = new List<Responsavel>();
                onlyOne.Add(SharedData.User);
                bind = true;
                this.cboAnalista.DataSource = onlyOne;
                this.cboAnalista.Enabled = false;
            }
            else
            {
                List<Responsavel> ListaAnalistas = new List<Responsavel>();
                ListaAnalistas = DataAccess.BuscarResponsaveisArea(SharedData.UserCelulas.Select(n => n.ID_Area).Distinct().ToList());
                if (SharedData.User.FLG_AutoProc)
                {
                    ListaAnalistas = ListaAnalistas.Where(j => j.UsuarioAtivo == true && j.CelulaAtiva == true && j.AreaAtiva == true).GroupBy(i => i.ID_Responsavel).Select(g => g.First()).ToList();
                }
                else
                {
                    ListaAnalistas = ListaAnalistas.Where(j => j.UsuarioAtivo == true && j.CelulaAtiva == true && j.AreaAtiva == true && j.FLG_AutoProc == false).GroupBy(i => i.ID_Responsavel).Select(g => g.First()).ToList();
                }

                this.cboAnalista.DataSource = ListaAnalistas;
                cboAnalista.SelectedValue = SharedData.User.ID_Responsavel;
                bind = true;
                ValidaBackGround();
            }
            #endregion

            this.Text = this.Text + " | " + SharedData.gVersao;

            #region [ Métodos]
            if (SharedData.gMetodos != null && SharedData.gMetodos.Count > 0)
            {
                List<ClassListMethod> temp = SharedData.gMetodos.Where(n => n.ID_Method ==0 ||n.MethodForm.ToUpper() == "PIPELINE").ToList();
                if (temp != null && temp.Count > 0)
                {
                    foreach (ClassListMethod c in temp)
                    {
                        _Metodos.Add(new ClassListMethod(c));
                    }
                }
            }

            if (_Metodos == null || _Metodos.Count == 0)
            {
                _Metodos = DataAccess.GetListMethodPipeline();
            }

            cmb_ListMethod.DataSource = _Metodos;
            cmb_ListMethod.Visible = (cmb_ListMethod.Items.Count > 1);      // sempre é adicionado o campo vazio, por isso >1
            label_ListMethod.Visible = (cmb_ListMethod.Items.Count > 1);
            btnPlayMethod.Visible = (cmb_ListMethod.Items.Count > 1);
            if (cmb_ListMethod.Visible)
                cmb_ListMethod.SelectedValue = 0;
            #endregion
        }
        void montarFiltro(List<PipelineCampos> ListCamposPipeline)
        {
            if (_FiltroPipelineAtivo)
            {
                _pipelineFiltro = TelaDinamica.MontarFiltro(ListCamposPipeline, this, this.panel_filtro, this.button_filtro);
            }
        }
        void t_Tick(object sender, EventArgs e)
        {
            if (bind)
            {
                invoke_background();
            }
        }

        void MontaPipeline()
        {
            pipeline = DataAccess.BuscarPipelineCampos();
            _MudarCorPipeline = DataAccess.BuscarPipelineVisual();
            montarFiltro(pipeline);

            DataGridViewColumn column;

            column = new DataGridViewCheckBoxColumn();
            column.HeaderText = "";
            column.Name = "Selecionar";
            column.Visible = true;
            column.Width = 40;
            dgvOp.Columns.Add(column);

            foreach (PipelineCampos campo in pipeline)
            {
                if (campo.TipoCampo.ToUpper() == "BOOLEAN")
                {
                    column = new DataGridViewCheckBoxColumn();
                }
                else
                {
                    column = new DataGridViewTextBoxColumn();
                }
                column.HeaderText = campo.NomeHeader;
                column.Name = campo.NomeDesign;
                column.DataPropertyName = campo.NomeDesign;
                column.Width = campo.Width;

                if (campo.Formato != null && campo.Formato != "")
                {
                    column.DefaultCellStyle.Format = campo.Formato;
                }
                column.Visible = campo.Visivel;
                column.ReadOnly = true;
                dgvOp.Columns.Add(column);
            }

            if (SharedData.gValidaDependenciaResponsavel && !dgvOp.Columns.Contains("ValidaDependente"))
            {
                column = new DataGridViewTextBoxColumn();
                column.HeaderText = "Pode Atuar";
                column.Name = "ValidaDependente";
                column.DataPropertyName = "ValidaDependente";
                column.Visible = false;
                column.ReadOnly = true;
                column.Width = 60;
                dgvOp.Columns.Add(column);
            }
        }

        #region [ Clicks ]
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRedirect_Click(object sender, EventArgs e)
        {
            DataTable dtPipe = (dgvOp.DataSource as DataTable).DefaultView.ToTable().Copy();
            DataTable dtPipeAtribuir = dtPipe.Clone();

            foreach (DataGridViewRow row in this.dgvOp.Rows)
            {
                if (row.Index != -1)
                {
                    bool checkd = Convert.ToBoolean(row.Cells["Selecionar"].Value);

                    if (checkd)
                    {
                        dtPipeAtribuir.Rows.Add((Object[])dtPipe.Rows[row.Index].ItemArray.Clone());
                    }
                }
            }

            if (dtPipeAtribuir.Rows.Count > 0)
            {
                if (!SharedData.isOpenForm(typeof(Atribuir), false))
                {
                    using (Form frm = new Atribuir(dtPipeAtribuir, dgvOp))
                    {
                        frm.ShowDialog();
                    }
                }
            }
            else
            {
                MessageBox.Show("Nenhum serviço selecionado.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnAll_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in this.dgvOp.Rows)
            {
                if (row.Index != -1)
                {
                    row.Cells["Selecionar"].Value = true;
                }
            }
        }

        private void btnDesembolsar_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in this.dgvOp.Rows)
            {
                if (row.Index != -1)
                {
                    bool checkd = Convert.ToBoolean(row.Cells["Selecionar"].Value);

                    if (checkd)
                    {
                        string codContrato = row.Cells["Contrato"].Value.ToString();
                    }
                }
            }

            //this.BindPipeline();
            invoke_background();
            MessageBox.Show("Operações desembolsadas com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            List<int> IdServicoCancelar = new List<int>();

            foreach (DataGridViewRow row in this.dgvOp.Rows)
            {
                if (row.Index != -1)
                {
                    bool checkd = Convert.ToBoolean(row.Cells["Selecionar"].Value);

                    if (checkd)
                    {
                        IdServicoCancelar.Add(Convert.ToInt32(row.Cells["ID_SERVICO"].Value));
                    }
                }
            }

            if (IdServicoCancelar.Count > 0)
            {
                if (MessageBox.Show(IdServicoCancelar.Count + " " + (IdServicoCancelar.Count == 1 ? "Serviço selecionado." : "Serviços selecionados") + "\n\nConfirma cancelamento do serviço?", "Mobios", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    DataAccess.CancelarServicoLote(IdServicoCancelar);

                    List<DataGridViewRow> rowsDeleted = new List<DataGridViewRow>();
                    foreach (DataGridViewRow r in dgvOp.Rows)
                    {
                        if (IdServicoCancelar.IndexOf(Convert.ToInt32(r.Cells["ID_SERVICO"].Value)) != -1)
                        {
                            rowsDeleted.Add(r);
                        }
                    }

                    foreach (DataGridViewRow r in rowsDeleted)
                    {
                        dgvOp.Rows.Remove(r);
                    }
                    
                    MessageBox.Show("Operações canceladas com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //invoke_background();
                }
            }
            else
            {
                MessageBox.Show("Nenhum serviço selecionado.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


        }

        private void dgvOp_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                _sb_selected_rows.Clear();
                int IdRespFluxo = this.dgvOp.Rows[e.RowIndex].Cells["IdResponsavelFluxo"].Value.ToString() == "" ? 0 : Convert.ToInt32(this.dgvOp.Rows[e.RowIndex].Cells["IdResponsavelFluxo"].Value);
                string NomeRespFluxo = this.dgvOp.Rows[e.RowIndex].Cells["ResponsavelFluxo"].Value.ToString();

                bool validadoAcesso = false;
                if (SharedData.gValidarResponsavel == false)
                {
                    validadoAcesso = true;
                }
                else if (IdRespFluxo != SharedData.User.ID_Responsavel && IdRespFluxo != 0 && !SharedData.User.FLG_Gestor)
                {
                    if (MessageBox.Show("A etapa já está atribuída a " + NomeRespFluxo + ".\n\nPara atuar solicite o redirecionamento.\n\nAcessar serviço mesmo assim?", "MOBIOS+", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        validadoAcesso = true;
                    }
                }

                bool validadoResponsavel = true;
                if (SharedData.gValidaDependenciaResponsavel)
                {
                    if (this.dgvOp.Rows[e.RowIndex].Cells["ValidaDependente"].Value != null)
                    {
                        if (this.dgvOp.Rows[e.RowIndex].Cells["ValidaDependente"].Value.ToString() == "Não")
                        {
                            validadoResponsavel = false;
                            MessageBox.Show("Você já atuou em uma etapa dependente nesta operação.", "Atuação", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                    }
                }

                if ((IdRespFluxo == 0 || IdRespFluxo == SharedData.User.ID_Responsavel || SharedData.User.FLG_Gestor || validadoAcesso) && validadoResponsavel)
                {
                    ResponsavelServico sv = new ResponsavelServico();
                    sv.ID_Servico = Convert.ToInt32(this.dgvOp.Rows[e.RowIndex].Cells["ID_SERVICO"].Value.ToString());

                    _sb_selected_rows.Add(sv.ID_Servico);

                    sv.ID_Responsavel = SharedData.User.ID_Responsavel;
                    sv.ID_Objeto = Convert.ToInt32(this.dgvOp.Rows[e.RowIndex].Cells["ID_OBJETO"].Value.ToString());
                    sv.ServicoName = this.dgvOp.Rows[e.RowIndex].Cells["SERVICONAME"].Value.ToString();
                    //_culture
                    sv.DataCriacao = Convert.ToDateTime(this.dgvOp.Rows[e.RowIndex].Cells["DataCriacao"].Value.ToString());
                    sv.NomeObjeto = this.dgvOp.Rows[e.RowIndex].Cells["NomeObjeto"].Value.ToString();
                    sv.Segmento = this.dgvOp.Rows[e.RowIndex].Cells["COD_Segmento"].Value.ToString();
                    sv.IdSegmento = Convert.ToInt32(this.dgvOp.Rows[e.RowIndex].Cells["ID_SEGMENTO"].Value.ToString());
                    sv.Prioridade = Convert.ToBoolean(this.dgvOp.Rows[e.RowIndex].Cells["Prioridade"].Value);

                    mysv = sv;
                    // Abre formulário

                    string ParametroForm = SharedData.gFormOperação;

                    _AbrindoForm = true;
                    _Maximizado = this.WindowState;
                    
                    bool loading = true;
                    BackgroundWorker bgk = new BackgroundWorker();
                    bgk.DoWork += (s, j) =>
                        {
                            Loading L = new Loading();
                            Loading.EnableStaticTextBox("Carregando Serviço...");
                            Loading.StaticFormVisible(true);
                            
                            while (loading)
                            {
                                Application.DoEvents();
                            }
                            Loading.StaticFormVisible(false);
                            try
                            {
                                L.Close();
                            }
                            catch { };
                        };
                    bgk.RunWorkerAsync();

                    if (ParametroForm == "MINUTAS")
                    {

                        if (!SharedData.isOpenForm(typeof(Minutas), true))
                        {
                            Minutas frm = new Minutas(sv, true);

                            frm.MdiParent = this.MdiParent;
                            //frm.WindowState = FormWindowState.Maximized;
                            frm.Left = 0;
                            frm.Top = 0;
                            frm.Show();
                        }
                    }
                    else
                    {
                        if (!SharedData.isOpenForm(typeof(Detalhe), true))
                        {
                            Detalhe frm = new Detalhe(sv);

                            frm.MdiParent = this.MdiParent;
                            frm.WindowState = FormWindowState.Maximized;
                            frm.Left = 0;
                            frm.Top = 0;
                            frm.Show();
                        }
                    }
                    loading = false;
                    while (bgk.IsBusy) { Application.DoEvents(); }
                    bgk.Dispose();
                    bgk = null;
                }
            }
        }

        private void dgvOp_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            _sb_selected_rows.Clear();
            if (e.RowIndex != -1)
                _sb_selected_rows.Add(Convert.ToInt32(this.dgvOp.Rows[e.RowIndex].Cells["ID_SERVICO"].Value.ToString()));
        }

        private void dgvOp_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {

        }

        private void btnNone_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in this.dgvOp.Rows)
            {
                if (row.Index != -1)
                {
                    row.Cells["Selecionar"].Value = false;
                }
            }
        }

        private void chkAtualizaAuto_CheckedChanged(object sender, EventArgs e)
        {
            _pipelineAtualiza = chkAtualizaAuto.Checked;
            this.btnRefresh.Visible = !_pipelineAtualiza;
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            _pipelineAtualizaObrigatorio = true;
            invoke_background();
        }
        #endregion

        #region [ Atualizar Pipeline ]
        private void ValidaBackGround()
        {
            if (_IdAnalistaSelecionado != Convert.ToInt32(cboAnalista.SelectedValue))
            {
                if (bind)
                {
                    invoke_background();
                    _IdAnalistaSelecionado = Convert.ToInt32(cboAnalista.SelectedValue);
                }

            }
        }
        private void cboAnalista_SelectedValueChanged(object sender, EventArgs e)
        {
            _pipelineAtualizaObrigatorio = true;
            _filtrar = true;
            ValidaBackGround();


        }
        void Pipeline_MyEvent(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            invoke_background();
        }

        private void invoke_background()
        {
            if (!backgroundWorker1.IsBusy)
            {
                if ((_pipelineAtualizaObrigatorio || _pipelineAtualiza))
                {
                    img_loading.Visible = true;
                    ID_Responsavel = Convert.ToInt32(this.cboAnalista.SelectedValue.ToString());
                    backgroundWorker1.RunWorkerAsync();
                }
            }
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            BindPipeline();
        }

        private void BindPipeline()
        {
            if (_Dt_ListaPipeline != null)
            {
                _Dt_ListaPipeline.Clear();
                _Dt_ListaPipeline.Dispose();
                _Dt_ListaPipeline = null;
            }
            _Dt_ListaPipeline = DataAccess.BuscarPipeline("ID_RESPONSAVEL", ID_Responsavel, pipeline);
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {


            if (SharedData.gPipeLinePageSize > 0)
                dgvOp.PageSize = SharedData.gPipeLinePageSize;
            else
                dgvOp.PageSize = _Dt_ListaPipeline.Rows.Count;

            if (_pipelineAtualiza || _pipelineAtualizaObrigatorio)
            {
                List<int> ServiçosSelecionados = new List<int>();
                foreach (DataGridViewRow r in dgvOp.Rows)
                {
                    if (Convert.ToBoolean(r.Cells["Selecionar"].Value) == true)
                    {
                        ServiçosSelecionados.Add(Convert.ToInt32(r.Cells["ID_Servico"].Value));
                    }
                }
                //this.dgvOp.DataSource = _Dt_ListaPipeline;
                this.dgvOp.SetPagedDataSource(_Dt_ListaPipeline, bindingNavigator1);
                FiltroDinamico();
                AfterRefresh(this.dgvOp);
                foreach (DataGridViewRow r in dgvOp.Rows)
                {
                    if (ServiçosSelecionados.IndexOf(Convert.ToInt32(r.Cells["ID_Servico"].Value)) != -1)
                    {
                        r.Cells["Selecionar"].Value = true;
                    }
                }
            }

            if (_Dt_ListaPipeline.Rows.Count == 0)
            {
                label_registros.Text = "Sem operações";
            }
            _pipelineAtualizaObrigatorio = false;
            img_loading.Visible = false;

        }

        private void AfterRefresh(DataGridView dgv)
        {
            MudarCorPipeline();

            for (int i = 0; i < dgv.Rows.Count; i++)
            {
                bool isInList = _sb_selected_rows.IndexOf(Convert.ToInt32(dgv.Rows[i].Cells["ID_SERVICO"].Value)) != -1;
                if (isInList)
                {
                    dgv.Rows[0].Selected = false;
                    dgv.Rows[i].Selected = true;
                    dgv.FirstDisplayedScrollingRowIndex = dgv.SelectedRows[dgv.SelectedRows.Count - 1].Index - (dgv.SelectedRows[dgv.SelectedRows.Count - 1].Index < 5 ? dgv.SelectedRows[dgv.SelectedRows.Count - 1].Index : 5);
                }

            }

        }

        public void Bind()
        {
            invoke_background();
        }
        private void Pipeline_Activated(object sender, EventArgs e)
        {
            try
            {
                if (t.Enabled == false)
                {
                    t.Start();
                    t.Enabled = true;
                }

                this.WindowState = _Maximizado;
            }
            catch { }
        }
        private void Pipeline_Deactivate(object sender, EventArgs e)
        {
            try
            {
                t.Stop();
                t.Enabled = false;

                if (!_AbrindoForm)
                {
                    _Maximizado = this.WindowState;
                }
                _AbrindoForm = false;
            }
            catch { }
        }
        private void Pipeline_FormClosing(object sender, FormClosingEventArgs e)
        {
            t.Stop();
            t.Enabled = false;
        }
        #endregion

        private void dgvOp_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            _RealizarSort = true;
            _sortIndex = e.ColumnIndex;
            SortPipeline();
            MudarCorPipeline();
        }

        //Data: 17/03/2017
        //Autor: Bruno Macarini
        //Descrição: Realiza a ordenação do pipeline.
        private void SortPipeline()
        {
            if (_RealizarSort)
            {
                _RealizarSort = false;
                for (int i = 0; i < dgvOp.Columns.Count; i++)
                {
                    dgvOp.Columns[i].HeaderText = dgvOp.Columns[i].HeaderText.Replace(" ▲", "");
                    dgvOp.Columns[i].HeaderText = dgvOp.Columns[i].HeaderText.Replace(" ▼", "");
                }
                if (_sortDirection == "")
                {
                    _sortDirection = "ASC";
                    _sort = "[" + dgvOp.Columns[_sortIndex].Name + "] " + _sortDirection;
                    dgvOp.Columns[_sortIndex].HeaderText = dgvOp.Columns[_sortIndex].HeaderText + " ▲";

                }
                else if (_sortDirection == "ASC")
                {
                    _sortDirection = "DESC";
                    _sort = "[" + dgvOp.Columns[_sortIndex].Name + "] " + _sortDirection;
                    dgvOp.Columns[_sortIndex].HeaderText = dgvOp.Columns[_sortIndex].HeaderText + " ▼";
                }
                else if (_sortDirection == "DESC")
                {
                    _sortDirection = "";
                    _sort = "";
                    dgvOp.Columns[_sortIndex].HeaderText = dgvOp.Columns[_sortIndex].HeaderText.Replace(" ▲", "");
                    dgvOp.Columns[_sortIndex].HeaderText = dgvOp.Columns[_sortIndex].HeaderText.Replace(" ▼", "");
                }

            }
            if (_sort != "")
            {
                if (_Dt_FiltroSort == null)
                    _Dt_FiltroSort = _Dt_ListaPipeline.Copy();
                DataView dv = _Dt_FiltroSort.DefaultView;
                dv.Sort = _sort;
                dgvOp.SetPagedDataSource(dv.ToTable(), bindingNavigator1);
            }
            else
            {
                if (_Dt_FiltroSort == null)
                    _Dt_FiltroSort = _Dt_ListaPipeline.Copy();
                dgvOp.SetPagedDataSource(_Dt_FiltroSort, bindingNavigator1);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            List<int> IdServicoExcluir = new List<int>();

            foreach (DataGridViewRow row in this.dgvOp.Rows)
            {
                if (row.Index != -1)
                {
                    bool checkd = Convert.ToBoolean(row.Cells["Selecionar"].Value);

                    if (checkd)
                    {
                        IdServicoExcluir.Add(Convert.ToInt32(row.Cells["ID_SERVICO"].Value));
                    }
                }
            }

            if (IdServicoExcluir.Count > 0)
            {
                if (MessageBox.Show(IdServicoExcluir.Count + " " + (IdServicoExcluir.Count == 1 ? "Serviço selecionado." : "Serviços selecionados") + "\n\nEsta ação excluirá permanentemente o serviço do sistema.\n\nConfirma exclusão?", "Mobios", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    DataAccess.ExcluirServicoLote(IdServicoExcluir);

                    List<DataGridViewRow> rowsDeleted = new List<DataGridViewRow>();
                    foreach (DataGridViewRow r in dgvOp.Rows)
                    {
                        if (IdServicoExcluir.IndexOf(Convert.ToInt32(r.Cells["ID_SERVICO"].Value)) != -1)
                        {
                            rowsDeleted.Add(r);
                        }
                    }

                    foreach (DataGridViewRow r in rowsDeleted)
                    {
                        dgvOp.Rows.Remove(r);
                    }

                    MessageBox.Show("Operações excluídas com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //invoke_background();
                }
            }
            else
            {
                MessageBox.Show("Nenhum serviço selecionado.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void button_filtro_Click(object sender, EventArgs e)
        {
            List<int> ServiçosSelecionados = new List<int>();
            foreach (DataGridViewRow r in dgvOp.Rows)
            {
                if (Convert.ToBoolean(r.Cells["Selecionar"].Value) == true)
                {
                    ServiçosSelecionados.Add(Convert.ToInt32(r.Cells["ID_Servico"].Value));
                }
            }
            _filtrar = true;
            FiltroDinamico();
            MudarCorPipeline();
            foreach (DataGridViewRow r in dgvOp.Rows)
            {
                if (ServiçosSelecionados.IndexOf(Convert.ToInt32(r.Cells["ID_Servico"].Value)) != -1)
                {
                    r.Cells["Selecionar"].Value = true;
                }
            }
        }
        //Data: 16/03/2017
        //Autor: Marcos Ramos / Bruno Macarini
        //Detalhe: Faz filtro no datagridview do tipo "supergrid"
        private void FiltroDinamico()
        {
            //if ((dgvOp.DataSource as DataTable) != null)
            if (_Dt_ListaPipeline != null)
            {
                if (_filtrar == true)
                {
                    _filtrar = false;
                    bool first = true;
                    string filter = string.Empty;

                    foreach (PipelineCampos c in _pipelineFiltro)
                    {
                        if (this.Text != "")
                        {
                            string obj = "";
                            if (c.FiltroTIPO.ToUpper() == "TEXTBOX" || c.FiltroTIPO.ToUpper() == "COMBOBOX")
                            {
                                obj = this.panel_filtro.Controls["txt" + c.NomeDesign].Text;
                            }
                            else if (c.FiltroTIPO.ToUpper() == "CHECKBOX")
                            {
                                if (this.panel_filtro.Controls["txt" + c.NomeDesign].Text == "SIM")
                                {
                                    obj = "true";
                                }
                                else if (this.panel_filtro.Controls["txt" + c.NomeDesign].Text == "NÃO")
                                {
                                    obj = "false";
                                }
                            }

                            if (obj != null)
                            {
                                if (obj != "")
                                {
                                    if (c.FiltroTIPO.ToUpper() == "CHECKBOX")
                                    {
                                        if (first)
                                        {
                                            filter = string.Format("[{0}] = {1}", c.NomeDesign, obj);
                                            first = false;
                                        }
                                        else
                                            filter += string.Format(" AND [{0}] = {1}", c.NomeDesign, obj);
                                    }
                                    else if (this.checkBox_valores_exatos.Checked)
                                    {
                                        if (c.TipoCampo.ToUpper() == "DECIMAL" || c.TipoCampo.ToUpper() == "INT")
                                        {
                                            if (first)
                                            {
                                                filter = string.Format("[{0}] = {1}", c.NomeDesign, obj);
                                                first = false;
                                            }
                                            else
                                                filter += string.Format(" AND [{0}] = {1}", c.NomeDesign, obj);
                                        }
                                        else
                                        {
                                            if (first)
                                            {
                                                filter = string.Format("[{0}] = '{1}'", c.NomeDesign, obj);
                                                first = false;
                                            }
                                            else
                                                filter += string.Format(" AND [{0}] = '{1}'", c.NomeDesign, obj);
                                        }
                                    }
                                    else
                                    {
                                        if (c.TipoCampo.ToUpper() == "DECIMAL" || c.TipoCampo.ToUpper() == "INT")
                                        {
                                            if (first)
                                            {
                                                filter = string.Format("CONVERT([{0}], 'System.String') LIKE '%{1}%'", c.NomeDesign, obj);
                                                first = false;
                                            }
                                            else
                                                filter += string.Format(" AND CONVERT([{0}], 'System.String') LIKE '%{1}%'", c.NomeDesign, obj);
                                        }
                                        else
                                        {
                                            if (first)
                                            {
                                                filter = string.Format("[{0}] LIKE '%{1}%'", c.NomeDesign, obj);
                                                first = false;
                                            }
                                            else
                                                filter += string.Format(" AND [{0}] LIKE '%{1}%'", c.NomeDesign, obj);
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (rdResponsavel.Checked)
                    {
                        if (filter != "")
                        {
                            filter += " AND ";
                        }
                        filter += "IdResponsavelFluxo" + " = " + ID_Responsavel;
                    }
                    _filter = filter;
                }
                //_Dt_ListaPipeline

                _Dt_FiltroSort = _Dt_ListaPipeline.Copy();
                try
                {
                    _Dt_FiltroSort.DefaultView.RowFilter = _filter;
                }
                catch { }

                if (_sort == "")
                    dgvOp.SetPagedDataSource(_Dt_FiltroSort.DefaultView.ToTable(), bindingNavigator1);
                else
                    SortPipeline();

                if (_Dt_FiltroSort.DefaultView.ToTable().Rows.Count == 1)
                {
                    label_registros.Text = "Encontrada " + _Dt_FiltroSort.DefaultView.ToTable().Rows.Count.ToString() + " operação";
                }
                else
                {
                    label_registros.Text = "Encontradas " + _Dt_FiltroSort.DefaultView.ToTable().Rows.Count.ToString() + " operações";
                }


            }
        }

        private void btnLimparFiltro_Click(object sender, EventArgs e)
        {
            foreach (PipelineCampos c in _pipelineFiltro)
            {
                if (c.FiltroTIPO.ToUpper() == "TEXTBOX" || c.FiltroTIPO.ToUpper() == "COMBOBOX" || c.FiltroTIPO.ToUpper() == "CHECKBOX")
                {
                    this.panel_filtro.Controls["txt" + c.NomeDesign].Text = "";
                }
            }
            List<int> ServiçosSelecionados = new List<int>();
            foreach (DataGridViewRow r in dgvOp.Rows)
            {
                if (Convert.ToBoolean(r.Cells["Selecionar"].Value) == true)
                {
                    ServiçosSelecionados.Add(Convert.ToInt32(r.Cells["ID_Servico"].Value));
                }
            }
            _filtrar = true;
            FiltroDinamico();
            MudarCorPipeline();
            foreach (DataGridViewRow r in dgvOp.Rows)
            {
                if (ServiçosSelecionados.IndexOf(Convert.ToInt32(r.Cells["ID_Servico"].Value)) != -1)
                {
                    r.Cells["Selecionar"].Value = true;
                }
            }
        }

        private void botPer_Click(object sender, EventArgs e)
        {
            using (PersonalizarPipe f = new PersonalizarPipe(Convert.ToInt32(cboAnalista.SelectedValue)))
            {
                f.ShowDialog();
                if (f.Feito == true)
                {
                    //Campos = DataAccess.getCampos(Convert.ToInt32(cboAnalista.SelectedValue));
                    invoke_background();
                }
            }
        }

        private void MudarCorPipeline()
        {
            if ((dgvOp) != null && dgvOp.DataSource != null)
            {
                if (_MudarCorPipeline.Count > 0)
                {
                    DataTable dt = (dgvOp.DataSource as DataTable).DefaultView.ToTable().Copy();

                    DataView dv = dt.DefaultView;
                    string filter = "";

                    List<PipelineVisual> pipelineVisual = new List<PipelineVisual>();

                    foreach (PipelineVisual campos in _MudarCorPipeline)
                    {
                        try
                        {
                            DataTable targetTable = new DataTable();

                            filter = campos.Criterio.Replace(@"Date()", "#" + DateTime.Today.ToString("yyyy/MM/dd") + "#").Replace(@"Now()", "#" + DateTime.Now.ToString("yyyy/MM/dd") + "#");
                            dv.RowFilter = filter;
                            targetTable = dv.ToTable();

                            if (targetTable.Rows.Count > 0)
                            {
                                pipelineVisual.AddRange((from DataRow dr in targetTable.Rows
                                                         select new PipelineVisual()
                                                         {
                                                             Ordem = campos.Ordem,
                                                             Criterio = campos.Criterio,
                                                             Cor = campos.Cor,
                                                             Tipo = campos.Tipo,
                                                             Colunas = campos.Colunas,
                                                             IdServico = Convert.ToInt32(dr["ID_SERVICO"])
                                                         }).ToList());
                            }
                        }
                        catch (Exception err)
                        {
                            msgLog = "Erro ao processar regra de gestão visual do pipeline. Regra: " + campos.Criterio + "." + "\n\n" + err.Message;
                            Log.GravaLog(msgLog);
                        }
                    }

                    foreach (DataGridViewRow r in dgvOp.Rows)
                    {
                        try
                        {
                            List<PipelineVisual> pipeLocalizado = new List<PipelineVisual>();
                            pipeLocalizado = pipelineVisual.FindAll(n => n.IdServico == Convert.ToInt32(r.Cells["ID_SERVICO"].Value)).OrderByDescending(n => n.Ordem).ToList();

                            if (pipeLocalizado.Count > 0)
                            {
                                dgvOp.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.White;
                                foreach (PipelineVisual criterio in pipeLocalizado)
                                {
                                    if (criterio.Tipo == "LINHA")
                                    {
                                        string[] cor = criterio.Cor.Split(';');

                                        foreach (DataGridViewColumn col in dgvOp.Columns)
                                        {
                                            if (cor[0] != "")
                                            {
                                                r.Cells[col.Name].Style.BackColor = System.Drawing.Color.FromName(cor[0]);
                                            }
                                            if (cor.Count() > 1)
                                            {
                                                if (cor[1] != "")
                                                {
                                                    r.Cells[col.Name].Style.ForeColor = System.Drawing.Color.FromName(cor[1]);
                                                }
                                            }
                                        }
                                        //r.DefaultCellStyle.BackColor = System.Drawing.Color.FromName(cor[0]);
                                        //r.DefaultCellStyle.ForeColor = System.Drawing.Color.FromName(cor[1]);
                                    }
                                    else
                                    {
                                        string[] cor = criterio.Cor.Split(';');
                                        string[] colunas = criterio.Colunas.Split(';');

                                        foreach (string col in colunas)
                                        {
                                            if (cor[0] != "")
                                            {
                                                r.Cells[col].Style.BackColor = System.Drawing.Color.FromName(cor[0]);
                                            }
                                            if (cor.Count() > 1)
                                            {
                                                if (cor[1] != "")
                                                {
                                                    r.Cells[col].Style.ForeColor = System.Drawing.Color.FromName(cor[1]);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        catch (Exception err)
                        {
                            msgLog = "Erro ao colorir linha pipeline. IdServico: " + r.Cells["ID_SERVICO"].Value + "." + "\n\n" + err.Message;
                            Log.GravaLog(msgLog);
                        }
                    }
                }
            }
        }

        private void rdResponsavel_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rdResponsavel.Checked)
            {
                List<int> ServiçosSelecionados = new List<int>();
                foreach (DataGridViewRow r in dgvOp.Rows)
                {
                    if (Convert.ToBoolean(r.Cells["Selecionar"].Value) == true)
                    {
                        ServiçosSelecionados.Add(Convert.ToInt32(r.Cells["ID_Servico"].Value));
                    }
                }
                _filtrar = true;
                FiltroDinamico();
                MudarCorPipeline();
                foreach (DataGridViewRow r in dgvOp.Rows)
                {
                    if (ServiçosSelecionados.IndexOf(Convert.ToInt32(r.Cells["ID_Servico"].Value)) != -1)
                    {
                        r.Cells["Selecionar"].Value = true;
                    }
                }
            }
        }

        private void rdCelula_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rdCelula.Checked)
            {
                List<int> ServiçosSelecionados = new List<int>();
                foreach (DataGridViewRow r in dgvOp.Rows)
                {
                    if (Convert.ToBoolean(r.Cells["Selecionar"].Value) == true)
                    {
                        ServiçosSelecionados.Add(Convert.ToInt32(r.Cells["ID_Servico"].Value));
                    }
                }
                _filtrar = true;
                FiltroDinamico();
                MudarCorPipeline();
                foreach (DataGridViewRow r in dgvOp.Rows)
                {
                    if (ServiçosSelecionados.IndexOf(Convert.ToInt32(r.Cells["ID_Servico"].Value)) != -1)
                    {
                        r.Cells["Selecionar"].Value = true;
                    }
                }
            }
        }

        private void Pipeline_SizeChanged(object sender, EventArgs e)
        {
            //if (this.WindowState != FormWindowState.Maximized && this.WindowState != FormWindowState.Minimized)
            //{
            //    if ((this.Left + this.Width) > (this.ParentForm.ClientSize.Width - 5))
            //    {
            //        this.WindowState = FormWindowState.Normal;
            //        this.Width = this.ParentForm.ClientSize.Width - 5 - this.Left;

            //        this.Height = this.ParentForm.ClientSize.Height - 100;
            //    }
            //    if ((this.Top + this.Height) > (this.ParentForm.ClientSize.Height - 100))
            //    {
            //        this.WindowState = FormWindowState.Normal;
            //        this.Height = this.ParentForm.ClientSize.Height - 100 - this.Top;
            //    }
            //}
        }

        private void Pipeline_Move(object sender, EventArgs e)
        {
            //if (this.WindowState != FormWindowState.Maximized && this.WindowState != FormWindowState.Minimized)
            //{
            //    if ((this.Left + this.Width) > (this.ParentForm.ClientSize.Width - 5))
            //    {
            //        this.WindowState = FormWindowState.Normal;
            //        this.Width = this.ParentForm.ClientSize.Width - 5 - this.Left;

            //        this.Height = this.ParentForm.ClientSize.Height - 100;
            //    }
            //    if ((this.Top + this.Height) > (this.ParentForm.ClientSize.Height - 100))
            //    {
            //        this.WindowState = FormWindowState.Normal;
            //        this.Height = this.ParentForm.ClientSize.Height - 100 - this.Top;
            //    }
            //}
        }

        private void button_exportar_datagrid_Click(object sender, EventArgs e)
        {
            DataTable dtEXPORT = _Dt_FiltroSort.Copy();
            
            List<int> indexColToRemove = new List<int>();
            for (int i = 0; i < dtEXPORT.Columns.Count; i++)
            {
                if (!dgvOp.Columns.Contains(dtEXPORT.Columns[i].ColumnName))
                {
                    //dtEXPORT.Columns.Remove(dtEXPORT.Columns[i].ColumnName);
                    indexColToRemove.Add(i);
                }
                else
                {
                    if (dgvOp.Columns[dtEXPORT.Columns[i].ColumnName].Visible == true)
                    {
                        dtEXPORT.Columns[i].ColumnName = i.ToString() + ". " + dgvOp.Columns[dtEXPORT.Columns[i].ColumnName].HeaderText.Replace(" ▲", "").Replace(" ▼", "");
                    }
                    else
                        indexColToRemove.Add(i);
                }
            }

            for (int i = indexColToRemove.Count - 1; i >= 0; i--)
            {
                dtEXPORT.Columns.Remove(dtEXPORT.Columns[indexColToRemove[i]].ColumnName);
            }

            for (int i = 0; i < dtEXPORT.Columns.Count; i++)
            {
                dtEXPORT.Columns[i].ColumnName = dtEXPORT.Columns[i].ColumnName.Remove(0, dtEXPORT.Columns[i].ColumnName.IndexOf(".") + 2);
            }
            TratarEventos.ExportaDataTable(dtEXPORT, "", "", true);
        }

        private void bindingNavigatorPositionItem_Leave(object sender, EventArgs e)
        {
            MudarCorPipeline();
        }

        private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
        {
            MudarCorPipeline();
        }

        private void bindingNavigatorMoveLastItem_Click(object sender, EventArgs e)
        {
            MudarCorPipeline();
        }

        private void bindingNavigatorMovePreviousItem_Click(object sender, EventArgs e)
        {
            MudarCorPipeline();
        }

        private void bindingNavigatorMoveFirstItem_Click(object sender, EventArgs e)
        {
            MudarCorPipeline();
        }

        private void Pipeline_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (_Dt_ListaPipeline != null)
            {
                _Dt_ListaPipeline.Clear();
                _Dt_ListaPipeline.Dispose();
                _Dt_ListaPipeline = null;
            }
            _Dt_ListaPipeline = null;
            if (_Dt_FiltroSort != null)
            {
                _Dt_FiltroSort.Clear();
                _Dt_FiltroSort.Dispose();
                _Dt_FiltroSort = null;
            }
            _Dt_FiltroSort = null;
            
            if (t != null)
            t.Dispose();
            t = null;

            if (backgroundWorker1 != null)
                backgroundWorker1.Dispose();
            backgroundWorker1 = null;

            this.dgvOp.ResetDataGridView();
        }

        private void btnPlayMethod_Click(object sender, EventArgs e)
        {
            if (cmb_ListMethod.SelectedValue.ToString() != "")
            {
                if (MessageBox.Show("Executar " + cmb_ListMethod.Text.ToString() + "?", "Método", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    _MyMethod = new ClassListMethod();
                    _MyMethod = (ClassListMethod)(cmb_ListMethod.SelectedItem);

                    string _MethodName = cmb_ListMethod.SelectedValue.ToString();

                    CustomMethod.ChamarMetodo(_MethodName, CustomMethod.MethodForm.Pipeline);

                    //#region [ Follow-up ]
                    //if (_MyMethod.MethodFUP == true)
                    //{
                    //    FollowUp FollowUpMetodo = new FollowUp();
                    //    FollowUpMetodo.ID_Servico = _Res.ID_Servico;
                    //    FollowUpMetodo.ID_Fluxo = _Etapa.ID_Etapa;
                    //    FollowUpMetodo.FollowUpEtapa = _MyMethod.MethodDescricao;

                    //    msgLog = "Gravando Follow-Up " + FollowUpMetodo.FollowUpEtapa;
                    //    DataAccess.RegistrarFollowUpEtapaServico(FollowUpMetodo, false);
                    //    _listaFollowUpServico = DataAccess.RecuperaFollowUpEtapaServico(_Etapa.ID_Servico);
                    //    this.AtualizaFollowUp();
                    //}
                    //#endregion

                    //#region [ Altera Status da Etapa ]
                    //try
                    //{
                    //    if (_MyMethod.MethodStatusEtapa > 0)
                    //    {
                    //        if (MessageBox.Show("Alterar Status da Etapa?", "MOBIOS+", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    //        {
                    //            int Status = _MyMethod.MethodStatusEtapa;
                    //            cboStatus.SelectedValue = Status;
                    //            btnSalvar.PerformClick();
                    //        }
                    //        else
                    //        {
                    //            MessageBox.Show("Status não alterado", "Mobios");
                    //        }
                    //    }
                    //}
                    //catch (Exception exp)
                    //{
                    //    msgLog = "Erro ao alterar status da etapa " + _Etapa.ID_Etapa + " do serviço " + _Etapa.ID_Objeto + " / " + _Etapa.ID_Servico + ".";
                    //    Log.GravaLog(msgLog);
                    //    MessageBox.Show(exp.Message);
                    //}
                    //#endregion
                }
            }
        }
    }
}



