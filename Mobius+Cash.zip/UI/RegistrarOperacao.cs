﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;

namespace Mobios
{
    public partial class RegistrarOperacao : Form
    {
        #region [ Variáveis ]
        string msgLog;
        public ResponsavelServico _Responsavel;
        List<Campos> lista = new List<Campos>();
        List<Boletador> _listaBoletador = new List<Boletador>();
        List<Objeto> ObjetoSegmento = new List<Objeto>();
        List <Objeto> _ListaObjetos;
        List<Segmento> _ListaSegmentos;
        List<string> _Categorias;
        #endregion

        public RegistrarOperacao()
        {
            InitializeComponent();
            msgLog = "Formulário de REGISTRAR SERVICO aberto.";
            Log.GravaLog(msgLog);

            _Responsavel = new ResponsavelServico();

            _ListaSegmentos = new List<Segmento>();
            _ListaSegmentos = DataAccess.buscarSegmento(SharedData.User.ID_Responsavel);
            this.cbSegmento.DataSource = _ListaSegmentos;

            _ListaObjetos = new List<Objeto>();
            _ListaObjetos = DataAccess.buscarProdObjAreaResponsavel(SharedData.User.ID_Responsavel);

            #region [ Boletador ]
            bool exibeBoletador = SharedData.gBoletadorTela.Contains("REGISTRO=TRUE");

            if (exibeBoletador)
            {
                _listaBoletador = DataAccess.buscarBoletador();
                this.cbBoletador.DataSource = _listaBoletador;

                if (_listaBoletador.Count > 0)
                {
                    this.cbBoletador.DataSource = _listaBoletador;
                    this.label3.Visible = true;
                    this.cbBoletador.Visible = true;
                    this.btnImportarBoleto.Visible = true;
                }
            }
            #endregion

            #region [ Botões Gestor ]
            if (!SharedData.User.FLG_Gestor)
            {
                List<Responsavel> onlyOne = new List<Responsavel>();
                onlyOne.Add(SharedData.User);

                this.cbAnalista.DataSource = onlyOne;
                this.cbAnalista.Enabled = false;
            }
            else
            {
                List<Responsavel> ListaAnalistas = new List<Responsavel>();
                
                ListaAnalistas = DataAccess.BuscarResponsaveisArea(SharedData.UserCelulas.Select(n => n.ID_Area).Distinct().ToList());
                if (SharedData.User.FLG_AutoProc)
                {
                    ListaAnalistas = ListaAnalistas.Where(j => j.UsuarioAtivo == true && j.CelulaAtiva == true && j.AreaAtiva == true).GroupBy(i => i.ID_Responsavel).Select(g => g.First()).ToList();
                }
                else
                { 
                    ListaAnalistas = ListaAnalistas.Where(j => j.UsuarioAtivo == true && j.CelulaAtiva == true && j.AreaAtiva == true && j.FLG_AutoProc == false).GroupBy(i => i.ID_Responsavel).Select(g => g.First()).ToList(); 
                }
                    

                this.cbAnalista.DataSource = ListaAnalistas;
                this.cbAnalista.SelectedValue = SharedData.User.ID_Responsavel;
            }
            this.boxAnalista.Visible = SharedData.gAtribuiResponsavelServico;
            #endregion

            if (!SharedData.gAtribuiResponsavelServico)
            {
                panel2.Height = panel2.Height - boxAnalista.Height;
            }

            this.Text = this.Text + " | " + SharedData.gVersao;

        }

        private bool validaCamposPrincipais()
        {
            bool combosOk = true;

            if (Convert.ToInt32(cbSegmento.SelectedValue) == 0)
            {
                combosOk = false;
                MessageBox.Show("Escolha um SEGMENTO.");
            }
            else
            {
                if (Convert.ToInt32(cbCategoria.SelectedValue) == 0)
                {
                    combosOk = false;
                    MessageBox.Show("Escolha um PRODUTO.");
                }
            }
            return combosOk;
        }
        
        private void SalvarRegistro(TabControl tabControl, List<Campos> listaEstrutura)
        {
            btnRegistrar.Enabled = false;
            this.Cursor = Cursors.WaitCursor;
            bool camposPrincipais = validaCamposPrincipais();
            
            if (camposPrincipais == true)
            {
                var tupla = TelaDinamica.ValidarCamposObrigatorios(listaEstrutura, tabControl);
                var tupla2 = TelaDinamica.ValidarTIPOSCampos(listaEstrutura, tabControl);

                if (tupla.Item1 && tupla2.Item1 && String.IsNullOrEmpty(txtIdentificacao.Text) == false)
                {
                    try
                    {
                        msgLog = "Registrando operação " + txtIdentificacao.Text.ToString() + ".";
                        Log.GravaLog(msgLog);

                        _Responsavel.ID_Servico = DataAccess.SalvarServico(Convert.ToInt32(cbSegmento.SelectedValue), Convert.ToInt32(cbCategoria.SelectedValue), txtIdentificacao.Text, ckbPrioridade.Checked, DateTime.Now);
                        if (_Responsavel.ID_Servico != 0)
                        {
                            msgLog = "Serviço " + _Responsavel.ID_Servico;
                            Log.GravaLog(msgLog);

                            TelaDinamica.CriarEtapaFluxo(_Responsavel.ID_Servico, Convert.ToInt32(cbCategoria.SelectedValue), Convert.ToInt32(cbAnalista.SelectedValue));

                            msgLog = "Atualizando campos";
                            Log.GravaLog(msgLog);
                            DataAccess.AtualizarDadosCamposGenerico(listaEstrutura, tabControl, _Responsavel.ID_Servico);
                            MessageBox.Show("Registro Salvo\n\nId do Serviço: " + _Responsavel.ID_Servico);
                            msgLog = "Registro concluído. Id do Serviço: " + _Responsavel.ID_Servico;
                            Log.GravaLog(msgLog);

                            if (MessageBox.Show("Registrar outro serviço?", "Contratos", MessageBoxButtons.YesNo) == DialogResult.Yes)
                            {
                                ClearControlsData(tabControl);
                                txtIdentificacao.Text = string.Empty;
                                ckbPrioridade.Checked = false;
                            }
                            else
                            {
                                this.Close();
                            }
                        }
                        else
                        {
                            throw new Exception("Não foi possível registrar o serviço. Tente novamente");
                        }

                    }
                    catch (Exception exp)
                    {
                        DataAccess.ExcluirServico(_Responsavel.ID_Servico);

                        MessageBox.Show("Erro ao tentar salvar registro. Erro: " + exp.Message);
                    }
                }
                else
                {
                    if (String.IsNullOrEmpty(txtIdentificacao.Text) == true)
                    {
                        MessageBox.Show("Campo identificação é obrigatório.\nEsta informação é CHAVE para pesquisa do serviço que está sendo cadastrado.");
                        txtIdentificacao.Focus();
                    }
                    else
                    {
                        if (tupla.Item1 == false)
                        {
                            MessageBox.Show(tupla.Item2);
                        }
                        else if (tupla2.Item1==false)
                        {
                            MessageBox.Show(tupla2.Item2);
                        }                        
                    }
                }
            }
            this.Cursor = Cursors.Default;
            btnRegistrar.Enabled = true;
        }
        
        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            this.SalvarRegistro(tabGroup1, lista);
        }

        private void ClearControlsData(TabControl parentControl)
        {
            for (int i = 0; i < parentControl.Controls.Count; i++)
            {
                foreach (Control ctrl in parentControl.TabPages[i].Controls)
                {
                    TextBox ctrlText;
                    ComboBox ctrlCombo;
                    CheckBox ctrlCheck;
                    NumericTextBox ctrlNumeric;
                    MaskedTextBox ctrlMasked;
                    DataGridView ctrlDataGrid;

                    if ((ctrlText = ctrl as TextBox) != null)
                    {
                        ctrlText.Text = string.Empty;
                    }
                    else if ((ctrlCombo = ctrl as ComboBox) != null)
                    {
                        ctrlCombo.SelectedIndex = -1;
                    }
                    else if ((ctrlCheck = ctrl as CheckBox) != null)
                    {
                        ctrlCheck.Checked = false;
                    }
                    else if ((ctrlNumeric = ctrl as NumericTextBox) != null)
                    {
                        ctrlNumeric.Text = null;
                    }
                    else if ((ctrlMasked = ctrl as MaskedTextBox) != null)
                    {
                        ctrlMasked.Text = string.Empty;
                    }
                    else if ((ctrlDataGrid = ctrl as DataGridView) != null)
                    {
                        ctrlDataGrid.Rows.Clear();
                    }
                }
            }
        }

        private void btnImportarBoleto_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(cbCategoria.SelectedValue) != 0 && (Convert.ToInt32(cbSegmento.SelectedValue) != 0) && (Convert.ToInt32(cbBoletador.SelectedValue) != 0))
            {
                try
                {
                    _Responsavel.ID_Servico = 0;
                    _Responsavel.ID_Objeto = Convert.ToInt32(cbCategoria.SelectedValue.ToString());
                    _Responsavel.ID_Responsavel = Convert.ToInt32(cbAnalista.SelectedValue);
                    _Responsavel.IdSegmento = Convert.ToInt32(cbSegmento.SelectedValue);
                    _Responsavel.Segmento = cbSegmento.Text.ToString();
                    _Responsavel.Prioridade = ckbPrioridade.Checked;

                    Boletador bol = (Boletador)(cbBoletador.SelectedItem);
                    if (bol.NomeMetodo != "")
                    {
                        CustomMethod.ChamarMetodo(bol.NomeMetodo, CustomMethod.MethodForm.RegistrarOperacao);
                    }

                    _Responsavel = new ResponsavelServico();

                    msgLog = "Registro concluído";
                    Log.GravaLog(msgLog);

                    if (MessageBox.Show("Registrar outro serviço?", "Contratos", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        ClearControlsData(tabGroup1);
                        txtIdentificacao.Text = string.Empty;
                        ckbPrioridade.Checked = false;
                    }
                    else
                    {
                        this.Close();
                    }
                }
                catch (Exception Excep)
                {
                    msgLog = "Erro so chamar serviço de importação. Erro: " + Excep.Message;
                    Log.GravaLog(msgLog);
                    MessageBox.Show(msgLog);
                }
            }
            else
            {
                MessageBox.Show("Dados obrigatórios:\n>> Escolha o Produto, Segmento e forma de importação", "Mobios");
            }
        }

        #region [ Mudança Valor ComboBox ]
        private void cboCategoria_SelectedValueChanged(object sender, EventArgs e)
        {
            if (_Responsavel.ID_Objeto != Convert.ToInt32(cbCategoria.SelectedValue.ToString()))
            {
                if (this.cbCategoria.Text == "")
                {
                    tabGroup1.Controls.Clear();
                }
                else
                {
                    lista = DataAccess.buscarCamposDinamicos(Convert.ToInt32(cbCategoria.SelectedValue));
                    tabGroup1.Controls.Clear();
                    TelaDinamica.MontarFormulario(lista, this, tabGroup1, true);
                }
                _Responsavel.ID_Objeto = Convert.ToInt32(cbCategoria.SelectedValue.ToString());
            }
        }

        private void cbProduto_SelectedValueChanged(object sender, EventArgs e)
        {
            if (this.cboProduto.Text == "")
            {
                this.cbCategoria.Visible = false;
                this.Categoria.Visible = false;
                this.cbCategoria.DataSource = ObjetoSegmento.Where(n => n.CategoriaObjeto == this.cboProduto.Text).ToList();
                this.cbCategoria.SelectedValue = 0;
            }
            else
            {
                List<Objeto> temp = ObjetoSegmento.Where(n => n.CategoriaObjeto == this.cboProduto.Text || n.CategoriaObjeto == "" || n.CategoriaObjeto == null).ToList();
                this.cbCategoria.DataSource = temp;
                this.cbCategoria.SelectedValue = 0;
                this.cbCategoria.Top = this.Categoria.Top - 4;

                if (temp.Count() == 2)
                {
                    this.cbCategoria.SelectedIndex = 1;
                }

                this.cbCategoria.Visible = true;
                this.Categoria.Visible = true;
            }
        }

        private void cbSegmento_SelectedValueChanged(object sender, EventArgs e)
        {
            if (_Responsavel.IdSegmento != Convert.ToInt32(cbSegmento.SelectedValue))
            {
                ObjetoSegmento = _ListaObjetos.Where(n => n.IdSegmento == Convert.ToInt32(cbSegmento.SelectedValue) || n.IdSegmento == 0).ToList();
                _Categorias = ObjetoSegmento.Select(n => n.CategoriaObjeto).Distinct().ToList();
                if (this.cbSegmento.Text == "")
                {
                    this.cbCategoria.Visible = false;
                    this.Categoria.Visible = false;
                    this.cboProduto.Visible = false;
                    this.produto.Visible = false;
                    this.cboProduto.DataSource = _Categorias;

                    _Categorias.Clear();
                }
                else
                {
                    
                    if (_Categorias.Count() <= 2)
                    {
                        this.cbCategoria.Top = this.cboProduto.Top;
                        this.cbCategoria.Left = this.cboProduto.Left;
                        this.cbCategoria.Width = this.cboProduto.Width;
                        this.cbCategoria.DataSource = ObjetoSegmento;
                        this.cbCategoria.Visible = true;

                        if (_Categorias.Count() == 2)
                        {
                            this.Categoria.Visible = false;
                            this.cbCategoria.SelectedIndex = 1;
                        }

                        this.cboProduto.Visible = false;
                        this.produto.Visible = true;
                    }
                    else
                    {
                        this.cboProduto.DataSource = _Categorias;
                        this.cboProduto.Visible = true;
                        this.produto.Visible = true;
                    }
                }
                _Responsavel.IdSegmento = Convert.ToInt32(cbSegmento.SelectedValue);

            }
        }
        #endregion

        private void RegistrarOperacao_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (SharedData.isOpenForm(typeof(Pipeline), false))
            {
                ((Pipeline)Application.OpenForms["Pipeline"]).Bind();
            }
        }
    }
}
