﻿namespace Mobios
{
    partial class RegistrarOperacao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegistrarOperacao));
            this.Segmento = new System.Windows.Forms.GroupBox();
            this.cbCategoria = new System.Windows.Forms.ComboBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnImportarBoleto = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.cbBoletador = new System.Windows.Forms.ComboBox();
            this.Categoria = new System.Windows.Forms.Label();
            this.cboProduto = new System.Windows.Forms.ComboBox();
            this.produto = new System.Windows.Forms.Label();
            this.cbSegmento = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabGroup1 = new System.Windows.Forms.TabControl();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.boxAnalista = new System.Windows.Forms.GroupBox();
            this.cbAnalista = new System.Windows.Forms.ComboBox();
            this.lblAnalista = new System.Windows.Forms.Label();
            this.lbNomeServico = new System.Windows.Forms.Label();
            this.txtIdentificacao = new System.Windows.Forms.TextBox();
            this.ckbPrioridade = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Segmento.SuspendLayout();
            this.panel7.SuspendLayout();
            this.boxAnalista.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // Segmento
            // 
            this.Segmento.Controls.Add(this.cbCategoria);
            this.Segmento.Controls.Add(this.panel7);
            this.Segmento.Controls.Add(this.Categoria);
            this.Segmento.Controls.Add(this.cboProduto);
            this.Segmento.Controls.Add(this.produto);
            this.Segmento.Controls.Add(this.cbSegmento);
            this.Segmento.Controls.Add(this.label1);
            this.Segmento.Location = new System.Drawing.Point(13, 6);
            this.Segmento.Name = "Segmento";
            this.Segmento.Size = new System.Drawing.Size(950, 94);
            this.Segmento.TabIndex = 0;
            this.Segmento.TabStop = false;
            this.Segmento.Text = "Operação";
            // 
            // cbCategoria
            // 
            this.cbCategoria.DisplayMember = "DescricaoObjeto";
            this.cbCategoria.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCategoria.FormattingEnabled = true;
            this.cbCategoria.Location = new System.Drawing.Point(70, 67);
            this.cbCategoria.Name = "cbCategoria";
            this.cbCategoria.Size = new System.Drawing.Size(413, 21);
            this.cbCategoria.TabIndex = 3;
            this.cbCategoria.ValueMember = "ID_Objeto";
            this.cbCategoria.Visible = false;
            this.cbCategoria.SelectedValueChanged += new System.EventHandler(this.cboCategoria_SelectedValueChanged);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.btnImportarBoleto);
            this.panel7.Controls.Add(this.label3);
            this.panel7.Controls.Add(this.cbBoletador);
            this.panel7.Location = new System.Drawing.Point(658, 14);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(286, 44);
            this.panel7.TabIndex = 24;
            // 
            // btnImportarBoleto
            // 
            this.btnImportarBoleto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImportarBoleto.Location = new System.Drawing.Point(178, 3);
            this.btnImportarBoleto.Name = "btnImportarBoleto";
            this.btnImportarBoleto.Size = new System.Drawing.Size(100, 23);
            this.btnImportarBoleto.TabIndex = 12;
            this.btnImportarBoleto.Text = "Capturar";
            this.btnImportarBoleto.UseVisualStyleBackColor = true;
            this.btnImportarBoleto.Visible = false;
            this.btnImportarBoleto.Click += new System.EventHandler(this.btnImportarBoleto_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "Importar:";
            this.label3.Visible = false;
            // 
            // cbBoletador
            // 
            this.cbBoletador.DisplayMember = "NomeBoletador";
            this.cbBoletador.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBoletador.FormattingEnabled = true;
            this.cbBoletador.Location = new System.Drawing.Point(65, 5);
            this.cbBoletador.Name = "cbBoletador";
            this.cbBoletador.Size = new System.Drawing.Size(107, 21);
            this.cbBoletador.TabIndex = 18;
            this.cbBoletador.ValueMember = "IdBoletador";
            this.cbBoletador.Visible = false;
            // 
            // Categoria
            // 
            this.Categoria.AutoSize = true;
            this.Categoria.Location = new System.Drawing.Point(9, 70);
            this.Categoria.Name = "Categoria";
            this.Categoria.Size = new System.Drawing.Size(55, 13);
            this.Categoria.TabIndex = 23;
            this.Categoria.Text = "Categoria:";
            this.Categoria.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Categoria.Visible = false;
            // 
            // cboProduto
            // 
            this.cboProduto.DisplayMember = "DescricaoObjeto";
            this.cboProduto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboProduto.FormattingEnabled = true;
            this.cboProduto.Location = new System.Drawing.Point(70, 42);
            this.cboProduto.Name = "cboProduto";
            this.cboProduto.Size = new System.Drawing.Size(413, 21);
            this.cboProduto.TabIndex = 22;
            this.cboProduto.Visible = false;
            this.cboProduto.SelectedValueChanged += new System.EventHandler(this.cbProduto_SelectedValueChanged);
            // 
            // produto
            // 
            this.produto.AutoSize = true;
            this.produto.Location = new System.Drawing.Point(17, 45);
            this.produto.Name = "produto";
            this.produto.Size = new System.Drawing.Size(47, 13);
            this.produto.TabIndex = 2;
            this.produto.Text = "Produto:";
            this.produto.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.produto.Visible = false;
            // 
            // cbSegmento
            // 
            this.cbSegmento.DisplayMember = "Codigo";
            this.cbSegmento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSegmento.FormattingEnabled = true;
            this.cbSegmento.Location = new System.Drawing.Point(70, 18);
            this.cbSegmento.Name = "cbSegmento";
            this.cbSegmento.Size = new System.Drawing.Size(413, 21);
            this.cbSegmento.TabIndex = 1;
            this.cbSegmento.ValueMember = "IdSegmento";
            this.cbSegmento.SelectedValueChanged += new System.EventHandler(this.cbSegmento_SelectedValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Segmento:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tabGroup1
            // 
            this.tabGroup1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabGroup1.Location = new System.Drawing.Point(0, 0);
            this.tabGroup1.Name = "tabGroup1";
            this.tabGroup1.SelectedIndex = 0;
            this.tabGroup1.Size = new System.Drawing.Size(950, 255);
            this.tabGroup1.TabIndex = 1;
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegistrar.Location = new System.Drawing.Point(46, 13);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(79, 23);
            this.btnRegistrar.TabIndex = 3;
            this.btnRegistrar.Text = "Registrar";
            this.btnRegistrar.UseVisualStyleBackColor = true;
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click);
            // 
            // boxAnalista
            // 
            this.boxAnalista.Controls.Add(this.cbAnalista);
            this.boxAnalista.Controls.Add(this.lblAnalista);
            this.boxAnalista.Location = new System.Drawing.Point(13, 106);
            this.boxAnalista.Name = "boxAnalista";
            this.boxAnalista.Size = new System.Drawing.Size(950, 36);
            this.boxAnalista.TabIndex = 5;
            this.boxAnalista.TabStop = false;
            this.boxAnalista.Text = "Analista";
            // 
            // cbAnalista
            // 
            this.cbAnalista.DisplayMember = "NomeResponsavel";
            this.cbAnalista.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbAnalista.FormattingEnabled = true;
            this.cbAnalista.Location = new System.Drawing.Point(70, 10);
            this.cbAnalista.Name = "cbAnalista";
            this.cbAnalista.Size = new System.Drawing.Size(413, 21);
            this.cbAnalista.TabIndex = 1;
            this.cbAnalista.ValueMember = "ID_Responsavel";
            // 
            // lblAnalista
            // 
            this.lblAnalista.AutoSize = true;
            this.lblAnalista.Location = new System.Drawing.Point(17, 16);
            this.lblAnalista.Name = "lblAnalista";
            this.lblAnalista.Size = new System.Drawing.Size(47, 13);
            this.lblAnalista.TabIndex = 0;
            this.lblAnalista.Text = "Analista:";
            this.lblAnalista.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbNomeServico
            // 
            this.lbNomeServico.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbNomeServico.AutoSize = true;
            this.lbNomeServico.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNomeServico.Location = new System.Drawing.Point(21, 155);
            this.lbNomeServico.Name = "lbNomeServico";
            this.lbNomeServico.Size = new System.Drawing.Size(90, 13);
            this.lbNomeServico.TabIndex = 6;
            this.lbNomeServico.Text = "*Identificação:";
            // 
            // txtIdentificacao
            // 
            this.txtIdentificacao.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtIdentificacao.Location = new System.Drawing.Point(113, 151);
            this.txtIdentificacao.Name = "txtIdentificacao";
            this.txtIdentificacao.Size = new System.Drawing.Size(177, 20);
            this.txtIdentificacao.TabIndex = 7;
            // 
            // ckbPrioridade
            // 
            this.ckbPrioridade.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ckbPrioridade.AutoSize = true;
            this.ckbPrioridade.Location = new System.Drawing.Point(316, 153);
            this.ckbPrioridade.Name = "ckbPrioridade";
            this.ckbPrioridade.Size = new System.Drawing.Size(73, 17);
            this.ckbPrioridade.TabIndex = 9;
            this.ckbPrioridade.Text = "Prioridade";
            this.ckbPrioridade.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ckbPrioridade.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 427);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(978, 50);
            this.panel1.TabIndex = 10;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.btnRegistrar);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(247, 50);
            this.panel6.TabIndex = 5;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbNomeServico);
            this.panel2.Controls.Add(this.boxAnalista);
            this.panel2.Controls.Add(this.Segmento);
            this.panel2.Controls.Add(this.ckbPrioridade);
            this.panel2.Controls.Add(this.txtIdentificacao);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(978, 172);
            this.panel2.TabIndex = 11;
            // 
            // panel3
            // 
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 172);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(14, 255);
            this.panel3.TabIndex = 12;
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(964, 172);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(14, 255);
            this.panel4.TabIndex = 13;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.tabGroup1);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(14, 172);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(950, 255);
            this.panel5.TabIndex = 14;
            // 
            // RegistrarOperacao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(978, 477);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "RegistrarOperacao";
            this.ShowIcon = false;
            this.Text = "Registrar serviço";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.RegistrarOperacao_FormClosed);
            this.Segmento.ResumeLayout(false);
            this.Segmento.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.boxAnalista.ResumeLayout(false);
            this.boxAnalista.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox Segmento;
        private System.Windows.Forms.ComboBox cbSegmento;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label produto;
        private System.Windows.Forms.ComboBox cbCategoria;
        private System.Windows.Forms.TabControl tabGroup1;
        private System.Windows.Forms.Button btnRegistrar;
        private System.Windows.Forms.GroupBox boxAnalista;
        private System.Windows.Forms.Label lblAnalista;
        private System.Windows.Forms.ComboBox cbAnalista;
        private System.Windows.Forms.Label lbNomeServico;
        private System.Windows.Forms.TextBox txtIdentificacao;
        private System.Windows.Forms.CheckBox ckbPrioridade;
        private System.Windows.Forms.ComboBox cboProduto;
        private System.Windows.Forms.Label Categoria;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button btnImportarBoleto;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbBoletador;
    }
}