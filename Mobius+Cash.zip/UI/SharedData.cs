﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Diagnostics;
//using System.Net.Mail;
//using System.Net;
using System.Linq;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using DAO = Microsoft.Office.Interop.Access.Dao;
using System.Security.Principal;
using System.Data.Common; // USED ONLY FOR THE DAO METHOD
using System.Data.OleDb;



namespace Mobios
{
    public class SharedData
    {
        private static string msgLog;
        public static string _ArquivoSalvo_Minuta;
        public static StringBuilder g_sb_processo = new StringBuilder();

        #region [ Parametros ]
        public static DataTable Queries { get; set; }
        public static DataTable Parametros { get; set; }
        public static List<Campos> gCamposObjeto { get; set; }
        public static List<Campos> gCamposEtapa { get; set; }
        public static List<CamposTabela> gCamposTabela { get; set; }
        public static List<EtapasObjeto> gEtapasObjeto { get; set; }
        public static List<Status> gStatusEtapa { get; set; }
        public static List<ClassListMethod> gMetodos { get; set; }
        public static bool gPreCarregarCampos { get; set; }
        public static string gVersao { get; set; }
        public static string gVersaoSistemaPublish { get; set; }
        public static string gVersaoSistemaDebug { get; set; }
        public static bool gValidarResponsavel { get; set; }
        public static bool gAtribuiResponsavelServico { get; set; }
        public static bool gPontoEletronico { get; set; }
        public static bool gLeitorWEB { get; set; }
        public static bool gLeitorEmail { get; set; }
        public static bool gLeitorSharepoint { get; set; }
        public static bool gLeitorMetodo { get; set; }
        public static bool gValidaBoleto { get; set; }
        public static string gPontoEletronicoURL { get; set; }
        public static bool gPipelineFiltro { get; set; }
        public static bool gPipelineAutomatico { get; set; }
        public static bool gValidaDependenciaResponsavel { get; set; }
        public static bool gValidaMesmoResponsavel { get; set; }
        public static bool gQrCode { get; set; }
        public static string gQrCodeTamanho { get; set; }
        public static bool gGravarLogAoGerarMinuta { get; set; }
        public static bool gPaginasPortalItau { get; set; }
        public static bool gBackUp { get; set; }
        public static int gBackUpQtd { get; set; }
        public static int gBackUpInterval { get; set; }
        public static bool gValidaPonto { get; set; }
        public static string gValidaPontoLink { get; set; }
        public static int gValidaPontoInterval { get; set; }
        public static string gSuporteAssunto { get; set; }
        public static string gSuporteEmail { get; set; }
        public static string gSuporteMensagem { get; set; }

        public static string gBenTagContrato { get; set; }
        public static string gBenTagSearchKey { get; set; }
        public static string gBenXmlResumo { get; set; }
        public static string gBenTrincaPME { get; set; }
        public static string gBenDetalhe { get; set; }

        public static string gBoletadorTela { get; set; }
        public static string gFormOperação { get; set; }
        public static string gLoginOQ { get; set; }
        public static string gLinkOQ { get; set; }
        public static string gLoginPN { get; set; }
        public static string gLinkPN { get; set; }

        public static int gTimerIntervalIntegracoes { get; set; }
        public static int gTimerIntervalFechamento { get; set; }
        public static int gTimerIntervalPortal { get; set; }
        public static int gTimerIntervalPipeline  { get; set; }
        public static int gTimerIntervalDetalhe { get; set; }

        public static int gPipeLinePageSize { get; set; }
        public static bool gPipeLineMaximizar { get; set; }

        public static bool gFalar { get; set; }
        #endregion

        #region [ Usuário ]
        public static Responsavel User { get; set; }
        public static List<Responsavel> UserCelulas { get; set; }
        public static List<int> UserAcessoCelulas { get; set; }
        #endregion

        public static EtapasObjeto Etapa { get; set; }
        
        public static string GetQueryDefinition(string QueryName)
        {
            string result = "";

            DataRow[] dtRows = SharedData.Queries.Select("TABLE_NAME = '" + QueryName + "'");

            if (dtRows.Count() > 0)
            {
                result = dtRows[0]["VIEW_DEFINITION"].ToString();
            }

            return result;
        }

        #region [ Acessos ]
        public static bool BuscarAcessos()
        {
            bool result = false;

            List<Responsavel> Resp = new List<Responsavel>();
            List<int> AcessoCelulas = new List<int>();

            #region [ busca usuario ]
            try
            {
                #region [ valida usuario ]
                Resp = DataAccess.BuscarResponsaveisAreaCelulasAcessadas(Environment.UserName.ToUpper());
                AcessoCelulas = Resp.Select(n => n.IdCelulaAcesso).Distinct().ToList();
                Resp = Resp.GroupBy(n => new { n.ID_Responsavel, n.ID_Celula }).Select(g => g.First()).ToList();

                if (Resp.Count > 0)
                {
                    SharedData.User = Resp.First();
                    SharedData.UserCelulas = Resp;
                }
                if (AcessoCelulas.Count > 0)
                {
                    SharedData.UserAcessoCelulas = AcessoCelulas;
                }
                #endregion
            }
            catch (Exception exp)
            {
                #region [ responsavel não cadastrado ]
                msgLog = "Erro acesso ao Buscar Responsáveis. " + exp.Message;
                msgLog += "\n Tentativa de logar com usuário: " + Environment.UserName.ToUpper() + "";
                msgLog += "\n Função: DataAccess.BuscarResponsaveisAreaCelulasAcessadas";
                MessageBox.Show(msgLog, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Log.GravaLog(msgLog);
                #endregion
            }
            finally
            {
                if (Resp.Count > 0 && AcessoCelulas.Count > 0)
                {
                    result = true;
                }
            }
            #endregion

            return result;
        }
        public static void CriaArquivoAcesso(string LoginUsuario)
        {
            Log.CriaDiretorioRede(SharedData.AcessosPath);

            string PathFull = SharedData.AcessosPath + LoginUsuario;
            if (!File.Exists(PathFull))
            {
                using (System.IO.StreamWriter sw = System.IO.File.CreateText(PathFull))
                {
                    sw.Close();
                }
            }
        }
        public static bool VerificaArquivoAcesso(string NomeArquivo = "")
        {
            if (NomeArquivo =="")
            {
                NomeArquivo = Environment.UserName.ToUpper();
            }
            bool result = false;

            string PathFull = SharedData.AcessosPath + NomeArquivo;

            if (File.Exists(PathFull))
            {
                result = true;
            }
            return result;
        }
        public static bool ExcluiArquivoAcesso(string NomeArquivo = "")
        {
            if (NomeArquivo == "")
            {
                NomeArquivo = Environment.UserName.ToUpper();
            }
            bool result = false;

            string PathFull = SharedData.AcessosPath + NomeArquivo;

            if (File.Exists(PathFull))
            {
                File.Delete(PathFull);
                result = true;
            }
            return result;
        }
        #endregion

        #region [ Back-Up ]
        public static void CriaArquivoBackUp()
        {
            Log.CriaDiretorioRede(SharedData.BackUpPathLog);

            string PathFull = SharedData.BackUpPathLog + "BACKUP";
            if (!File.Exists(PathFull))
            {
                using (System.IO.StreamWriter sw = System.IO.File.CreateText(PathFull))
                {
                    sw.Close();
                }
            }
        }
        public static bool VerificaArquivoBackUp()
        {
            bool result = false;

            string PathFull = SharedData.BackUpPathLog + "BACKUP";

            if (File.Exists(PathFull))
            {
                result = true;
            }
            return result;
        }
        public static bool ExcluiArquivoBackUp()
        {
            bool result = false;

            string PathFull = SharedData.BackUpPathLog + "BACKUP";

            if (File.Exists(PathFull))
            {
                File.Delete(PathFull);
                result = true;
            }
            return result;
        }
        #endregion

        #region [ Obriga Fechamento ]
        public static void CriaArquivoOFF()
        {
            string En = SharedData.PathObrigarFechamento;

            if (!File.Exists(En))
            {
                using (System.IO.StreamWriter sw = System.IO.File.CreateText(En))
                {
                    sw.Close();
                }
            }
        }
        public static bool ExcluiArquivoOFF()
        {
            string En = SharedData.PathObrigarFechamento;
            bool result = false;

            string PathFull = En;

            try
            {
                if (File.Exists(PathFull))
                {
                    File.Delete(PathFull);
                    result = true;
                }
            }
            catch(Exception errOFF)
            {
                Log.GravaLog(errOFF.Message);
            }
            return result;
        }
        #endregion

        public static DateTime AddWorkdays(DateTime originalDate, int workDays)
        {
            DateTime tmpDate = originalDate;
            while (workDays > 0)
            {
                tmpDate = tmpDate.AddDays(1);
                if (tmpDate.DayOfWeek < DayOfWeek.Saturday &&
                    tmpDate.DayOfWeek > DayOfWeek.Sunday)
                    workDays--;
            }
            return tmpDate;
        }

        public static int EmailParms { get; set; }

        #region [ Application Settings ]
        public static string ApplicationPath { get; set; }
        public static bool gHomologação { get; set; }
        public static string BDPath { get; set; }
        public static string BD { get; set; }
        public static string LogPath { get; set; }
        public static string AcessosPath { get; set; }
        public static string BackUpPath { get; set; }
        public static string BackUpPathLog { get; set; }
        public static string PathObrigarFechamento{ get; set; }

        public static string ReturnApplicationPath()
        {
            string result = TratamentoCampo.AdicionaBarraPath(Path.GetDirectoryName(Application.ExecutablePath));
            return result;
        }
        public static bool ReturnHomologacao()
        {
            bool result = Convert.ToBoolean(ConfigurationManager.ConnectionStrings["Homologacao"].ConnectionString);
            return result;
        }
        public static string ReturnBase(string DB)
        {
            string connectionString = string.Empty;

            if (SharedData.gHomologação)
            {
                DB = DB + "Homologacao";
            }
            connectionString = SharedData.BDPath + ConfigurationManager.ConnectionStrings[DB].ConnectionString;

            return connectionString;
        }
        public static string ReturnPathBase()
        {
            string connectionString = string.Empty;

            string BDpath = "BDpath";

            if (SharedData.gHomologação)
            {
                BDpath = BDpath + "Homologacao";
            }
            connectionString = ConfigurationManager.ConnectionStrings[BDpath].ConnectionString;
            connectionString = TratamentoCampo.AdicionaBarraPath(connectionString);

            return connectionString;
        }
        public static string ReturnPathLog()
        {
            string PathLOG = "";
            if (SharedData.gHomologação)
            {
                PathLOG = System.Configuration.ConfigurationManager.AppSettings["CaminhoLOGHomologacao"].ToString();
            }
            else
            {
                PathLOG = System.Configuration.ConfigurationManager.AppSettings["CaminhoLOG"].ToString();
            }
            PathLOG = TratamentoCampo.AdicionaBarraPath(PathLOG);
            return PathLOG;
        }
        public static string ReturnPathAcessos()
        {
            string PathLOG = SharedData.LogPath + "LogAcessos\\";
            return PathLOG;
        }
        public static string ReturnPathBackUp()
        {
            string PathLOG = SharedData.ApplicationPath + "BackUp\\";
            return PathLOG;
        }
        public static string ReturnPathBackUpLog()
        {
            string PathLOG = SharedData.LogPath + "BackUp\\";
            return PathLOG;
        }
        public static string ReturnPathObrigarFechamento()
        {
            string PathLOG = "";
            if (ConfigurationManager.ConnectionStrings["Homologacao"].ConnectionString == "true")
            {
                PathLOG = System.Configuration.ConfigurationManager.AppSettings["PathObrigarFechamentoHomologacao"].ToString();
            }
            else
            {
                PathLOG = System.Configuration.ConfigurationManager.AppSettings["PathObrigarFechamento"].ToString();
            }
            return PathLOG;
        }

        public static bool ValidaBD()
        {
            bool result = true;
            string BDPath = "BDpath";
            List<string> DB = new List<string>();
            DB.Add("BDconsulta");


            if (SharedData.gHomologação)
            {
                BDPath = BDPath + "Homologacao";
                List<string> temp = new List<string>();
                foreach (string d in DB)
                {
                    temp.Add(d + "Homologacao");
                }

                for (int i = 0; i < DB.Count; i++)
                {
                    DB[i] = temp[i];
                }
            }
            foreach (string d in DB)
            {
                string PathBD = ConfigurationManager.ConnectionStrings[BDPath].ConnectionString + ConfigurationManager.ConnectionStrings[d].ConnectionString;
                if (!File.Exists(PathBD))
                {
                    result = false;
                    break;
                }
            }
            return result;
        }
        public static void Quit()
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();

            if (System.Windows.Forms.Application.MessageLoop)
            {
                // WinForms app
                System.Windows.Forms.Application.Exit();
            }
            else
            {
                // Console app
                System.Environment.Exit(1);
            }
        }
        public static bool isOpenForm(Type frmType, bool MostraMensagem = false, bool ativar = true)
        {
            bool bolCtl = false;
            foreach (Form form in Application.OpenForms)
            {
                if (form.GetType().Equals(frmType))
                {
                    //form.Show();
                    if (MostraMensagem)
                        MessageBox.Show("Formulário '" + form.Name.ToString() + "' já está aberto. Favor fechá-lo para abrir nova instância.", "Formulário Aberto", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    if (ativar)
                    form.Activate();
                    bolCtl = true;
                    break;
                }
            }
            return bolCtl;
        }
        public static void CloseAllForms(Type frmType = null)
        {
            List<Form> f = new List<Form>();
            foreach (Form form in Application.OpenForms)
            {
                f.Add(form);
            }

            foreach (Form form in f)
            {
                if (frmType != null)
                {
                    if (!form.GetType().Equals(frmType))
                    {
                        try
                        {
                            form.Close();
                        }
                        catch { }
                        try
                        {
                            form.Dispose();
                        }
                        catch { }
                    }
                }
                else
                {
                    try
                    {
                        form.Close();
                    }
                    catch { }
                    try
                    {
                        form.Dispose();
                    }
                    catch { }
                }
            }
        }
        public static bool verExec(string Processo)
        {

            System.Diagnostics.Process currentProcess = System.Diagnostics.Process.GetCurrentProcess();

            // Get all processes running on the local computer.
            System.Diagnostics.Process[] localAll = System.Diagnostics.Process.GetProcesses();

            // Get all instances of Notepad running on the local computer.
            // This will return an empty array if notepad isn't running.
            System.Diagnostics.Process[] localByName = System.Diagnostics.Process.GetProcessesByName(Processo);

            if (localByName.Length > 1)
                return true;
            else
                return false;



        }
        public static bool versao_sistema(string versao_verifica, bool publish)
        {

            bool result = true;
            string versao_tabela_access = "";
            
            if (publish)
            {
                versao_tabela_access = SharedData.gVersaoSistemaPublish;
            }
            else
            {
                versao_tabela_access = SharedData.gVersaoSistemaDebug;
            }

            if (versao_tabela_access != "" && versao_tabela_access != null)
            {
                if (versao_verifica == versao_tabela_access)
                {
                    msgLog = "Versão OK...Versão rodando: " + versao_verifica + " | Versão apta (tabela access VERSAO):" + versao_tabela_access + ".";
                    Log.GravaLog(msgLog);
                    result = true;
                }
                else
                {
                    msgLog = "Versão ERRADA...Versão rodando: " + versao_verifica + " | Versão apta (tabela access VERSAO):" + versao_tabela_access + ".";
                    Log.GravaLog(msgLog);
                    result = false;
                }
                if (!result)
                {
                    Loading.StaticFormVisible(false);
                    MessageBox.Show("Versão do sistema (" + versao_verifica + ") não habilitada na tabela do Access.\n\nFavor trocar para a versão habilitada.(" + versao_tabela_access + ") ou alterar a configuração do Access.\n\nSistema será fechado.", "Mobios", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }

            else
            {
                msgLog = "Versão não encontrada... Verifique se a conexão com o banco de dados está funcionando ou se a tabela VERSAO está com dados.";
                Log.GravaLog(msgLog);
                result = false;
                if (!result)
                {
                    MessageBox.Show("Não foi possível determinar a versão habilitada para rodar o sistema.\n\nFavor verificar conexão com o banco de dados ou se a tabela Versao está com dados.\n\nSistema será fechado.", "Mobios Versão:" + versao_verifica, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }

            return result;

        }
        #endregion

        #region [ outlook ]
        public static bool CreateMailItem(string mySubject, string myTo, string myHtmlBody, string myPathAttachment = "", bool MostrarEmail = true, string myCc = "")
        {
            Microsoft.Office.Interop.Outlook.Application app = new Microsoft.Office.Interop.Outlook.Application();
            Microsoft.Office.Interop.Outlook.MailItem mailItem = app.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
            mailItem.Subject = mySubject;
            mailItem.To = myTo;
            if (myCc != "")
                mailItem.CC = myCc;
            //mailItem.Body = "This is the message.";
            mailItem.HTMLBody = myHtmlBody;
            if (myPathAttachment != "")
            {
                mailItem.Attachments.Add(myPathAttachment);
            }

            //mailItem.Attachment.Add(logPath);//logPath is a string holding path to the log.txt file
            //mailItem.Importance = Microsoft.Office.Tools.Outlook.OlImportance.olImportanceHigh;
            if (SharedData.gHomologação && !MostrarEmail)
            {
                if (MessageBox.Show("Um email está sendo gerado de forma automática.\n\nDados:\nAssunto:" + mySubject + "\nPara: " + myTo + (myCc != "" ? ("\nEm cópia: " + myCc) : "") + "\n\nExibir mensagem antes de enviar?", "Envio de E-mail", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
                {
                    MostrarEmail = true;
                }
            }

            if (MostrarEmail == false)
                try
                {
                    mailItem.Send();
                }
                catch (Exception err)
                {
                    mailItem.Display();
                    MessageBox.Show("Não foi possível enviar o email.\n\nConfira os dados do e-mail.\n\n" + err.Message, "E-mail", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            else
                mailItem.Display();

            return true;
        }

        public static void GetFolders(Microsoft.Office.Interop.Outlook.MAPIFolder folder)
        {
            if (folder.Folders.Count == 0)
            {
                Debug.Print(folder.Name);
            }
            else
            {
                foreach (Microsoft.Office.Interop.Outlook.MAPIFolder subFolder in folder.Folders)
                {
                    GetFolders(subFolder);
                }
            }
        }
        // Opção por leitura da pasta OutLook porque permite criar regra para mover as mensagens para pasta particular e reduzir qde de msg a ser lida
        public static string ReadMailItem(string parmPasta, string parmTextoEsperado)
        {
            string deuerronaconversão = "";
            string titulo = "";
            string remetente = "";

            string msgRetorno = "";
            int qdeRetorno = 0;

            string validateMailAddress = "";

            List<string> listEmailsCannotRead = DataAccess.RetornaEmailsCannotRead();
            // variaveis MOBIOS
            Microsoft.Office.Interop.Outlook.Application app = new Microsoft.Office.Interop.Outlook.Application();
            Microsoft.Office.Interop.Outlook.Items items;
            Microsoft.Office.Interop.Outlook.NameSpace ns;
            Microsoft.Office.Interop.Outlook.MAPIFolder inboxDefined = null;
            //Microsoft.Office.Interop.Outlook.MAPIFolder destFolder;
            string separadorStr = "|";

            //RETORNA CONTA E PASTA CONFIGURADA NA TABELA tb_0200_Parametros
            //boxName = DataAccess.GetParametro("EmailAccount");
            //inboxBoxName = DataAccess.GetParametro("EmailBox");

            //ns = app.Session;
            try
            {
                List<ResponsavelCelula> responsCelula = DataAccess.BuscarResponsaveisCelula(Environment.UserName.ToUpper());

                ns = app.GetNamespace("MAPI");
                //PARA CADA CAIXA DO OUTLOOK ELE PROCURA A CONTA CONFIGURADA NO PARAMETRO
                foreach (Microsoft.Office.Interop.Outlook.MAPIFolder folder in ns.Folders)
                {
                    foreach (ResponsavelCelula respCelula in responsCelula)
                    {
                        if (folder.Name.Contains("@") && folder.Name.Contains("."))
                        {
                            validateMailAddress = folder.Name;
                        }
                        else
                        {
                            validateMailAddress = folder.Name.Replace(" ", string.Empty) + "@itaubba.com.br";
                        }
                        if (validateMailAddress.ToLower() == respCelula.EmailAccount.ToLower())
                        {
                            //PARA CADA PASTA DENTRO DA CAIXA DEFINIDA ELE PROCURA A PASTA CONFIGURADA NO PARAMETRO
                            foreach (Microsoft.Office.Interop.Outlook.MAPIFolder subfolder in folder.Folders)
                            {
                                if (subfolder.Name.ToLower() == respCelula.EmailBox.ToLower())
                                {
                                    inboxDefined = subfolder;
                                    items = inboxDefined.Items;
                                    //foreach (Microsoft.Office.Interop.Outlook.MailItem mail in items)
                                    foreach (Object email in items)
                                    {
                                        //DEBUG
                                        deuerronaconversão = "";

                                        if (email is Microsoft.Office.Interop.Outlook.MailItem)
                                        {
                                            //String.Compare(CType(email, Outlook.MailItem).MessageClass, "IPM.NOTE.EnterpriseVault.Shortcut", True) = 0
                                            Microsoft.Office.Interop.Outlook.MailItem mail = (Microsoft.Office.Interop.Outlook.MailItem)email;
                                            bool canRead = true;
                                            if (mail.Sender != null)
                                            {
                                                Microsoft.Office.Interop.Outlook.AddressEntry sender = mail.Sender;
                                                remetente = sender.Name.ToString();
                                                titulo = mail.Subject;
                                                foreach (string cannotread in listEmailsCannotRead)
                                                {
                                                    if (cannotread.ToLower() == sender.Name.ToString().ToLower())
                                                    {
                                                        canRead = false;
                                                    }
                                                }
                                            }

                                            //DEBUG
                                            deuerronaconversão = "Deu erro depois do Conversion " + mail.MessageClass.ToString();

                                            if (canRead)
                                            {
                                                if (mail.UnRead == true)
                                                {
                                                    if (mail.Subject != null)
                                                    {
                                                        if (mail.Subject.ToUpper().Contains(parmTextoEsperado.ToUpper()))
                                                        {
                                                            qdeRetorno++;
                                                            //string chaveMOBIOS = mail.Subject.Substring(2, mail.Subject.IndexOf("#]")-2);
                                                            //MessageBox.Show(chaveMOBIOS);
                                                            msgRetorno = msgRetorno + "Assunto.: " + mail.Subject.ToString() + ". Horario: " + mail.SentOn.ToString() + separadorStr;
                                                            if (mail.Body.ToUpper().Contains("{#"))
                                                            {
                                                                msgRetorno += "Body.: " + mail.Body.Substring(mail.Body.IndexOf("{#"), (mail.Body.IndexOf("#}") - (mail.Body.IndexOf("{#") - 2))) + separadorStr;
                                                            }
                                                            else
                                                            {
                                                                msgRetorno += "Body.: " + "{##}" + separadorStr;
                                                            }
                                                            // retirado para inicio do piloto
                                                            msgRetorno += "|" + mail.SentOn.ToString() + separadorStr;
                                                            mail.UnRead = false;
                                                            //mail.Move(destFolder);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else if (respCelula.EmailAccount == "")
                        {
                            inboxDefined = ns.GetDefaultFolder(Microsoft.Office.Interop.Outlook.OlDefaultFolders.olFolderInbox);
                            items = inboxDefined.Items;
                            //foreach (Microsoft.Office.Interop.Outlook.MailItem mail in items)
                            foreach (Object email in items)
                            {
                                //DEBUG
                                deuerronaconversão = "";

                                if (email is Microsoft.Office.Interop.Outlook.MailItem)
                                {
                                    //String.Compare(CType(email, Outlook.MailItem).MessageClass, "IPM.NOTE.EnterpriseVault.Shortcut", True) = 0
                                    Microsoft.Office.Interop.Outlook.MailItem mail = (Microsoft.Office.Interop.Outlook.MailItem)email;
                                    //DEBUG
                                    deuerronaconversão = "Deu erro depois do Conversion " + mail.MessageClass.ToString();
                                    if (mail.UnRead == true)
                                    {
                                        if (mail.Subject != null)
                                        {
                                            if (mail.Subject.ToUpper().Contains(parmTextoEsperado.ToUpper()))
                                            {
                                                qdeRetorno++;
                                                //string chaveMOBIOS = mail.Subject.Substring(2, mail.Subject.IndexOf("#]")-2);
                                                //MessageBox.Show(chaveMOBIOS);
                                                msgRetorno = msgRetorno + "Assunto.: " + mail.Subject.ToString() + ". Horario: " + mail.SentOn.ToString() + separadorStr;
                                                if (mail.Body.ToUpper().Contains("{#"))
                                                {
                                                    msgRetorno += "Body.: " + mail.Body.Substring(mail.Body.IndexOf("{#"), (mail.Body.IndexOf("#}") - (mail.Body.IndexOf("{#") - 2))) + separadorStr;
                                                }
                                                else
                                                {
                                                    msgRetorno += "Body.: " + "{##}" + separadorStr;
                                                }
                                                // retirado para inicio do piloto
                                                mail.UnRead = false;
                                                //mail.Move(destFolder);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                // Retorno
                if (qdeRetorno > 0)
                    msgRetorno = qdeRetorno.ToString() + separadorStr + msgRetorno;
                else
                    msgRetorno = "0" + separadorStr;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao ler mensagens do e-mail. Erro: " + ex.Message + ". Informações do e-mail: " + titulo + " " + remetente);
                msgRetorno = "0" + separadorStr;
                MessageBox.Show(deuerronaconversão);
            }

            return msgRetorno;
        }
        #endregion

        /// <summary>
        /// Read table from a range in an excel sheet.
        /// Header line of the table in in excel sheet must contain field names.
        /// Copyrights: Finaquant Analytics - www.finaquant.com
        /// </summary>
        /// <param name="ExcelFilePath">A valid file path like  @"C:\Users\John\Documents\Inventory.xlsx</param>
        /// <param name="SheetName">Name of excel sheet</param>
        /// <param name="RangeStr">A valid range string like "B3:E10"</param>
        /// <returns>Table</returns>
        public static DataTable ReadTableFromExcelRange(string ExcelFilePath, string SheetName, string RangeStr, ProgressBar PB = null)
        {

            // PARAMETER CHECKS
            if (ExcelFilePath == null || ExcelFilePath == "")
            {
                //throw new Exception("ReadTableFromExcelRange: Null or empty string FilePath");
                MessageBox.Show("Leitura do Excel: Arquivo não encontrado!");
                return null;
            }

            if (SheetName == null || SheetName == "")
            {
                //throw new Exception("ReadTableFromExcelRange: Null or empty string SheetName");
                MessageBox.Show("Leitura do Excel: Nome da Planilha não foi encontrado!");
                return null;
            }

            if (RangeStr == null || RangeStr == "")
            {
                //throw new Exception("ReadTableFromExcelRange: Null or empty string RangeStr");
                MessageBox.Show("Leitura do Excel: Range Excel está em branco. Verificar parametros!");
                return null;
            }

            if (!File.Exists(ExcelFilePath))
            {
                //throw new Exception("ReadTableFromExcelRange: Excel file is not found!");
                MessageBox.Show("Leitura do Excel: Arquivo Excel não foi encontrado!");
                return null;
            }


            // parameter checks OK ...
            object misValue = System.Reflection.Missing.Value;
            var xlApp = new Excel.Application();
            bool IfReadOnly = true;
            Excel.Worksheet xlWorkSheet = null;
            Excel.Workbook xlWorkBook = null;

            try
            {
                // open workbook
                string msgLog = "Abrindo arquivo para leitura..." + ExcelFilePath + "";
                Log.GravaLog(msgLog);

                xlWorkBook = xlApp.Workbooks.Open(ExcelFilePath, 0, IfReadOnly, 5, "", "", true,
                        Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, 1, 0);

                // check if sheet exists
                bool SheetExists = false;

                foreach (Excel.Worksheet sheet in xlWorkBook.Sheets)
                {
                    if (sheet.Name.Equals(SheetName))
                    {
                        SheetExists = true;
                        break;
                    }
                }

                if (!SheetExists)
                {
                    //throw new Exception("ReadTableFromExcelRange: Sheet is not found in excel file!");
                    MessageBox.Show("ReadTableFromExcelRange: Sheet is not found in excel file!");
                    return null;
                }


                // get worksheet
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Sheets.get_Item(SheetName);

                // int ultimalinha = xlWorkSheet.UsedRange.Rows.Count;

                // get range object
                Excel.Range myRange = (Excel.Range)xlWorkSheet.get_Range(RangeStr);
                int fullRow = myRange.Rows.Count;
                int ultimalinha = myRange.Cells[fullRow, 1].End(Excel.XlDirection.xlUp).Row;
                int lastRowIgnoreFormulas = xlWorkSheet.Cells.Find(
                                "*",
                                System.Reflection.Missing.Value,
                                Excel.XlFindLookIn.xlValues,
                                Excel.XlLookAt.xlWhole,
                                Excel.XlSearchOrder.xlByRows,
                                Excel.XlSearchDirection.xlPrevious,
                                false,
                                System.Reflection.Missing.Value,
                                System.Reflection.Missing.Value).Row;

                DataTable tbl = new DataTable();
                string nomecoluna = "";
                // get column names from header line 
                // Add column F# when it not find
                for (int i = 0; i < myRange.Columns.Count; i++)
                {
                    object CellValue = (object)myRange.Cells[1, i + 1].Value2;
                    if (CellValue == null)
                    {
                        nomecoluna = "F" + (i + 1).ToString();
                        tbl.Columns.Add(nomecoluna);
                    }
                    else
                    {
                        tbl.Columns.Add(CellValue.ToString(), typeof(object));
                    }

                }

                // read values row by row
                //for (int i = 0; i < ultimalinha; i++)
                int linha_maxima = myRange.Rows.Count - 1;
                if (ultimalinha < myRange.Rows.Count)
                {
                    linha_maxima = ultimalinha;
                }

                if (PB != null)
                {
                    PB.Maximum = linha_maxima;
                    PB.Minimum = 0;
                }

                for (int i = 0; i < linha_maxima; i++)
                {
                    tbl.Rows.Add();
                    if (PB != null)
                    {
                        PB.Value = i;
                    }
                    Application.DoEvents();
                    for (int j = 0; j < myRange.Columns.Count; j++)
                    {
                        Application.DoEvents();
                        object CellValue = (object)myRange.Cells[2 + i, j + 1].Value2;
                        tbl.Rows[i][j] = CellValue;
                    }
                }
                // return data table



                return tbl;
            }
            catch (Exception ex)
            {
                //throw new Exception("ReadTableFromExcelRange: " + ex.Message);
                MessageBox.Show(ex.Message);
                return null;
            }
            finally
            {
                try
                {
                    if (xlWorkSheet != null)
                    {
                        Marshal.FinalReleaseComObject(xlWorkSheet);
                    }
                    if (xlWorkBook != null)
                    {
                        Marshal.FinalReleaseComObject(xlWorkBook);
                    }
                    if (xlApp != null)
                    {
                        xlApp.Quit();
                        Marshal.FinalReleaseComObject(xlApp);
                    }
                    string msgLog = "Arquivo Fechado";
                    Log.GravaLog(msgLog);
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
                catch { }
            }
        }
        public static string WriteTable_Excel(string ExcelFilePath, string SheetName, string RangeStrInit, DataTable dt, string NOME_Arquivo, ProgressBar PB = null)
        {
            // PARAMETER CHECKS
            if (ExcelFilePath == null || ExcelFilePath == "")
            {
                MessageBox.Show("ReadTableFromExcelRange: Null or empty string FilePath");
                throw new Exception("ReadTableFromExcelRange: Null or empty string FilePath");
            }

            if (SheetName == null || SheetName == "")
            {
                MessageBox.Show("ReadTableFromExcelRange: Null or empty string SheetName");
                throw new Exception("ReadTableFromExcelRange: Null or empty string SheetName");
            }

            if (RangeStrInit == null || RangeStrInit == "")
            {
                MessageBox.Show("ReadTableFromExcelRange: Null or empty string RangeStr");
                throw new Exception("ReadTableFromExcelRange: Null or empty string RangeStr");
            }

            if (!File.Exists(ExcelFilePath))
            {
                MessageBox.Show("ReadTableFromExcelRange: Excel file is not found!");
                throw new Exception("ReadTableFromExcelRange: Excel file is not found!");
            }


            // parameter checks OK ...
            object misValue = System.Reflection.Missing.Value;
            var xlApp = new Excel.Application();
            bool IfReadOnly = false;
            Excel.Worksheet xlWorkSheet = null;
            Excel.Workbook xlWorkBook = null;

            try
            {
                // open workbook
                xlWorkBook = xlApp.Workbooks.Open(ExcelFilePath, 0, IfReadOnly, 5, "", "", true,
                        Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "\t", true, false, 0, true, 1, 0);

                // check if sheet exists
                bool SheetExists = false;

                foreach (Excel.Worksheet sheet in xlWorkBook.Sheets)
                {
                    if (sheet.Name.Equals(SheetName))
                    {
                        SheetExists = true;
                        break;
                    }
                }

                if (!SheetExists)
                {
                    MessageBox.Show("ReadTableFromExcelRange: Sheet is not found in excel file!");
                    throw new Exception("ReadTableFromExcelRange: Sheet is not found in excel file!");
                }




                // get worksheet
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Sheets.get_Item(SheetName);

                // int ultimalinha = xlWorkSheet.UsedRange.Rows.Count;

                // get range object
                Excel.Range myRange = (Excel.Range)xlWorkSheet.get_Range(RangeStrInit);

                if (PB != null)
                {
                    PB.Minimum = 0;
                    PB.Maximum = dt.Rows.Count;
                }
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (PB != null) PB.Value = i;
                    Application.DoEvents();
                    for (int j = 0; j < dt.Columns.Count; j++)
                    {
                        Application.DoEvents();
                        myRange.Cells[i + 1, j + 1].Value = dt.Rows[i][j].ToString();
                        //myRange.Cells[i + 1, j + 1].Interior.ColorIndex = 44;
                        System.Diagnostics.Debug.Write("| dt.Rows[" + i + "][" + j + "]=" + dt.Rows[i][j].ToString());
                    }
                    System.Diagnostics.Debug.Write("\n");
                }
                if (dt.Rows.Count == 0)
                {
                    string msgLog = "DataTable para exportação para o arquivo excel vazio\n";
                    msgLog += "FilePath do Arquivo Padrão: " + ExcelFilePath + "";
                    Log.GravaLog(msgLog);
                }

                // Pegar Path para salvar o arquivo
                string path_Arquivo = CustomMethod.GetParametroFromColeta("PATH_ARQUIVOS");
                int _ID_Servico = SharedData.Etapa.ID_Servico;
                string Pasta = "Demanda_" + _ID_Servico;
                path_Arquivo = TratamentoCampo.AdicionaBarraPath(path_Arquivo);
                path_Arquivo += Pasta;

                if (!Directory.Exists(path_Arquivo))
                {
                    Directory.CreateDirectory(path_Arquivo);
                }

                string timeStamp = DateTime.Now.ToString("s");
                timeStamp = timeStamp.Replace(":", "");
                timeStamp = timeStamp.Replace("T", "_");

                string NomeExcel = "Servico_" + _ID_Servico + "_" + NOME_Arquivo + "_" + timeStamp + ".xlsx";
                path_Arquivo += @"\" + NomeExcel;
                xlApp.DisplayAlerts = false;
                xlWorkSheet.Protect(misValue, misValue, misValue, misValue, misValue, misValue, true, misValue, misValue, misValue, misValue, misValue, misValue, misValue, true, misValue);
                xlWorkBook.SaveAs(path_Arquivo, Excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue,
                        Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                // salvando o arquivo (save as)
                //xlApp.DisplayAlerts = true;
                xlWorkBook.Close();
                string msgLog2 = "Arquivo Excel Criado: " + path_Arquivo + "\n";
                Log.GravaLog(msgLog2);


                return path_Arquivo;

            }
            catch (Exception ex)
            {
                MessageBox.Show("ReadTableFromExcelRange: " + ex.Message);
                throw new Exception("ReadTableFromExcelRange: " + ex.Message);
            }
            finally
            {
                try
                {
                    if (xlWorkSheet != null)
                    {
                        Marshal.FinalReleaseComObject(xlWorkSheet);
                    }
                    if (xlWorkBook != null)
                    {
                        Marshal.FinalReleaseComObject(xlWorkBook);
                    }
                    if (xlApp != null)
                    {
                        xlApp.Quit();
                        Marshal.FinalReleaseComObject(xlApp);
                    }
                    string msgLog = "Arquivo Fechado";
                    Log.GravaLog(msgLog);
                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                }
                catch { }
            }
        }

        //Helper function for releasing unused resources
        public static void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                System.Diagnostics.Debug.WriteLine("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        //Colocar na declaração: "using DAO = Microsoft.Office.Interop.Access.Dao; "
        //ADD referente: "Microsoft.Office.Interop.Access.Dao"
        public static void BulkExportToAccess(DataTable dtOutData, String TableNm = "", String DBPath = "", string DB = "")
        {
            StringBuilder sb = new StringBuilder();
            DAO.DBEngine dbEngine = new DAO.DBEngine();
            Boolean CheckFl = false;
            if (DBPath == "")
            {
                if (DB != "")
                {
                    if (SharedData.gHomologação)
                    {
                        DB = DB + "Homologacao";
                    }

                    if (!SharedData.ValidaBD())
                    {
                        SharedData.Quit();
                    }
                    DBPath = SharedData.BDPath + ConfigurationManager.ConnectionStrings[DB].ConnectionString;
                }

            }

            try
            {
                DAO.Database db = dbEngine.OpenDatabase(DBPath);
                DAO.Recordset AccesssRecordset = db.OpenRecordset(TableNm);
                DAO.Field[] AccesssFields = new DAO.Field[dtOutData.Columns.Count];

                //Loop on each row of dtOutData
                for (Int32 rowCounter = 0; rowCounter < dtOutData.Rows.Count; rowCounter++)
                {
                    try
                    {
                        AccesssRecordset.AddNew();
                        //Loop on column
                        for (Int32 colCounter = 0; colCounter < dtOutData.Columns.Count; colCounter++)
                        {
                            // for the first time... setup the field name.
                            if (!CheckFl)
                                AccesssFields[colCounter] = AccesssRecordset.Fields[dtOutData.Columns[colCounter].ColumnName];
                            AccesssFields[colCounter].Value = dtOutData.Rows[rowCounter][colCounter];
                        }

                        AccesssRecordset.Update();
                        CheckFl = true;
                    }
                    catch (Exception ex)
                    {

                        if (sb.ToString().IndexOf("Erro ao tentar inserir dados na tabela") < 0)
                        {
                            sb.AppendLine("Erro ao tentar inserir dados na tabela " + TableNm + "");
                            sb.AppendLine("Dados que estavam sendo gravados no momento");
                            for (Int32 colCounter = 0; colCounter < dtOutData.Columns.Count; colCounter++)
                            {
                                if (colCounter == 0)
                                    sb.Append(dtOutData.Columns[colCounter].ColumnName);
                                else
                                    sb.Append("| " + dtOutData.Columns[colCounter].ColumnName);
                            }
                            sb.Append("| Erro");
                        }
                        sb.AppendLine();
                        for (Int32 colCounter = 0; colCounter < dtOutData.Columns.Count; colCounter++)
                        {
                            //Pegando os valores que não foram gravados
                            if (colCounter == 0)
                                sb.Append(dtOutData.Rows[rowCounter][colCounter]);
                            else
                                sb.Append("| " + dtOutData.Rows[rowCounter][colCounter]);
                        }
                        sb.Append(" | " + ex.Message);

                    }
                }

                AccesssRecordset.Close();
                db.Close();
            }
            finally
            {
                if (sb.Length != 0)
                    Log.GravaLog(sb.ToString(), "Err_BulkExportToAccess");
                System.Runtime.InteropServices.Marshal.ReleaseComObject(dbEngine);
                dbEngine = null;
            }
        }

        public static string FormatarErro(StringBuilder sb, Exception e)
        {
            string user = WindowsIdentity.GetCurrent().Name.Split('\\')[1].ToUpper();
            sb.AppendFormat("\n\n\n\n\nUser: {0}  | Date: {1} \n\n\n", user, DateTime.Now);
            sb.AppendFormat("Exception Found:\nType: {0}", e.GetType().FullName);
            sb.AppendFormat("\nMessage: {0}", e.Message);
            sb.AppendFormat("\nSource: {0}", e.Source);
            sb.AppendFormat("\nStacktrace: {0} \n\n\n", e.StackTrace);

            if (e.InnerException != null)
            {
                sb.Append("\n");
                FormatarErro(sb, e.InnerException);
            }

            return sb.ToString();
        }

        public static string ReturnPathBase(string DB)
        {
            string connectionString = string.Empty;

            string BDpath = "BDpath";

            if (ConfigurationManager.ConnectionStrings["Homologacao"].ConnectionString == "true")
            {
                BDpath = BDpath + "Homologacao";
                DB = DB + "Homologacao";
            }
            connectionString = ConfigurationManager.ConnectionStrings[BDpath].ConnectionString + ConfigurationManager.ConnectionStrings[DB].ConnectionString;

            return connectionString;
        }

        public class TABELA
        {
            public string CAMINHO { get; set; }
            public string NOMETABELA { get; set; }
        }
        public class COLUNA
        {
            public string CAMINHO { get; set; }
            public string NOMETABELA { get; set; }
            public string NOMECOLUNA { get; set; }
        }

        public static List<COLUNA> ExportTableSchema(List<string> DBsPath)
        {

            
            List<COLUNA> ListColunas = new List<COLUNA>();
            for (int i = 0; i < DBsPath.Count; i++)
            {
                
                DataTable userTables = null;
                
                using (OleDbConnection connection = new OleDbConnection())
                {
                    // c:\test\test.mdb
                    connection.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + DBsPath[i] + ";Persist Security Info=False";
                    // We only want user tables, not system tables
                    string[] restrictions = new string[4];
                    restrictions[3] = "Table";

                    connection.Open();

                    // Get list of user tables
                    userTables = connection.GetSchema("Tables", restrictions);


                   // List<TABELA> tableNames = new List<TABELA>();
                    for (int j = 0; j < userTables.Rows.Count; j++)
                    {
                        //TABELA minhatabela = new TABELA();
                        //minhatabela.CAMINHO = DBsPath[i];
                        //minhatabela.NOMETABELA = userTables.Rows[j][2].ToString();
                        //tableNames.Add(minhatabela);

                        using (var cmd = new OleDbCommand("select top 1 * from [" + userTables.Rows[j][2].ToString() + "]", connection))
                        using (var reader = cmd.ExecuteReader(CommandBehavior.SchemaOnly))
                        {
                            var table = reader.GetSchemaTable();
                            var nameCol = table.Columns["ColumnName"];

                            foreach (DataRow row in table.Rows)
                            {
                                COLUNA minhacoluna = new COLUNA();
                                minhacoluna.CAMINHO = DBsPath[i];
                                minhacoluna.NOMETABELA = userTables.Rows[j][2].ToString();
                                minhacoluna.NOMECOLUNA = userTables.Rows[j][2].ToString() + "|" + row[nameCol].ToString() + "|" + row["DataType"].ToString();
                                ListColunas.Add(minhacoluna);
                            }
                        }
                    }
                }    
                
            }

            return ListColunas;
            
        }
    }

    public static class Integra
    {

        private static string getValor(string[] Dados, string Campo)
        {

            for (int i = 0; i < Dados.Length; i++)
            {
                if (Dados[i].Contains(Campo))
                {

                    return Dados[i].Replace(Campo, "").Trim();
                }
            }

            return "";

        }

        public class DadosFlag
        {
            public DateTime Horario;
            public string Usuario;
            public string Maquina;
            public Int64 Tempo;

        }



        public static DadosFlag Dados()
        {



            string PT = Gibinho.IO.CurrentPath() + "\\cfg.txt";
            Integra.DadosFlag d = new Integra.DadosFlag();

            bool Tem = System.IO.File.Exists(PT);

            if (Tem == false) return d;

            try
            {

                string[] lines = System.IO.File.ReadAllLines(PT);

                d.Maquina = lines[0];
                d.Usuario = lines[1];
                d.Horario = Convert.ToDateTime(lines[2]);

                DateTime dt1 = DateTime.Now;
                TimeSpan ts1 = dt1.Subtract(d.Horario);
                d.Tempo = Convert.ToInt64(ts1.TotalSeconds);
            }

            catch
            {
                DateTime dt1 = DateTime.Now;
                d.Horario = DateTime.Now;
                TimeSpan ts1 = dt1.Subtract(d.Horario);
                d.Tempo = Convert.ToInt64(ts1.TotalSeconds);
                d.Maquina = "-";
                d.Usuario = "-";

            }

            return d;

        }

        public static void MarcaFlag()
        {

            try
            {

                string PT = Gibinho.IO.CurrentPath() + "\\cfg.txt";

                bool Tem = System.IO.File.Exists(PT);

                if (Tem == false) return;

                using (System.IO.StreamWriter file = new System.IO.StreamWriter(PT, false))
                {
                    file.WriteLine(Environment.MachineName);
                    file.WriteLine(Environment.UserName);
                    file.WriteLine(DateTime.Now);

                }
            }
            catch
            {

            }

        }
    }

}
