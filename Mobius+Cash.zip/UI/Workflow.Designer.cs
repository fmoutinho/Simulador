﻿namespace Mobios
{
    partial class Workflow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Workflow));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chkServCancelado = new System.Windows.Forms.CheckBox();
            this.cbProduto = new System.Windows.Forms.ComboBox();
            this.produto = new System.Windows.Forms.Label();
            this.chkServConcluido = new System.Windows.Forms.CheckBox();
            this.cboAnalista = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dtgWorkFlow = new System.Windows.Forms.DataGridView();
            this.ID_OBJETO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID_Fluxo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID_Area = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID_Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID_Segmento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID_SERVICO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID_RESPONSAVEL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NomeObjeto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SERVICONAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NomeResponsavel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DataCriacao = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Concluido = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Cancelado = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.NomeEtapa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ConcluidoFluxo = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.StatusDescricao = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnVisualizar = new System.Windows.Forms.Button();
            this.dtpFimPeriodo = new System.Windows.Forms.DateTimePicker();
            this.dtpInicioPeriodo = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFimPeriodo = new System.Windows.Forms.TextBox();
            this.txtInicioPeriodo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnExcel = new System.Windows.Forms.Button();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.btnProcessarIndicadores = new System.Windows.Forms.Button();
            this.btnVisualizarIndicadores = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgWorkFlow)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkServCancelado);
            this.groupBox1.Controls.Add(this.cbProduto);
            this.groupBox1.Controls.Add(this.produto);
            this.groupBox1.Controls.Add(this.chkServConcluido);
            this.groupBox1.Controls.Add(this.cboAnalista);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.dtgWorkFlow);
            this.groupBox1.Controls.Add(this.btnVisualizar);
            this.groupBox1.Controls.Add(this.dtpFimPeriodo);
            this.groupBox1.Controls.Add(this.dtpInicioPeriodo);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtFimPeriodo);
            this.groupBox1.Controls.Add(this.txtInicioPeriodo);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1028, 503);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Workflow";
            // 
            // chkServCancelado
            // 
            this.chkServCancelado.AutoSize = true;
            this.chkServCancelado.Location = new System.Drawing.Point(656, 70);
            this.chkServCancelado.Name = "chkServCancelado";
            this.chkServCancelado.Size = new System.Drawing.Size(161, 17);
            this.chkServCancelado.TabIndex = 12;
            this.chkServCancelado.Text = "Mostrar serviços cancelados";
            this.chkServCancelado.UseVisualStyleBackColor = true;
            // 
            // cbProduto
            // 
            this.cbProduto.DisplayMember = "NomeObjeto";
            this.cbProduto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbProduto.FormattingEnabled = true;
            this.cbProduto.Location = new System.Drawing.Point(64, 19);
            this.cbProduto.Name = "cbProduto";
            this.cbProduto.Size = new System.Drawing.Size(485, 21);
            this.cbProduto.TabIndex = 11;
            this.cbProduto.ValueMember = "IDProdObj";
            // 
            // produto
            // 
            this.produto.AutoSize = true;
            this.produto.Location = new System.Drawing.Point(11, 22);
            this.produto.Name = "produto";
            this.produto.Size = new System.Drawing.Size(47, 13);
            this.produto.TabIndex = 10;
            this.produto.Text = "Produto:";
            this.produto.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // chkServConcluido
            // 
            this.chkServConcluido.AutoSize = true;
            this.chkServConcluido.Location = new System.Drawing.Point(656, 42);
            this.chkServConcluido.Name = "chkServConcluido";
            this.chkServConcluido.Size = new System.Drawing.Size(159, 17);
            this.chkServConcluido.TabIndex = 8;
            this.chkServConcluido.Text = "Mostrar serviços concluídos";
            this.chkServConcluido.UseVisualStyleBackColor = true;
            // 
            // cboAnalista
            // 
            this.cboAnalista.DisplayMember = "NomeResponsavel";
            this.cboAnalista.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboAnalista.FormattingEnabled = true;
            this.cboAnalista.Location = new System.Drawing.Point(64, 42);
            this.cboAnalista.Name = "cboAnalista";
            this.cboAnalista.Size = new System.Drawing.Size(485, 21);
            this.cboAnalista.TabIndex = 9;
            this.cboAnalista.ValueMember = "ID_Responsavel";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Analista:";
            // 
            // dtgWorkFlow
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgWorkFlow.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgWorkFlow.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgWorkFlow.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID_OBJETO,
            this.ID_Fluxo,
            this.ID_Area,
            this.ID_Status,
            this.ID_Segmento,
            this.ID_SERVICO,
            this.ID_RESPONSAVEL,
            this.NomeObjeto,
            this.SERVICONAME,
            this.NomeResponsavel,
            this.DataCriacao,
            this.Concluido,
            this.Cancelado,
            this.NomeEtapa,
            this.ConcluidoFluxo,
            this.StatusDescricao});
            this.dtgWorkFlow.Location = new System.Drawing.Point(6, 96);
            this.dtgWorkFlow.Name = "dtgWorkFlow";
            this.dtgWorkFlow.Size = new System.Drawing.Size(1016, 401);
            this.dtgWorkFlow.TabIndex = 7;
            // 
            // ID_OBJETO
            // 
            this.ID_OBJETO.DataPropertyName = "ID_OBJETO";
            this.ID_OBJETO.HeaderText = "ID_OBJETO";
            this.ID_OBJETO.Name = "ID_OBJETO";
            this.ID_OBJETO.Visible = false;
            // 
            // ID_Fluxo
            // 
            this.ID_Fluxo.DataPropertyName = "ID_FLUXO";
            this.ID_Fluxo.HeaderText = "ID_Fluxo";
            this.ID_Fluxo.Name = "ID_Fluxo";
            this.ID_Fluxo.Visible = false;
            // 
            // ID_Area
            // 
            this.ID_Area.DataPropertyName = "ID_Area";
            this.ID_Area.HeaderText = "ID_Area";
            this.ID_Area.Name = "ID_Area";
            this.ID_Area.Visible = false;
            // 
            // ID_Status
            // 
            this.ID_Status.DataPropertyName = "ID_Status";
            this.ID_Status.HeaderText = "ID_Status";
            this.ID_Status.Name = "ID_Status";
            this.ID_Status.Visible = false;
            // 
            // ID_Segmento
            // 
            this.ID_Segmento.DataPropertyName = "ID_Segmento";
            this.ID_Segmento.HeaderText = "ID_Segmento";
            this.ID_Segmento.Name = "ID_Segmento";
            this.ID_Segmento.Visible = false;
            // 
            // ID_SERVICO
            // 
            this.ID_SERVICO.DataPropertyName = "ID_SERVICO";
            this.ID_SERVICO.HeaderText = "ID_SERVICO";
            this.ID_SERVICO.Name = "ID_SERVICO";
            this.ID_SERVICO.Visible = false;
            // 
            // ID_RESPONSAVEL
            // 
            this.ID_RESPONSAVEL.DataPropertyName = "ID_RESPONSAVEL";
            this.ID_RESPONSAVEL.HeaderText = "ID_RESPONSAVEL";
            this.ID_RESPONSAVEL.Name = "ID_RESPONSAVEL";
            this.ID_RESPONSAVEL.Visible = false;
            // 
            // NomeObjeto
            // 
            this.NomeObjeto.DataPropertyName = "NomeObjeto";
            this.NomeObjeto.HeaderText = "Serviço";
            this.NomeObjeto.Name = "NomeObjeto";
            this.NomeObjeto.Width = 200;
            // 
            // SERVICONAME
            // 
            this.SERVICONAME.DataPropertyName = "SERVICONAME";
            this.SERVICONAME.HeaderText = "Identificação";
            this.SERVICONAME.Name = "SERVICONAME";
            this.SERVICONAME.Width = 120;
            // 
            // NomeResponsavel
            // 
            this.NomeResponsavel.DataPropertyName = "NomeResponsavel";
            this.NomeResponsavel.HeaderText = "Responsável";
            this.NomeResponsavel.Name = "NomeResponsavel";
            this.NomeResponsavel.Width = 150;
            // 
            // DataCriacao
            // 
            this.DataCriacao.DataPropertyName = "DataCriacao";
            this.DataCriacao.HeaderText = "Abertura";
            this.DataCriacao.Name = "DataCriacao";
            // 
            // Concluido
            // 
            this.Concluido.DataPropertyName = "Concluido";
            this.Concluido.HeaderText = "Serviço Concluído";
            this.Concluido.Name = "Concluido";
            this.Concluido.ReadOnly = true;
            this.Concluido.Width = 70;
            // 
            // Cancelado
            // 
            this.Cancelado.DataPropertyName = "Cancelado";
            this.Cancelado.HeaderText = "Serviço Cancelado";
            this.Cancelado.Name = "Cancelado";
            this.Cancelado.Width = 70;
            // 
            // NomeEtapa
            // 
            this.NomeEtapa.DataPropertyName = "NomeEtapa";
            this.NomeEtapa.HeaderText = "Fluxo";
            this.NomeEtapa.Name = "NomeEtapa";
            // 
            // ConcluidoFluxo
            // 
            this.ConcluidoFluxo.DataPropertyName = "ConcluidoFluxo";
            this.ConcluidoFluxo.HeaderText = "Fluxo Concluído";
            this.ConcluidoFluxo.Name = "ConcluidoFluxo";
            this.ConcluidoFluxo.ReadOnly = true;
            this.ConcluidoFluxo.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ConcluidoFluxo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ConcluidoFluxo.Width = 70;
            // 
            // StatusDescricao
            // 
            this.StatusDescricao.DataPropertyName = "StatusDescricao";
            this.StatusDescricao.HeaderText = "Status Fluxo";
            this.StatusDescricao.Name = "StatusDescricao";
            this.StatusDescricao.Width = 90;
            // 
            // btnVisualizar
            // 
            this.btnVisualizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVisualizar.Location = new System.Drawing.Point(331, 67);
            this.btnVisualizar.Name = "btnVisualizar";
            this.btnVisualizar.Size = new System.Drawing.Size(75, 23);
            this.btnVisualizar.TabIndex = 6;
            this.btnVisualizar.Text = "Visualizar";
            this.btnVisualizar.UseVisualStyleBackColor = true;
            this.btnVisualizar.Click += new System.EventHandler(this.btnVisualizar_Click);
            // 
            // dtpFimPeriodo
            // 
            this.dtpFimPeriodo.Location = new System.Drawing.Point(305, 68);
            this.dtpFimPeriodo.Name = "dtpFimPeriodo";
            this.dtpFimPeriodo.Size = new System.Drawing.Size(20, 20);
            this.dtpFimPeriodo.TabIndex = 5;
            this.dtpFimPeriodo.ValueChanged += new System.EventHandler(this.dtpFimPeriodo_ValueChanged);
            // 
            // dtpInicioPeriodo
            // 
            this.dtpInicioPeriodo.Location = new System.Drawing.Point(164, 68);
            this.dtpInicioPeriodo.Name = "dtpInicioPeriodo";
            this.dtpInicioPeriodo.Size = new System.Drawing.Size(19, 20);
            this.dtpInicioPeriodo.TabIndex = 4;
            this.dtpInicioPeriodo.ValueChanged += new System.EventHandler(this.dtpInicioPeriodo_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(186, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(13, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "a";
            // 
            // txtFimPeriodo
            // 
            this.txtFimPeriodo.Location = new System.Drawing.Point(205, 68);
            this.txtFimPeriodo.Name = "txtFimPeriodo";
            this.txtFimPeriodo.Size = new System.Drawing.Size(100, 20);
            this.txtFimPeriodo.TabIndex = 2;
            // 
            // txtInicioPeriodo
            // 
            this.txtInicioPeriodo.Location = new System.Drawing.Point(64, 68);
            this.txtInicioPeriodo.Name = "txtInicioPeriodo";
            this.txtInicioPeriodo.Size = new System.Drawing.Size(100, 20);
            this.txtInicioPeriodo.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Periodo:";
            // 
            // btnExcel
            // 
            this.btnExcel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcel.Image = ((System.Drawing.Image)(resources.GetObject("btnExcel.Image")));
            this.btnExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExcel.Location = new System.Drawing.Point(864, 521);
            this.btnExcel.Name = "btnExcel";
            this.btnExcel.Size = new System.Drawing.Size(176, 36);
            this.btnExcel.TabIndex = 10;
            this.btnExcel.Text = "Gerar planilha";
            this.btnExcel.UseVisualStyleBackColor = true;
            this.btnExcel.Visible = false;
            this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.Filter = "Arquivo CSV | *.csv";
            // 
            // btnProcessarIndicadores
            // 
            this.btnProcessarIndicadores.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProcessarIndicadores.Location = new System.Drawing.Point(120, 528);
            this.btnProcessarIndicadores.Name = "btnProcessarIndicadores";
            this.btnProcessarIndicadores.Size = new System.Drawing.Size(147, 23);
            this.btnProcessarIndicadores.TabIndex = 11;
            this.btnProcessarIndicadores.Text = "Processar indicadores";
            this.btnProcessarIndicadores.UseVisualStyleBackColor = true;
            this.btnProcessarIndicadores.Visible = false;
            this.btnProcessarIndicadores.Click += new System.EventHandler(this.btnProcessarIndicadores_Click);
            // 
            // btnVisualizarIndicadores
            // 
            this.btnVisualizarIndicadores.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVisualizarIndicadores.Image = ((System.Drawing.Image)(resources.GetObject("btnVisualizarIndicadores.Image")));
            this.btnVisualizarIndicadores.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVisualizarIndicadores.Location = new System.Drawing.Point(273, 521);
            this.btnVisualizarIndicadores.Name = "btnVisualizarIndicadores";
            this.btnVisualizarIndicadores.Size = new System.Drawing.Size(176, 36);
            this.btnVisualizarIndicadores.TabIndex = 12;
            this.btnVisualizarIndicadores.Text = "Indicadores";
            this.btnVisualizarIndicadores.UseVisualStyleBackColor = true;
            this.btnVisualizarIndicadores.Visible = false;
            this.btnVisualizarIndicadores.Click += new System.EventHandler(this.btnVisualizarIndicadores_Click);
            // 
            // Workflow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1052, 563);
            this.Controls.Add(this.btnVisualizarIndicadores);
            this.Controls.Add(this.btnProcessarIndicadores);
            this.Controls.Add(this.btnExcel);
            this.Controls.Add(this.groupBox1);
            this.Name = "Workflow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Workflow";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgWorkFlow)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpFimPeriodo;
        private System.Windows.Forms.DateTimePicker dtpInicioPeriodo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtFimPeriodo;
        private System.Windows.Forms.TextBox txtInicioPeriodo;
        private System.Windows.Forms.Button btnVisualizar;
        private System.Windows.Forms.DataGridView dtgWorkFlow;
        private System.Windows.Forms.CheckBox chkServConcluido;
        private System.Windows.Forms.ComboBox cboAnalista;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnExcel;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.ComboBox cbProduto;
        private System.Windows.Forms.Label produto;
        private System.Windows.Forms.CheckBox chkServCancelado;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_OBJETO;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_Fluxo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_Area;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_Segmento;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_SERVICO;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_RESPONSAVEL;
        private System.Windows.Forms.DataGridViewTextBoxColumn NomeObjeto;
        private System.Windows.Forms.DataGridViewTextBoxColumn SERVICONAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn NomeResponsavel;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataCriacao;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Concluido;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Cancelado;
        private System.Windows.Forms.DataGridViewTextBoxColumn NomeEtapa;
        private System.Windows.Forms.DataGridViewCheckBoxColumn ConcluidoFluxo;
        private System.Windows.Forms.DataGridViewTextBoxColumn StatusDescricao;
        private System.Windows.Forms.Button btnProcessarIndicadores;
        private System.Windows.Forms.Button btnVisualizarIndicadores;
    }
}