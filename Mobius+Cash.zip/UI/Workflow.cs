﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
//using System.Runtime.InteropServices;
using System.Configuration;
using System.Globalization;

namespace Mobios
{
    

    public partial class Workflow : Form        
    {
        List<WorkflowEnty> listWorkflow = new List<WorkflowEnty>();

        public Workflow()
        {
            InitializeComponent();
            this.cbProduto.DataSource = DataAccess.buscarProdObjAreaResponsavel(SharedData.User.ID_Responsavel, true);

            #region [ Seleção de Analista se parametro de Responsavel por Serviço ]
            if (SharedData.gAtribuiResponsavelServico)
            {
                //if (!SharedData.User.FLG_Gestor)
                //{
                //    List<Responsavel> onlyOne = new List<Responsavel>();
                //    onlyOne.Add(SharedData.User);

                //    this.cboAnalista.DataSource = onlyOne;
                //    this.cboAnalista.Enabled = false;
                //}
                //else
                //{
                    this.cboAnalista.DataSource = DataAccess.BuscarResponsaveisArea(SharedData.UserCelulas.Select(n => n.ID_Area).Distinct().ToList(), true).Where(j => j.UsuarioAtivo == true && j.CelulaAtiva == true && j.AreaAtiva == true).GroupBy(i => i.ID_Responsavel).Select(g => g.First()).ToList();
                //}
            }
            cboAnalista.Visible = SharedData.gAtribuiResponsavelServico;
            label3.Visible = SharedData.gAtribuiResponsavelServico;
            #endregion

            #region [ Data filtro ]
            txtInicioPeriodo.Enabled = true;
            txtFimPeriodo.Text = dtpFimPeriodo.Value.ToString("dd/MM/yyyy");
            
            txtFimPeriodo.Enabled = true;
            txtInicioPeriodo.Text = dtpInicioPeriodo.Value.ToString("dd/MM/yyyy");
            #endregion
        }

        #region [ Datas ]
        private void dtpInicioPeriodo_ValueChanged(object sender, EventArgs e)
        {
            if (dtpInicioPeriodo.Value > dtpFimPeriodo.Value)
            {
                dtpFimPeriodo.Value = dtpInicioPeriodo.Value;
                txtFimPeriodo.Text = dtpFimPeriodo.Value.ToString("dd/MM/yyyy");
            }
            else
            {
                txtInicioPeriodo.Text = dtpInicioPeriodo.Value.ToString("dd/MM/yyyy");
            }
            txtInicioPeriodo.Text = dtpInicioPeriodo.Value.ToString("dd/MM/yyyy");

        }

        private void dtpFimPeriodo_ValueChanged(object sender, EventArgs e)
        {
            if (dtpInicioPeriodo.Value > dtpFimPeriodo.Value)
            {
                dtpInicioPeriodo.Value = dtpFimPeriodo.Value;
                txtInicioPeriodo.Text = dtpInicioPeriodo.Value.ToString("dd/MM/yyyy");
            }
            else
            {
                txtInicioPeriodo.Text = dtpInicioPeriodo.Value.ToString("dd/MM/yyyy");
            }
            txtFimPeriodo.Text = dtpFimPeriodo.Value.ToString("dd/MM/yyyy");
        }
        #endregion

        private void btnVisualizar_Click(object sender, EventArgs e)
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;
                CultureInfo c = TratamentoLinguagem.BuscarLinguagem("pt-BR");
                dtgWorkFlow.DataSource = DataAccess.BuscarWorkflow(Convert.ToDateTime(dtpInicioPeriodo.Text, c), Convert.ToDateTime(dtpFimPeriodo.Text, c), Convert.ToInt32(cboAnalista.SelectedValue), Convert.ToInt32(cbProduto.SelectedValue), chkServConcluido.Checked, chkServCancelado.Checked);
            }
            catch (Exception exp)
            {
                MessageBox.Show("Erro: " + exp.Message);
            }        
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        #region [ Indicadores ]
        private void btnExcel_Click(object sender, EventArgs e)
        {
        // Inicio
            DataTable dt = DataAccess.BuscarWorkflowDT(Convert.ToDateTime(dtpInicioPeriodo.Text), Convert.ToDateTime(dtpFimPeriodo.Text), SharedData.User.ID_Area, Convert.ToInt32(cboAnalista.SelectedValue), Convert.ToInt32(cbProduto.SelectedValue), chkServConcluido.Checked, chkServCancelado.Checked);                  
                if ((dt != null) && (dt.Rows.Count > 0))
                {
                    if (this.saveFileDialog.ShowDialog() == DialogResult.OK)
                    {

                        var lines = new List<string>();
                        StringBuilder sb = new StringBuilder();
                        IEnumerable<string> columnNames = dt.Columns.Cast<DataColumn>().
                                                          Select(column => column.ColumnName);

                        sb.AppendLine(string.Join(";", columnNames));

                        foreach (DataRow row in dt.Rows)
                        {
                            IEnumerable<string> fields = row.ItemArray.Select(field => field.ToString());
                            sb.AppendLine(string.Join(";", fields));
                        }

                        File.WriteAllText(this.saveFileDialog.FileName, sb.ToString(), Encoding.Default);

                        MessageBox.Show("Relatório gerado com sucesso", "Relatórios", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Não há dados para geração do relatório com os parãmetros especificados.", "Relatórios", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
        // Fim
        }

        private void btnProcessarIndicadores_Click(object sender, EventArgs e)
        {
            // Processar arquivos para gerar indicadores
            this.Cursor = Cursors.WaitCursor;
            TratarEventos.ProcessDirectory(TratarEventos.BuscaPathIndicadores());
            this.Cursor = Cursors.Default;
            MessageBox.Show("Processamento terminado.");
        }

        private void btnVisualizarIndicadores_Click(object sender, EventArgs e)
        {
            // Processar arquivos para gerar indicadores
            this.Cursor = Cursors.WaitCursor;

            // Gera Excel Geral para criação dos indicadores
            DateTime dtInicio = Convert.ToDateTime(dtpInicioPeriodo.Text);
            DateTime dtFim = Convert.ToDateTime(dtpFimPeriodo.Text);
            
            // Inicio
            DataTable dt = DataAccess.Listagem(0, dtInicio, dtFim);
            if ((dt != null) && (dt.Rows.Count > 0))
            {
                if (this.saveFileDialog.ShowDialog() == DialogResult.OK)
                {

                    var lines = new List<string>();
                    StringBuilder sb = new StringBuilder();
                    IEnumerable<string> columnNames = dt.Columns.Cast<DataColumn>().
                                                      Select(column => column.ColumnName);

                    sb.AppendLine(string.Join(";", columnNames));

                    foreach (DataRow row in dt.Rows)
                    {
                        IEnumerable<string> fields = row.ItemArray.Select(field => field.ToString());
                        sb.AppendLine(string.Join(";", fields));
                    }

                    File.WriteAllText(this.saveFileDialog.FileName, sb.ToString(), Encoding.Default);

                    MessageBox.Show("Relatório gerado com sucesso", "Relatórios", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Não há dados para geração do relatório com os parãmetros especificados.", "Relatórios", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            // Fim

            this.Cursor = Cursors.Default;
        }
        #endregion

    }
}
